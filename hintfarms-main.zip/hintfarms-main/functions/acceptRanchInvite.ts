import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        console.log('=== Accept Ranch Invite Request Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            console.error('No authenticated user found');
            return Response.json({ 
                error: 'unauthorized',
                message: 'You must be logged in to accept an invitation.' 
            }, { status: 401 });
        }

        console.log('User authenticated:', user.email);

        const { token } = await req.json();
        
        if (!token) {
            console.error('No token provided');
            return Response.json({ 
                error: 'invalid',
                message: 'No invitation token provided.' 
            }, { status: 400 });
        }

        console.log('Processing invite token:', token);

        // Fetch the invitation
        const invites = await base44.entities.RanchInvite.filter({ invite_token: token });
        const invite = invites[0];

        if (!invite) {
            console.error('Invite not found for token:', token);
            return Response.json({ 
                error: 'invalid',
                message: 'Invalid invitation link.' 
            }, { status: 404 });
        }

        console.log('Invite found:', {
            ranch_id: invite.ranch_id,
            ranch_name: invite.ranch_name,
            invited_email: invite.invited_email,
            status: invite.status
        });

        // Check if invite has already been used
        if (invite.status === 'Accepted') {
            console.error('Invite already accepted');
            return Response.json({ 
                error: 'used',
                message: 'This invitation has already been accepted.' 
            }, { status: 400 });
        }

        // Check if invite has expired
        if (invite.expires_at && new Date(invite.expires_at) < new Date()) {
            console.error('Invite expired:', invite.expires_at);
            return Response.json({ 
                error: 'expired',
                message: 'This invitation has expired.' 
            }, { status: 400 });
        }

        // CRITICAL: Case-insensitive email matching
        const userEmail = user.email.toLowerCase();
        const invitedEmail = invite.invited_email.toLowerCase();

        console.log('Email comparison:', {
            userEmail,
            invitedEmail,
            match: userEmail === invitedEmail
        });

        if (userEmail !== invitedEmail) {
            console.error('Email mismatch:', { userEmail, invitedEmail });
            return Response.json({ 
                error: 'email_mismatch',
                message: `This invitation was sent to ${invite.invited_email}. Please sign in with that email address.`,
                invited_email: invite.invited_email
            }, { status: 403 });
        }

        // Check if user is already a member of this ranch
        const existingMembers = await base44.entities.RanchMember.filter({
            ranch_id: invite.ranch_id
        });
        
        const existingMember = existingMembers.find(m => 
            m.user_email.toLowerCase() === userEmail && m.status === 'Active'
        );

        if (existingMember) {
            console.log('User is already an active member, updating invite status and setting active ranch');
            
            // Update invite to accepted
            await base44.asServiceRole.entities.RanchInvite.update(invite.id, {
                status: 'Accepted',
                accepted_at: new Date().toISOString()
            });

            // Set as active ranch
            await base44.auth.updateMe({
                active_ranch_id: invite.ranch_id
            });

            return Response.json({
                success: true,
                ranch_id: invite.ranch_id,
                ranch_name: invite.ranch_name,
                message: 'Ranch set as active.'
            });
        }

        console.log('Creating new RanchMember...');

        // Create RanchMember entry with LOWERCASE email
        const newMember = await base44.asServiceRole.entities.RanchMember.create({
            ranch_id: invite.ranch_id,
            user_email: userEmail, // Use lowercase
            user_name: user.full_name || user.email.split('@')[0],
            role: invite.role,
            status: 'Active',
            joined_date: new Date().toISOString().split('T')[0],
            invited_by: invite.invited_by_email
        });

        console.log('RanchMember created:', newMember.id);

        // Update invite status
        await base44.asServiceRole.entities.RanchInvite.update(invite.id, {
            status: 'Accepted',
            accepted_at: new Date().toISOString()
        });

        console.log('Invite status updated to Accepted');

        // Set the newly joined ranch as the active ranch
        await base44.auth.updateMe({
            active_ranch_id: invite.ranch_id
        });

        console.log('User active_ranch_id updated to:', invite.ranch_id);

        return Response.json({
            success: true,
            ranch_id: invite.ranch_id,
            ranch_name: invite.ranch_name,
            role: invite.role,
            message: 'Invitation accepted successfully!'
        });

    } catch (error) {
        console.error('=== Accept Ranch Invite Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        
        return Response.json({ 
            error: 'server_error',
            message: `Failed to accept invitation: ${error.message}` 
        }, { status: 500 });
    }
});