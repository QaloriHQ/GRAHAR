import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { ranch_id } = await req.json();

    if (!ranch_id) {
      return Response.json({ error: 'ranch_id required' }, { status: 400 });
    }

    const suggestions = [];

    // Analyze expense patterns
    const expensePatterns = await analyzeExpensePatterns(base44, ranch_id);
    suggestions.push(...expensePatterns);

    // Analyze health patterns
    const healthSuggestions = await analyzeHealthData(base44, ranch_id);
    suggestions.push(...healthSuggestions);

    // Analyze breeding cycles
    const breedingSuggestions = await analyzeBreedingCycles(base44, ranch_id);
    suggestions.push(...breedingSuggestions);

    // Analyze pasture rotation
    const pastureSuggestions = await analyzePastureRotation(base44, ranch_id);
    suggestions.push(...pastureSuggestions);

    // Sort by priority
    suggestions.sort((a, b) => {
      const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    return Response.json({ suggestions: suggestions.slice(0, 10) });
  } catch (error) {
    console.error('Pattern analysis error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function analyzeExpensePatterns(base44, ranchId) {
  const suggestions = [];
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  
  const expenses = await base44.asServiceRole.entities.Expense.filter({ 
    ranch_id: ranchId 
  });

  // Group by category and animal
  const patterns = {};
  
  for (const expense of expenses) {
    const expenseDate = new Date(expense.date);
    if (expenseDate < thirtyDaysAgo) continue;
    
    const key = `${expense.category}_${expense.animal_id || 'general'}`;
    
    if (!patterns[key]) {
      patterns[key] = {
        category: expense.category,
        animal_id: expense.animal_id,
        animal_name: expense.animal_name,
        count: 0,
        total: 0,
        dates: []
      };
    }
    
    patterns[key].count++;
    patterns[key].total += expense.amount || 0;
    patterns[key].dates.push(expenseDate);
  }

  // Detect recurring patterns (3+ occurrences in 30 days)
  for (const [key, pattern] of Object.entries(patterns)) {
    if (pattern.count >= 3) {
      // Calculate average interval
      const sortedDates = pattern.dates.sort((a, b) => a - b);
      const intervals = [];
      for (let i = 1; i < sortedDates.length; i++) {
        intervals.push((sortedDates[i] - sortedDates[i-1]) / (24 * 60 * 60 * 1000));
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      
      // Suggest recurring task if pattern is consistent
      if (avgInterval >= 5 && avgInterval <= 10) {
        suggestions.push({
          type: 'recurring_task',
          priority: 'medium',
          title: `Create recurring task for ${pattern.category}`,
          description: `You've logged ${pattern.count} ${pattern.category} expenses in the past 30 days${pattern.animal_name ? ` for ${pattern.animal_name}` : ''}. Consider creating a recurring task to track this regularly.`,
          action: {
            task_title: `${pattern.category} for ${pattern.animal_name || 'livestock'}`,
            frequency: Math.round(avgInterval),
            category: pattern.category,
            animal_id: pattern.animal_id,
            animal_name: pattern.animal_name
          }
        });
      }
    }
  }

  return suggestions;
}

async function analyzeHealthData(base44, ranchId) {
  const suggestions = [];
  const now = new Date();
  
  const animals = await base44.asServiceRole.entities.Animal.filter({ 
    ranch_id: ranchId 
  });
  
  const healthRecords = await base44.asServiceRole.entities.HealthRecord.filter({ 
    ranch_id: ranchId 
  });

  for (const animal of animals) {
    const animalRecords = healthRecords.filter(r => r.animal_id === animal.id);
    
    // Check for overdue vaccinations (last vaccination > 6 months)
    const vaccinations = animalRecords
      .filter(r => r.record_type === 'Vaccination')
      .sort((a, b) => new Date(b.date) - new Date(a.date));
    
    if (vaccinations.length > 0) {
      const lastVaccination = new Date(vaccinations[0].date);
      const daysSince = (now - lastVaccination) / (24 * 60 * 60 * 1000);
      
      if (daysSince > 180) {
        suggestions.push({
          type: 'health_alert',
          priority: 'high',
          title: `Vaccination overdue for #${animal.tag_number}`,
          description: `${animal.name || animal.tag_number} hasn't been vaccinated in ${Math.floor(daysSince)} days. Last vaccination was on ${lastVaccination.toLocaleDateString()}.`,
          action: {
            animal_id: animal.id,
            animal_name: animal.name || animal.tag_number,
            record_type: 'Vaccination',
            suggested_date: now.toISOString().split('T')[0]
          }
        });
      }
    } else {
      // No vaccination history
      suggestions.push({
        type: 'health_alert',
        priority: 'medium',
        title: `No vaccination records for #${animal.tag_number}`,
        description: `Consider scheduling a vaccination for ${animal.name || animal.tag_number}.`,
        action: {
          animal_id: animal.id,
          animal_name: animal.name || animal.tag_number,
          record_type: 'Vaccination',
          suggested_date: now.toISOString().split('T')[0]
        }
      });
    }

    // Check for ongoing treatments
    const recentTreatments = animalRecords
      .filter(r => r.record_type === 'Treatment' && r.status !== 'Completed')
      .sort((a, b) => new Date(b.date) - new Date(a.date));
    
    if (recentTreatments.length > 0 && animal.health_status === 'Under Treatment') {
      const treatment = recentTreatments[0];
      const treatmentDate = new Date(treatment.date);
      const daysSince = (now - treatmentDate) / (24 * 60 * 60 * 1000);
      
      if (daysSince > 7) {
        suggestions.push({
          type: 'health_followup',
          priority: 'high',
          title: `Follow-up needed for #${animal.tag_number}`,
          description: `${animal.name || animal.tag_number} has been under treatment for ${Math.floor(daysSince)} days. Consider scheduling a checkup.`,
          action: {
            animal_id: animal.id,
            animal_name: animal.name || animal.tag_number,
            record_type: 'Checkup',
            suggested_date: now.toISOString().split('T')[0]
          }
        });
      }
    }
  }

  return suggestions;
}

async function analyzeBreedingCycles(base44, ranchId) {
  const suggestions = [];
  const now = new Date();
  
  const breedingRecords = await base44.asServiceRole.entities.BreedingRecord.filter({ 
    ranch_id: ranchId 
  });

  for (const record of breedingRecords) {
    if (record.status === 'Pregnant' && record.expected_calving_date) {
      const expectedDate = new Date(record.expected_calving_date);
      const daysUntil = (expectedDate - now) / (24 * 60 * 60 * 1000);
      
      // Alert 30 days before calving
      if (daysUntil > 0 && daysUntil <= 35 && daysUntil >= 25) {
        suggestions.push({
          type: 'breeding_alert',
          priority: 'high',
          title: `Calving approaching for #${record.animal_id}`,
          description: `${record.animal_name} is expected to calve in approximately ${Math.floor(daysUntil)} days on ${expectedDate.toLocaleDateString()}.`,
          action: {
            animal_id: record.animal_id,
            animal_name: record.animal_name,
            task_title: `Prepare for calving - ${record.animal_name}`,
            due_date: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
          }
        });
      }
    }
  }

  return suggestions;
}

async function analyzePastureRotation(base44, ranchId) {
  const suggestions = [];
  const now = new Date();
  
  const pastures = await base44.asServiceRole.entities.Pasture.filter({ 
    ranch_id: ranchId 
  });

  for (const pasture of pastures) {
    // Check for overgrazing
    if (pasture.capacity && pasture.current_animal_count > pasture.capacity) {
      const overstocking = ((pasture.current_animal_count - pasture.capacity) / pasture.capacity * 100).toFixed(0);
      
      suggestions.push({
        type: 'pasture_alert',
        priority: 'urgent',
        title: `Overstocked: ~${pasture.name}`,
        description: `${pasture.name} is ${overstocking}% over capacity with ${pasture.current_animal_count} animals (capacity: ${pasture.capacity}).`,
        action: {
          pasture_id: pasture.id,
          pasture_name: pasture.name,
          task_title: `Rotate animals from ${pasture.name}`,
          due_date: now.toISOString().split('T')[0]
        }
      });
    }

    // Check for rotation reminders
    if (pasture.last_rotation_date) {
      const lastRotation = new Date(pasture.last_rotation_date);
      const daysSince = (now - lastRotation) / (24 * 60 * 60 * 1000);
      
      if (daysSince > 30) {
        suggestions.push({
          type: 'pasture_rotation',
          priority: 'medium',
          title: `Rotation overdue: ~${pasture.name}`,
          description: `${pasture.name} hasn't been rotated in ${Math.floor(daysSince)} days.`,
          action: {
            pasture_id: pasture.id,
            pasture_name: pasture.name,
            task_title: `Rotate animals in ${pasture.name}`,
            due_date: now.toISOString().split('T')[0]
          }
        });
      }
    }
  }

  return suggestions;
}