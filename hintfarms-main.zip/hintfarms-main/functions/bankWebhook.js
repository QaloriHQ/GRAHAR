import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
    try {
        const signature = req.headers.get('stripe-signature');
        const body = await req.text();

        if (!signature) {
            return Response.json({ error: 'No signature' }, { status: 400 });
        }

        const base44 = createClientFromRequest(req);
        
        // Verify webhook signature
        let event;
        try {
            event = await stripe.webhooks.constructEventAsync(
                body,
                signature,
                webhookSecret
            );
        } catch (err) {
            console.error('Webhook signature verification failed:', err.message);
            return Response.json({ error: 'Invalid signature' }, { status: 400 });
        }

        console.log('=== Bank Webhook Event:', event.type, '===');

        switch (event.type) {
            case 'financial_connections.account.created': {
                const account = event.data.object;
                console.log('New FC account created:', account.id);
                console.log('Institution:', account.institution_name);
                console.log('Customer:', account.account_holder.customer);
                
                // Retrieve full account details to get balance
                const fullAccount = await stripe.financialConnections.accounts.retrieve(account.id);
                console.log('Account balance:', fullAccount.balance);
                
                // Find ranch by customer ID
                const ranches = await base44.asServiceRole.entities.Ranch.filter({
                    stripe_customer_id: account.account_holder.customer
                });

                if (ranches.length === 0) {
                    console.error('No ranch found for customer:', account.account_holder.customer);
                    return Response.json({ error: 'Ranch not found' }, { status: 404 });
                }

                const ranch = ranches[0];
                console.log('Found ranch:', ranch.name, '(ID:', ranch.id, ')');

                // Check if connection already exists
                const existing = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                // Convert balance from cents to dollars
                const balanceInDollars = fullAccount.balance?.current 
                    ? fullAccount.balance.current / 100 
                    : 0;

                console.log(`Balance: $${balanceInDollars} ${fullAccount.balance?.currency || 'usd'}`);

                if (existing.length > 0) {
                    console.log('Connection already exists, updating...');
                    await base44.asServiceRole.entities.BankConnection.update(existing[0].id, {
                        status: 'active',
                        institution_name: account.institution_name,
                        account_last4: account.last4 || null,
                        account_type: account.subcategory || 'checking',
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        data_scopes: account.permissions || [],
                        sync_enabled: true,
                        last_sync_at: new Date().toISOString()
                    });
                    console.log('Updated existing connection:', existing[0].id);
                    
                    // Trigger transaction sync
                    try {
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: existing[0].id
                        });
                        console.log('Triggered transaction sync');
                    } catch (syncError) {
                        console.error('Failed to trigger sync:', syncError);
                    }
                } else {
                    // Create new connection
                    console.log('Creating new BankConnection record...');
                    const connection = await base44.asServiceRole.entities.BankConnection.create({
                        ranch_id: ranch.id,
                        stripe_customer_id: account.account_holder.customer,
                        stripe_fincon_account_id: account.id,
                        institution_name: account.institution_name,
                        account_last4: account.last4 || null,
                        account_type: account.subcategory || 'checking',
                        status: 'active',
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        data_scopes: account.permissions || [],
                        sync_enabled: true,
                        last_sync_at: new Date().toISOString()
                    });
                    
                    console.log('✅ Created BankConnection:', connection.id);
                    console.log('   - Institution:', connection.institution_name);
                    console.log('   - Account:', connection.account_type, '****', connection.account_last4);
                    console.log('   - Balance: $', balanceInDollars);
                    console.log('   - Ranch:', ranch.name);

                    // Trigger initial transaction sync
                    try {
                        console.log('Triggering initial transaction sync...');
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: connection.id
                        });
                        console.log('✅ Transaction sync completed');
                    } catch (syncError) {
                        console.error('❌ Failed to sync transactions:', syncError.message);
                    }
                }
                
                break;
            }

            case 'financial_connections.account.disconnected': {
                const account = event.data.object;
                console.log('FC account disconnected:', account.id);
                
                // Update connection status
                const connections = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                if (connections.length > 0) {
                    await base44.asServiceRole.entities.BankConnection.update(connections[0].id, {
                        status: 'disconnected',
                        sync_enabled: false
                    });
                    console.log('✅ Connection marked as disconnected:', connections[0].id);
                }
                break;
            }

            case 'financial_connections.account.refreshed_balance':
            case 'financial_connections.account.refreshed_transactions': {
                const account = event.data.object;
                console.log('FC account refreshed:', account.id);
                
                // Retrieve full account details to get updated balance
                const fullAccount = await stripe.financialConnections.accounts.retrieve(account.id);
                
                // Find and sync connection
                const connections = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                if (connections.length > 0) {
                    const connection = connections[0];
                    
                    // Update balance
                    const balanceInDollars = fullAccount.balance?.current 
                        ? fullAccount.balance.current / 100 
                        : 0;

                    await base44.asServiceRole.entities.BankConnection.update(connection.id, {
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        last_sync_at: new Date().toISOString()
                    });
                    console.log(`✅ Updated balance: $${balanceInDollars}`);

                    // Trigger transaction sync
                    try {
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: connection.id
                        });
                        console.log('✅ Transactions synced after refresh');
                    } catch (syncError) {
                        console.error('❌ Failed to sync after refresh:', syncError);
                    }
                }
                break;
            }

            default:
                console.log(`Unhandled event type: ${event.type}`);
        }

        return Response.json({ received: true });

    } catch (error) {
        console.error('=== Bank Webhook Error ===');
        console.error('Error:', error.message);
        console.error('Stack:', error.stack);
        return Response.json({ error: error.message }, { status: 500 });
    }
});