import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
    try {
        const signature = req.headers.get('stripe-signature');
        const body = await req.text();

        if (!signature) {
            return Response.json({ error: 'No signature' }, { status: 400 });
        }

        const base44 = createClientFromRequest(req);
        
        // Verify webhook signature
        let event;
        try {
            event = await stripe.webhooks.constructEventAsync(
                body,
                signature,
                webhookSecret
            );
        } catch (err) {
            console.error('Webhook signature verification failed:', err.message);
            return Response.json({ error: 'Invalid signature' }, { status: 400 });
        }

        console.log('=== Bank Webhook Event:', event.type, '===');

        // Generate unique sync run ID for this webhook event
        const bank_sync_id = crypto.randomUUID();
        console.log('📊 Webhook sync run ID:', bank_sync_id);

        switch (event.type) {
            case 'financial_connections.account.created': {
                const account = event.data.object;
                console.log(`[sync_id:${bank_sync_id}] New FC account created:`, account.id);
                console.log(`[sync_id:${bank_sync_id}] Institution:`, account.institution_name);
                console.log(`[sync_id:${bank_sync_id}] Customer:`, account.account_holder.customer);
                
                // Retrieve full account details to get balance
                const fullAccount = await stripe.financialConnections.accounts.retrieve(account.id);
                console.log(`[sync_id:${bank_sync_id}] Account balance:`, fullAccount.balance);
                
                // Find ranch by customer ID - this establishes our locked ranch context
                const ranches = await base44.asServiceRole.entities.Ranch.filter({
                    stripe_customer_id: account.account_holder.customer
                });

                if (ranches.length === 0) {
                    console.error(`[sync_id:${bank_sync_id}] No ranch found for customer:`, account.account_holder.customer);
                    return Response.json({ error: 'Ranch not found' }, { status: 404 });
                }

                const ranch = ranches[0];
                // 🔒 LOCK RANCH CONTEXT from the webhook payload
                const RANCH_ID = ranch.id;
                console.log(`[sync_id:${bank_sync_id}] 🔒 Locked ranch context:`, RANCH_ID, '(', ranch.name, ')');

                // Check if connection already exists
                const existing = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id,
                    ranch_id: RANCH_ID  // 🔒 Security: ensure connection belongs to this ranch
                });

                // Convert balance from cents to dollars
                const balanceInDollars = fullAccount.balance?.current 
                    ? fullAccount.balance.current / 100 
                    : 0;

                console.log(`[sync_id:${bank_sync_id}] Balance: $${balanceInDollars} ${fullAccount.balance?.currency || 'usd'}`);

                if (existing.length > 0) {
                    console.log(`[sync_id:${bank_sync_id}] Connection already exists, updating...`);
                    await base44.asServiceRole.entities.BankConnection.update(existing[0].id, {
                        status: 'active',
                        institution_name: account.institution_name,
                        account_last4: account.last4 || null,
                        account_type: account.subcategory || 'checking',
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        data_scopes: account.permissions || [],
                        sync_enabled: true,
                        last_sync_at: new Date().toISOString(),
                        last_sync_run_id: bank_sync_id  // 📊 Track sync run
                    });
                    console.log(`[sync_id:${bank_sync_id}] Updated existing connection:`, existing[0].id);
                    
                    // Trigger transaction sync with locked context
                    try {
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: existing[0].id,
                            ranch_id: RANCH_ID,  // 🔒 Pass locked ranch ID explicitly
                            bank_sync_id  // 📊 Pass sync run ID
                        });
                        console.log(`[sync_id:${bank_sync_id}] Triggered transaction sync`);
                    } catch (syncError) {
                        console.error(`[sync_id:${bank_sync_id}] Failed to trigger sync:`, syncError);
                    }
                } else {
                    // Create new connection with locked ranch ID
                    console.log(`[sync_id:${bank_sync_id}] Creating new BankConnection record...`);
                    const connection = await base44.asServiceRole.entities.BankConnection.create({
                        ranch_id: RANCH_ID,  // 🔒 Use locked ranch ID
                        stripe_customer_id: account.account_holder.customer,
                        stripe_fincon_account_id: account.id,
                        institution_name: account.institution_name,
                        account_last4: account.last4 || null,
                        account_type: account.subcategory || 'checking',
                        status: 'active',
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        data_scopes: account.permissions || [],
                        sync_enabled: true,
                        last_sync_at: new Date().toISOString(),
                        last_sync_run_id: bank_sync_id  // 📊 Track sync run
                    });
                    
                    console.log(`[sync_id:${bank_sync_id}] ✅ Created BankConnection:`, connection.id);
                    console.log(`[sync_id:${bank_sync_id}]    - Institution:`, connection.institution_name);
                    console.log(`[sync_id:${bank_sync_id}]    - Account:`, connection.account_type, '****', connection.account_last4);
                    console.log(`[sync_id:${bank_sync_id}]    - Balance: $`, balanceInDollars);
                    console.log(`[sync_id:${bank_sync_id}]    - Ranch:`, ranch.name);

                    // Trigger initial transaction sync with locked context (with delay to allow Stripe to populate data)
                    try {
                        console.log(`[sync_id:${bank_sync_id}] Waiting 3 seconds before initial sync...`);
                        await new Promise(resolve => setTimeout(resolve, 3000));
                        
                        console.log(`[sync_id:${bank_sync_id}] Triggering initial transaction sync...`);
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: connection.id,
                            ranch_id: RANCH_ID,  // 🔒 Pass locked ranch ID explicitly
                            bank_sync_id  // 📊 Pass sync run ID
                        });
                        console.log(`[sync_id:${bank_sync_id}] ✅ Transaction sync completed`);
                    } catch (syncError) {
                        console.error(`[sync_id:${bank_sync_id}] ❌ Failed to sync transactions:`, syncError.message);
                    }
                }
                
                break;
            }

            case 'financial_connections.account.disconnected': {
                const account = event.data.object;
                console.log(`[sync_id:${bank_sync_id}] FC account disconnected:`, account.id);
                
                // Update connection status (no ranch_id needed for status update)
                const connections = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                if (connections.length > 0) {
                    await base44.asServiceRole.entities.BankConnection.update(connections[0].id, {
                        status: 'disconnected',
                        sync_enabled: false,
                        last_sync_run_id: bank_sync_id  // 📊 Track sync run
                    });
                    console.log(`[sync_id:${bank_sync_id}] ✅ Connection marked as disconnected:`, connections[0].id);
                }
                break;
            }

            case 'financial_connections.account.refreshed_balance':
            case 'financial_connections.account.refreshed_transactions': {
                const account = event.data.object;
                console.log(`[sync_id:${bank_sync_id}] FC account refreshed:`, account.id);
                
                // Retrieve full account details to get updated balance
                const fullAccount = await stripe.financialConnections.accounts.retrieve(account.id);
                
                // Find and sync connection
                const connections = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                if (connections.length > 0) {
                    const connection = connections[0];
                    // 🔒 Use the connection's ranch_id as our locked context
                    const RANCH_ID = connection.ranch_id;
                    console.log(`[sync_id:${bank_sync_id}] 🔒 Locked ranch context from connection:`, RANCH_ID);
                    
                    // Update balance
                    const balanceInDollars = fullAccount.balance?.current 
                        ? fullAccount.balance.current / 100 
                        : 0;

                    await base44.asServiceRole.entities.BankConnection.update(connection.id, {
                        balance: balanceInDollars,
                        currency: fullAccount.balance?.currency || 'usd',
                        last_sync_at: new Date().toISOString(),
                        last_sync_run_id: bank_sync_id  // 📊 Track sync run
                    });
                    console.log(`[sync_id:${bank_sync_id}] ✅ Updated balance: $${balanceInDollars}`);

                    // Trigger transaction sync with locked context
                    try {
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: connection.id,
                            ranch_id: RANCH_ID,  // 🔒 Pass locked ranch ID explicitly
                            bank_sync_id  // 📊 Pass sync run ID
                        });
                        console.log(`[sync_id:${bank_sync_id}] ✅ Transactions synced after refresh`);
                    } catch (syncError) {
                        console.error(`[sync_id:${bank_sync_id}] ❌ Failed to sync after refresh:`, syncError);
                    }
                }
                break;
            }

            default:
                console.log(`[sync_id:${bank_sync_id}] Unhandled event type: ${event.type}`);
        }

        return Response.json({ received: true, sync_run_id: bank_sync_id });

    } catch (error) {
        console.error('=== Bank Webhook Error ===');
        console.error('Error:', error.message);
        console.error('Stack:', error.stack);
        return Response.json({ error: error.message }, { status: 500 });
    }
});