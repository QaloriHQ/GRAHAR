
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});

// Price ID mapping
const PRICE_IDS = {
  'pro': Deno.env.get('STRIPE_PRO_PRICE_ID'),
  'enterprise': Deno.env.get('STRIPE_ENTERPRISE_PRICE_ID')
};

Deno.serve(async (req) => {
    try {
        console.log('=== Checkout Session Request Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            console.error('No authenticated user found');
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log('User authenticated:', user.email);

        const body = await req.json();
        const { priceId, planName } = body;

        console.log('Request body:', { priceId, planName });

        if (!priceId || !planName) {
            console.error('Missing required parameters:', { priceId, planName });
            return Response.json({ error: 'Price ID and plan name are required' }, { status: 400 });
        }

        // Get the actual Stripe price ID from environment
        const stripePriceId = PRICE_IDS[priceId.toLowerCase()];
        
        console.log('Mapping price ID:', priceId, '→', stripePriceId);

        if (!stripePriceId) {
            console.error('Invalid or missing price ID mapping for:', priceId);
            console.error('Available mappings:', Object.keys(PRICE_IDS));
            console.error('Environment variables:', {
                STRIPE_PRO_PRICE_ID: Deno.env.get('STRIPE_PRO_PRICE_ID') ? 'Set' : 'Not set',
                STRIPE_ENTERPRISE_PRICE_ID: Deno.env.get('STRIPE_ENTERPRISE_PRICE_ID') ? 'Set' : 'Not set'
            });
            return Response.json({ 
                error: `Payment configuration error. The ${planName} plan price is not configured. Please contact support to set up billing.` 
            }, { status: 500 });
        }

        // Validate that the price ID looks like a valid Stripe price ID
        if (!stripePriceId.startsWith('price_')) {
            console.error('Invalid Stripe price ID format:', stripePriceId);
            console.error('Expected format: price_xxxxx, but got:', stripePriceId);
            return Response.json({ 
                error: `Payment configuration error. The price ID for ${planName} is incorrectly configured (received: ${stripePriceId}). Please contact support. Stripe price IDs should start with 'price_'.` 
            }, { status: 500 });
        }

        // Verify Stripe API key is set
        const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
        if (!stripeKey) {
            console.error('STRIPE_SECRET_KEY not configured');
            return Response.json({ 
                error: 'Payment system not configured. Please contact support.' 
            }, { status: 500 });
        }

        // Validate Stripe key format
        if (!stripeKey.startsWith('sk_test_') && !stripeKey.startsWith('sk_live_')) {
            console.error('Invalid Stripe API key format');
            return Response.json({ 
                error: 'Payment system misconfigured. Please contact support.' 
            }, { status: 500 });
        }

        // Get ranch
        console.log('Fetching ranch for user. Ranch ID:', user.ranch_id);
        
        if (!user.ranch_id) {
            console.error('User does not have a ranch_id set');
            return Response.json({ 
                error: 'No ranch found for your account. Please complete the onboarding process or contact support to set up your ranch.' 
            }, { status: 404 });
        }

        let ranches;
        try {
            ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
            console.log('Ranch query result:', ranches);
        } catch (queryError) {
            console.error('Failed to query ranch:', queryError);
            return Response.json({ 
                error: `Database error while looking up ranch: ${queryError.message}. Please contact support.` 
            }, { status: 500 });
        }

        const ranch = ranches?.[0];

        if (!ranch) {
            console.error('Ranch not found for ID:', user.ranch_id);
            console.error('User email:', user.email);
            console.error('Available ranches:', ranches);
            return Response.json({ 
                error: `Your ranch (ID: ${user.ranch_id}) was not found in our system. This may happen if your account setup was incomplete. Please contact support or complete the onboarding process again.` 
            }, { status: 404 });
        }

        console.log('Ranch found:', { 
            id: ranch.id, 
            name: ranch.name,
            owner: ranch.owner_email,
            has_stripe_customer: !!ranch.stripe_customer_id 
        });

        // Create or get Stripe customer
        let customerId = ranch.stripe_customer_id;

        if (!customerId) {
            console.log('Creating new Stripe customer...');
            try {
                const customer = await stripe.customers.create({
                    email: user.email,
                    name: user.full_name,
                    metadata: {
                        ranch_id: ranch.id,
                        ranch_name: ranch.name,
                        user_id: user.id
                    }
                });
                customerId = customer.id;
                console.log('Stripe customer created:', customerId);

                // Validate customer ID format
                if (!customerId.startsWith('cus_')) {
                    console.error('Unexpected customer ID format:', customerId);
                    return Response.json({ 
                        error: 'Payment customer creation returned unexpected format. Please try again.' 
                    }, { status: 500 });
                }

                // Update ranch with customer ID using service role
                await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                    stripe_customer_id: customerId
                });
                console.log('Ranch updated with Stripe customer ID');
            } catch (stripeError) {
                console.error('Failed to create Stripe customer:', stripeError);
                console.error('Stripe error details:', {
                    type: stripeError.type,
                    code: stripeError.code,
                    message: stripeError.message
                });
                return Response.json({ 
                    error: `Failed to create payment customer: ${stripeError.message}. Please try again or contact support.` 
                }, { status: 500 });
            }
        } else {
            console.log('Using existing Stripe customer:', customerId);
            
            // Validate existing customer ID format
            if (!customerId.startsWith('cus_')) {
                console.error('Invalid stored customer ID format:', customerId);
                console.error('This customer ID needs to be reset. Attempting to create new customer...');
                
                // Customer ID is invalid, create a new one
                try {
                    const customer = await stripe.customers.create({
                        email: user.email,
                        name: user.full_name,
                        metadata: {
                            ranch_id: ranch.id,
                            ranch_name: ranch.name,
                            user_id: user.id
                        }
                    });
                    customerId = customer.id;
                    console.log('New Stripe customer created:', customerId);

                    await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                        stripe_customer_id: customerId
                    });
                    console.log('Ranch updated with new Stripe customer ID');
                } catch (stripeError) {
                    console.error('Failed to recover from invalid customer ID:', stripeError);
                    return Response.json({ 
                        error: 'Payment customer configuration error. Please contact support to reset your billing information.' 
                    }, { status: 500 });
                }
            }
        }

        // Get the app URL from the request
        const url = new URL(req.url);
        const origin = url.origin;

        console.log('Creating checkout session with:', {
            customerId,
            priceId: stripePriceId,
            origin,
            metadata: {
                ranch_id: ranch.id,
                plan_name: planName,
                user_id: user.id
            }
        });

        // Create checkout session
        try {
            const session = await stripe.checkout.sessions.create({
                customer: customerId,
                mode: 'subscription',
                line_items: [
                    {
                        price: stripePriceId,
                        quantity: 1,
                    },
                ],
                success_url: `${origin}/Dashboard?session_id={CHECKOUT_SESSION_ID}&success=true`,
                cancel_url: `${origin}/Dashboard?canceled=true`,
                metadata: {
                    ranch_id: ranch.id,
                    plan_name: planName,
                    user_id: user.id
                },
                allow_promotion_codes: true,
                billing_address_collection: 'auto',
            });

            console.log('Checkout session created successfully:', session.id);
            console.log('Session URL:', session.url);

            return Response.json({ 
                sessionId: session.id,
                url: session.url 
            });

        } catch (stripeError) {
            console.error('Stripe checkout session creation failed:', stripeError);
            console.error('Stripe error details:', {
                type: stripeError.type,
                code: stripeError.code,
                message: stripeError.message,
                param: stripeError.param
            });
            
            // Provide specific error messages based on the error type
            let userMessage = 'Payment setup failed. Please try again or contact support.';
            
            if (stripeError.code === 'resource_missing') {
                userMessage = `The ${planName} plan configuration is invalid. Please contact support to set up billing correctly.`;
            } else if (stripeError.param === 'line_items[0][price]') {
                userMessage = `The price for ${planName} plan is incorrectly configured (${stripePriceId}). Please contact support.`;
            } else if (stripeError.param === 'customer') {
                userMessage = `Customer billing setup error. Please contact support to reset your billing information.`;
            }
            
            return Response.json({ 
                error: userMessage
            }, { status: 500 });
        }

    } catch (error) {
        console.error('=== Checkout Session Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return Response.json({ 
            error: `We couldn't start checkout for this ranch. Please refresh and try again, or contact support if the issue continues.` 
        }, { status: 500 });
    }
});
