import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
    try {
        console.log('=== Customer Portal Request Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            console.error('No authenticated user found');
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log('User authenticated:', user.email);

        // Get ranch
        const ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
        const ranch = ranches[0];

        if (!ranch || !ranch.stripe_customer_id) {
            console.error('No Stripe customer found for ranch:', user.ranch_id);
            return Response.json({ error: 'No subscription found. Please subscribe first.' }, { status: 404 });
        }

        console.log('Ranch found with Stripe customer:', ranch.stripe_customer_id);

        // Get the app URL from the request
        const url = new URL(req.url);
        const origin = url.origin;

        console.log('Creating customer portal session...');

        // Create customer portal session
        const session = await stripe.billingPortal.sessions.create({
            customer: ranch.stripe_customer_id,
            return_url: `${origin}/Dashboard`,
        });

        console.log('Portal session created:', session.url);

        return Response.json({ url: session.url });

    } catch (error) {
        console.error('=== Customer Portal Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return Response.json({ 
            error: `Portal access failed: ${error.message || 'Unknown error'}. Please try again or contact support.` 
        }, { status: 500 });
    }
});