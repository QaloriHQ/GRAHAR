import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

Deno.serve(async (req) => {
    try {
        console.log('=== Financial Connections Session Request Started ===');
        
        const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
        if (!stripeKey) {
            console.error('STRIPE_SECRET_KEY not set');
            return Response.json({ 
                error: 'Stripe configuration missing. Please contact support.' 
            }, { status: 500 });
        }

        const stripe = new Stripe(stripeKey, {
            apiVersion: '2023-10-16',
        });

        const base44 = createClientFromRequest(req);
        
        let user;
        try {
            user = await base44.auth.me();
        } catch (authError) {
            console.error('Authentication failed:', authError);
            return Response.json({ error: 'Authentication failed' }, { status: 401 });
        }

        if (!user) {
            console.error('No authenticated user found');
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        console.log('User authenticated:', user.email);

        if (!user.ranch_id) {
            console.error('User has no ranch_id');
            return Response.json({ 
                error: 'No ranch associated with your account. Please complete onboarding or contact support.' 
            }, { status: 400 });
        }

        // Get ranch
        console.log('Fetching ranch with ID:', user.ranch_id);
        let ranch = null;
        
        try {
            const ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
            ranch = ranches[0];
        } catch (ranchError) {
            console.error('Error fetching ranch:', ranchError);
        }

        if (!ranch) {
            console.error('Ranch not found for ID:', user.ranch_id);
            console.log('Attempting to find any ranches owned by this user...');
            
            try {
                const userRanches = await base44.entities.Ranch.filter({ owner_email: user.email });
                if (userRanches.length > 0) {
                    ranch = userRanches[0];
                    console.log('Found ranch owned by user:', ranch.id);
                    await base44.auth.updateMe({ ranch_id: ranch.id });
                    console.log('Updated user ranch_id to:', ranch.id);
                }
            } catch (findError) {
                console.error('Failed to find user ranches:', findError);
            }
        }

        if (!ranch) {
            console.error('No ranch found for user');
            return Response.json({ 
                error: 'No ranch found. Please go to Ranch Settings to create or select a ranch, or contact support.' 
            }, { status: 404 });
        }

        console.log('Ranch found:', ranch.name, 'ID:', ranch.id);

        // Get or create Stripe customer
        let customerId = ranch.stripe_customer_id;

        if (!customerId) {
            console.log('Creating new Stripe customer...');
            try {
                const customer = await stripe.customers.create({
                    email: user.email,
                    name: user.full_name || user.email,
                    metadata: {
                        ranch_id: ranch.id,
                        ranch_name: ranch.name
                    }
                });
                customerId = customer.id;
                console.log('Created Stripe customer:', customerId);
                
                await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                    stripe_customer_id: customerId
                });
                console.log('Updated ranch with customer ID');
            } catch (customerError) {
                console.error('Failed to create Stripe customer:', customerError);
                return Response.json({ 
                    error: `Failed to create payment customer: ${customerError.message}` 
                }, { status: 500 });
            }
        } else {
            console.log('Using existing Stripe customer:', customerId);
        }

        // Create Financial Connections Session with metadata
        console.log('Creating Financial Connections session...');
        try {
            const session = await stripe.financialConnections.sessions.create({
                account_holder: {
                    type: 'customer',
                    customer: customerId,
                },
                permissions: ['balances', 'transactions'],
                filters: {
                    countries: ['US'],
                },
            });

            console.log('Financial Connections session created:', session.id);
            console.log('Client secret exists:', !!session.client_secret);

            // Store session metadata for webhook lookup
            await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                latest_fc_session_id: session.id
            });

            return Response.json({ 
                client_secret: session.client_secret,
                session_id: session.id
            });

        } catch (sessionError) {
            console.error('Failed to create Financial Connections session:', sessionError);
            return Response.json({ 
                error: `Failed to create banking session: ${sessionError.message}` 
            }, { status: 500 });
        }

    } catch (error) {
        console.error('=== Financial Connections Fatal Error ===');
        console.error('Error:', error.message);
        return Response.json({ 
            error: `Unexpected error: ${error.message}` 
        }, { status: 500 });
    }
});