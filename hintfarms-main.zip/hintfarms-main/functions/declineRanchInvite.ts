import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';

Deno.serve(async (req) => {
    try {
        console.log('=== Decline Ranch Invite Request Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            console.error('No authenticated user found');
            return Response.json({ 
                error: 'unauthorized',
                message: 'You must be logged in to decline an invitation.' 
            }, { status: 401 });
        }

        console.log('User authenticated:', user.email);

        const { invite_id } = await req.json();
        
        if (!invite_id) {
            console.error('No invite_id provided');
            return Response.json({ 
                error: 'invalid',
                message: 'No invitation ID provided.' 
            }, { status: 400 });
        }

        console.log('Processing decline for invite ID:', invite_id);

        // Fetch the invitation
        const invites = await base44.asServiceRole.entities.RanchInvite.filter({ id: invite_id });
        const invite = invites[0];

        if (!invite) {
            console.error('Invite not found for ID:', invite_id);
            return Response.json({ 
                error: 'invalid',
                message: 'Invitation not found.' 
            }, { status: 404 });
        }

        console.log('Invite found:', {
            ranch_id: invite.ranch_id,
            ranch_name: invite.ranch_name,
            invited_email: invite.invited_email,
            status: invite.status
        });

        // CRITICAL: Case-insensitive email matching
        const userEmail = user.email.toLowerCase();
        const invitedEmail = invite.invited_email.toLowerCase();

        console.log('Email comparison:', {
            userEmail,
            invitedEmail,
            match: userEmail === invitedEmail
        });

        if (userEmail !== invitedEmail) {
            console.error('Email mismatch:', { userEmail, invitedEmail });
            return Response.json({ 
                error: 'email_mismatch',
                message: `This invitation was sent to ${invite.invited_email}. You cannot decline invitations for other users.`
            }, { status: 403 });
        }

        // Check if invite has already been declined or accepted
        if (invite.status === 'Declined') {
            console.log('Invite already declined');
            return Response.json({ 
                success: true,
                message: 'This invitation has already been declined.',
                already_declined: true
            });
        }

        if (invite.status === 'Accepted') {
            console.error('Cannot decline accepted invite');
            return Response.json({ 
                error: 'already_accepted',
                message: 'This invitation has already been accepted and cannot be declined.' 
            }, { status: 400 });
        }

        console.log('Declining invite...');

        // Update invite status to Declined
        await base44.asServiceRole.entities.RanchInvite.update(invite.id, {
            status: 'Declined',
            declined_at: new Date().toISOString()
        });

        console.log('Invite declined successfully');

        return Response.json({
            success: true,
            ranch_name: invite.ranch_name,
            message: 'Invitation declined successfully.'
        });

    } catch (error) {
        console.error('=== Decline Ranch Invite Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        
        return Response.json({ 
            error: 'server_error',
            message: `Failed to decline invitation: ${error.message}` 
        }, { status: 500 });
    }
});