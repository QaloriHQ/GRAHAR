import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { action, data, ranch_id } = await req.json();

    if (!ranch_id || !action || !data) {
      return Response.json({ error: 'action, data, and ranch_id required' }, { status: 400 });
    }

    // Execute action based on type
    let result;
    
    switch (action) {
      case 'create_task':
        result = await executeCreateTask(base44, data, ranch_id, user);
        break;
      case 'create_note':
        result = await executeCreateNote(base44, data, ranch_id);
        break;
      case 'create_expense':
        result = await executeCreateExpense(base44, data, ranch_id);
        break;
      case 'create_revenue':
        result = await executeCreateRevenue(base44, data, ranch_id);
        break;
      case 'create_health_record':
        result = await executeCreateHealthRecord(base44, data, ranch_id);
        break;
      case 'move_animals':
        result = await executeMoveAnimals(base44, data, ranch_id);
        break;
      case 'create_breeding_record':
        result = await executeCreateBreedingRecord(base44, data, ranch_id);
        break;
      default:
        return Response.json({ error: 'Unknown action' }, { status: 400 });
    }

    return Response.json({
      success: true,
      result,
      message: getSuccessMessage(action, result)
    });
  } catch (error) {
    console.error('Execute action error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});

async function executeCreateTask(base44, data, ranchId, user) {
  // Get default list ID
  const lists = await base44.asServiceRole.entities.List.filter({ ranch_id: ranchId });
  const defaultList = lists[0];
  
  if (!defaultList) {
    // Create default list if none exists
    const newList = await base44.asServiceRole.entities.List.create({
      ranch_id: ranchId,
      name: 'General',
      list_type: 'To-Do'
    });
    data.list_id = newList.id;
    data.list_name = newList.name;
  } else {
    data.list_id = defaultList.id;
    data.list_name = defaultList.name;
  }
  
  const task = await base44.asServiceRole.entities.Task.create(data);
  return task;
}

async function executeCreateNote(base44, data, ranchId) {
  const note = await base44.asServiceRole.entities.Note.create(data);
  return note;
}

async function executeCreateExpense(base44, data, ranchId) {
  const expense = await base44.asServiceRole.entities.Expense.create(data);
  return expense;
}

async function executeCreateRevenue(base44, data, ranchId) {
  const revenue = await base44.asServiceRole.entities.Revenue.create(data);
  return revenue;
}

async function executeCreateHealthRecord(base44, data, ranchId) {
  const record = await base44.asServiceRole.entities.HealthRecord.create(data);
  return record;
}

async function executeMoveAnimals(base44, data, ranchId) {
  const { animal_ids, to_pasture, to_pasture_name, date } = data;
  
  const updates = [];
  for (const animalId of animal_ids) {
    const updated = await base44.asServiceRole.entities.Animal.update(animalId, {
      pasture_id: to_pasture,
      pasture_location: to_pasture_name
    });
    
    // Create pasture history record
    const animal = await base44.asServiceRole.entities.Animal.filter({ id: animalId });
    await base44.asServiceRole.entities.PastureHistory.create({
      ranch_id: ranchId,
      animal_id: animalId,
      animal_name: animal[0]?.name || animal[0]?.tag_number,
      pasture_id: to_pasture,
      pasture_name: to_pasture_name,
      moved_date: date
    });
    
    updates.push(updated);
  }
  
  return { updated: updates.length };
}

async function executeCreateBreedingRecord(base44, data, ranchId) {
  const record = await base44.asServiceRole.entities.BreedingRecord.create(data);
  return record;
}

function getSuccessMessage(action, result) {
  switch (action) {
    case 'create_task':
      return `✓ Task created successfully`;
    case 'create_note':
      return `✓ Note saved`;
    case 'create_expense':
      return `✓ Expense recorded`;
    case 'create_revenue':
      return `✓ Revenue recorded`;
    case 'create_health_record':
      return `✓ Health record added`;
    case 'move_animals':
      return `✓ Moved ${result.updated} animal(s)`;
    case 'create_breeding_record':
      return `✓ Breeding record created`;
    default:
      return `✓ Action completed`;
  }
}