import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import * as XLSX from 'npm:xlsx@0.18.5';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Get ranch details
        const ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
        const ranch = ranches[0];

        if (!ranch) {
            return Response.json({ error: 'Ranch not found' }, { status: 404 });
        }

        // Check subscription tier
        if (ranch.subscription_plan !== 'Pro' && ranch.subscription_plan !== 'Enterprise') {
            return Response.json({ 
                error: 'Data export is only available for PRO and Enterprise plans',
                upgrade_required: true 
            }, { status: 403 });
        }

        // Fetch all ranch data
        const [animals, tasks, lists, expenses, revenue, healthRecords, breedingRecords, pastures] = await Promise.all([
            base44.entities.Animal.filter({ ranch_id: user.ranch_id }),
            base44.entities.Task.filter({ ranch_id: user.ranch_id }),
            base44.entities.List.filter({ ranch_id: user.ranch_id }),
            base44.entities.Expense.filter({ ranch_id: user.ranch_id }),
            base44.entities.Revenue.filter({ ranch_id: user.ranch_id }),
            base44.entities.HealthRecord.filter({ ranch_id: user.ranch_id }),
            base44.entities.BreedingRecord.filter({ ranch_id: user.ranch_id }),
            base44.entities.Pasture.filter({ ranch_id: user.ranch_id })
        ]);

        // Create workbook
        const wb = XLSX.utils.book_new();

        // Animals Sheet
        const animalsWS = XLSX.utils.json_to_sheet(animals.map(a => ({
            'Tag Number': a.tag_number,
            'Name': a.name,
            'Type': a.type,
            'Breed': a.breed,
            'Date of Birth': a.date_of_birth,
            'Gender': a.gender,
            'Weight (lbs)': a.weight,
            'Purchase Price': a.purchase_price,
            'Current Value': a.current_value,
            'Pasture': a.pasture_location,
            'Health Status': a.health_status,
            'Breeding Status': a.breeding_status,
            'Notes': a.notes
        })));
        XLSX.utils.book_append_sheet(wb, animalsWS, 'Animals');

        // Tasks Sheet
        const tasksWS = XLSX.utils.json_to_sheet(tasks.map(t => ({
            'List': t.list_name,
            'Title': t.title,
            'Description': t.description,
            'Assigned To': t.assigned_to_name,
            'Due Date': t.due_date,
            'Priority': t.priority,
            'Status': t.status,
            'Related Animal': t.related_animal_name,
            'Related Pasture': t.related_pasture_name,
            'Created': t.created_date
        })));
        XLSX.utils.book_append_sheet(wb, tasksWS, 'Tasks');

        // Expenses Sheet
        const expensesWS = XLSX.utils.json_to_sheet(expenses.map(e => ({
            'Date': e.date,
            'Category': e.category,
            'Description': e.description,
            'Amount': e.amount,
            'Vendor': e.vendor,
            'Payment Method': e.payment_method,
            'Notes': e.notes
        })));
        XLSX.utils.book_append_sheet(wb, expensesWS, 'Expenses');

        // Revenue Sheet
        const revenueWS = XLSX.utils.json_to_sheet(revenue.map(r => ({
            'Date': r.date,
            'Category': r.category,
            'Description': r.description,
            'Amount': r.amount,
            'Buyer': r.buyer,
            'Payment Method': r.payment_method,
            'Notes': r.notes
        })));
        XLSX.utils.book_append_sheet(wb, revenueWS, 'Revenue');

        // Health Records Sheet
        const healthWS = XLSX.utils.json_to_sheet(healthRecords.map(h => ({
            'Date': h.date,
            'Animal': h.animal_name,
            'Type': h.record_type,
            'Description': h.description,
            'Medication': h.medication_name,
            'Dosage': h.dosage,
            'Veterinarian': h.veterinarian,
            'Cost': h.cost,
            'Next Due Date': h.next_due_date,
            'Status': h.status
        })));
        XLSX.utils.book_append_sheet(wb, healthWS, 'Health Records');

        // Breeding Records Sheet
        const breedingWS = XLSX.utils.json_to_sheet(breedingRecords.map(b => ({
            'Breeding Date': b.breeding_date,
            'Female': b.animal_name,
            'Bull': b.bull_name,
            'Method': b.breeding_method,
            'Expected Calving': b.expected_calving_date,
            'Actual Calving': b.actual_calving_date,
            'Conception Confirmed': b.conception_confirmed,
            'Calf Gender': b.calf_gender,
            'Calf Weight': b.calf_weight,
            'Status': b.status,
            'Notes': b.notes
        })));
        XLSX.utils.book_append_sheet(wb, breedingWS, 'Breeding');

        // Pastures Sheet
        const pasturesWS = XLSX.utils.json_to_sheet(pastures.map(p => ({
            'Name': p.name,
            'Size (acres)': p.size_acres,
            'Capacity': p.capacity,
            'Current Animals': p.current_animal_count,
            'Grazing Quality': p.grazing_quality,
            'Water Source': p.water_source,
            'Fence Condition': p.fence_condition,
            'Last Rotation': p.last_rotation_date,
            'Next Rotation': p.next_rotation_date,
            'Notes': p.notes
        })));
        XLSX.utils.book_append_sheet(wb, pasturesWS, 'Pastures');

        // Summary Sheet
        const summaryWS = XLSX.utils.json_to_sheet([{
            'Ranch Name': ranch.name,
            'Export Date': new Date().toISOString(),
            'Total Animals': animals.length,
            'Total Tasks': tasks.length,
            'Total Expenses': expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
            'Total Revenue': revenue.reduce((sum, r) => sum + (r.amount || 0), 0),
            'Net Profit': revenue.reduce((sum, r) => sum + (r.amount || 0), 0) - expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
            'Health Records': healthRecords.length,
            'Breeding Records': breedingRecords.length,
            'Pastures': pastures.length
        }]);
        XLSX.utils.book_append_sheet(wb, summaryWS, 'Summary');

        // Generate Excel file
        const excelBuffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

        // Create file name
        const date = new Date().toISOString().split('T')[0];
        const fileName = `${ranch.name.replace(/[^a-z0-9]/gi, '_')}_RanchData_${date}.xlsx`;

        // Log export
        await base44.entities.DataExport.create({
            ranch_id: user.ranch_id,
            user_email: user.email,
            user_name: user.full_name,
            export_date: new Date().toISOString(),
            file_name: fileName,
            export_type: 'Full'
        });

        // Return Excel file
        return new Response(excelBuffer, {
            status: 200,
            headers: {
                'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'Content-Disposition': `attachment; filename="${fileName}"`
            }
        });

    } catch (error) {
        console.error('Export error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});