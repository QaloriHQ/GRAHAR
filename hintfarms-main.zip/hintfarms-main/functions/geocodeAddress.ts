import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const MAPBOX_TOKEN = Deno.env.get("MAPBOX_ACCESS_TOKEN");
    if (!MAPBOX_TOKEN) {
      console.error('MAPBOX_ACCESS_TOKEN not set in environment');
      return Response.json({ error: 'Mapbox access token not configured' }, { status: 500 });
    }

    const body = await req.json();
    const { address_line1, address_line2, city, state, postal_code, country } = body;

    // Build full address from components
    const addressParts = [
      address_line1,
      address_line2,
      city,
      state,
      postal_code,
      country
    ].filter(Boolean);

    const fullAddress = addressParts.join(', ');

    if (!fullAddress) {
      return Response.json({ 
        error: 'No address provided for geocoding',
        success: false 
      }, { status: 400 });
    }

    console.log('Geocoding address:', fullAddress);

    const mapboxUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(fullAddress)}.json?access_token=${MAPBOX_TOKEN}&limit=1`;

    const response = await fetch(mapboxUrl);
    const data = await response.json();

    console.log('Mapbox Geocoding API response:', data);

    if (data.features && data.features.length > 0) {
      const [lon, lat] = data.features[0].center;
      
      console.log('Geocoding successful:', { lat, lon });

      return Response.json({
        success: true,
        lat: parseFloat(lat.toFixed(6)),
        lon: parseFloat(lon.toFixed(6)),
        geocode_status: 'success',
        geocode_source: 'mapbox',
        geocode_updated_at: new Date().toISOString()
      });
    } else {
      console.error('Mapbox Geocoding API Error: No results');
      return Response.json({
        success: false,
        error: 'Could not geocode address',
        geocode_status: 'failed',
        geocode_source: 'mapbox',
        geocode_updated_at: new Date().toISOString()
      }, { status: 400 });
    }

  } catch (error) {
    console.error('Geocoding backend function error:', error);
    return Response.json({ 
      success: false,
      error: error.message, 
      stack: error.stack 
    }, { status: 500 });
  }
});