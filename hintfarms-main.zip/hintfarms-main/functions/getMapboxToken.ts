import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const MAPBOX_TOKEN = Deno.env.get("MAPBOX_ACCESS_TOKEN");
    
    if (!MAPBOX_TOKEN) {
      return Response.json({ error: 'Mapbox access token not configured' }, { status: 500 });
    }

    return Response.json({ token: MAPBOX_TOKEN });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});