import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ 
        success: false,
        error: 'NO_AUTH',
        message: 'Authentication required' 
      }, { status: 401 });
    }

    const { 
      ranch_id,
      species,
      class: animalClass,
      weight_lbs,
      date_from,
      date_to
    } = await req.json();

    if (!ranch_id || !species) {
      return Response.json({ 
        success: false,
        error: 'MISSING_PARAMS',
        message: 'ranch_id and species are required' 
      }, { status: 400 });
    }

    console.log(`[getMarketPrices] ranch_id: ${ranch_id}, species: ${species}, class: ${animalClass}, weight: ${weight_lbs}`);

    // Look up the Ranch's primary USDA market
    const primaryMarkets = await base44.asServiceRole.entities.RanchLocalMarket.filter({
      ranch_id,
      is_primary: true,
      source_type: "USDA_AMS"
    });

    if (primaryMarkets.length === 0) {
      console.log(`[getMarketPrices] No primary USDA AMS market found for ranch_id: ${ranch_id}`);
      return Response.json({
        success: false,
        error: "NO_PRIMARY_MARKET_CONFIGURED",
        message: "No primary USDA AMS market configured. Please configure one in Ranch Settings → Market."
      });
    }

    const market = primaryMarkets[0];
    console.log(`[getMarketPrices] Using market: ${market.display_name} (${market.source_market_code})`);

    // Query existing data from MarketInsightsPrice as cache
    const startDate = date_from || new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const endDate = date_to || new Date().toISOString().split('T')[0];

    let cachedPrices = await base44.asServiceRole.entities.MarketInsightsPrice.filter({
      commodity_type: species,
      market_code: market.source_market_code
    });

    // Filter by date and weight
    cachedPrices = cachedPrices.filter(p => {
      const saleDate = new Date(p.sale_date);
      const inDateRange = saleDate >= new Date(startDate) && saleDate <= new Date(endDate);
      if (!inDateRange) return false;
      
      if (weight_lbs && p.weight_min && p.weight_max) {
        const avgWeight = (p.weight_min + p.weight_max) / 2;
        return Math.abs(avgWeight - weight_lbs) <= 100;
      }
      return true;
    });

    console.log(`[getMarketPrices] Found ${cachedPrices.length} cached price records`);

    if (cachedPrices.length === 0) {
      console.log(`[getMarketPrices] No cached data, returning NO_RECENT_SALES`);
      return Response.json({
        success: false,
        error: "NO_RECENT_SALES",
        message: `No recent sales found for ${species} ${animalClass || ''} ${weight_lbs ? weight_lbs + 'lbs' : ''} at ${market.display_name} in the last 14 days.`.trim()
      });
    }

    // Calculate summary statistics
    let totalPrice = 0;
    let minPrice = Infinity;
    let maxPrice = -Infinity;
    let lastSaleDate = null;

    for (const price of cachedPrices) {
      totalPrice += price.price_per_cwt;
      minPrice = Math.min(minPrice, price.price_low || price.price_per_cwt);
      maxPrice = Math.max(maxPrice, price.price_high || price.price_per_cwt);
      
      const saleDate = new Date(price.sale_date);
      if (!lastSaleDate || saleDate > lastSaleDate) {
        lastSaleDate = saleDate;
      }
    }

    const avgPrice = totalPrice / cachedPrices.length;

    console.log(`[getMarketPrices] Avg: $${avgPrice.toFixed(2)}, Min: $${minPrice.toFixed(2)}, Max: $${maxPrice.toFixed(2)}, Samples: ${cachedPrices.length}`);

    return Response.json({
      success: true,
      results: cachedPrices.slice(0, 5).map(p => ({
        market_name: p.market_name,
        region: p.region,
        weight_min: p.weight_min,
        weight_max: p.weight_max,
        avg_weight: p.avg_weight,
        price_per_cwt: p.price_per_cwt,
        price_low: p.price_low,
        price_high: p.price_high,
        sale_date: p.sale_date,
        currency: p.currency || "USD",
        source: p.provider
      })),
      summary: {
        market_name: market.display_name,
        market_location: `${market.city}, ${market.state}`,
        last_sale_date: lastSaleDate ? lastSaleDate.toISOString().split('T')[0] : null,
        avg_price_per_cwt: avgPrice,
        min_price_per_cwt: minPrice === Infinity ? null : minPrice,
        max_price_per_cwt: maxPrice === -Infinity ? null : maxPrice,
        currency: "USD",
        sample_count: cachedPrices.length
      },
      query: {
        ranch_id,
        species,
        class: animalClass,
        weight_lbs,
        date_from: startDate,
        date_to: endDate
      }
    });

  } catch (error) {
    console.error('[getMarketPrices] Error:', error);
    return Response.json({ 
      success: false,
      error: 'SERVER_ERROR',
      message: error.message || 'Internal server error' 
    }, { status: 500 });
  }
});