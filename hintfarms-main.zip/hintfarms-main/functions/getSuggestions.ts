import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { trigger, search = '', ranch_id } = await req.json();

    if (!ranch_id) {
      return Response.json({ error: 'ranch_id required' }, { status: 400 });
    }

    let suggestions = [];

    switch (trigger) {
      case 'animal':
        suggestions = await getAnimalSuggestions(base44, ranch_id, search);
        break;
      case 'pasture':
        suggestions = await getPastureSuggestions(base44, ranch_id, search);
        break;
      case 'category':
        suggestions = getCategorySuggestions(search);
        break;
      case 'time':
        suggestions = getTimeSuggestions(search);
        break;
      default:
        suggestions = [];
    }

    return Response.json({ suggestions });
  } catch (error) {
    console.error('Suggestion error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});

async function getAnimalSuggestions(base44, ranchId, search) {
  try {
    const animals = await base44.asServiceRole.entities.Animal.filter({ ranch_id: ranchId });
    
    return animals
      .filter(a => {
        if (!search) return true;
        const searchLower = search.toLowerCase();
        return (
          a.tag_number?.toLowerCase().includes(searchLower) ||
          a.name?.toLowerCase().includes(searchLower) ||
          a.external_id?.toLowerCase().includes(searchLower)
        );
      })
      .slice(0, 10)
      .map(a => ({
        type: 'animal',
        id: a.id,
        display: `#${a.tag_number}${a.name ? ` ${a.name}` : ''}`,
        subtext: `${a.type || 'Animal'} • ${a.pasture_location || 'No location'} • ${a.health_status || 'Unknown'}`,
        token: `#${a.tag_number}`,
        badge: a.health_status !== 'Healthy' ? a.health_status : null,
        data: a
      }));
  } catch (error) {
    console.error('Error fetching animal suggestions:', error);
    return [];
  }
}

async function getPastureSuggestions(base44, ranchId, search) {
  try {
    const pastures = await base44.asServiceRole.entities.Pasture.filter({ ranch_id: ranchId });
    
    return pastures
      .filter(p => {
        if (!search) return true;
        return p.name?.toLowerCase().includes(search.toLowerCase());
      })
      .slice(0, 10)
      .map(p => {
        const stockingRate = p.size_acres > 0 && p.current_animal_count 
          ? (p.current_animal_count / p.size_acres).toFixed(2) 
          : '0';
        
        return {
          type: 'pasture',
          id: p.id,
          display: `~${p.name}`,
          subtext: `${p.size_acres || 0} acres • ${p.current_animal_count || 0} animals • Stocking: ${stockingRate} AU/ac`,
          token: `~${p.name}`,
          badge: p.condition,
          data: p
        };
      });
  } catch (error) {
    console.error('Error fetching pasture suggestions:', error);
    return [];
  }
}

function getCategorySuggestions(search) {
  const categories = [
    // Financial categories
    { value: '/feed', label: 'Feed', group: 'Expense Category' },
    { value: '/hay', label: 'Hay', group: 'Expense Category' },
    { value: '/vetvisit', label: 'Veterinary Visit', group: 'Expense Category' },
    { value: '/fuel', label: 'Fuel', group: 'Expense Category' },
    { value: '/labor', label: 'Labor', group: 'Expense Category' },
    { value: '/rent', label: 'Rent', group: 'Expense Category' },
    { value: '/equipment', label: 'Equipment', group: 'Expense Category' },
    { value: '/supplement', label: 'Supplements', group: 'Expense Category' },
    { value: '/services', label: 'Services', group: 'Expense Category' },
    { value: '/sale', label: 'Sale', group: 'Revenue Category' },
    
    // App pages
    { value: '/animals', label: 'Animals Page', group: 'Navigation' },
    { value: '/pastures', label: 'Pastures Page', group: 'Navigation' },
    { value: '/financials', label: 'Financials Page', group: 'Navigation' },
    { value: '/expenses', label: 'Expenses Page', group: 'Navigation' },
    { value: '/revenue', label: 'Revenue Page', group: 'Navigation' },
    { value: '/tasks', label: 'Tasks Page', group: 'Navigation' },
    { value: '/health', label: 'Health Records', group: 'Navigation' },
    { value: '/breeding', label: 'Breeding Page', group: 'Navigation' },
    { value: '/reports', label: 'Reports Page', group: 'Navigation' },
    
    // Metrics
    { value: '/herdsize', label: 'Herd Size', group: 'Metric' },
    { value: '/stockingrate', label: 'Stocking Rate', group: 'Metric' },
    { value: '/adg', label: 'Average Daily Gain', group: 'Metric' },
    { value: '/grossmargin', label: 'Gross Margin', group: 'Metric' },
    { value: '/cashflow', label: 'Cash Flow', group: 'Metric' },
    { value: '/netprofit', label: 'Net Profit', group: 'Metric' }
  ];

  const searchLower = search.toLowerCase();
  return categories
    .filter(c => 
      !search || 
      c.value.toLowerCase().includes(searchLower) || 
      c.label.toLowerCase().includes(searchLower)
    )
    .slice(0, 10)
    .map(c => ({
      type: 'category',
      display: c.label,
      subtext: c.group,
      token: c.value,
      data: c
    }));
}

function getTimeSuggestions(search) {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  
  const timeRanges = [
    { value: '@today', label: 'Today', subtext: 'Current date' },
    { value: '@yesterday', label: 'Yesterday', subtext: 'Previous day' },
    { value: '@last7d', label: 'Last 7 Days', subtext: 'Past week' },
    { value: '@last30d', label: 'Last 30 Days', subtext: 'Past month' },
    { value: '@last12m', label: 'Last 12 Months', subtext: 'Past year' },
    { value: '@thismonth', label: 'This Month', subtext: `${year}-${month}` },
    { value: '@lastmonth', label: 'Last Month', subtext: 'Previous month' },
    { value: '@2025Q1', label: '2025 Q1', subtext: 'Jan-Mar 2025' },
    { value: '@2025Q2', label: '2025 Q2', subtext: 'Apr-Jun 2025' },
    { value: '@2025Q3', label: '2025 Q3', subtext: 'Jul-Sep 2025' },
    { value: '@2025Q4', label: '2025 Q4', subtext: 'Oct-Dec 2025' },
    { value: `@${year}`, label: `Year ${year}`, subtext: 'Current year' }
  ];

  const searchLower = search.toLowerCase();
  return timeRanges
    .filter(t => 
      !search || 
      t.value.toLowerCase().includes(searchLower) || 
      t.label.toLowerCase().includes(searchLower)
    )
    .slice(0, 10)
    .map(t => ({
      type: 'time',
      display: t.label,
      subtext: t.subtext,
      token: t.value,
      data: t
    }));
}