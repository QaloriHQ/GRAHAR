import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ 
        success: false,
        error: 'Authentication required' 
      }, { status: 401 });
    }

    const { 
      commodity_type, 
      target_weight_lbs = null, 
      ranch_id,
      region_override = null,
      sale_date_range = null,
      limit = 5
    } = await req.json();

    if (!commodity_type || !ranch_id) {
      return Response.json({ 
        success: false,
        error: 'commodity_type and ranch_id required' 
      }, { status: 400 });
    }

    if (user.active_ranch_id !== ranch_id && user.role !== 'admin') {
      return Response.json({ 
        success: false,
        error: 'Access denied to this ranch' 
      }, { status: 403 });
    }

    const ranch = await base44.asServiceRole.entities.Ranch.filter({ id: ranch_id });
    if (ranch.length === 0) {
      return Response.json({ 
        success: false,
        error: 'Ranch not found' 
      }, { status: 404 });
    }

    const region = region_override || deriveRegion(ranch[0]);
    
    const localMarkets = await base44.asServiceRole.entities.RanchLocalMarket.filter({ 
      ranch_id 
    });

    const query = {
      commodity_type
    };

    let allPrices = await base44.asServiceRole.entities.MarketInsightsPrice.filter(query);
    
    if (sale_date_range) {
      allPrices = allPrices.filter(p => {
        const saleDate = new Date(p.sale_date);
        return saleDate >= new Date(sale_date_range.from) && saleDate <= new Date(sale_date_range.to);
      });
    } else {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      allPrices = allPrices.filter(p => new Date(p.sale_date) >= thirtyDaysAgo);
    }

    if (target_weight_lbs) {
      allPrices = allPrices.filter(p => 
        p.weight_min <= target_weight_lbs && p.weight_max >= target_weight_lbs
      );
      
      if (allPrices.length === 0) {
        allPrices = await base44.asServiceRole.entities.MarketInsightsPrice.filter(query);
        allPrices = allPrices.map(p => ({
          ...p,
          weightDistance: Math.abs(((p.weight_min + p.weight_max) / 2) - target_weight_lbs)
        })).sort((a, b) => a.weightDistance - b.weightDistance);
      }
    }

    const localMarketNames = localMarkets.map(m => m.display_name.toLowerCase());
    const localMarketCodes = localMarkets.map(m => m.source_market_code).filter(Boolean);
    
    const prioritized = allPrices.sort((a, b) => {
      const aIsLocal = localMarketNames.includes(a.market_name.toLowerCase()) || 
                       localMarketCodes.includes(a.market_code);
      const bIsLocal = localMarketNames.includes(b.market_name.toLowerCase()) || 
                       localMarketCodes.includes(b.market_code);
      
      if (aIsLocal && !bIsLocal) return -1;
      if (!aIsLocal && bIsLocal) return 1;
      
      return new Date(b.sale_date) - new Date(a.sale_date);
    });

    const regionalPrices = prioritized.filter(p => 
      p.region.toLowerCase().includes(region.toLowerCase()) ||
      region.toLowerCase().includes(p.region.toLowerCase())
    );

    const results = (regionalPrices.length > 0 ? regionalPrices : prioritized).slice(0, limit);

    if (results.length === 0) {
      return Response.json({
        success: false,
        error: 'No market data available',
        message: 'No recent market data found for your region. Try configuring local markets in Ranch Settings or check back later as new data is synced.',
        query: {
          commodity_type,
          target_weight_lbs,
          region
        }
      });
    }

    return Response.json({
      success: true,
      results: results.map(p => ({
        market_name: p.market_name,
        region: p.region,
        weight_min: p.weight_min,
        weight_max: p.weight_max,
        avg_weight: p.avg_weight,
        price_per_cwt: p.price_per_cwt,
        price_low: p.price_low,
        price_high: p.price_high,
        sale_date: p.sale_date,
        source: p.provider,
        is_local_market: localMarketNames.includes(p.market_name.toLowerCase()) || 
                        localMarketCodes.includes(p.market_code)
      })),
      query: {
        commodity_type,
        target_weight_lbs,
        region
      }
    });
  } catch (error) {
    console.error('Market price query error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});

function deriveRegion(ranch) {
  const state = ranch.location?.split(',')[1]?.trim() || '';
  
  const regionMap = {
    'Arkansas': 'Arkansas-Texas',
    'Texas': 'Arkansas-Texas',
    'Oklahoma': 'Oklahoma',
    'Missouri': 'Missouri',
    'Kansas': 'Kansas',
    'Nebraska': 'Nebraska'
  };
  
  return regionMap[state] || state || 'National';
}