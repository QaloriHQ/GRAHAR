import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ 
        success: false,
        error: 'Authentication required' 
      }, { status: 401 });
    }

    const { 
      commodity_type, 
      ranch_id,
      months_back = 6,
      target_weight_lbs = null
    } = await req.json();

    if (!commodity_type || !ranch_id) {
      return Response.json({ 
        success: false,
        error: 'commodity_type and ranch_id required' 
      }, { status: 400 });
    }

    if (user.active_ranch_id !== ranch_id && user.role !== 'admin') {
      return Response.json({ 
        success: false,
        error: 'Access denied to this ranch' 
      }, { status: 403 });
    }

    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - months_back);

    const ranch = await base44.asServiceRole.entities.Ranch.filter({ id: ranch_id });
    const region = ranch[0]?.location?.split(',')[1]?.trim() || '';

    let prices = await base44.asServiceRole.entities.MarketInsightsPrice.filter({
      commodity_type
    });

    prices = prices.filter(p => new Date(p.sale_date) >= startDate);

    if (region) {
      prices = prices.filter(p => 
        p.region.toLowerCase().includes(region.toLowerCase()) ||
        region.toLowerCase().includes(p.region.toLowerCase())
      );
    }

    if (target_weight_lbs) {
      prices = prices.filter(p => 
        p.weight_min <= target_weight_lbs && p.weight_max >= target_weight_lbs
      );
    }

    const monthlyData = {};
    
    for (const price of prices) {
      const month = price.sale_date.substring(0, 7);
      
      if (!monthlyData[month]) {
        monthlyData[month] = {
          month,
          prices: [],
          count: 0
        };
      }
      
      monthlyData[month].prices.push(price.price_per_cwt);
      monthlyData[month].count++;
    }

    const history = Object.values(monthlyData).map(data => ({
      month: data.month,
      avg_price: data.prices.reduce((a, b) => a + b, 0) / data.prices.length,
      min_price: Math.min(...data.prices),
      max_price: Math.max(...data.prices),
      sample_count: data.count
    })).sort((a, b) => a.month.localeCompare(b.month));

    return Response.json({
      success: true,
      history,
      query: {
        commodity_type,
        months_back,
        target_weight_lbs,
        region
      }
    });
  } catch (error) {
    console.error('Market price history error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});