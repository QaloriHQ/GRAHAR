import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { message, ranch_id, conversation_history = [] } = await req.json();

    if (!ranch_id || !message) {
      return Response.json({ error: 'message and ranch_id required' }, { status: 400 });
    }

    // Extract entities from conversation history for context
    const historicalEntities = extractHistoricalEntities(conversation_history);
    
    // Parse message for shortcuts
    const parsed = await parseMessage(message, base44, ranch_id, historicalEntities);
    
    // Build context for AI
    const context = await buildContext(parsed, base44, ranch_id);
    
    // Classify intent
    const intent = classifyIntent(message);
    context.detectedIntent = intent;

    // Handle market pricing intent
    if (intent === 'market_pricing') {
      const marketQuery = detectMarketQuery(message, parsed);

      // Check if markets are configured
      const localMarkets = await base44.asServiceRole.entities.RanchLocalMarket.filter({ 
        ranch_id 
      });

      if (localMarkets.length === 0) {
        context.marketContext = `Markets NOT configured. User asked about market prices but this ranch has no local markets set up yet.
    Respond conversationally: explain that local sale barns need to be configured, and guide them to Ranch Settings → Market.
    Do NOT mention lexicon tips for this response.`;

        const aiResponse = await generateAIResponse(message, context, conversation_history, parsed);
        return Response.json({
          type: 'query',
          message: aiResponse,
          links: [{ label: 'Configure Markets', url: '/RanchSettings?tab=market' }],
          entities: parsed.entities,
          detectedIntent: 'market_pricing',
          data: {
            animalCount: context.ranchSummary?.totalAnimals || 0,
            pastureCount: context.ranchSummary?.totalPastures || 0
          },
          ranchContext: context.ranchSummary
        });
      }

      // Markets are configured - try to get data
      if (marketQuery) {
        const marketResponse = await handleMarketQuery(marketQuery, base44, ranch_id);

        if (marketResponse.data?.no_data) {
          const errorType = marketResponse.data.error_type;
          if (errorType === 'NO_PRIMARY_MARKET_CONFIGURED') {
            context.marketContext = `No primary USDA AMS market configured. Explain that they need to configure a primary market in Ranch Settings → Market.`;
          } else if (errorType === 'NO_RECENT_SALES') {
            context.marketContext = `Markets ARE configured (${localMarkets.length} markets), but no recent price data available matching criteria. ${marketResponse.message}`;
          } else if (errorType === 'AMS_FETCH_FAILED') {
            context.marketContext = `Markets ARE configured, but error fetching from USDA AMS. ${marketResponse.message}`;
          } else {
            context.marketContext = `Markets ARE configured (${localMarkets.length} markets), but no recent price data available yet.`;
          }
        } else {
          context.marketContext = `Market data available: ${JSON.stringify(marketResponse.data.summary)}`;
        }

        const aiResponse = await generateAIResponse(message, context, conversation_history, parsed);
        return Response.json({
          type: 'market_query',
          message: aiResponse,
          links: marketResponse.links,
          data: {
            ...marketResponse.data.summary,
            animalCount: context.ranchSummary?.totalAnimals || 0,
            pastureCount: context.ranchSummary?.totalPastures || 0
          },
          entities: parsed.entities,
          detectedIntent: 'market_pricing',
          ranchContext: context.ranchSummary
        });
      } else {
        // General market question without specific query
        context.marketContext = `General market question. ${localMarkets.length} local markets configured.`;
      }
    }

    // Detect intent and action
    const intent = detectIntent(message, parsed);

    // If this is an action request, prepare proposal
    if (intent.action && intent.action !== 'query') {
      const proposal = await prepareActionProposal(intent, parsed, base44, ranch_id, user);

      // If proposal has validation errors (data is null), return as regular message
      if (!proposal.data) {
        return Response.json({
          type: 'query',
          message: proposal.confirmationMessage,
          entities: parsed.entities,
          detectedIntent: intent.action,
          ranchContext: context.ranchSummary
        });
      }

      return Response.json({
        type: 'action_proposal',
        action: intent.action,
        proposal,
        message: proposal.confirmationMessage,
        parsed,
        entities: parsed.entities,
        detectedIntent: intent.action,
        ranchContext: context.ranchSummary
      });
    }

    // Generate response with LLM for queries
    const aiResponse = await generateAIResponse(message, context, conversation_history, parsed);

    // Generate deep links
    const links = generateDeepLinks(parsed);

    return Response.json({
      type: 'query',
      message: aiResponse,
      links,
      data: {
        ...context.summary,
        animalCount: context.ranchSummary?.totalAnimals || 0,
        pastureCount: context.ranchSummary?.totalPastures || 0
      },
      entities: parsed.entities,
      detectedIntent: classifyIntent(message),
      ranchContext: context.ranchSummary,
      historicalContext: historicalEntities
    });
  } catch (error) {
    console.error('AI Agent error:', error);
    return Response.json({ 
      message: 'I encountered an error processing your request. Please try again.',
      error: error.message 
    }, { status: 500 });
  }
});

function extractHistoricalEntities(conversationHistory) {
  const historicalEntities = [];
  
  for (const msg of conversationHistory) {
    if (msg.role === 'assistant' && msg.entities) {
      historicalEntities.push(...msg.entities);
    }
  }
  
  return historicalEntities;
}

async function parseMessage(message, base44, ranchId, historicalEntities = []) {
  const entities = [];
  const categories = [];
  const metrics = [];
  const dates = [];
  const amounts = [];
  
  // Check for pronoun references (her, his, it, them, that, this)
  const hasPronouns = /\b(her|his|it|them|that|this|she|he|they)\b/i.test(message);
  
  // If pronouns detected and we have historical entities, inherit most recent
  if (hasPronouns && historicalEntities.length > 0) {
    const mostRecentAnimal = historicalEntities.filter(e => e.type === 'animal').slice(-1)[0];
    const mostRecentPasture = historicalEntities.filter(e => e.type === 'pasture').slice(-1)[0];
    
    if (mostRecentAnimal) {
      entities.push({
        ...mostRecentAnimal,
        fromContext: true
      });
    }
    
    if (mostRecentPasture && /pasture|location|field/i.test(message)) {
      entities.push({
        ...mostRecentPasture,
        fromContext: true
      });
    }
  }

  // Parse animals (#)
  const animalMatches = message.match(/#(\w+)/g);
  if (animalMatches) {
    for (const match of animalMatches) {
      const tagNumber = match.slice(1);
      const animals = await base44.asServiceRole.entities.Animal.filter({ 
        ranch_id: ranchId, 
        tag_number: tagNumber 
      });
      if (animals.length > 0) {
        entities.push({
          type: 'animal',
          token: match,
          id: animals[0].id,
          data: animals[0]
        });
      }
    }
  }

  // Parse pastures (~)
  const pastureMatches = message.match(/~(\w+)/g);
  if (pastureMatches) {
    for (const match of pastureMatches) {
      const pastureName = match.slice(1);
      const pastures = await base44.asServiceRole.entities.Pasture.filter({ 
        ranch_id: ranchId
      });
      const foundPasture = pastures.find(p => 
        p.name.toLowerCase().replace(/\s+/g, '') === pastureName.toLowerCase()
      );
      if (foundPasture) {
        entities.push({
          type: 'pasture',
          token: match,
          id: foundPasture.id,
          data: foundPasture
        });
      }
    }
  }

  // Parse categories, metrics, and pages (/)
  const categoryMatches = message.match(/\/(\w+)/g);
  if (categoryMatches) {
    for (const match of categoryMatches) {
      const value = match.toLowerCase();
      
      // Check if it's a metric
      if (['/herdsize', '/stockingrate', '/adg', '/grossmargin', '/cashflow', '/netprofit'].includes(value)) {
        metrics.push(match);
      }
      // Check if it's a category
      else if (['/feed', '/hay', '/vetvisit', '/fuel', '/labor', '/rent', '/equipment', '/supplement', '/services', '/sale'].includes(value)) {
        categories.push(match);
      }
    }
  }

  // Parse dates (@)
  const dateMatches = message.match(/@(\w+)/g);
  if (dateMatches) {
    dates.push(...dateMatches.map(m => m.slice(1)));
  }

  // Parse amounts
  const amountMatches = message.match(/[-+]?\$?\d+(\.\d+)?/g);
  if (amountMatches) {
    amounts.push(...amountMatches);
  }

  return { entities, categories, metrics, dates, amounts };
}

async function buildContext(parsed, base44, ranchId) {
  const context = {
    entities: [],
    financials: {},
    metrics: {},
    summary: {},
    ranchSummary: null
  };

  // Always fetch ranch summary for conversational context
  try {
    const ranch = await base44.asServiceRole.entities.Ranch.filter({ id: ranchId });
    if (ranch.length > 0) {
      const animals = await base44.asServiceRole.entities.Animal.filter({ ranch_id: ranchId }, null, 1000);
      const pastures = await base44.asServiceRole.entities.Pasture.filter({ ranch_id: ranchId }, null, 100);

      context.ranchSummary = {
        name: ranch[0].name,
        location: ranch[0].location || ranch[0].address,
        totalAnimals: animals.length,
        totalPastures: pastures.length,
        subscriptionPlan: ranch[0].subscription_plan || 'Free',
        herdSize: ranch[0].herd_size
      };
    }
  } catch (error) {
    console.error('Error fetching ranch summary:', error);
  }

  // Fetch entity details
  for (const entity of parsed.entities) {
    if (entity.type === 'animal') {
      const healthRecords = await base44.asServiceRole.entities.HealthRecord.filter({
        ranch_id: ranchId,
        animal_id: entity.id
      });
      entity.healthRecords = healthRecords.sort((a, b) => 
        new Date(b.date) - new Date(a.date)
      );

      const breedingRecords = await base44.asServiceRole.entities.BreedingRecord.filter({
        ranch_id: ranchId,
        animal_id: entity.id
      });
      entity.breedingRecords = breedingRecords.sort((a, b) => 
        new Date(b.breeding_date) - new Date(a.breeding_date)
      );
    }
    context.entities.push(entity);
  }

  // Fetch financial data if categories mentioned
  if (parsed.categories.length > 0) {
    const expenses = await base44.asServiceRole.entities.Expense.filter({ ranch_id: ranchId });
    const revenue = await base44.asServiceRole.entities.Revenue.filter({ ranch_id: ranchId });
    
    context.financials = {
      totalExpenses: expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
      totalRevenue: revenue.reduce((sum, r) => sum + (r.amount || 0), 0),
      byCategory: {}
    };

    // Group by category
    for (const cat of parsed.categories) {
      const categoryName = cat.slice(1);
      const categoryExpenses = expenses.filter(e => 
        e.category?.toLowerCase() === categoryName.toLowerCase()
      );
      context.financials.byCategory[categoryName] = {
        count: categoryExpenses.length,
        total: categoryExpenses.reduce((sum, e) => sum + (e.amount || 0), 0),
        expenses: categoryExpenses.slice(0, 5)
      };
    }
  }

  // Calculate metrics
  if (parsed.metrics.includes('/herdsize')) {
    const animals = await base44.asServiceRole.entities.Animal.filter({ ranch_id: ranchId });
    context.metrics.herdsize = animals.length;
  }

  if (parsed.metrics.includes('/netprofit')) {
    const expenses = await base44.asServiceRole.entities.Expense.filter({ ranch_id: ranchId });
    const revenue = await base44.asServiceRole.entities.Revenue.filter({ ranch_id: ranchId });
    const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const totalRevenue = revenue.reduce((sum, r) => sum + (r.amount || 0), 0);
    context.metrics.netprofit = totalRevenue - totalExpenses;
  }

  // Build summary for display
  context.summary = {
    animalCount: context.entities.filter(e => e.type === 'animal').length,
    pastureCount: context.entities.filter(e => e.type === 'pasture').length,
    ...context.metrics
  };

  return context;
}

async function generateAIResponse(message, context, history, parsed) {
  const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');

  if (!OPENAI_API_KEY) {
    return buildBasicResponse(message, context, parsed);
  }

  try {
    // Build detailed context for the AI
    const entityDetails = context.entities.map(e => {
      if (e.type === 'animal') {
        return {
          type: 'animal',
          tag: e.data.tag_number,
          name: e.data.name,
          health: e.data.health_status,
          location: e.data.pasture_location,
          weight: e.data.weight,
          healthRecordCount: e.healthRecords?.length || 0,
          breedingRecordCount: e.breedingRecords?.length || 0,
          fromContext: e.fromContext
        };
      } else if (e.type === 'pasture') {
        return {
          type: 'pasture',
          name: e.data.name,
          size: e.data.size_acres,
          animals: e.data.current_animal_count,
          condition: e.data.condition
        };
      }
      return e;
    });

    const systemPrompt = `You are Ranch Assist, an AI assistant embedded in the GRAHAR app.
    Your job is to talk with ranchers in a friendly, conversational way and help them understand their ranch operations, market conditions, and records.

    You must:
    - Always try to answer the user's question in natural language first.
    - Use ranch context (active ranch, herd, pastures, financials, markets) when it is available.
    - Use the Ranch Lexicon only when the user actually uses shortcuts (like #29, /revenue, /vet, ~NorthPasture) or when you need to disambiguate.
    - Never require the lexicon to answer a question. It is an enhancement, not a requirement.

    **Context you have received:**
    ${context.ranchSummary ? `
    Active Ranch: ${context.ranchSummary.name}
    - Location: ${context.ranchSummary.location || 'Not set'}
    - Total Animals: ${context.ranchSummary.totalAnimals || 0}
    - Total Pastures: ${context.ranchSummary.totalPastures || 0}
    - Subscription: ${context.ranchSummary.subscriptionPlan || 'Free'}
    ` : ''}

    ${entityDetails.length > 0 ? `Lexicon Matches (user used shortcuts): ${JSON.stringify(entityDetails, null, 2)}` : ''}
    ${context.financials?.byCategory ? `Financial Data: ${JSON.stringify(context.financials)}` : ''}
    ${context.metrics ? `Metrics: ${JSON.stringify(context.metrics)}` : ''}
    ${context.marketContext ? `Market Context: ${context.marketContext}` : ''}

    **When answering:**
    1. Understand intent first. The user's message is primarily about: ${context.detectedIntent || 'general question'}

    2. Route to the appropriate response:
    - For market_pricing: use market data if available
    - For ranch_overview: use active ranch summary
    - For ranch_records or lexicon_query: use lexicon matches plus ranch data
    - For general_question: answer from general ranch knowledge, referencing context if helpful

    3. If you don't have needed data, respond conversationally, explain what's missing, and give a clear next step.

    4. Only show lexicon tips after you've tried to answer the question, and only if it would genuinely help.

    5. Keep responses short, clear, and ranch-practical.

    **Examples:**
    - "What are cattle prices like in my area?" → If market data available: summarize recent local prices, trends, and which markets. If not: explain markets need to be configured in Ranch Settings → Markets.
    - "What's going on with cow #29?" → If #29 resolves: summarize recent health records, tasks, financials in plain language.
    - "Am I spending too much on feed?" → Compare feed expenses vs historical if possible; otherwise explain what data is missing.

    Always respond like you are a knowledgeable ranch partner looking at their GRAHAR data with them.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.slice(-6).map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: message }
    ];

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages,
        max_tokens: 500,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error('OpenAI API error');
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('OpenAI error:', error);
    return buildBasicResponse(message, context);
  }
}

function buildBasicResponse(message, context, parsed) {
  const parts = [];

  // Start with conversational greeting if no data
  if (context.entities.length === 0 && !context.financials.byCategory && Object.keys(context.metrics).length === 0) {
    if (context.ranchSummary) {
      return `I'd be happy to help! ${context.ranchSummary.name} currently has ${context.ranchSummary.totalAnimals} animals across ${context.ranchSummary.totalPastures} pastures. What would you like to know more about?\n\n*Tip: You can reference specific animals with #tag or pastures with ~name for detailed information.*`;
    }
    return "I'd be happy to help with your ranch management! What would you like to know? You can ask about animals, pastures, finances, or general ranch operations.\n\n*Tip: Use shortcuts like #tag for animals or ~name for pastures to get specific details.*";
  }

  // Check if question is about vaccinations/health for an animal from context
  const isHealthQuery = /vaccin|treatment|health|medical|vet/i.test(message);

  // Deduplicate animals by ID
  const animals = context.entities.filter(e => e.type === 'animal');
  const uniqueAnimals = animals.reduce((acc, animal) => {
    if (!acc.some(a => a.id === animal.id)) {
      acc.push(animal);
    }
    return acc;
  }, []);

  if (uniqueAnimals.length > 0) {
    for (const animal of uniqueAnimals) {
      const a = animal.data;
      const fromContext = animal.fromContext ? ' (from our previous conversation)' : '';

      parts.push(`**${a.name || `Animal ${a.tag_number}`}**${fromContext}`);
      parts.push(`Currently in ${a.pasture_location || 'unknown location'}, weighing ${a.weight || 'N/A'} lbs. Health status: ${a.health_status || 'Unknown'}.`);

      if (animal.healthRecords?.length > 0) {
        parts.push(`\n**Recent Health Records** (${animal.healthRecords.length} total):`);

        const records = isHealthQuery && /vaccin/i.test(message)
          ? animal.healthRecords.filter(r => /vaccin/i.test(r.record_type) || /vaccin/i.test(r.description))
          : animal.healthRecords.slice(0, 3);

        for (const record of records) {
          const date = new Date(record.date).toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric', 
            year: 'numeric' 
          });
          parts.push(`- **${record.record_type}** on ${date}${record.medication_name ? `: ${record.medication_name}` : ''}`);
          if (record.description) parts.push(`  ${record.description}`);
        }

        if (records.length === 0 && isHealthQuery) {
          parts.push("I don't see any vaccination records yet for this animal.");
        }
      } else if (isHealthQuery) {
        parts.push('\nNo health records found yet for this animal. Would you like to add one?');
      }
    }
  }

  // Pasture info
  const pastures = context.entities.filter(e => e.type === 'pasture');
  if (pastures.length > 0) {
    for (const pasture of pastures) {
      const p = pasture.data;
      const stockingRate = p.size_acres > 0 && p.current_animal_count 
        ? (p.current_animal_count / p.size_acres).toFixed(2) 
        : '0';
      parts.push(`**${p.name}** is ${p.size_acres || 0} acres with ${p.current_animal_count || 0} animals (${stockingRate} per acre). Condition: ${p.condition || 'Unknown'}.`);
    }
  }

  // Financial info
  if (context.financials.byCategory) {
    for (const [category, data] of Object.entries(context.financials.byCategory)) {
      parts.push(`You've spent **$${data.total.toLocaleString()}** on ${category} across ${data.count} transactions.`);
    }
  }

  // Metrics
  if (Object.keys(context.metrics).length > 0) {
    parts.push('**Key Metrics:**');
    for (const [metric, value] of Object.entries(context.metrics)) {
      const formatted = typeof value === 'number' && metric.includes('profit') 
        ? `$${value.toLocaleString()}`
        : value;
      parts.push(`- ${metric}: ${formatted}`);
    }
  }

  return parts.join('\n\n');
}

function classifyIntent(message) {
  const msgLower = message.toLowerCase();
  
  // Market pricing queries
  if (/\b(price|market|sell|selling|worth|value|cattle prices|barn|auction)\b/.test(msgLower)) {
    return 'market_pricing';
  }
  
  // Ranch overview queries
  if (/\b(how is|how's|overview|summary|doing|performance|ranch)\b/.test(msgLower) && 
      /\b(ranch|operation|farm|herd)\b/.test(msgLower)) {
    return 'ranch_overview';
  }
  
  // Lexicon query (contains shortcuts)
  if (/#\w+|~\w+|\/\w+|@\w+/.test(message)) {
    return 'lexicon_query';
  }
  
  // Ranch records (specific data queries)
  if (/\b(animal|cow|cattle|heifer|steer|pasture|expense|revenue|health|breeding|task)\b/.test(msgLower)) {
    return 'ranch_records';
  }
  
  // Default to general question
  return 'general_question';
}

function detectMarketQuery(message, parsed) {
  const msgLower = message.toLowerCase();
  
  // Market price queries
  if (/\b(price|market|sell|selling|worth|value)\b/.test(msgLower) && 
      /\b(steer|heifer|calf|calves|cattle|cow)\b/.test(msgLower)) {
    
    // Extract commodity type
    let commodity = 'feeder_steer';
    if (/heifer/i.test(message)) commodity = 'feeder_heifer';
    else if (/calf|calves/i.test(message)) commodity = 'calf';
    else if (/slaughter.*cow/i.test(message)) commodity = 'slaughter_cow';
    
    // Extract class (steer, heifer, etc.)
    let classType = null;
    if (/steer/i.test(message)) classType = 'steer';
    else if (/heifer/i.test(message)) classType = 'heifer';
    else if (/bull/i.test(message)) classType = 'bull';
    else if (/cow/i.test(message)) classType = 'cow';
    
    // Extract weight if mentioned
    const weightMatch = message.match(/(\d{3,4})\s*(-?\s*lb|pound)?/);
    const weight = weightMatch ? parseInt(weightMatch[1]) : null;
    
    return { 
      type: 'price_query',
      commodity,
      class: classType,
      weight,
      isSellQuery: /\b(sell|selling|should i sell)\b/.test(msgLower)
    };
  }
  
  return null;
}

async function handleMarketQuery(query, base44, ranchId) {
  try {
    // Call the new getMarketPrices function
    const priceResponse = await base44.functions.invoke('getMarketPrices', {
      species: query.commodity,
      class: query.class,
      weight_lbs: query.weight,
      ranch_id: ranchId
    });
    
    console.log('[handleMarketQuery] Price response:', JSON.stringify(priceResponse.data));
    
    if (!priceResponse.data?.success) {
      const errorType = priceResponse.data?.error;
      let message = priceResponse.data?.message || '';
      
      if (errorType === 'NO_PRIMARY_MARKET_CONFIGURED') {
        message = message || 'No primary USDA AMS market configured. Please configure one in Ranch Settings → Market.';
      } else if (errorType === 'NO_RECENT_SALES') {
        message = message || 'No recent sales found matching your criteria.';
      } else if (errorType === 'AMS_FETCH_FAILED') {
        message = message || 'Error fetching data from USDA AMS. Please check your market configuration.';
      }
      
      return {
        message,
        links: [{ label: 'Configure Markets', url: '/RanchSettings?tab=market' }],
        data: { no_data: true, error_type: errorType }
      };
    }
    
    const summary = priceResponse.data.summary;
    
    // Get historical data for trend analysis if it's a sell query
    let trend = null;
    if (query.isSellQuery) {
      const historyResponse = await base44.functions.invoke('queryMarketInsightsPriceHistory', {
        commodity_type: query.commodity,
        ranch_id: ranchId,
        months_back: 6,
        target_weight_lbs: query.weight
      });
      
      const history = historyResponse.data?.history || [];
      if (history.length >= 2) {
        const recent = history[history.length - 1];
        const sixMonthsAgo = history[0];
        const percentChange = ((recent.avg_price - sixMonthsAgo.avg_price) / sixMonthsAgo.avg_price * 100).toFixed(1);
        trend = {
          percentChange,
          direction: percentChange > 0 ? 'up' : 'down',
          recentPrice: recent.avg_price,
          historicalPrice: sixMonthsAgo.avg_price
        };
      }
    }
    
    // Return structured data for LLM to format conversationally
    return {
      message: '',
      links: [
        { label: 'View Full Market Report', url: `/Market?commodity=${query.commodity}` },
        { label: 'Configure Local Markets', url: '/RanchSettings?tab=market' }
      ],
      data: {
        summary,
        commodity: formatCommodity(query.commodity),
        prices: priceResponse.data.results,
        trend,
        targetWeight: query.weight,
        isSellQuery: query.isSellQuery
      }
    };
  } catch (error) {
    console.error('Market query error:', error);
    return {
      message: "I encountered an error fetching market data. Please try again.",
      links: [],
      data: { error_type: 'SERVER_ERROR' }
    };
  }
}

function formatCommodity(commodity) {
  const names = {
    'feeder_steer': 'Feeder Steers',
    'feeder_heifer': 'Feeder Heifers',
    'calf': 'Calves',
    'slaughter_cow': 'Slaughter Cows',
    'slaughter_bull': 'Slaughter Bulls'
  };
  return names[commodity] || commodity;
}

function detectIntent(message, parsed) {
  const msgLower = message.toLowerCase();
  
  // Task creation keywords
  if (/\b(remind|task|todo|checklist|need to|don't forget)\b/.test(msgLower)) {
    return { action: 'create_task', entities: parsed.entities };
  }
  
  // Note creation
  if (/\b(note|write down|record that|make a note)\b/.test(msgLower) && !/expense|revenue|cost|\$/.test(msgLower)) {
    return { action: 'create_note', entities: parsed.entities };
  }
  
  // Expense
  if ((/-\$\d+/.test(message) || /\bexpense|cost|paid|spent|bought\b/.test(msgLower)) && !/(revenue|income|sale)/.test(msgLower)) {
    return { action: 'create_expense', entities: parsed.entities };
  }
  
  // Revenue
  if ((/\+\$\d+/.test(message) || /\brevenue|income|sale|sold\b/.test(msgLower)) && !/expense|cost/.test(msgLower)) {
    return { action: 'create_revenue', entities: parsed.entities };
  }
  
  // Health record
  if (/\b(health record|vaccin|treat|medication|vet|doctor|inject|dose)\b/.test(msgLower) && /\b(add|create|record|log)\b/.test(msgLower)) {
    return { action: 'create_health_record', entities: parsed.entities };
  }
  
  // Pasture movement
  if (/\b(move|moved|transfer|relocate)\b/.test(msgLower) && (parsed.entities.some(e => e.type === 'animal') || parsed.entities.some(e => e.type === 'pasture'))) {
    return { action: 'move_animals', entities: parsed.entities };
  }
  
  // Breeding record
  if (/\b(breed|bred|ai|artificial insemination|bull|exposed|breeding)\b/.test(msgLower) && /\b(record|log|mark)\b/.test(msgLower)) {
    return { action: 'create_breeding_record', entities: parsed.entities };
  }
  
  return { action: 'query', entities: parsed.entities };
}

async function prepareActionProposal(intent, parsed, base44, ranchId, user) {
  const proposal = {
    action: intent.action,
    data: {},
    confirmationMessage: ''
  };
  
  switch (intent.action) {
    case 'create_task':
      return await prepareTaskProposal(parsed, base44, ranchId, user);
    case 'create_note':
      return await prepareNoteProposal(parsed, base44, ranchId, user);
    case 'create_expense':
      return await prepareExpenseProposal(parsed, base44, ranchId);
    case 'create_revenue':
      return await prepareRevenueProposal(parsed, base44, ranchId);
    case 'create_health_record':
      return await prepareHealthRecordProposal(parsed, base44, ranchId);
    case 'move_animals':
      return await preparePastureMovementProposal(parsed, base44, ranchId);
    case 'create_breeding_record':
      return await prepareBreedingRecordProposal(parsed, base44, ranchId);
  }
  
  return proposal;
}

async function prepareTaskProposal(parsed, base44, ranchId, user) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  const pastures = parsed.entities.filter(e => e.type === 'pasture');
  
  // Extract title from message (simplified)
  const title = "Task"; // Will be improved with AI
  
  const data = {
    ranch_id: ranchId,
    title,
    related_animal_id: animals[0]?.id || null,
    related_animal_name: animals[0]?.data?.name || null,
    related_pasture_id: pastures[0]?.id || null,
    related_pasture_name: pastures[0]?.data?.name || null,
    due_date: new Date().toISOString().split('T')[0],
    priority: 'Medium',
    status: 'Pending'
  };
  
  return {
    action: 'create_task',
    data,
    confirmationMessage: `I can create this task:\n\n**${title}**\n${animals[0] ? `Animal: #${animals[0].data.tag_number}` : ''}\n${pastures[0] ? `Pasture: ~${pastures[0].data.name}` : ''}\nDue: ${data.due_date}\n\nProceed?`
  };
}

async function prepareNoteProposal(parsed, base44, ranchId, user) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  
  // Note entity requires animal_id, note_text, and created_by_name
  if (!animals[0]) {
    return {
      action: 'create_note',
      data: null,
      confirmationMessage: `Notes must be associated with an animal. Please specify which animal using #tag_number.`
    };
  }
  
  const data = {
    ranch_id: ranchId,
    animal_id: animals[0].id,
    animal_name: animals[0].data.name || animals[0].data.tag_number,
    note_text: "General note", // Will be extracted from message
    created_by_name: user.full_name
  };
  
  return {
    action: 'create_note',
    data,
    confirmationMessage: `I can create this note:\n\nFor: #${animals[0].data.tag_number} ${animals[0].data.name || ''}\n\nProceed?`
  };
}

async function prepareExpenseProposal(parsed, base44, ranchId) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  const amount = parsed.amounts.find(a => a.startsWith('-') || !a.startsWith('+'));
  const amountValue = amount ? Math.abs(parseFloat(amount.replace(/[^\d.-]/g, ''))) : 0;
  const category = parsed.categories[0]?.slice(1) || 'Other';
  
  const data = {
    ranch_id: ranchId,
    date: new Date().toISOString().split('T')[0],
    category: category.charAt(0).toUpperCase() + category.slice(1),
    description: `${category} expense`,
    amount: amountValue,
    animal_id: animals[0]?.id || null,
    animal_name: animals[0]?.data?.name || null
  };
  
  return {
    action: 'create_expense',
    data,
    confirmationMessage: `I can record this expense:\n\n**Amount:** -$${amountValue}\n**Category:** ${data.category}\n${animals[0] ? `**Animal:** #${animals[0].data.tag_number}` : ''}\n**Date:** ${data.date}\n\nProceed?`
  };
}

async function prepareRevenueProposal(parsed, base44, ranchId) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  const amount = parsed.amounts.find(a => a.startsWith('+') || !a.startsWith('-'));
  const amountValue = amount ? Math.abs(parseFloat(amount.replace(/[^\d.+]/g, ''))) : 0;
  
  const data = {
    ranch_id: ranchId,
    date: new Date().toISOString().split('T')[0],
    category: 'Cattle Sale',
    description: 'Sale',
    amount: amountValue,
    animal_id: animals[0]?.id || null,
    animal_name: animals[0]?.data?.name || null
  };
  
  return {
    action: 'create_revenue',
    data,
    confirmationMessage: `I can record this revenue:\n\n**Amount:** +$${amountValue}\n**Category:** ${data.category}\n${animals[0] ? `**Animal:** #${animals[0].data.tag_number}` : ''}\n**Date:** ${data.date}\n\nProceed?`
  };
}

async function prepareHealthRecordProposal(parsed, base44, ranchId) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  
  const data = {
    ranch_id: ranchId,
    animal_id: animals[0]?.id,
    animal_name: animals[0]?.data?.name || animals[0]?.data?.tag_number,
    record_type: 'Treatment',
    date: new Date().toISOString().split('T')[0],
    description: 'Health record',
    status: 'Completed'
  };
  
  return {
    action: 'create_health_record',
    data,
    confirmationMessage: `I can create this health record:\n\n**Animal:** #${animals[0]?.data.tag_number}\n**Type:** ${data.record_type}\n**Date:** ${data.date}\n\nProceed?`
  };
}

async function preparePastureMovementProposal(parsed, base44, ranchId) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  const pastures = parsed.entities.filter(e => e.type === 'pasture');
  
  const data = {
    ranch_id: ranchId,
    animal_ids: animals.map(a => a.id),
    from_pasture: null,
    to_pasture: pastures[0]?.id,
    to_pasture_name: pastures[0]?.data.name,
    date: new Date().toISOString().split('T')[0]
  };
  
  return {
    action: 'move_animals',
    data,
    confirmationMessage: `I can move these animals:\n\n**Animals:** ${animals.map(a => `#${a.data.tag_number}`).join(', ')}\n**To:** ~${pastures[0]?.data.name}\n**Date:** ${data.date}\n\nProceed?`
  };
}

async function prepareBreedingRecordProposal(parsed, base44, ranchId) {
  const animals = parsed.entities.filter(e => e.type === 'animal');
  
  const data = {
    ranch_id: ranchId,
    animal_id: animals[0]?.id,
    animal_name: animals[0]?.data?.name || animals[0]?.data?.tag_number,
    record_type: 'Service',
    breeding_date: new Date().toISOString().split('T')[0],
    breeding_method: 'Natural',
    status: 'Breeding'
  };
  
  return {
    action: 'create_breeding_record',
    data,
    confirmationMessage: `I can create this breeding record:\n\n**Animal:** #${animals[0]?.data.tag_number}\n**Method:** ${data.breeding_method}\n**Date:** ${data.breeding_date}\n\nProceed?`
  };
}

function generateDeepLinks(parsed) {
  const links = [];

  for (const entity of parsed.entities) {
    if (entity.type === 'animal') {
      links.push({
        label: `View ${entity.data.name || entity.data.tag_number}`,
        url: `/AnimalProfile?id=${entity.id}`
      });
    } else if (entity.type === 'pasture') {
      links.push({
        label: `View ${entity.data.name}`,
        url: `/PastureProfile?id=${entity.id}`
      });
    }
  }

  if (parsed.categories.length > 0) {
    links.push({
      label: 'View Expenses',
      url: '/Expenses'
    });
  }

  if (parsed.metrics.length > 0) {
    links.push({
      label: 'View Reports',
      url: '/Reports'
    });
  }

  return links;
}