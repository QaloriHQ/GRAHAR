import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

/**
 * Scheduled Market Data Sync
 * 
 * This function should be called by a scheduler (e.g., cron job, platform scheduler)
 * every 6 hours to keep market data fresh.
 * 
 * Setup Instructions:
 * 1. Configure your scheduler to POST to this endpoint every 6 hours
 * 2. Include header: X-Scheduled-Task: true
 * 3. Use service role authentication or configure API key
 */

Deno.serve(async (req) => {
  try {
    // Verify this is a scheduled task
    const scheduledHeader = req.headers.get('X-Scheduled-Task');
    const apiKey = req.headers.get('X-API-Key');
    const expectedApiKey = Deno.env.get('SCHEDULED_TASK_API_KEY');

    if (scheduledHeader !== 'true' && apiKey !== expectedApiKey) {
      return Response.json({ error: 'Unauthorized - scheduled task only' }, { status: 401 });
    }

    console.log(`[${new Date().toISOString()}] Starting scheduled market data sync...`);

    // Call the sync function with service role
    const syncUrl = `${req.url.split('/scheduledMarketSync')[0]}/syncUSDAAmsMarketData`;
    
    const syncResponse = await fetch(syncUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Scheduled-Task': 'true'
      },
      body: JSON.stringify({
        regions: ['Arkansas', 'Texas', 'Oklahoma', 'Missouri', 'Kansas', 'Nebraska']
      })
    });

    const syncResult = await syncResponse.json();

    console.log(`[${new Date().toISOString()}] Sync completed:`, syncResult);

    return Response.json({
      success: true,
      timestamp: new Date().toISOString(),
      syncResult
    });
  } catch (error) {
    console.error('Scheduled sync error:', error);
    return Response.json({ 
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
});