import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');

Deno.serve(async (req) => {
    try {
        const signature = req.headers.get('stripe-signature');
        const body = await req.text();

        if (!signature) {
            return Response.json({ error: 'No signature' }, { status: 400 });
        }

        // Initialize base44 with service role for webhook operations
        const base44 = createClientFromRequest(req);
        
        // Verify webhook signature
        let event;
        try {
            event = await stripe.webhooks.constructEventAsync(
                body,
                signature,
                webhookSecret
            );
        } catch (err) {
            console.error('Webhook signature verification failed:', err.message);
            return Response.json({ error: 'Invalid signature' }, { status: 400 });
        }

        console.log('Webhook event type:', event.type);

        // Handle different event types
        switch (event.type) {
            case 'checkout.session.completed': {
                const session = event.data.object;
                const ranchId = session.metadata.ranch_id;
                const planName = session.metadata.plan_name;

                if (ranchId) {
                    await base44.asServiceRole.entities.Ranch.update(ranchId, {
                        subscription_plan: planName,
                        subscription_status: 'Active',
                        stripe_subscription_id: session.subscription,
                        subscription_start_date: new Date().toISOString().split('T')[0]
                    });
                    console.log(`Ranch ${ranchId} subscribed to ${planName}`);
                }
                break;
            }

            case 'customer.subscription.updated': {
                const subscription = event.data.object;
                const customerId = subscription.customer;

                // Find ranch by customer ID
                const ranches = await base44.asServiceRole.entities.Ranch.filter({ 
                    stripe_customer_id: customerId 
                });

                if (ranches.length > 0) {
                    const ranch = ranches[0];
                    const status = subscription.status === 'active' ? 'Active' : 
                                 subscription.status === 'canceled' ? 'Cancelled' : 
                                 subscription.status === 'past_due' ? 'Expired' : 'Active';

                    const endDate = new Date(subscription.current_period_end * 1000).toISOString().split('T')[0];

                    await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                        subscription_status: status,
                        subscription_end_date: endDate
                    });
                    console.log(`Ranch ${ranch.id} subscription updated: ${status}`);
                }
                break;
            }

            case 'customer.subscription.deleted': {
                const subscription = event.data.object;
                const customerId = subscription.customer;

                // Find ranch by customer ID
                const ranches = await base44.asServiceRole.entities.Ranch.filter({ 
                    stripe_customer_id: customerId 
                });

                if (ranches.length > 0) {
                    const ranch = ranches[0];
                    await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                        subscription_plan: 'Free',
                        subscription_status: 'Cancelled',
                        stripe_subscription_id: null
                    });
                    console.log(`Ranch ${ranch.id} subscription cancelled, reverted to Free plan`);
                }
                break;
            }

            case 'invoice.payment_failed': {
                const invoice = event.data.object;
                const customerId = invoice.customer;

                // Find ranch by customer ID
                const ranches = await base44.asServiceRole.entities.Ranch.filter({ 
                    stripe_customer_id: customerId 
                });

                if (ranches.length > 0) {
                    const ranch = ranches[0];
                    await base44.asServiceRole.entities.Ranch.update(ranch.id, {
                        subscription_status: 'Expired'
                    });
                    console.log(`Ranch ${ranch.id} payment failed`);
                }
                break;
            }

            default:
                console.log(`Unhandled event type: ${event.type}`);
        }

        return Response.json({ received: true });

    } catch (error) {
        console.error('Webhook handler error:', error);
        return Response.json({ error: error.message }, { status: 500 });
    }
});