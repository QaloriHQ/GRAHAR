import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';
import { createHash } from 'node:crypto';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
    try {
        console.log('=== Bank Transaction Sync Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json();
        const { connection_id } = body;

        if (!connection_id) {
            return Response.json({ error: 'connection_id required' }, { status: 400 });
        }

        console.log('Syncing connection:', connection_id);

        // Get connection
        const connections = await base44.asServiceRole.entities.BankConnection.filter({ 
            id: connection_id
        });
        const connection = connections[0];

        if (!connection) {
            return Response.json({ error: 'Connection not found' }, { status: 404 });
        }

        console.log('Found connection:', connection.institution_name);
        console.log('Stripe FC Account ID:', connection.stripe_fincon_account_id);

        // Fetch transactions from Stripe
        console.log('Fetching transactions from Stripe...');
        let transactions;
        try {
            transactions = await stripe.financialConnections.transactions.list({
                account: connection.stripe_fincon_account_id,
                limit: 100,
            });
            console.log(`✅ Found ${transactions.data.length} transactions from Stripe`);
        } catch (stripeError) {
            console.error('❌ Failed to fetch transactions from Stripe:', stripeError.message);
            
            // Check if this is the "no transactions" error
            if (stripeError.message && stripeError.message.includes('no transactions to retrieve')) {
                console.log('ℹ️ No transactions available yet - this is normal for new connections');
                
                // Update last sync time anyway
                await base44.asServiceRole.entities.BankConnection.update(connection.id, {
                    last_sync_at: new Date().toISOString()
                });
                
                return Response.json({ 
                    success: true,
                    message: 'No transactions available yet. Stripe is still processing your account data. Please try again in a few minutes.',
                    new_transactions: 0,
                    skipped: 0,
                    errors: 0
                });
            }
            
            // For other errors, return error response
            return Response.json({ 
                error: `Failed to fetch transactions: ${stripeError.message}` 
            }, { status: 500 });
        }

        let newCount = 0;
        let skippedCount = 0;
        let errorCount = 0;

        for (const txn of transactions.data) {
            try {
                // Create hash for deduplication
                const hashData = `${txn.posted_at || txn.transacted_at}-${txn.amount}-${txn.description}-${connection.id}`;
                const hash = createHash('sha256').update(hashData).digest('hex');

                // Check if transaction already exists
                const existing = await base44.asServiceRole.entities.BankTransaction.filter({
                    ranch_id: connection.ranch_id,
                    transaction_hash: hash
                });

                if (existing.length > 0) {
                    skippedCount++;
                    continue;
                }

                // Determine amount (Stripe stores in cents, convert to dollars)
                const amount = txn.amount / 100;

                // Auto-categorize based on description
                let category = 'Other';
                if (txn.description) {
                    const desc = txn.description.toLowerCase();
                    if (desc.includes('feed') || desc.includes('hay')) category = 'Feed';
                    else if (desc.includes('vet') || desc.includes('veterinary')) category = 'Veterinary';
                    else if (desc.includes('livestock') || desc.includes('cattle')) {
                        category = amount > 0 ? 'Cattle Sale' : 'Feed';
                    }
                    else if (desc.includes('equipment') || desc.includes('tractor')) category = 'Equipment';
                    else if (desc.includes('fuel') || desc.includes('gas')) category = 'Transportation';
                }

                // Create bank transaction record
                await base44.asServiceRole.entities.BankTransaction.create({
                    ranch_id: connection.ranch_id,
                    connection_id: connection.id,
                    stripe_transaction_id: txn.id,
                    posted_at: txn.posted_at || txn.transacted_at,
                    amount: amount,
                    currency: txn.currency,
                    description: txn.description,
                    merchant_name: txn.merchant_name || null,
                    category: category,
                    status: txn.status || 'posted',
                    import_state: 'new',
                    transaction_hash: hash
                });

                newCount++;
            } catch (txnError) {
                console.error(`❌ Failed to create transaction ${txn.id}:`, txnError.message);
                errorCount++;
            }
        }

        // Update last sync time
        await base44.asServiceRole.entities.BankConnection.update(connection.id, {
            last_sync_at: new Date().toISOString()
        });

        console.log('=== Sync Complete ===');
        console.log(`✅ Created: ${newCount} transactions`);
        console.log(`⏭️  Skipped: ${skippedCount} duplicates`);
        if (errorCount > 0) {
            console.log(`❌ Errors: ${errorCount}`);
        }

        return Response.json({ 
            success: true,
            new_transactions: newCount,
            skipped: skippedCount,
            errors: errorCount
        });

    } catch (error) {
        console.error('=== Sync Error ===');
        console.error('Error:', error.message);
        console.error('Stack:', error.stack);
        return Response.json({ 
            error: `Sync failed: ${error.message}` 
        }, { status: 500 });
    }
});