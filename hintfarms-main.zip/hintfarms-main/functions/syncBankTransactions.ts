import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';
import Stripe from 'npm:stripe@14.11.0';
import { createHash } from 'node:crypto';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
    const syncStartTime = new Date();
    let historyRecord = null;
    
    try {
        console.log('=== Bank Transaction Sync Started ===');
        
        const base44 = createClientFromRequest(req);
        
        // Parse request body to get parameters
        const body = await req.json();
        const { connection_id, bank_sync_id, ranch_id } = body;

        console.log('📊 Sync run ID:', bank_sync_id);
        console.log('Connection ID:', connection_id);
        console.log('Ranch ID from request:', ranch_id);

        if (!connection_id) {
            return Response.json({ error: 'connection_id required' }, { status: 400 });
        }

        if (!bank_sync_id) {
            return Response.json({ error: 'bank_sync_id required' }, { status: 400 });
        }

        // Determine ranch context - either from explicit parameter (webhook) or from authenticated user
        let ACTIVE_RANCH_ID = ranch_id;

        if (!ACTIVE_RANCH_ID) {
            // Called by user - authenticate and get ranch from user context
            try {
                const user = await base44.auth.me();
                if (!user || !user.active_ranch_id) {
                    console.error('No authenticated user or active ranch.');
                    return Response.json({ error: 'Unauthorized' }, { status: 401 });
                }
                ACTIVE_RANCH_ID = user.active_ranch_id;
                console.log('🔒 Using user active ranch context:', ACTIVE_RANCH_ID);
            } catch (authError) {
                console.error('Authentication failed:', authError);
                return Response.json({ error: 'Unauthorized' }, { status: 401 });
            }
        } else {
            // Called by webhook with explicit ranch_id
            console.log('🔒 Using webhook ranch context:', ACTIVE_RANCH_ID);
        }

        console.log('Syncing connection:', connection_id);

        // Get connection - validate it belongs to the ranch
        const connections = await base44.asServiceRole.entities.BankConnection.filter({ 
            id: connection_id,
            ranch_id: ACTIVE_RANCH_ID  // 🔒 Security: ensure connection belongs to this ranch
        });
        const connection = connections[0];

        if (!connection) {
            console.error('Connection not found or does not belong to ranch:', ACTIVE_RANCH_ID);
            return Response.json({ error: 'Connection not found or access denied' }, { status: 404 });
        }

        console.log('Found connection:', connection.institution_name);
        console.log('Stripe FC Account ID:', connection.stripe_fincon_account_id);

        // Create sync history record
        historyRecord = await base44.asServiceRole.entities.BankSyncHistory.create({
            ranch_id: ACTIVE_RANCH_ID,
            connection_id: connection.id,
            institution_name: connection.institution_name,
            account_type: connection.account_type,
            account_last4: connection.account_last4,
            sync_started_at: syncStartTime.toISOString(),
            status: 'success',
            transactions_new: 0,
            transactions_skipped: 0,
            transactions_errors: 0
        });

        // Fetch transactions from Stripe
        console.log('Fetching transactions from Stripe...');
        let transactions;
        try {
            transactions = await stripe.financialConnections.transactions.list({
                account: connection.stripe_fincon_account_id,
                limit: 100,
            });
            console.log(`✅ Found ${transactions.data.length} transactions from Stripe`);
        } catch (stripeError) {
            console.error('❌ Failed to fetch transactions from Stripe:', stripeError.message);
            
            if (stripeError.message && stripeError.message.includes('no transactions to retrieve')) {
                console.log('ℹ️ No transactions available yet - this is normal for new connections');
                
                await base44.asServiceRole.entities.BankConnection.update(connection.id, {
                    last_sync_at: new Date().toISOString(),
                    last_sync_run_id: bank_sync_id
                });

                // Update history record
                if (historyRecord) {
                    await base44.asServiceRole.entities.BankSyncHistory.update(historyRecord.id, {
                        sync_completed_at: new Date().toISOString(),
                        status: 'success',
                        transactions_new: 0,
                        transactions_skipped: 0,
                        transactions_errors: 0
                    });
                }
                
                return Response.json({ 
                    success: true,
                    message: 'No transactions available yet. Stripe is still processing your account data. Please try again in a few minutes.',
                    new_transactions: 0,
                    skipped: 0,
                    errors: 0
                });
            }
            
            // Update history record with failure
            if (historyRecord) {
                await base44.asServiceRole.entities.BankSyncHistory.update(historyRecord.id, {
                    sync_completed_at: new Date().toISOString(),
                    status: 'failed',
                    error_message: stripeError.message
                });
            }
            
            return Response.json({ 
                error: `Failed to fetch transactions: ${stripeError.message}` 
            }, { status: 500 });
        }

        let newCount = 0;
        let skippedCount = 0;
        let errorCount = 0;

        for (const txn of transactions.data) {
            try {
                // Create hash for deduplication
                const hashData = `${txn.posted_at || txn.transacted_at}-${txn.amount}-${txn.description}-${connection.id}`;
                const hash = createHash('sha256').update(hashData).digest('hex');

                // Check if transaction already exists
                const existing = await base44.asServiceRole.entities.BankTransaction.filter({
                    ranch_id: ACTIVE_RANCH_ID,  // 🔒 Use active ranch ID
                    transaction_hash: hash
                });

                if (existing.length > 0) {
                    skippedCount++;
                    continue;
                }

                // Determine amount (Stripe stores in cents, convert to dollars)
                const amount = txn.amount / 100;

                // Auto-categorize based on description
                let category = 'Other';
                if (txn.description) {
                    const desc = txn.description.toLowerCase();
                    if (desc.includes('feed') || desc.includes('hay')) category = 'Feed';
                    else if (desc.includes('vet') || desc.includes('veterinary')) category = 'Veterinary';
                    else if (desc.includes('livestock') || desc.includes('cattle')) {
                        category = amount > 0 ? 'Cattle Sale' : 'Feed';
                    }
                    else if (desc.includes('equipment') || desc.includes('tractor')) category = 'Equipment';
                    else if (desc.includes('fuel') || desc.includes('gas')) category = 'Transportation';
                }

                // Create bank transaction record with active ranch ID and sync ID
                await base44.asServiceRole.entities.BankTransaction.create({
                    ranch_id: ACTIVE_RANCH_ID,  // 🔒 Use active ranch ID
                    connection_id: connection.id,
                    sync_run_id: bank_sync_id,  // 📊 Track sync run
                    stripe_transaction_id: txn.id,
                    posted_at: txn.posted_at || txn.transacted_at,
                    amount: amount,
                    currency: txn.currency,
                    description: txn.description,
                    merchant_name: txn.merchant_name || null,
                    category: category,
                    status: txn.status || 'posted',
                    import_state: 'new',
                    transaction_hash: hash
                });

                newCount++;
            } catch (txnError) {
                console.error(`❌ [sync_id:${bank_sync_id}] Failed to create transaction ${txn.id}:`, txnError.message);
                errorCount++;
            }
        }

        // Update last sync time with sync run ID
        await base44.asServiceRole.entities.BankConnection.update(connection.id, {
            last_sync_at: new Date().toISOString(),
            last_sync_run_id: bank_sync_id  // 📊 Track sync run
        });

        console.log(`=== [sync_id:${bank_sync_id}] Sync Complete ===`);
        console.log(`✅ Created: ${newCount} transactions`);
        console.log(`⏭️  Skipped: ${skippedCount} duplicates`);
        if (errorCount > 0) {
            console.log(`❌ Errors: ${errorCount}`);
        }

        // Update history record with final counts
        if (historyRecord) {
            const syncStatus = errorCount > 0 && newCount === 0 ? 'failed' : 
                               errorCount > 0 ? 'partial' : 'success';
            
            await base44.asServiceRole.entities.BankSyncHistory.update(historyRecord.id, {
                sync_completed_at: new Date().toISOString(),
                status: syncStatus,
                transactions_new: newCount,
                transactions_skipped: skippedCount,
                transactions_errors: errorCount
            });
        }

        return Response.json({ 
            success: true,
            new_transactions: newCount,
            skipped: skippedCount,
            errors: errorCount,
            sync_run_id: bank_sync_id
        });

    } catch (error) {
        console.error('=== Sync Error ===');
        console.error('Error:', error.message);
        console.error('Stack:', error.stack);

        // Update history record with failure
        if (historyRecord) {
            try {
                const base44 = createClientFromRequest(req);
                await base44.asServiceRole.entities.BankSyncHistory.update(historyRecord.id, {
                    sync_completed_at: new Date().toISOString(),
                    status: 'failed',
                    error_message: error.message
                });
            } catch (updateError) {
                console.error('Failed to update history record:', updateError.message);
            }
        }

        return Response.json({ 
            error: `Sync failed: ${error.message}` 
        }, { status: 500 });
    }
});