import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'), {
    apiVersion: '2023-10-16',
});

Deno.serve(async (req) => {
    try {
        console.log('=== Manual Bank Connection Sync Started ===');
        
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        if (!user.ranch_id) {
            return Response.json({ error: 'No ranch associated' }, { status: 400 });
        }

        console.log('User:', user.email, 'Ranch:', user.ranch_id);

        // Get ranch
        const ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
        const ranch = ranches[0];

        if (!ranch || !ranch.stripe_customer_id) {
            return Response.json({ error: 'No Stripe customer found for ranch' }, { status: 404 });
        }

        console.log('Ranch:', ranch.name, 'Customer:', ranch.stripe_customer_id);

        // List all Financial Connections accounts for this customer
        console.log('Fetching Financial Connections accounts from Stripe...');
        const accounts = await stripe.financialConnections.accounts.list({
            account_holder: {
                customer: ranch.stripe_customer_id
            }
        });

        console.log(`Found ${accounts.data.length} Financial Connections accounts`);

        let created = 0;
        let updated = 0;
        let errors = 0;

        for (const account of accounts.data) {
            try {
                console.log(`Processing account: ${account.id} - ${account.institution_name}`);
                
                // Retrieve full account details to get balance
                const fullAccount = await stripe.financialConnections.accounts.retrieve(account.id);
                console.log('Full account data:', JSON.stringify(fullAccount, null, 2));
                console.log('Account balance object:', fullAccount.balance);

                // Check if connection already exists
                const existing = await base44.asServiceRole.entities.BankConnection.filter({
                    stripe_fincon_account_id: account.id
                });

                // Convert balance from cents to dollars
                let balanceInDollars = 0;
                if (fullAccount.balance?.current !== undefined && fullAccount.balance?.current !== null) {
                    balanceInDollars = fullAccount.balance.current / 100;
                } else if (fullAccount.balance?.cash !== undefined && fullAccount.balance?.cash !== null) {
                    balanceInDollars = fullAccount.balance.cash / 100;
                } else if (fullAccount.balance?.available !== undefined && fullAccount.balance?.available !== null) {
                    balanceInDollars = fullAccount.balance.available / 100;
                }

                console.log(`Calculated balance: $${balanceInDollars} ${fullAccount.balance?.currency || 'usd'}`);

                const connectionData = {
                    ranch_id: ranch.id,
                    stripe_customer_id: ranch.stripe_customer_id,
                    stripe_fincon_account_id: account.id,
                    institution_name: account.institution_name,
                    account_last4: account.last4 || null,
                    account_type: account.subcategory || 'checking',
                    status: account.status === 'active' ? 'active' : 'disconnected',
                    balance: balanceInDollars,
                    currency: fullAccount.balance?.currency || 'usd',
                    data_scopes: account.permissions || [],
                    sync_enabled: true,
                    last_sync_at: new Date().toISOString()
                };

                console.log('Connection data to save:', JSON.stringify(connectionData, null, 2));

                if (existing.length > 0) {
                    // Update existing
                    await base44.asServiceRole.entities.BankConnection.update(
                        existing[0].id,
                        connectionData
                    );
                    console.log(`✅ Updated connection: ${existing[0].id} with balance: $${balanceInDollars}`);
                    updated++;
                } else {
                    // Create new
                    const connection = await base44.asServiceRole.entities.BankConnection.create(connectionData);
                    console.log(`✅ Created connection: ${connection.id} with balance: $${balanceInDollars}`);
                    created++;

                    // Trigger transaction sync for this connection
                    try {
                        console.log(`Triggering transaction sync for connection ${connection.id}...`);
                        await base44.asServiceRole.functions.invoke('syncBankTransactions', {
                            connection_id: connection.id
                        });
                        console.log(`✅ Transaction sync completed for ${connection.id}`);
                    } catch (syncError) {
                        console.error(`❌ Failed to sync transactions: ${syncError.message}`);
                    }
                }
            } catch (accountError) {
                console.error(`❌ Failed to process account ${account.id}:`, accountError.message);
                errors++;
            }
        }

        console.log('=== Sync Complete ===');
        console.log(`✅ Created: ${created} connections`);
        console.log(`🔄 Updated: ${updated} connections`);
        if (errors > 0) {
            console.log(`❌ Errors: ${errors}`);
        }

        return Response.json({
            success: true,
            created,
            updated,
            errors,
            total: accounts.data.length
        });

    } catch (error) {
        console.error('=== Sync Error ===');
        console.error('Error:', error.message);
        console.error('Stack:', error.stack);
        return Response.json({
            error: `Sync failed: ${error.message}`
        }, { status: 500 });
    }
});