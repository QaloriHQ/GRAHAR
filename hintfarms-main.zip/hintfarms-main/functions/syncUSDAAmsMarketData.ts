import { createClientFromRequest } from 'npm:@base44/sdk@0.8.4';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Allow scheduled/automated calls without user auth
    const isScheduledRun = req.headers.get('X-Scheduled-Task') === 'true';
    
    if (!isScheduledRun) {
      const user = await base44.auth.me();
      if (!user || user.role !== 'admin') {
        return Response.json({ error: 'Unauthorized - admin only' }, { status: 401 });
      }
    }

    const USDA_API_KEY = Deno.env.get('USDA_AMS_API_KEY');
    const USDA_BASE_URL = Deno.env.get('USDA_AMS_BASE_URL') || 'https://marsapi.ams.usda.gov/services/v1.2/';

    if (!USDA_API_KEY) {
      console.error('USDA_AMS_API_KEY not configured');
      return Response.json({ 
        success: false,
        error: 'USDA API key not configured. Please set USDA_AMS_API_KEY in environment variables.' 
      }, { status: 500 });
    }

    const body = req.method === 'POST' ? await req.json() : {};
    const { regions = ['Arkansas', 'Texas', 'Oklahoma', 'Missouri'] } = body;

    let totalInserted = 0;
    let totalUpdated = 0;
    const errors = [];

    for (const region of regions) {
      try {
        // Fetch cattle reports from USDA AMS
        const reportUrl = `${USDA_BASE_URL}reports?q=report_title:cattle AND state:${region}&api_key=${USDA_API_KEY}`;
        
        const response = await fetch(reportUrl, {
          headers: {
            'Accept': 'application/json'
          },
          timeout: 30000 // 30 second timeout
        });
        
        if (!response.ok) {
          const errorDetail = response.status === 401 ? 'Invalid API key' : 
                             response.status === 429 ? 'Rate limit exceeded' :
                             response.status === 404 ? 'Endpoint not found' :
                             response.statusText;
          errors.push(`Failed to fetch ${region}: ${errorDetail} (${response.status})`);
          console.error(`USDA AMS API error for ${region}:`, errorDetail);
          continue;
        }

        const data = await response.json();
        
        if (!data.results || !Array.isArray(data.results)) {
          continue;
        }

        for (const report of data.results) {
          try {
            // Store raw payload
            await base44.asServiceRole.entities.MarketInsightsSource.create({
              provider: 'USDA_AMS',
              raw_market_id: report.slug_id || report.report_title,
              raw_payload: report,
              fetched_at: new Date().toISOString()
            });

            // Parse and normalize prices
            const prices = parseUSDAAmsReport(report, region);
            
            for (const priceData of prices) {
              // Check if exists (idempotency)
              const existing = await base44.asServiceRole.entities.MarketInsightsPrice.filter({
                market_name: priceData.market_name,
                sale_date: priceData.sale_date,
                commodity_type: priceData.commodity_type,
                weight_min: priceData.weight_min,
                weight_max: priceData.weight_max
              });

              if (existing.length > 0) {
                // Update
                await base44.asServiceRole.entities.MarketInsightsPrice.update(existing[0].id, priceData);
                totalUpdated++;
              } else {
                // Create
                await base44.asServiceRole.entities.MarketInsightsPrice.create(priceData);
                totalInserted++;
              }
            }
          } catch (reportError) {
            errors.push(`Error processing report ${report.slug_id}: ${reportError.message}`);
          }
        }
      } catch (regionError) {
        errors.push(`Error processing region ${region}: ${regionError.message}`);
      }
    }

    return Response.json({
      success: true,
      totalInserted,
      totalUpdated,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ 
      success: false,
      error: error.message 
    }, { status: 500 });
  }
});

function parseUSDAAmsReport(report, region) {
  const prices = [];
  
  try {
    // Extract market name
    const marketName = report.market_name || report.office || 'Unknown Market';
    const saleDate = report.published_date || report.report_date || new Date().toISOString().split('T')[0];
    const reportDate = report.published_date || new Date().toISOString().split('T')[0];
    
    // Parse report sections for cattle prices
    if (report.sections && Array.isArray(report.sections)) {
      for (const section of report.sections) {
        if (section.tables && Array.isArray(section.tables)) {
          for (const table of section.tables) {
            if (table.rows && Array.isArray(table.rows)) {
              for (const row of table.rows) {
                const parsed = parseRow(row, marketName, saleDate, reportDate, region, report.market_code);
                if (parsed) {
                  prices.push(parsed);
                }
              }
            }
          }
        }
      }
    }
  } catch (error) {
    console.error('Parse error:', error);
  }
  
  return prices;
}

function parseRow(row, marketName, saleDate, reportDate, region, marketCode) {
  try {
    // Typical USDA AMS row structure: commodity, weight range, head count, price range
    const commodity = detectCommodityType(row);
    if (!commodity) return null;
    
    const { weightMin, weightMax, avgWeight } = extractWeightRange(row);
    if (!weightMin || !weightMax) return null;
    
    const { priceLow, priceHigh, priceAvg } = extractPriceRange(row);
    if (!priceAvg) return null;
    
    return {
      region,
      market_name: marketName,
      market_code: marketCode || '',
      commodity_type: commodity,
      weight_min: weightMin,
      weight_max: weightMax,
      avg_weight: avgWeight || (weightMin + weightMax) / 2,
      price_per_cwt: priceAvg,
      price_low: priceLow || priceAvg,
      price_high: priceHigh || priceAvg,
      currency: 'USD',
      sale_date: saleDate,
      report_date: reportDate,
      provider: 'USDA_AMS'
    };
  } catch (error) {
    return null;
  }
}

function detectCommodityType(row) {
  const text = JSON.stringify(row).toLowerCase();
  
  if (text.includes('feeder steer') || text.includes('steer calf')) return 'feeder_steer';
  if (text.includes('feeder heifer') || text.includes('heifer calf')) return 'feeder_heifer';
  if (text.includes('slaughter cow')) return 'slaughter_cow';
  if (text.includes('slaughter bull')) return 'slaughter_bull';
  if (text.includes('replacement heifer')) return 'replacement_heifer';
  if (text.includes('calf') || text.includes('calves')) return 'calf';
  
  return null;
}

function extractWeightRange(row) {
  // Look for weight patterns like "500-600 lbs" or "500-600"
  const text = JSON.stringify(row);
  const weightMatch = text.match(/(\d{3,4})\s*-\s*(\d{3,4})/);
  
  if (weightMatch) {
    return {
      weightMin: parseInt(weightMatch[1]),
      weightMax: parseInt(weightMatch[2]),
      avgWeight: (parseInt(weightMatch[1]) + parseInt(weightMatch[2])) / 2
    };
  }
  
  return { weightMin: null, weightMax: null, avgWeight: null };
}

function extractPriceRange(row) {
  // Look for price patterns like "$150-$175" or "150.00-175.00"
  const text = JSON.stringify(row);
  const priceMatch = text.match(/\$?(\d{2,3}\.?\d{0,2})\s*-\s*\$?(\d{2,3}\.?\d{0,2})/);
  
  if (priceMatch) {
    const low = parseFloat(priceMatch[1]);
    const high = parseFloat(priceMatch[2]);
    return {
      priceLow: low,
      priceHigh: high,
      priceAvg: (low + high) / 2
    };
  }
  
  // Single price
  const singleMatch = text.match(/\$?(\d{2,3}\.?\d{0,2})/);
  if (singleMatch) {
    const price = parseFloat(singleMatch[1]);
    return {
      priceLow: price,
      priceHigh: price,
      priceAvg: price
    };
  }
  
  return { priceLow: null, priceHigh: null, priceAvg: null };
}