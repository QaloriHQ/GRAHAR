
import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import Stripe from 'npm:stripe@14.11.0';

Deno.serve(async (req) => {
    try {
        console.log('=== Stripe Config Test Started ===');
        
        const base44 = createClientFromRequest(req);
        
        let user;
        try {
            user = await base44.auth.me();
            console.log('User authenticated:', user?.email);
        } catch (authError) {
            console.error('Authentication error:', authError);
            return Response.json({ 
                success: false,
                error: 'Authentication failed',
                checks: [{
                    name: 'User Authentication',
                    status: '❌ FAILED',
                    message: `Could not authenticate user: ${authError.message}`
                }]
            }, { status: 401 });
        }

        if (!user) {
            return Response.json({ 
                success: false,
                error: 'Not authenticated',
                checks: [{
                    name: 'User Authentication',
                    status: '❌ FAILED',
                    message: 'No user session found'
                }]
            }, { status: 401 });
        }

        const results = {
            success: true,
            checks: []
        };

        // Check 1: Stripe Secret Key
        const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
        console.log('Checking STRIPE_SECRET_KEY...');
        
        if (!stripeKey) {
            results.checks.push({
                name: 'STRIPE_SECRET_KEY',
                status: '❌ NOT SET',
                message: 'Please set your Stripe Secret Key in environment secrets'
            });
            results.success = false;
        } else if (!stripeKey.startsWith('sk_test_') && !stripeKey.startsWith('sk_live_')) {
            results.checks.push({
                name: 'STRIPE_SECRET_KEY',
                status: '❌ INVALID FORMAT',
                message: `Key should start with sk_test_ or sk_live_, but starts with: ${stripeKey.substring(0, 10)}...`
            });
            results.success = false;
        } else {
            results.checks.push({
                name: 'STRIPE_SECRET_KEY',
                status: '✅ Valid',
                message: `Using ${stripeKey.startsWith('sk_test_') ? 'TEST' : 'LIVE'} mode`
            });

            // Try to initialize Stripe
            console.log('Testing Stripe API connection...');
            try {
                const stripe = new Stripe(stripeKey);
                await stripe.products.list({ limit: 1 });
                results.checks.push({
                    name: 'Stripe API Connection',
                    status: '✅ Connected',
                    message: 'Successfully connected to Stripe API'
                });
            } catch (error) {
                console.error('Stripe API connection failed:', error);
                results.checks.push({
                    name: 'Stripe API Connection',
                    status: '❌ FAILED',
                    message: `Error: ${error.message}`
                });
                results.success = false;
            }
        }

        // Check 2: PRO Price ID
        console.log('Checking STRIPE_PRO_PRICE_ID...');
        const proPriceId = Deno.env.get('STRIPE_PRO_PRICE_ID');
        if (!proPriceId) {
            results.checks.push({
                name: 'STRIPE_PRO_PRICE_ID',
                status: '❌ NOT SET',
                message: 'Please set your PRO plan price ID'
            });
            results.success = false;
        } else if (!proPriceId.startsWith('price_')) {
            results.checks.push({
                name: 'STRIPE_PRO_PRICE_ID',
                status: '❌ INVALID FORMAT',
                message: `Price ID should start with 'price_' but is: ${proPriceId}`
            });
            results.success = false;
        } else {
            results.checks.push({
                name: 'STRIPE_PRO_PRICE_ID',
                status: '✅ Valid',
                message: `Set to: ${proPriceId}`
            });

            // Try to fetch the price
            if (stripeKey && (stripeKey.startsWith('sk_test_') || stripeKey.startsWith('sk_live_'))) {
                console.log('Validating PRO price in Stripe...');
                try {
                    const stripe = new Stripe(stripeKey);
                    const price = await stripe.prices.retrieve(proPriceId);
                    results.checks.push({
                        name: 'PRO Price Validation',
                        status: '✅ Valid',
                        message: `Found price: $${(price.unit_amount / 100).toFixed(2)}/${price.recurring?.interval || 'one-time'}`
                    });
                } catch (error) {
                    console.error('PRO price validation failed:', error);
                    results.checks.push({
                        name: 'PRO Price Validation',
                        status: '❌ NOT FOUND',
                        message: `Error retrieving price: ${error.message}`
                    });
                    results.success = false;
                }
            }
        }

        // Check 3: Enterprise Price ID
        console.log('Checking STRIPE_ENTERPRISE_PRICE_ID...');
        const entPriceId = Deno.env.get('STRIPE_ENTERPRISE_PRICE_ID');
        if (!entPriceId) {
            results.checks.push({
                name: 'STRIPE_ENTERPRISE_PRICE_ID',
                status: '❌ NOT SET',
                message: 'Please set your Enterprise plan price ID'
            });
            results.success = false;
        } else if (!entPriceId.startsWith('price_')) {
            results.checks.push({
                name: 'STRIPE_ENTERPRISE_PRICE_ID',
                status: '❌ INVALID FORMAT',
                message: `Price ID should start with 'price_' but is: ${entPriceId}`
            });
            results.success = false;
        } else {
            results.checks.push({
                name: 'STRIPE_ENTERPRISE_PRICE_ID',
                status: '✅ Valid',
                message: `Set to: ${entPriceId}`
            });

            // Try to fetch the price
            if (stripeKey && (stripeKey.startsWith('sk_test_') || stripeKey.startsWith('sk_live_'))) {
                console.log('Validating Enterprise price in Stripe...');
                try {
                    const stripe = new Stripe(stripeKey);
                    const price = await stripe.prices.retrieve(entPriceId);
                    results.checks.push({
                        name: 'Enterprise Price Validation',
                        status: '✅ Valid',
                        message: `Found price: $${(price.unit_amount / 100).toFixed(2)}/${price.recurring?.interval || 'one-time'}`
                    });
                } catch (error) {
                    console.error('Enterprise price validation failed:', error);
                    results.checks.push({
                        name: 'Enterprise Price Validation',
                        status: '❌ NOT FOUND',
                        message: `Error retrieving price: ${error.message}`
                    });
                    results.success = false;
                }
            }
        }

        // Check 4: Webhook Secret
        console.log('Checking STRIPE_WEBHOOK_SECRET...');
        const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
        if (!webhookSecret) {
            results.checks.push({
                name: 'STRIPE_WEBHOOK_SECRET',
                status: '⚠️ NOT SET',
                message: 'Webhook secret not set. Webhooks will not work for subscription updates.'
            });
        } else if (!webhookSecret.startsWith('whsec_')) {
            results.checks.push({
                name: 'STRIPE_WEBHOOK_SECRET',
                status: '❌ INVALID FORMAT',
                message: `Webhook secret should start with 'whsec_' but starts with: ${webhookSecret.substring(0, 10)}...`
            });
        } else {
            results.checks.push({
                name: 'STRIPE_WEBHOOK_SECRET',
                status: '✅ Valid',
                message: 'Webhook secret is properly formatted'
            });
        }

        // Check 5: Ranch Configuration
        console.log('Checking ranch configuration...');
        console.log('User ranch_id:', user.ranch_id);
        
        if (!user.ranch_id) {
            results.checks.push({
                name: 'Ranch Configuration',
                status: '❌ NO RANCH ID',
                message: 'User does not have a ranch_id set. Please complete onboarding or contact support.'
            });
            results.success = false;
        } else {
            try {
                console.log('Looking up ranch with ID:', user.ranch_id);
                const ranches = await base44.entities.Ranch.filter({ id: user.ranch_id });
                console.log('Found ranches:', ranches);
                
                if (!ranches || ranches.length === 0) {
                    results.checks.push({
                        name: 'Ranch Configuration',
                        status: '❌ RANCH NOT FOUND',
                        message: `Ranch with ID "${user.ranch_id}" does not exist in database. The user's ranch may have been deleted or the ID is incorrect. Please complete onboarding again or contact support.`
                    });
                    results.success = false;
                } else {
                    const ranch = ranches[0];
                    results.checks.push({
                        name: 'Ranch Configuration',
                        status: '✅ Found',
                        message: `Ranch: ${ranch.name}, Plan: ${ranch.subscription_plan || 'Free'}, Customer: ${ranch.stripe_customer_id || 'Not created yet'}`
                    });
                }
            } catch (ranchError) {
                console.error('Ranch lookup failed:', ranchError);
                console.error('Error details:', {
                    message: ranchError.message,
                    stack: ranchError.stack,
                    name: ranchError.name
                });
                results.checks.push({
                    name: 'Ranch Configuration',
                    status: '❌ LOOKUP ERROR',
                    message: `Failed to look up ranch: ${ranchError.message}. The ranch may not exist or there may be a database connection issue.`
                });
                results.success = false;
            }
        }

        console.log('=== Stripe Config Test Completed ===');
        console.log('Results:', JSON.stringify(results, null, 2));

        return Response.json(results);

    } catch (error) {
        console.error('=== Config Test Fatal Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        
        return Response.json({ 
            success: false,
            error: error.message,
            errorType: error.constructor.name,
            checks: [{
                name: 'Test Execution',
                status: '❌ FAILED',
                message: `Fatal error during test: ${error.message}`
            }]
        }, { status: 500 });
    }
});
