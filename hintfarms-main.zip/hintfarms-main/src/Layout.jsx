import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils"; // Changed import path
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { differenceInDays } from "date-fns";
import {
  LayoutDashboard,
  Beef,
  DollarSign,
  Heart,
  Sprout,
  MapPin,
  BarChart3,
  Bell,
  Search,
  User,
  CheckSquare,
  Shield,
  Users,
  CreditCard,
  Sparkles,
  TrendingUp,
  ChevronRight,
  ChevronDown,
  FileText,
  Wallet,
  Building2
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import NotificationDrawer from "@/components/notifications/NotificationDrawer";
import AccountManagementDialog from "@/components/account/AccountManagementDialog";
import RanchSwitcher from "@/components/navigation/RanchSwitcher";
import { ThemeProvider, useTheme } from "@/components/theme/ThemeProvider";
import TeamManagementDialog from "@/components/team/TeamManagementDialog";
import { TutorialProvider } from "@/components/tutorial/TutorialProvider";
import TutorialOverlay from "@/components/tutorial/TutorialOverlay";
import RanchGuard from "@/components/navigation/RanchGuard";
import { initGA, trackPageView, setUserProperties } from "@/components/utils"; // Changed import path
import RanchInsightsAgent from "@/components/ai/RanchInsightsAgent";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [notificationDrawerOpen, setNotificationDrawerOpen] = React.useState(false);
  const [accountDialogOpen, setAccountDialogOpen] = React.useState(false);
  const [teamDialogOpen, setTeamDialogOpen] = React.useState(false);
  const [accountDialogTab, setAccountDialogTab] = React.useState("profile");
  const [aiInsightsOpen, setAiInsightsOpen] = React.useState(false);
  const { theme, setTheme } = useTheme();

  const [financialsExpanded, setFinancialsExpanded] = React.useState(() => {
    const saved = localStorage.getItem('financialsExpanded');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [animalsExpanded, setAnimalsExpanded] = React.useState(() => {
    const saved = localStorage.getItem('animalsExpanded');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: () => user?.active_ranch_id ? base44.entities.Ranch.filter({ id: user.active_ranch_id }).then(r => r[0]) : null,
    enabled: !!user?.active_ranch_id,
    staleTime: 0,
    cacheTime: 5 * 60 * 1000,
  });

  const { data: notificationCounts } = useQuery({
    queryKey: ['notificationCounts', user?.active_ranch_id],
    queryFn: async () => {
      const response = await base44.functions.invoke('getUnreadNotificationCounts', {
        ranch_id: user?.active_ranch_id
      });
      return response.data;
    },
    enabled: !!user,
    refetchInterval: 30000,
  });

  // Initialize Google Analytics on mount (consent given during account creation)
  React.useEffect(() => {
    initGA();
  }, []);

  // Set user properties when user is available
  React.useEffect(() => {
    if (user?.id) {
      setUserProperties(user.id, {
        ranch_id: user.active_ranch_id,
        role: user.role
      });
    }
  }, [user]);

  // Track page views on route change
  React.useEffect(() => {
    if (currentPageName) {
      trackPageView(currentPageName, location.pathname);
    }
  }, [location.pathname, currentPageName]);

  React.useEffect(() => {
    localStorage.setItem('financialsExpanded', JSON.stringify(financialsExpanded));
  }, [financialsExpanded]);

  React.useEffect(() => {
    localStorage.setItem('animalsExpanded', JSON.stringify(animalsExpanded));
  }, [animalsExpanded]);

  const menuItems = [
    {
      title: "Dashboard",
      icon: LayoutDashboard,
      path: createPageUrl("Dashboard"),
    },
    {
      title: "Livestock",
      icon: Beef,
      path: createPageUrl("Animals"),
      badge: ranch?.total_head_count,
      expandable: true,
      expanded: animalsExpanded,
      onToggle: () => setAnimalsExpanded(!animalsExpanded),
      subItems: [
        { title: "All Livestock", path: createPageUrl("Animals"), icon: Beef },
        { title: "Health Records", path: createPageUrl("HealthRecords"), icon: Heart },
        { title: "Breeding", path: createPageUrl("Breeding"), icon: Sprout },
      ]
    },
    {
      title: "Financials",
      icon: DollarSign,
      path: createPageUrl("Financials"),
      expandable: true,
      expanded: financialsExpanded,
      onToggle: () => setFinancialsExpanded(!financialsExpanded),
      subItems: [
        { title: "Overview", path: createPageUrl("Financials"), icon: DollarSign },
        { title: "Expenses", path: createPageUrl("Expenses"), icon: FileText },
        { title: "Revenue", path: createPageUrl("Revenue"), icon: Wallet },
        { title: "Bank Imports", path: createPageUrl("BankImports"), icon: Building2 },
      ]
    },
    {
      title: "Pastures",
      icon: MapPin,
      path: createPageUrl("Pastures"),
      badge: ranch?.total_pastures,
    },
    {
      title: "Inventory",
      icon: Building2,
      path: createPageUrl("Inventory"),
    },
    {
      title: "Tasks",
      icon: CheckSquare,
      path: createPageUrl("Tasks"),
      badge: notificationCounts?.tasks,
      badgeVariant: "default",
    },
    {
      title: "Reports",
      icon: BarChart3,
      path: createPageUrl("Reports"),
    },
    {
      title: "Scenarios",
      icon: TrendingUp,
      path: createPageUrl("Scenarios"),
    },
  ];

  const settingsMenuItems = [
    {
      title: "Ranch Settings",
      icon: Building2,
      path: createPageUrl("RanchSettings"),
    },
    {
      title: "Account Settings",
      icon: User,
      path: createPageUrl("AccountSettings"),
    },
  ];

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const totalAlerts = (notificationCounts?.general || 0) + (notificationCounts?.alerts || 0);

  const isFreePlan = !ranch?.subscription_plan || ranch?.subscription_plan === 'free';
  const daysUntilTrial = ranch?.trial_end_date
    ? differenceInDays(new Date(ranch.trial_end_date), new Date())
    : null;
  const isInTrial = daysUntilTrial !== null && daysUntilTrial >= 0;

  const handleUpgradeClick = () => {
    setAccountDialogOpen(true);
    setAccountDialogTab("subscription");
  };

  // Check if current page is AdminPortal
  const isAdminPortal = currentPageName === "AdminPortal";

  // If admin is viewing AdminPortal, don't render regular layout at all
  if (isAdminPortal && user?.role === 'admin') {
    return (
      <ThemeProvider>
        <TutorialProvider>
          {children}
          <ToastHandler />
        </TutorialProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <TutorialProvider>
        <SidebarProvider>
          <RanchGuard>
            <div className="min-h-screen flex w-full bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
              <Sidebar className="border-r border-gray-800 bg-[#1a1a1a]">
                <SidebarHeader className="border-b border-gray-800 p-4 bg-[#1a1a1a]">
                  <div className="flex items-center justify-center py-2">
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/9f8fc448e_IMG_7458.png" 
                      alt="GRAHAR" 
                      className="h-12 w-auto"
                    />
                  </div>
                  <div className="mt-4">
                    <RanchSwitcher />
                  </div>
                </SidebarHeader>

                <SidebarContent className="py-4 bg-[#1a1a1a]">
                  <SidebarGroup>
                    <SidebarGroupLabel className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      NAVIGATION
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                      <SidebarMenu>
                        {menuItems.map((item) => (
                          <div key={item.title}>
                            <SidebarMenuItem>
                              <SidebarMenuButton
                                asChild={!item.expandable}
                                isActive={location.pathname === item.path}
                                onClick={item.expandable ? item.onToggle : undefined}
                                className={`group hover:bg-[#F5A623]/20 ${location.pathname === item.path ? '!bg-[#F5A623] hover:!bg-[#F5A623] text-white' : ''}`}
                              >
                                {!item.expandable ? (
                                  <Link to={item.path} className="flex items-center gap-3 w-full">
                                    <item.icon className="h-4 w-4" />
                                    <span className="flex-1">{item.title}</span>
                                    {item.badge && (
                                      <Badge
                                        variant={item.badgeVariant || "secondary"}
                                        className="ml-auto"
                                      >
                                        {item.badge}
                                      </Badge>
                                    )}
                                  </Link>
                                ) : (
                                  <div className="flex items-center gap-3 w-full cursor-pointer">
                                    <item.icon className="h-4 w-4" />
                                    <span className="flex-1">{item.title}</span>
                                    {item.badge && (
                                      <Badge variant="secondary" className="ml-auto mr-1">
                                        {item.badge}
                                      </Badge>
                                    )}
                                    <ChevronDown
                                      className={`h-4 w-4 transition-transform ${
                                        item.expanded ? "rotate-180" : ""
                                      }`}
                                    />
                                  </div>
                                )}
                              </SidebarMenuButton>
                            </SidebarMenuItem>
                            {item.expandable && item.expanded && item.subItems && (
                              <div className="ml-4 mt-1 space-y-1">
                                {item.subItems.map((subItem) => (
                                  <SidebarMenuItem key={subItem.title}>
                                    <SidebarMenuButton
                                      asChild
                                      isActive={location.pathname === subItem.path}
                                      className={`pl-4 hover:bg-[#F5A623]/20 ${location.pathname === subItem.path ? '!bg-[#F5A623] hover:!bg-[#F5A623] text-white' : ''}`}
                                    >
                                      <Link to={subItem.path} className="flex items-center gap-3">
                                        <subItem.icon className="h-3.5 w-3.5" />
                                        <span className="text-sm">{subItem.title}</span>
                                      </Link>
                                    </SidebarMenuButton>
                                  </SidebarMenuItem>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </SidebarMenu>
                    </SidebarGroupContent>
                  </SidebarGroup>

                  <SidebarGroup>
                    <SidebarGroupLabel className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      SETTINGS
                    </SidebarGroupLabel>
                    <SidebarGroupContent>
                      <SidebarMenu>
                        {settingsMenuItems.map((item) => (
                          <SidebarMenuItem key={item.title}>
                            <SidebarMenuButton
                              asChild
                              isActive={location.pathname === item.path}
                              className={`group hover:bg-[#F5A623]/20 ${location.pathname === item.path ? '!bg-[#F5A623] hover:!bg-[#F5A623] text-white' : ''}`}
                            >
                              <Link to={item.path} className="flex items-center gap-3 w-full">
                                <item.icon className="h-4 w-4" />
                                <span className="flex-1">{item.title}</span>
                              </Link>
                            </SidebarMenuButton>
                          </SidebarMenuItem>
                        ))}
                      </SidebarMenu>
                    </SidebarGroupContent>
                  </SidebarGroup>

                  {(isFreePlan || isInTrial) && (
                    <SidebarGroup className="mt-4">
                      <div className="mx-4">
                        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-800">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-2 mb-2">
                              <Sparkles className="h-4 w-4 text-[#F5A623] mt-0.5" />
                              <div>
                                <p className="font-semibold text-sm text-orange-900 dark:text-orange-100">
                                  {isInTrial ? 'Trial Active' : 'Upgrade to PRO'}
                                </p>
                                {isInTrial && daysUntilTrial !== null && (
                                  <p className="text-xs text-orange-700 dark:text-orange-300 mt-1">
                                    {daysUntilTrial} {daysUntilTrial === 1 ? 'day' : 'days'} remaining
                                  </p>
                                )}
                                {!isInTrial && (
                                  <p className="text-xs text-orange-700 dark:text-orange-300 mt-1">
                                    Unlock advanced features
                                  </p>
                                )}
                              </div>
                            </div>
                            <Button
                              size="sm"
                              onClick={handleUpgradeClick}
                              className="w-full bg-[#F5A623] hover:bg-[#E09612] text-white"
                            >
                              {isInTrial ? 'View Plans' : 'Upgrade Now'}
                            </Button>
                          </CardContent>
                        </Card>
                      </div>
                    </SidebarGroup>
                  )}
                </SidebarContent>

                <SidebarFooter className="border-t border-gray-800 p-4 bg-[#1a1a1a]">
                  <div className="flex items-center justify-end gap-1 mb-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setNotificationDrawerOpen(true)}
                      className="h-8 w-8 relative"
                    >
                      <Bell className="h-4 w-4" />
                      {totalAlerts > 0 && (
                        <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                          {totalAlerts > 9 ? "9+" : totalAlerts}
                        </span>
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setAccountDialogTab("profile");
                        setAccountDialogOpen(true);
                      }}
                      className="h-8 w-8"
                    >
                      <User className="h-4 w-4" />
                    </Button>
                  </div>
                  {user && (
                    <div className="text-xs text-gray-400">
                      <p className="font-medium text-gray-200 truncate">
                        {user.full_name}
                      </p>
                      <p className="truncate">{user.email}</p>
                    </div>
                  )}
                </SidebarFooter>
              </Sidebar>

              <main className="flex-1 flex flex-col overflow-hidden bg-gray-50">
                {!isAdminPortal && (
                  <header className="fixed top-0 right-0 left-0 lg:left-64 z-40 bg-white border-b border-gray-200 px-4 md:px-6 py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3 md:gap-6">
                      <SidebarTrigger className="lg:hidden" />
                      <nav className="hidden md:flex gap-6">
                      <Link 
                        to={createPageUrl("Dashboard")} 
                        className={`text-sm font-medium pb-3 border-b-2 transition-colors ${
                          currentPageName === "Dashboard" 
                            ? "border-[#F5A623] text-gray-900" 
                            : "border-transparent text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        Dashboard
                      </Link>
                      <Link 
                        to={createPageUrl("Animals")} 
                        className={`text-sm font-medium pb-3 border-b-2 transition-colors ${
                          currentPageName === "Animals" 
                            ? "border-[#F5A623] text-gray-900" 
                            : "border-transparent text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        Livestock
                      </Link>
                      <Link 
                        to={createPageUrl("Pastures")} 
                        className={`text-sm font-medium pb-3 border-b-2 transition-colors ${
                          currentPageName === "Pastures" 
                            ? "border-[#F5A623] text-gray-900" 
                            : "border-transparent text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        Pastures
                      </Link>
                      <Link 
                        to={createPageUrl("Tasks")} 
                        className={`text-sm font-medium pb-3 border-b-2 transition-colors ${
                          currentPageName === "Tasks" 
                            ? "border-[#F5A623] text-gray-900" 
                            : "border-transparent text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        Tasks
                      </Link>
                      <Link 
                        to={createPageUrl("Market")} 
                        className={`text-sm font-medium pb-3 border-b-2 transition-colors ${
                          currentPageName === "Market" 
                            ? "border-[#F5A623] text-gray-900" 
                            : "border-transparent text-gray-600 hover:text-gray-900"
                        }`}
                      >
                        Market
                      </Link>
                      </nav>
                    </div>
                    <div className="flex items-center gap-2">
                    {user?.role === 'admin' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => navigate(createPageUrl("AdminPortal"))}
                        title="Admin Portal"
                        className="hidden md:flex"
                      >
                        <Shield className="w-5 h-5 text-blue-500" />
                      </Button>
                    )}
                    <div className="w-10 h-10 bg-[#F5A623] rounded-full flex items-center justify-center">
                      <span className="font-bold text-[#1a1a1a] text-sm">
                        {user?.full_name?.charAt(0) || 'G'}
                      </span>
                    </div>
                    </div>
                  </header>
                )}

                <div className={`flex-1 overflow-y-auto ${!isAdminPortal ? 'pt-16' : ''}`}>{children}</div>
              </main>

              <NotificationDrawer
                open={notificationDrawerOpen}
                onOpenChange={setNotificationDrawerOpen}
                user={user}
                ranch={ranch}
                notificationCounts={notificationCounts}
              />

              <AccountManagementDialog
                open={accountDialogOpen}
                onOpenChange={setAccountDialogOpen}
                defaultTab={accountDialogTab}
              />

              <TeamManagementDialog
                open={teamDialogOpen}
                onOpenChange={setTeamDialogOpen}
              />

              {/* Floating AI Insights Button */}
              <button
                onClick={() => setAiInsightsOpen(true)}
                className="fixed bottom-6 right-6 w-16 h-16 bg-[#F5A623] hover:bg-[#E09612] rounded-lg shadow-2xl flex items-center justify-center transition-all hover:scale-110 z-50"
                title="Ranch Assist"
              >
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/f05c94bea_FindCash-7.png" 
                  alt="GRAHAR Ranch Assist" 
                  className="w-10 h-10"
                />
              </button>

              {/* Ranch Assist Dialog */}
              <Dialog open={aiInsightsOpen} onOpenChange={setAiInsightsOpen}>
                <DialogContent className="!w-screen !h-[100dvh] !max-w-none md:!w-full md:!h-[80vh] md:!max-w-4xl fixed !top-0 !left-0 !right-0 !bottom-0 !translate-x-0 !translate-y-0 md:!top-[50%] md:!left-[50%] md:!translate-x-[-50%] md:!translate-y-[-50%] rounded-none md:rounded-lg flex flex-col p-0 m-0 border-0 md:border z-[9999] bg-white">
                  <DialogHeader className="px-4 md:px-6 py-3 md:py-4 border-b flex-shrink-0">
                    <DialogTitle className="flex items-center gap-2 text-base md:text-lg">
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/f05c94bea_FindCash-7.png" 
                        alt="GRAHAR" 
                        className="w-5 h-5 md:w-6 md:h-6"
                      />
                      Ranch Assist
                    </DialogTitle>
                  </DialogHeader>
                  <div className="flex-1 overflow-hidden min-h-0">
                    {user?.active_ranch_id && (
                      <RanchInsightsAgent ranchId={user.active_ranch_id} />
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            <TutorialOverlay />
            <ToastHandler />
          </RanchGuard>
        </SidebarProvider>
      </TutorialProvider>
    </ThemeProvider>
  );
}

function ToastHandler() {
  React.useEffect(() => {
    const handleToast = (event) => {
      const { message, type } = event.detail;
      const toastEvent = new CustomEvent('sonner-toast', {
        detail: {
          message,
          type: type || 'default'
        }
      });
      window.dispatchEvent(toastEvent);
    };

    window.addEventListener('showToast', handleToast);
    return () => window.removeEventListener('showToast', handleToast);
  }, []);

  return null;
}