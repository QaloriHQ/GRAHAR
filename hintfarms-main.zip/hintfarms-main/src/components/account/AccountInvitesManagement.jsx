import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import {
  Building2,
  Mail,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Crown,
  Users,
  Loader2,
  Search,
  ExternalLink
} from "lucide-react";
import { format, formatDistanceToNow, isPast } from "date-fns";

export default function AccountInvitesManagement() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch all invites for the current user
  const { data: allInvites = [], isLoading: invitesLoading } = useQuery({
    queryKey: ['userInvites', user?.email?.toLowerCase()],
    queryFn: async () => {
      if (!user?.email) return [];
      
      const userEmail = user.email.toLowerCase();
      console.log('Fetching all invites for:', userEmail);
      
      // Fetch all invites for this email
      const invites = await base44.entities.RanchInvite.filter({}, '-created_date');
      
      // Filter client-side for case-insensitive match
      const userInvites = invites.filter(invite => 
        invite.invited_email.toLowerCase() === userEmail
      );
      
      console.log('User invites found:', userInvites.length);
      return userInvites;
    },
    enabled: !!user?.email,
  });

  // Fetch ranch details for all invites
  const { data: ranches = [] } = useQuery({
    queryKey: ['inviteRanches', allInvites],
    queryFn: async () => {
      if (!allInvites || allInvites.length === 0) return [];
      
      const ranchIds = [...new Set(allInvites.map(inv => inv.ranch_id))];
      const ranchesData = await Promise.all(
        ranchIds.map(async (id) => {
          try {
            const results = await base44.entities.Ranch.filter({ id });
            return results[0];
          } catch (error) {
            console.error(`Failed to fetch ranch ${id}:`, error);
            return null;
          }
        })
      );
      
      return ranchesData.filter(Boolean);
    },
    enabled: allInvites.length > 0,
  });

  // Check if user is already a member of ranches
  const { data: userMemberships = [] } = useQuery({
    queryKey: ['userMemberships', user?.email?.toLowerCase()],
    queryFn: async () => {
      if (!user?.email) return [];
      
      const userEmail = user.email.toLowerCase();
      const allMembers = await base44.entities.RanchMember.filter({ status: 'Active' });
      
      return allMembers.filter(m => m.user_email.toLowerCase() === userEmail);
    },
    enabled: !!user?.email,
  });

  const acceptInviteMutation = useMutation({
    mutationFn: async (token) => {
      const response = await base44.functions.invoke('acceptRanchInvite', { token });
      return response.data;
    },
    onSuccess: async (data) => {
      console.log('Invite accepted:', data);
      
      const event = new CustomEvent('showToast', {
        detail: { 
          message: `You've successfully joined ${data.ranch_name}!`, 
          type: 'success' 
        }
      });
      window.dispatchEvent(event);

      await queryClient.invalidateQueries({ queryKey: ['userInvites'] });
      await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      await queryClient.invalidateQueries({ queryKey: ['userMemberships'] });
      await queryClient.invalidateQueries({ queryKey: ['userRanchMembers'] });
    },
    onError: (error) => {
      console.error('Failed to accept invite:', error);
      
      const errorData = error.response?.data || error.data || {};
      const event = new CustomEvent('showToast', {
        detail: { message: errorData.message || 'Failed to accept invitation', type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const declineInviteMutation = useMutation({
    mutationFn: async (inviteId) => {
      const response = await base44.functions.invoke('declineRanchInvite', { invite_id: inviteId });
      return response.data;
    },
    onSuccess: async (data) => {
      const event = new CustomEvent('showToast', {
        detail: { 
          message: `Invitation to ${data.ranch_name} declined.`, 
          type: 'success' 
        }
      });
      window.dispatchEvent(event);

      await queryClient.invalidateQueries({ queryKey: ['userInvites'] });
    },
    onError: (error) => {
      console.error('Failed to decline invite:', error);
      
      const errorData = error.response?.data || error.data || {};
      const event = new CustomEvent('showToast', {
        detail: { message: errorData.message || 'Failed to decline invitation', type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const handleAccept = (invite) => {
    acceptInviteMutation.mutate(invite.invite_token);
  };

  const handleDecline = (invite) => {
    declineInviteMutation.mutate(invite.id);
  };

  const handleSwitchToRanch = async (ranchId) => {
    await base44.auth.updateMe({ active_ranch_id: ranchId });
    await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    navigate(createPageUrl('Dashboard'));
  };

  // Categorize invites
  const pendingInvites = allInvites.filter(inv => {
    if (inv.status !== 'Pending') return false;
    if (inv.expires_at && isPast(new Date(inv.expires_at))) return false;
    return true;
  });

  const pastInvites = allInvites.filter(inv => {
    if (inv.status !== 'Pending') return true;
    if (inv.expires_at && isPast(new Date(inv.expires_at))) return true;
    return false;
  });

  // Filter invites based on search
  const filterInvites = (invites) => {
    if (!searchQuery.trim()) return invites;
    
    const query = searchQuery.toLowerCase();
    return invites.filter(inv => 
      inv.ranch_name?.toLowerCase().includes(query) ||
      inv.role?.toLowerCase().includes(query)
    );
  };

  const filteredPendingInvites = filterInvites(pendingInvites);
  const filteredPastInvites = filterInvites(pastInvites);

  const getRanchInfo = (ranchId) => {
    return ranches.find(r => r.id === ranchId);
  };

  const isAlreadyMember = (ranchId) => {
    return userMemberships.some(m => m.ranch_id === ranchId);
  };

  const getStatusBadge = (invite) => {
    if (invite.status === 'Accepted') {
      return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400">Accepted</Badge>;
    }
    if (invite.status === 'Declined') {
      return <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400">Declined</Badge>;
    }
    if (invite.status === 'Revoked') {
      return <Badge className="bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400">Revoked</Badge>;
    }
    if (invite.expires_at && isPast(new Date(invite.expires_at))) {
      return <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400">Expired</Badge>;
    }
    return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400">Pending</Badge>;
  };

  const getRoleBadgeColor = (role) => {
    const colors = {
      'Owner': 'bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800',
      'Manager': 'bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800',
      'Worker': 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800',
      'Veterinarian': 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800',
      'Assistant': 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-800'
    };
    return colors[role] || colors['Worker'];
  };

  if (invitesLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#F5A623]" />
        <span className="ml-3 text-gray-600 dark:text-gray-400">Loading invitations...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
          Ranch Invitations
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2">
          <Mail className="w-4 h-4" />
          Invitations for {user?.email}
        </p>
      </div>

      {/* Search */}
      {allInvites.length > 0 && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
          <Input
            placeholder="Search by ranch name or role..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
          />
        </div>
      )}

      {/* Pending Invitations */}
      {filteredPendingInvites.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">
            Pending Invitations ({filteredPendingInvites.length})
          </h4>
          <div className="space-y-3">
            {filteredPendingInvites.map((invite) => {
              const ranch = getRanchInfo(invite.ranch_id);
              const alreadyMember = isAlreadyMember(invite.ranch_id);
              const isExpired = invite.expires_at && isPast(new Date(invite.expires_at));
              
              return (
                <Card key={invite.id} className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
                          {ranch?.logo_url ? (
                            <img 
                              src={ranch.logo_url} 
                              alt={invite.ranch_name}
                              className="w-full h-full object-cover rounded-xl"
                            />
                          ) : (
                            <Building2 className="w-6 h-6 text-white" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-lg dark:text-gray-100">
                              {invite.ranch_name}
                            </h4>
                            <Badge className={`${getRoleBadgeColor(invite.role)} border text-xs`}>
                              {invite.role}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              Invited {formatDistanceToNow(new Date(invite.created_date || invite.created_at), { addSuffix: true })}
                            </span>
                            {invite.expires_at && (
                              <span className={`flex items-center gap-1 ${isExpired ? 'text-orange-600 dark:text-orange-400 font-medium' : ''}`}>
                                {isExpired ? <AlertCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                                {isExpired ? 'Expired' : `Expires ${format(new Date(invite.expires_at), 'MMM d, yyyy')}`}
                              </span>
                            )}
                          </div>
                          {alreadyMember && (
                            <div className="mt-2 text-sm text-orange-700 dark:text-orange-400 flex items-center gap-1">
                              <CheckCircle2 className="w-4 h-4" />
                              You're already a member of this ranch
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {!alreadyMember && !isExpired && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDecline(invite)}
                              disabled={declineInviteMutation.isPending}
                              className="dark:border-gray-700 dark:text-gray-300"
                            >
                              {declineInviteMutation.isPending ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                'Decline'
                              )}
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleAccept(invite)}
                              disabled={acceptInviteMutation.isPending}
                              className="bg-[#F5A623] hover:bg-[#E09612]"
                            >
                              {acceptInviteMutation.isPending ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Accepting...
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="w-4 h-4 mr-2" />
                                  Accept
                                </>
                              )}
                            </Button>
                          </>
                        )}
                        {alreadyMember && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSwitchToRanch(invite.ranch_id)}
                            className="dark:border-gray-700 dark:text-gray-300"
                          >
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Switch to Ranch
                          </Button>
                        )}
                        {isExpired && (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled
                            className="dark:border-gray-700 dark:text-gray-500"
                          >
                            Expired
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Past Invitations */}
      {filteredPastInvites.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">
            Past Invitations ({filteredPastInvites.length})
          </h4>
          <div className="space-y-2">
            {filteredPastInvites.map((invite) => {
              const ranch = getRanchInfo(invite.ranch_id);
              
              return (
                <Card key={invite.id} className="dark:bg-gray-950 dark:border-gray-800">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0">
                          {ranch?.logo_url ? (
                            <img 
                              src={ranch.logo_url} 
                              alt={invite.ranch_name}
                              className="w-full h-full object-cover rounded-lg"
                            />
                          ) : (
                            <Building2 className="w-5 h-5 text-gray-400 dark:text-gray-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <p className="font-medium text-sm dark:text-gray-200">{invite.ranch_name}</p>
                            <Badge className={`${getRoleBadgeColor(invite.role)} border text-xs`}>
                              {invite.role}
                            </Badge>
                            {getStatusBadge(invite)}
                          </div>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                            {format(new Date(invite.created_date || invite.created_at), 'MMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty State */}
      {allInvites.length === 0 && (
        <Card className="dark:bg-gray-950 dark:border-gray-800">
          <CardContent className="p-12 text-center">
            <Mail className="w-16 h-16 text-gray-300 dark:text-gray-700 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
              No Invitations Yet
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              You don't have any ranch invitations at the moment.
            </p>
          </CardContent>
        </Card>
      )}

      {/* No Search Results */}
      {allInvites.length > 0 && filteredPendingInvites.length === 0 && filteredPastInvites.length === 0 && searchQuery && (
        <Card className="dark:bg-gray-950 dark:border-gray-800">
          <CardContent className="p-12 text-center">
            <Search className="w-16 h-16 text-gray-300 dark:text-gray-700 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">
              No Results Found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              No invitations match "{searchQuery}"
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}