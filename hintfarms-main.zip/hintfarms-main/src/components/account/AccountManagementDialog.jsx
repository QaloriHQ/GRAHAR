import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  User,
  Mail,
  Phone,
  Building2,
  Shield,
  Bell,
  Camera,
  Save,
  CheckCircle2,

  RotateCcw, // Added RotateCcw icon for tutorial button
  CreditCard, // Added for billing tab icon
  HelpCircle, // Added for help tab icon
  Sparkles, // Added for tutorial section
  FileText, // Added for documentation icon
  MessageSquare, // Added for live chat icon
  Banknote, // Added for banking tab icon
  LogOut // Added for logout button
} from "lucide-react";

import BillingManagement from "@/components/billing/BillingManagement";
import BankingManagement from "@/components/billing/BankingManagement"; // Added import for BankingManagement
import { useTutorial } from "@/components/tutorial/TutorialProvider"; // Added import for useTutorial

export default function AccountManagementDialog({ open, onOpenChange, defaultTab = "profile" }) {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = React.useState(defaultTab);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const { restartTutorial, user: tutorialUser } = useTutorial(); // Destructure tutorial functions and data

  const { data: user, isLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const [profileData, setProfileData] = useState({
    full_name: "",
    phone_number: "",
    role_title: "",
    ranch_name: "",
    profile_photo_url: ""
  });

  const [notificationPrefs, setNotificationPrefs] = useState({
    email_notifications: true,
    task_reminders: true,
    health_alerts: true,
    breeding_notifications: true,
    financial_alerts: true
  });

  const [passwordData, setPasswordData] = useState({
    current_password: "",
    new_password: "",
    confirm_password: ""
  });

  React.useEffect(() => {
    if (user) {
      setProfileData({
        full_name: user.full_name || "",
        phone_number: user.phone_number || "",
        role_title: user.role_title || "",
        ranch_name: user.ranch_name || "",
        profile_photo_url: user.profile_photo_url || ""
      });
      setNotificationPrefs({
        email_notifications: user.email_notifications ?? true,
        task_reminders: user.task_reminders ?? true,
        health_alerts: user.health_alerts ?? true,
        breeding_notifications: user.breeding_notifications ?? true,
        financial_alerts: user.financial_alerts ?? true
      });
    }
  }, [user]);

  // Set active tab when defaultTab prop changes
  React.useEffect(() => {
    if (defaultTab) {
      setActiveTab(defaultTab);
    }
  }, [defaultTab, open]);

  // Aggressively invalidate ranch data when dialog opens
  React.useEffect(() => {
    if (open) {
      console.log('Account dialog opened - invalidating ranch queries');
      queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    }
  }, [open, queryClient]);



  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      setShowSuccessMessage(true);
      setTimeout(() => setShowSuccessMessage(false), 3000);
    },
  });

  const uploadPhotoMutation = useMutation({
    mutationFn: async (file) => {
      const result = await base44.integrations.Core.UploadFile({ file });
      return result.file_url;
    },
    onSuccess: (fileUrl) => {
      updateProfileMutation.mutate({ profile_photo_url: fileUrl });
    },
  });

  const handlePhotoUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      uploadPhotoMutation.mutate(file);
    }
  };

  const handleProfileSave = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handleNotificationSave = () => {
    updateProfileMutation.mutate(notificationPrefs);
  };

  const handlePasswordChange = () => {
    if (passwordData.new_password !== passwordData.confirm_password) {
      alert("New passwords do not match");
      return;
    }
    alert("Password changed successfully");
    setPasswordData({ current_password: "", new_password: "", confirm_password: "" });
  };

  const handleLogout = () => {
    base44.auth.logout();
  };



  const handleRestartTutorial = () => {
    onOpenChange(false);
    setTimeout(() => {
      restartTutorial();
    }, 300);
  };

  if (isLoading) {
    return null;
  }

  const userInitials = user?.full_name
    ?.split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase() || 'U';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold dark:text-gray-100">Account Management</DialogTitle>
          <DialogDescription className="dark:text-gray-400">
            Manage your profile, preferences, and subscription
          </DialogDescription>
        </DialogHeader>

        {showSuccessMessage && (
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3 mb-4">
            <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
            <p className="text-green-800 dark:text-green-300 font-medium">Changes saved successfully!</p>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 dark:bg-gray-900">
            <TabsTrigger value="profile" className="dark:data-[state=active]:bg-gray-800">
              <User className="w-4 h-4 mr-2" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="notifications" className="dark:data-[state=active]:bg-gray-800">
              <Bell className="w-4 h-4 mr-2" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="help" className="dark:data-[state=active]:bg-gray-800">
              <HelpCircle className="w-4 h-4 mr-2" />
              Help
            </TabsTrigger>
          </TabsList>

          <div className="mt-6">
            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6 m-0">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>Update your personal details and ranch information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Profile Photo */}
                  <div className="flex items-center gap-6">
                    <Avatar className="w-24 h-24">
                      <AvatarImage src={profileData.profile_photo_url} />
                      <AvatarFallback className="text-2xl bg-orange-100 text-orange-700">
                        {userInitials}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <Label htmlFor="photo-upload" className="cursor-pointer">
                        <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors">
                          <Camera className="w-4 h-4" />
                          <span className="text-sm font-medium">Upload Photo</span>
                        </div>
                        <Input
                          id="photo-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handlePhotoUpload}
                        />
                      </Label>
                      <p className="text-xs text-gray-500 mt-2">JPG, PNG or GIF (max. 2MB)</p>
                    </div>
                  </div>

                  {/* Form Fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">
                        <User className="w-4 h-4 inline mr-2" />
                        Full Name
                      </Label>
                      <Input
                        id="full_name"
                        value={profileData.full_name}
                        onChange={(e) => setProfileData({...profileData, full_name: e.target.value})}
                        placeholder="John Doe"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">
                        <Mail className="w-4 h-4 inline mr-2" />
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        value={user?.email}
                        disabled
                        className="bg-gray-50"
                      />
                      <p className="text-xs text-gray-500">Email cannot be changed</p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone_number">
                        <Phone className="w-4 h-4 inline mr-2" />
                        Phone Number
                      </Label>
                      <Input
                        id="phone_number"
                        value={profileData.phone_number}
                        onChange={(e) => setProfileData({...profileData, phone_number: e.target.value})}
                        placeholder="(555) 123-4567"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="role_title">
                        <Shield className="w-4 h-4 inline mr-2" />
                        Role / Title
                      </Label>
                      <Select
                        value={profileData.role_title}
                        onValueChange={(value) => setProfileData({...profileData, role_title: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Owner">Owner</SelectItem>
                          <SelectItem value="Manager">Manager</SelectItem>
                          <SelectItem value="Worker">Worker</SelectItem>
                          <SelectItem value="Veterinarian">Veterinarian</SelectItem>
                          <SelectItem value="Assistant">Assistant</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="ranch_name">
                        <Building2 className="w-4 h-4 inline mr-2" />
                        Ranch / Organization Name
                      </Label>
                      <Input
                        id="ranch_name"
                        value={profileData.ranch_name}
                        onChange={(e) => setProfileData({...profileData, ranch_name: e.target.value})}
                        placeholder="HintFarms Ranch"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={handleProfileSave}
                      className="bg-[#F5A623] hover:bg-[#E09612]"
                      disabled={updateProfileMutation.isPending}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Logout Section */}
              <Card className="border-red-200 dark:border-red-800">
                <CardHeader>
                  <CardTitle className="text-red-600 dark:text-red-400">Account Actions</CardTitle>
                  <CardDescription className="dark:text-gray-400">
                    Sign out of your HintFarms account
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    onClick={handleLogout}
                    className="w-full border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sign Out
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6 m-0">
              {/* Notification Preferences */}
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>Choose what notifications you want to receive</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Email Notifications</p>
                        <p className="text-sm text-gray-500">Receive notifications via email</p>
                      </div>
                      <Switch
                        checked={notificationPrefs.email_notifications}
                        onCheckedChange={(checked) =>
                          setNotificationPrefs({...notificationPrefs, email_notifications: checked})
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Task Reminders</p>
                        <p className="text-sm text-gray-500">Get reminders for upcoming and overdue tasks</p>
                      </div>
                      <Switch
                        checked={notificationPrefs.task_reminders}
                        onCheckedChange={(checked) =>
                          setNotificationPrefs({...notificationPrefs, task_reminders: checked})
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Health Alerts</p>
                        <p className="text-sm text-gray-500">Notifications for animal health records and checkups</p>
                      </div>
                      <Switch
                        checked={notificationPrefs.health_alerts}
                        onCheckedChange={(checked) =>
                          setNotificationPrefs({...notificationPrefs, health_alerts: checked})
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Breeding Notifications</p>
                        <p className="text-sm text-gray-500">Updates on breeding cycles and calving</p>
                      </div>
                      <Switch
                        checked={notificationPrefs.breeding_notifications}
                        onCheckedChange={(checked) =>
                          setNotificationPrefs({...notificationPrefs, breeding_notifications: checked})
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Financial Alerts</p>
                        <p className="text-sm text-gray-500">Notifications for expenses and revenue updates</p>
                      </div>
                      <Switch
                        checked={notificationPrefs.financial_alerts}
                        onCheckedChange={(checked) =>
                          setNotificationPrefs({...notificationPrefs, financial_alerts: checked})
                        }
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-4 border-t">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={handleNotificationSave}
                      className="bg-[#F5A623] hover:bg-[#E09612]"
                      disabled={updateProfileMutation.isPending}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Save Preferences
                    </Button>
                  </div>
                </CardContent>
              </Card>


            </TabsContent>

            {/* Help Tab */}
            <TabsContent value="help" className="space-y-6 m-0">
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4 dark:text-gray-100">Getting Started</h3>
                  <Card className="dark:bg-gray-900 dark:border-gray-800">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-xl flex items-center justify-center flex-shrink-0">
                          <Sparkles className="w-6 h-6 text-[#F5A623]" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold mb-2 dark:text-gray-100">Interactive Tutorial</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            Take a guided tour through HintFarms' key features. Learn how to manage animals, track finances, and organize your ranch operations.
                          </p>
                          <Button
                            onClick={handleRestartTutorial}
                            className="bg-[#F5A623] hover:bg-[#E09612]"
                          >
                            <Sparkles className="w-4 h-4 mr-2" />
                            {tutorialUser?.tutorial_status === "Completed" ? "Restart Tutorial" : "Start Tutorial"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4 dark:text-gray-100">Support Resources</h3>
                  <div className="grid gap-4">
                    <Card className="dark:bg-gray-900 dark:border-gray-800">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                          <div>
                            <h4 className="font-semibold dark:text-gray-100">Documentation</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Comprehensive guides and tutorials
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="dark:bg-gray-900 dark:border-gray-800">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <Mail className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                          <div>
                            <h4 className="font-semibold dark:text-gray-100">Email Support</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              support@hintfarms.com
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="dark:bg-gray-900 dark:border-gray-800">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <MessageSquare className="w-5 h-5 text-green-600 dark:text-green-400" />
                          <div>
                            <h4 className="font-semibold dark:text-gray-100">Live Chat</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Available Mon-Fri, 9am-5pm CST
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4 dark:text-gray-100">About</h3>
                  <Card className="dark:bg-gray-900 dark:border-gray-800">
                    <CardContent className="p-4">
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        <strong className="dark:text-gray-200">HintFarms™</strong> Version 1.0.0
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Modern ranch management software for tracking animals, finances, health records, and operations.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}