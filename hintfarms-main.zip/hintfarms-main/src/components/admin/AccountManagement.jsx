import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Search, Eye, Ban, CheckCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function AccountManagement() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);

  const { data: users = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const filteredUsers = users.filter(user =>
    user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getUserRanch = (email) => ranches.find(r => r.owner_email === email);

  const handleViewDetails = (user) => {
    setSelectedAccount(user);
    setShowDetailDialog(true);
  };

  const subscriptionColors = {
    'Active': 'bg-green-100 text-green-800',
    'Trialing': 'bg-blue-100 text-blue-800',
    'Past Due': 'bg-red-100 text-red-800',
    'Canceled': 'bg-gray-100 text-gray-800',
  };

  return (
    <div className="space-y-6 w-full">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <CardTitle>User Accounts</CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 dark:bg-gray-900"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Ranch</TableHead>
                <TableHead>Subscription</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map(user => {
                const ranch = getUserRanch(user.email);
                return (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.full_name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{ranch?.name || 'N/A'}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {ranch?.subscription_plan || 'Free'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={subscriptionColors[ranch?.subscription_status] || 'bg-gray-100 text-gray-800'}>
                        {ranch?.subscription_status || 'N/A'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {format(new Date(user.created_date), 'MMM dd, yyyy')}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDetails(user)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl dark:bg-gray-950">
          <DialogHeader>
            <DialogTitle>Account Details</DialogTitle>
          </DialogHeader>
          {selectedAccount && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Name</p>
                  <p className="font-semibold">{selectedAccount.full_name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Email</p>
                  <p className="font-semibold">{selectedAccount.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Role</p>
                  <Badge>{selectedAccount.role}</Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Joined</p>
                  <p className="font-semibold">
                    {format(new Date(selectedAccount.created_date), 'MMM dd, yyyy')}
                  </p>
                </div>
              </div>

              {getUserRanch(selectedAccount.email) && (
                <Card className="dark:bg-gray-900">
                  <CardHeader>
                    <CardTitle className="text-lg">Ranch Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Ranch Name</span>
                      <span className="font-semibold">{getUserRanch(selectedAccount.email).name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Subscription</span>
                      <Badge>{getUserRanch(selectedAccount.email).subscription_plan || 'Free'}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Status</span>
                      <Badge className={subscriptionColors[getUserRanch(selectedAccount.email).subscription_status]}>
                        {getUserRanch(selectedAccount.email).subscription_status || 'N/A'}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Herd Size</span>
                      <span className="font-semibold">{getUserRanch(selectedAccount.email).herd_size || 0}</span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}