import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Users, Building2, DollarSign, Activity } from "lucide-react";
import { format, subDays } from "date-fns";

export default function AnalyticsDashboard() {
  const [timeRange, setTimeRange] = useState("30");

  const { data: users = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['admin-all-animals'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  // Calculate metrics
  const daysAgo = parseInt(timeRange);
  const cutoffDate = subDays(new Date(), daysAgo);

  const newUsers = users.filter(u => new Date(u.created_date) >= cutoffDate).length;
  const newRanches = ranches.filter(r => new Date(r.created_date) >= cutoffDate).length;
  const activeSubscriptions = ranches.filter(r => r.subscription_status === 'Active').length;

  // User growth data
  const userGrowthData = Array.from({ length: daysAgo }, (_, i) => {
    const date = subDays(new Date(), daysAgo - i);
    const count = users.filter(u => new Date(u.created_date) <= date).length;
    return {
      date: format(date, 'MMM dd'),
      users: count
    };
  });

  // Subscription breakdown
  const subscriptionData = [
    { name: 'Free/Trial', value: ranches.filter(r => !r.subscription_plan || r.subscription_plan === 'Free').length, color: '#94a3b8' },
    { name: 'Pro', value: ranches.filter(r => r.subscription_plan === 'Pro').length, color: '#3b82f6' },
    { name: 'Enterprise', value: ranches.filter(r => r.subscription_plan === 'Enterprise').length, color: '#8b5cf6' },
  ];

  // Ranch activity
  const ranchActivityData = ranches
    .sort((a, b) => (b.herd_size || 0) - (a.herd_size || 0))
    .slice(0, 10)
    .map(r => ({
      name: r.name,
      animals: r.herd_size || 0
    }));

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="dark:bg-gray-800">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Analytics Overview</h3>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-40 dark:bg-gray-900">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 Days</SelectItem>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">New Users</p>
                <p className="text-2xl font-bold">{newUsers}</p>
                <p className="text-xs text-green-600">Last {timeRange} days</p>
              </div>
              <Users className="w-8 h-8 text-blue-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">New Ranches</p>
                <p className="text-2xl font-bold">{newRanches}</p>
                <p className="text-xs text-green-600">Last {timeRange} days</p>
              </div>
              <Building2 className="w-8 h-8 text-green-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Active Subs</p>
                <p className="text-2xl font-bold">{activeSubscriptions}</p>
                <p className="text-xs text-gray-500">Current total</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Animals</p>
                <p className="text-2xl font-bold">{animals.length}</p>
                <p className="text-xs text-gray-500">Platform-wide</p>
              </div>
              <Activity className="w-8 h-8 text-orange-500 opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-lg">User Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="users" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Subscription Breakdown */}
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-lg">Subscription Plans</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={subscriptionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {subscriptionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Ranches by Herd Size */}
        <Card className="dark:bg-gray-800 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Top Ranches by Herd Size</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ranchActivityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="animals" fill="#f59e0b" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}