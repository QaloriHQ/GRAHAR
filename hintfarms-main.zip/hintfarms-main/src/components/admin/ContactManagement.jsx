import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit2, Trash2, Mail, Phone, Star } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function ContactManagement() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [newContact, setNewContact] = useState({
    ranch_id: "",
    full_name: "",
    email: "",
    phone: "",
    role: "",
    is_primary: false,
    notes: ""
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ['admin-contacts'],
    queryFn: () => base44.entities.Contact.list('-created_date'),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const createContactMutation = useMutation({
    mutationFn: (data) => {
      const ranch = ranches.find(r => r.id === data.ranch_id);
      return base44.entities.Contact.create({
        ...data,
        ranch_name: ranch?.name || ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-contacts'] });
      setShowDialog(false);
      resetForm();
      toast.success('Contact created');
    },
  });

  const updateContactMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Contact.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-contacts'] });
      setShowDialog(false);
      setEditingContact(null);
      toast.success('Contact updated');
    },
  });

  const deleteContactMutation = useMutation({
    mutationFn: (id) => base44.entities.Contact.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-contacts'] });
      toast.success('Contact deleted');
    },
  });

  const resetForm = () => {
    setNewContact({
      ranch_id: "",
      full_name: "",
      email: "",
      phone: "",
      role: "",
      is_primary: false,
      notes: ""
    });
  };

  const handleEdit = (contact) => {
    setEditingContact(contact);
    setNewContact({
      ranch_id: contact.ranch_id,
      full_name: contact.full_name,
      email: contact.email,
      phone: contact.phone || "",
      role: contact.role || "",
      is_primary: contact.is_primary,
      notes: contact.notes || ""
    });
    setShowDialog(true);
  };

  const filteredContacts = contacts.filter(contact =>
    contact.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.ranch_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Ranch Contacts</CardTitle>
            <div className="flex gap-2">
              <Input
                placeholder="Search contacts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 dark:bg-gray-900"
              />
              <Button
                onClick={() => {
                  setEditingContact(null);
                  resetForm();
                  setShowDialog(true);
                }}
                className="bg-[#F5A623] hover:bg-[#E09612]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Contact
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Ranch</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Contact Info</TableHead>
                <TableHead>Primary</TableHead>
                <TableHead>Last Interaction</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredContacts.map(contact => (
                <TableRow key={contact.id}>
                  <TableCell className="font-medium">{contact.full_name}</TableCell>
                  <TableCell>{contact.ranch_name}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{contact.role || 'N/A'}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      {contact.email && (
                        <a href={`mailto:${contact.email}`} className="text-xs text-blue-600 flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          {contact.email}
                        </a>
                      )}
                      {contact.phone && (
                        <a href={`tel:${contact.phone}`} className="text-xs text-blue-600 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {contact.phone}
                        </a>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {contact.is_primary && (
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-gray-600">
                    {contact.last_interaction 
                      ? format(new Date(contact.last_interaction), 'MMM dd, yyyy')
                      : 'N/A'}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(contact)}>
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Delete this contact?')) {
                            deleteContactMutation.mutate(contact.id);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-xl dark:bg-gray-950">
          <DialogHeader>
            <DialogTitle>{editingContact ? 'Edit Contact' : 'Add New Contact'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Ranch *</Label>
              <Select
                value={newContact.ranch_id}
                onValueChange={(value) => setNewContact({...newContact, ranch_id: value})}
              >
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue placeholder="Select ranch..." />
                </SelectTrigger>
                <SelectContent>
                  {ranches.map(ranch => (
                    <SelectItem key={ranch.id} value={ranch.id}>
                      {ranch.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Full Name *</Label>
                <Input
                  value={newContact.full_name}
                  onChange={(e) => setNewContact({...newContact, full_name: e.target.value})}
                  placeholder="John Doe"
                  className="dark:bg-gray-900"
                />
              </div>
              <div className="space-y-2">
                <Label>Email *</Label>
                <Input
                  type="email"
                  value={newContact.email}
                  onChange={(e) => setNewContact({...newContact, email: e.target.value})}
                  placeholder="email@example.com"
                  className="dark:bg-gray-900"
                />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input
                  value={newContact.phone}
                  onChange={(e) => setNewContact({...newContact, phone: e.target.value})}
                  placeholder="(555) 123-4567"
                  className="dark:bg-gray-900"
                />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Input
                  value={newContact.role}
                  onChange={(e) => setNewContact({...newContact, role: e.target.value})}
                  placeholder="Ranch Manager"
                  className="dark:bg-gray-900"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="is_primary"
                checked={newContact.is_primary}
                onChange={(e) => setNewContact({...newContact, is_primary: e.target.checked})}
                className="w-4 h-4"
              />
              <Label htmlFor="is_primary">Primary Contact</Label>
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={newContact.notes}
                onChange={(e) => setNewContact({...newContact, notes: e.target.value})}
                placeholder="Additional notes..."
                rows={3}
                className="dark:bg-gray-900"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingContact) {
                  updateContactMutation.mutate({ id: editingContact.id, data: newContact });
                } else {
                  createContactMutation.mutate(newContact);
                }
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
              disabled={!newContact.ranch_id || !newContact.full_name || !newContact.email}
            >
              {editingContact ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}