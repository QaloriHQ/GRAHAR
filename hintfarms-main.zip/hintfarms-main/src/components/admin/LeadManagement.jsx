import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit2, Trash2, TrendingUp, Phone, Mail } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function LeadManagement() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingLead, setEditingLead] = useState(null);
  const [newLead, setNewLead] = useState({
    company_name: "",
    contact_name: "",
    email: "",
    phone: "",
    location: "",
    herd_size: 0,
    status: "New",
    source: "Website",
    interest_level: "Warm",
    interested_plan: "Pro",
    notes: "",
    last_contact_date: "",
    next_followup_date: ""
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['admin-leads'],
    queryFn: () => base44.entities.Lead.list('-created_date'),
    initialData: [],
  });

  const createLeadMutation = useMutation({
    mutationFn: (data) => base44.entities.Lead.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leads'] });
      setShowDialog(false);
      resetForm();
      toast.success('Lead created');
    },
  });

  const updateLeadMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leads'] });
      setShowDialog(false);
      setEditingLead(null);
      toast.success('Lead updated');
    },
  });

  const deleteLeadMutation = useMutation({
    mutationFn: (id) => base44.entities.Lead.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leads'] });
      toast.success('Lead deleted');
    },
  });

  const resetForm = () => {
    setNewLead({
      company_name: "",
      contact_name: "",
      email: "",
      phone: "",
      location: "",
      herd_size: 0,
      status: "New",
      source: "Website",
      interest_level: "Warm",
      interested_plan: "Pro",
      notes: "",
      last_contact_date: "",
      next_followup_date: ""
    });
  };

  const handleEdit = (lead) => {
    setEditingLead(lead);
    setNewLead({
      company_name: lead.company_name || "",
      contact_name: lead.contact_name,
      email: lead.email,
      phone: lead.phone || "",
      location: lead.location || "",
      herd_size: lead.herd_size || 0,
      status: lead.status,
      source: lead.source || "Website",
      interest_level: lead.interest_level,
      interested_plan: lead.interested_plan || "Pro",
      notes: lead.notes || "",
      last_contact_date: lead.last_contact_date || "",
      next_followup_date: lead.next_followup_date || ""
    });
    setShowDialog(true);
  };

  const statusColors = {
    'New': 'bg-blue-100 text-blue-800',
    'Contacted': 'bg-purple-100 text-purple-800',
    'Qualified': 'bg-yellow-100 text-yellow-800',
    'Demo Scheduled': 'bg-orange-100 text-orange-800',
    'Proposal': 'bg-indigo-100 text-indigo-800',
    'Negotiation': 'bg-pink-100 text-pink-800',
    'Won': 'bg-green-100 text-green-800',
    'Lost': 'bg-red-100 text-red-800',
  };

  const interestColors = {
    'Cold': 'bg-gray-100 text-gray-800',
    'Warm': 'bg-yellow-100 text-yellow-800',
    'Hot': 'bg-red-100 text-red-800',
  };

  const stats = {
    total: leads.length,
    new: leads.filter(l => l.status === 'New').length,
    qualified: leads.filter(l => l.status === 'Qualified').length,
    won: leads.filter(l => l.status === 'Won').length,
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Leads</p>
            <p className="text-2xl font-bold">{stats.total}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">New</p>
            <p className="text-2xl font-bold text-blue-600">{stats.new}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Qualified</p>
            <p className="text-2xl font-bold text-yellow-600">{stats.qualified}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Won</p>
            <p className="text-2xl font-bold text-green-600">{stats.won}</p>
          </CardContent>
        </Card>
      </div>

      {/* Leads Table */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Leads Pipeline</CardTitle>
            <Button
              onClick={() => {
                setEditingLead(null);
                resetForm();
                setShowDialog(true);
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Lead
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Company</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Interest</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Herd Size</TableHead>
                <TableHead>Next Followup</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leads.map(lead => (
                <TableRow key={lead.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{lead.company_name || 'N/A'}</p>
                      <p className="text-xs text-gray-500">{lead.location}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{lead.contact_name}</p>
                      <div className="flex gap-2 mt-1">
                        {lead.email && (
                          <a href={`mailto:${lead.email}`} className="text-xs text-blue-600 flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                          </a>
                        )}
                        {lead.phone && (
                          <a href={`tel:${lead.phone}`} className="text-xs text-blue-600 flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[lead.status]}>
                      {lead.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={interestColors[lead.interest_level]}>
                      {lead.interest_level}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{lead.interested_plan}</Badge>
                  </TableCell>
                  <TableCell>{lead.herd_size || 'N/A'}</TableCell>
                  <TableCell className="text-sm">
                    {lead.next_followup_date ? format(new Date(lead.next_followup_date), 'MMM dd') : 'N/A'}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(lead)}>
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Delete this lead?')) {
                            deleteLeadMutation.mutate(lead.id);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl dark:bg-gray-950 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingLead ? 'Edit Lead' : 'Add New Lead'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label>Company Name</Label>
              <Input
                value={newLead.company_name}
                onChange={(e) => setNewLead({...newLead, company_name: e.target.value})}
                placeholder="Ranch name..."
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Contact Name *</Label>
              <Input
                value={newLead.contact_name}
                onChange={(e) => setNewLead({...newLead, contact_name: e.target.value})}
                placeholder="John Doe..."
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Email *</Label>
              <Input
                type="email"
                value={newLead.email}
                onChange={(e) => setNewLead({...newLead, email: e.target.value})}
                placeholder="email@example.com"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input
                value={newLead.phone}
                onChange={(e) => setNewLead({...newLead, phone: e.target.value})}
                placeholder="(555) 123-4567"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Input
                value={newLead.location}
                onChange={(e) => setNewLead({...newLead, location: e.target.value})}
                placeholder="Texas, USA"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Herd Size</Label>
              <Input
                type="number"
                value={newLead.herd_size}
                onChange={(e) => setNewLead({...newLead, herd_size: parseInt(e.target.value) || 0})}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={newLead.status} onValueChange={(value) => setNewLead({...newLead, status: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="New">New</SelectItem>
                  <SelectItem value="Contacted">Contacted</SelectItem>
                  <SelectItem value="Qualified">Qualified</SelectItem>
                  <SelectItem value="Demo Scheduled">Demo Scheduled</SelectItem>
                  <SelectItem value="Proposal">Proposal</SelectItem>
                  <SelectItem value="Negotiation">Negotiation</SelectItem>
                  <SelectItem value="Won">Won</SelectItem>
                  <SelectItem value="Lost">Lost</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Interest Level</Label>
              <Select value={newLead.interest_level} onValueChange={(value) => setNewLead({...newLead, interest_level: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cold">Cold</SelectItem>
                  <SelectItem value="Warm">Warm</SelectItem>
                  <SelectItem value="Hot">Hot</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Source</Label>
              <Select value={newLead.source} onValueChange={(value) => setNewLead({...newLead, source: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Website">Website</SelectItem>
                  <SelectItem value="Referral">Referral</SelectItem>
                  <SelectItem value="Social Media">Social Media</SelectItem>
                  <SelectItem value="Event">Event</SelectItem>
                  <SelectItem value="Cold Outreach">Cold Outreach</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Interested Plan</Label>
              <Select value={newLead.interested_plan} onValueChange={(value) => setNewLead({...newLead, interested_plan: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Free">Free</SelectItem>
                  <SelectItem value="Pro">Pro</SelectItem>
                  <SelectItem value="Enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Last Contact Date</Label>
              <Input
                type="date"
                value={newLead.last_contact_date}
                onChange={(e) => setNewLead({...newLead, last_contact_date: e.target.value})}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Next Followup Date</Label>
              <Input
                type="date"
                value={newLead.next_followup_date}
                onChange={(e) => setNewLead({...newLead, next_followup_date: e.target.value})}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={newLead.notes}
                onChange={(e) => setNewLead({...newLead, notes: e.target.value})}
                placeholder="Additional notes..."
                rows={3}
                className="dark:bg-gray-900"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingLead) {
                  updateLeadMutation.mutate({ id: editingLead.id, data: newLead });
                } else {
                  createLeadMutation.mutate(newLead);
                }
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
              disabled={!newLead.contact_name || !newLead.email}
            >
              {editingLead ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}