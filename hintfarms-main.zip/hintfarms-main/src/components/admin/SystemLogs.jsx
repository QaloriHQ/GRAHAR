import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Activity, AlertCircle, CheckCircle, Info } from "lucide-react";
import { format } from "date-fns";

export default function SystemLogs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [logType, setLogType] = useState("all");

  const { data: users = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: () => base44.entities.User.list('-created_date'),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list('-created_date'),
    initialData: [],
  });

  // Generate activity logs from user and ranch data
  const activityLogs = [
    ...users.slice(0, 20).map(u => ({
      id: u.id,
      timestamp: u.created_date,
      type: 'user_signup',
      user: u.email,
      action: 'User signed up',
      details: u.full_name,
      status: 'success'
    })),
    ...ranches.slice(0, 20).map(r => ({
      id: r.id,
      timestamp: r.created_date,
      type: 'ranch_created',
      user: r.owner_email,
      action: 'Ranch created',
      details: r.name,
      status: 'success'
    }))
  ].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const filteredLogs = activityLogs.filter(log => {
    const matchesSearch = log.user?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         log.details?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = logType === 'all' || log.type === logType;
    return matchesSearch && matchesType;
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      success: 'bg-green-100 text-green-800',
      error: 'bg-red-100 text-red-800',
      warning: 'bg-yellow-100 text-yellow-800',
      info: 'bg-blue-100 text-blue-800'
    };
    return colors[status] || colors.info;
  };

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5" />
              System Activity Logs
            </CardTitle>
            <div className="flex gap-2">
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search logs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 dark:bg-gray-900"
                />
              </div>
              <Select value={logType} onValueChange={setLogType}>
                <SelectTrigger className="w-40 dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="user_signup">User Signups</SelectItem>
                  <SelectItem value="ranch_created">Ranch Created</SelectItem>
                  <SelectItem value="subscription">Subscriptions</SelectItem>
                  <SelectItem value="error">Errors</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Timestamp</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Details</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.slice(0, 50).map(log => (
                <TableRow key={log.id}>
                  <TableCell className="text-sm">
                    {format(new Date(log.timestamp), 'MMM dd, yyyy HH:mm')}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-xs">
                      {log.type.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">{log.user}</TableCell>
                  <TableCell className="font-medium">{log.action}</TableCell>
                  <TableCell className="text-sm text-gray-600">{log.details}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(log.status)}
                      <Badge className={getStatusBadge(log.status)}>
                        {log.status}
                      </Badge>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}