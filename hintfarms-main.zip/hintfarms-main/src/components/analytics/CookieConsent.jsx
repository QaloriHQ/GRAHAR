import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, X } from "lucide-react";
import { hasAskedForConsent, setAnalyticsConsent, initGA } from "@/utils";

export default function CookieConsent() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    // Show banner if user hasn't been asked for consent yet
    if (!hasAskedForConsent()) {
      // Small delay to avoid showing banner immediately on page load
      const timer = setTimeout(() => {
        setShowBanner(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    setAnalyticsConsent('accepted');
    setShowBanner(false);
    initGA(); // Initialize GA4 after consent
    
    // Show toast notification
    const event = new CustomEvent('showToast', {
      detail: { 
        message: 'Analytics enabled. Thank you for helping us improve!', 
        type: 'success' 
      }
    });
    window.dispatchEvent(event);
  };

  const handleDecline = () => {
    setAnalyticsConsent('declined');
    setShowBanner(false);
    
    // Show toast notification
    const event = new CustomEvent('showToast', {
      detail: { 
        message: 'Analytics disabled. You can change this anytime in Account Settings.', 
        type: 'info' 
      }
    });
    window.dispatchEvent(event);
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[10000] p-4 md:p-6 pointer-events-none">
      <div className="max-w-4xl mx-auto pointer-events-auto">
        <Card className="bg-white dark:bg-gray-950 border-2 border-emerald-500 dark:border-emerald-600 shadow-2xl">
          <div className="p-6">
            <div className="flex items-start gap-4">
              {/* Icon */}
              <div className="flex-shrink-0 w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">
                  We value your privacy
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  HintFarms uses analytics to understand how you use our app and improve your experience. 
                  We collect anonymous usage data like page views and feature interactions. 
                  Your ranch data remains private and is never shared with third parties.
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-500 mb-4">
                  You can change your preference anytime in <span className="font-semibold">Account Settings → Privacy</span>.
                </p>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    onClick={handleAccept}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    Accept Analytics
                  </Button>
                  <Button
                    onClick={handleDecline}
                    variant="outline"
                    className="border-gray-300 dark:border-gray-700"
                  >
                    Decline
                  </Button>
                </div>
              </div>

              {/* Close button (counts as decline) */}
              <button
                onClick={handleDecline}
                className="flex-shrink-0 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300 transition-colors"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}