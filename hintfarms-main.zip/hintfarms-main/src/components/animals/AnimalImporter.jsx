import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Download,
  X,
  Info
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function AnimalImporter({ open, onOpenChange }) {
  const [file, setFile] = useState(null);
  const [uploadedFileUrl, setUploadedFileUrl] = useState(null);
  const [createMissingPastures, setCreateMissingPastures] = useState(false);
  const [validationResults, setValidationResults] = useState(null);
  const [importResults, setImportResults] = useState(null);
  const [step, setStep] = useState("upload"); // upload, validating, preview, importing, complete
  
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const uploadMutation = useMutation({
    mutationFn: async (file) => {
      const response = await base44.integrations.Core.UploadFile({ file });
      return response.file_url;
    },
    onSuccess: (fileUrl) => {
      setUploadedFileUrl(fileUrl);
      setStep("validating");
      validateMutation.mutate({ fileUrl, createMissingPastures });
    },
  });

  const validateMutation = useMutation({
    mutationFn: async ({ fileUrl, createMissingPastures }) => {
      const response = await base44.functions.invoke('importAnimals', {
        file_url: fileUrl,
        dry_run: true,
        create_missing_pastures: createMissingPastures
      });
      return response.data;
    },
    onSuccess: (data) => {
      setValidationResults(data);
      setStep("preview");
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Validation failed: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
      setStep("upload");
    }
  });

  const importMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('importAnimals', {
        file_url: uploadedFileUrl,
        dry_run: false,
        create_missing_pastures: createMissingPastures
      });
      return response.data;
    },
    onSuccess: (data) => {
      setImportResults(data);
      setStep("complete");
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      
      const event = new CustomEvent('showToast', {
        detail: { 
          message: `Import complete! Created ${data.created_count}, Updated ${data.updated_count}, Skipped ${data.skipped_count}`, 
          type: 'success' 
        }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Import failed: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
      setStep("preview");
    }
  });

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith('.csv')) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Please select a CSV file', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }

    if (selectedFile.size > 10 * 1024 * 1024) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'File size must be less than 10MB', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }

    setFile(selectedFile);
  };

  const handleUpload = () => {
    if (!file) return;
    uploadMutation.mutate(file);
  };

  const handleCommit = () => {
    setStep("importing");
    importMutation.mutate();
  };

  const handleReset = () => {
    setFile(null);
    setUploadedFileUrl(null);
    setValidationResults(null);
    setImportResults(null);
    setStep("upload");
    setCreateMissingPastures(false);
  };

  const handleClose = () => {
    handleReset();
    onOpenChange(false);
  };

  const downloadErrorCSV = () => {
    if (!validationResults?.error_rows) return;

    const headers = ['Row', 'Error'];
    const rows = validationResults.error_rows.map(err => [err.row_number, err.error]);
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'import_errors.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ready':
        return <Badge className="bg-green-100 text-green-800">Ready</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Error</Badge>;
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Import Animals from CSV</DialogTitle>
          <DialogDescription>
            Upload a CSV file to bulk import or update animals
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-auto">
          {step === "upload" && (
            <div className="space-y-6 py-4">
              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>CSV Format Requirements</AlertTitle>
                <AlertDescription>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                    <li>File must be UTF-8 encoded CSV with header row</li>
                    <li>Maximum file size: 10MB</li>
                    <li>Required columns: <code>tag_number</code> or <code>id</code></li>
                    <li>All animals will be imported to your active ranch</li>
                  </ul>
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="csv-file">Select CSV File</Label>
                  <div className="mt-2 flex items-center gap-4">
                    <input
                      id="csv-file"
                      type="file"
                      accept=".csv"
                      onChange={handleFileSelect}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium"
                    />
                    {file && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setFile(null)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  {file && (
                    <p className="text-sm text-gray-500 mt-2">
                      {file.name} ({(file.size / 1024).toFixed(2)} KB)
                    </p>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="create-pastures"
                    checked={createMissingPastures}
                    onCheckedChange={setCreateMissingPastures}
                  />
                  <Label htmlFor="create-pastures" className="text-sm font-normal">
                    Automatically create missing pastures from pasture_location
                  </Label>
                </div>
              </div>
            </div>
          )}

          {step === "validating" && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
              <p className="text-lg font-medium">Validating CSV...</p>
              <p className="text-sm text-gray-500">This may take a moment</p>
            </div>
          )}

          {step === "preview" && validationResults && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-green-700">{validationResults.ready_count || 0}</p>
                  <p className="text-sm text-green-600">Ready to Import</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-yellow-700">{validationResults.warning_count || 0}</p>
                  <p className="text-sm text-yellow-600">Warnings</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-red-700">{validationResults.error_count || 0}</p>
                  <p className="text-sm text-red-600">Errors</p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-blue-700">{validationResults.total_rows || 0}</p>
                  <p className="text-sm text-blue-600">Total Rows</p>
                </div>
              </div>

              {validationResults.error_count > 0 && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Import Blocked</AlertTitle>
                  <AlertDescription>
                    {validationResults.error_count} row(s) have errors that must be fixed before importing.
                    <Button
                      variant="outline"
                      size="sm"
                      className="ml-4"
                      onClick={downloadErrorCSV}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Error Report
                    </Button>
                  </AlertDescription>
                </Alert>
              )}

              <div>
                <h3 className="font-semibold mb-2">Preview (First 50 rows)</h3>
                <ScrollArea className="h-96 border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-16">Row</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Tag Number</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Message</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {validationResults.preview_rows?.slice(0, 50).map((row, idx) => (
                        <TableRow key={idx}>
                          <TableCell>{row.row_number}</TableCell>
                          <TableCell>{getStatusBadge(row.status)}</TableCell>
                          <TableCell>{row.tag_number || '-'}</TableCell>
                          <TableCell>{row.name || '-'}</TableCell>
                          <TableCell>{row.type || '-'}</TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {row.message || '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </div>
            </div>
          )}

          {step === "importing" && (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
              <p className="text-lg font-medium">Importing Animals...</p>
              <p className="text-sm text-gray-500">Please wait, this may take a few moments</p>
            </div>
          )}

          {step === "complete" && importResults && (
            <div className="space-y-6 py-4">
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <AlertTitle className="text-green-800">Import Successful!</AlertTitle>
                <AlertDescription className="text-green-700">
                  Your animals have been imported successfully.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-3 gap-4">
                <div className="bg-emerald-50 p-6 rounded-lg text-center">
                  <p className="text-3xl font-bold text-emerald-700">{importResults.created_count}</p>
                  <p className="text-sm text-emerald-600 mt-1">Created</p>
                </div>
                <div className="bg-blue-50 p-6 rounded-lg text-center">
                  <p className="text-3xl font-bold text-blue-700">{importResults.updated_count}</p>
                  <p className="text-sm text-blue-600 mt-1">Updated</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg text-center">
                  <p className="text-3xl font-bold text-gray-700">{importResults.skipped_count}</p>
                  <p className="text-sm text-gray-600 mt-1">Skipped</p>
                </div>
              </div>

              {importResults.error_rows && importResults.error_rows.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Errors</h3>
                  <ScrollArea className="h-48 border rounded-lg p-4">
                    <ul className="space-y-2">
                      {importResults.error_rows.map((err, idx) => (
                        <li key={idx} className="text-sm text-red-600">
                          Row {err.row_number}: {err.error}
                        </li>
                      ))}
                    </ul>
                  </ScrollArea>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={handleClose}>
            {step === "complete" ? "Close" : "Cancel"}
          </Button>
          
          <div className="flex gap-2">
            {step === "upload" && (
              <Button
                onClick={handleUpload}
                disabled={!file || uploadMutation.isPending}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {uploadMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload & Validate
                  </>
                )}
              </Button>
            )}

            {step === "preview" && (
              <>
                <Button variant="outline" onClick={handleReset}>
                  Start Over
                </Button>
                <Button
                  onClick={handleCommit}
                  disabled={
                    validationResults.error_count > 0 ||
                    validationResults.ready_count === 0
                  }
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Commit Import
                </Button>
              </>
            )}

            {step === "complete" && (
              <Button onClick={handleReset} className="bg-emerald-600 hover:bg-emerald-700">
                Import Another File
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}