import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Beef } from "lucide-react";

export default function AnimalSelector({ onSelect, excludeIds = [], filterGender = null, ranchId }) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', ranchId],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: ranchId }),
    enabled: !!ranchId,
  });

  const filteredAnimals = animals.filter(animal => {
    // Exclude specified IDs
    if (excludeIds.includes(animal.id)) return false;
    
    // Filter by gender if specified
    if (filterGender && animal.gender !== filterGender) return false;
    
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        animal.name.toLowerCase().includes(query) ||
        animal.tag_number.toLowerCase().includes(query) ||
        animal.breed?.toLowerCase().includes(query)
      );
    }
    
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
        <Input
          placeholder="Search by name, tag, or breed..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
        />
      </div>

      <ScrollArea className="h-[300px] border rounded-lg dark:border-gray-700">
        {filteredAnimals.length > 0 ? (
          <div className="p-2 space-y-1">
            {filteredAnimals.map(animal => (
              <Button
                key={animal.id}
                variant="ghost"
                className="w-full justify-start hover:bg-emerald-50 dark:hover:bg-emerald-900/20 dark:text-gray-300"
                onClick={() => onSelect(animal)}
              >
                <Beef className="w-4 h-4 mr-3 text-emerald-600 dark:text-emerald-400" />
                <div className="flex flex-col items-start">
                  <span className="font-semibold dark:text-gray-100">{animal.name}</span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {animal.tag_number} • {animal.breed} • {animal.gender}
                  </span>
                </div>
              </Button>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <Beef className="w-12 h-12 text-gray-300 dark:text-gray-600 mb-3" />
            <p className="text-gray-500 dark:text-gray-400">
              {searchQuery ? "No animals found matching your search" : "No animals available"}
            </p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
}