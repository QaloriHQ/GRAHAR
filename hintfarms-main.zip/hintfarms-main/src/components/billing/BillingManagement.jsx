import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  CreditCard,
  Crown,
  Sparkles,
  CheckCircle2,
  Loader2,
  Calendar,
  DollarSign,
  AlertCircle,
  Settings,
  TrendingDown,
  Info,
  Check, // New
  Zap, // New
  ExternalLink, // New
  Building2, // New
  Users, // New
} from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { toast } from "sonner"; // New import
import { trackPlanUpgrade, trackBillingPortalOpen } from "@/components/utils"; // New import

export default function BillingManagement() {
  const [loading, setLoading] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);
  const [refreshLoading, setRefreshLoading] = useState(false); // New state for refresh button
  const [downgradeLoading, setDowngradeLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showDowngradeDialog, setShowDowngradeDialog] = useState(false);
  const [selectedDowngrade, setSelectedDowngrade] = useState(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch, isLoading: ranchLoading, refetch: refetchRanch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) {
        console.warn('No active_ranch_id on user, cannot fetch ranch.');
        return null;
      }
      console.log('Fetching ranch data for active_ranch_id:', user.active_ranch_id);
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      const fetchedRanch = ranches?.[0] || null;
      console.log('Fetched ranch billing data:', {
        id: fetchedRanch?.id,
        subscription_plan: fetchedRanch?.subscription_plan,
        subscription_status: fetchedRanch?.subscription_status,
        stripe_customer_id: fetchedRanch?.stripe_customer_id,
        stripe_subscription_id: fetchedRanch?.stripe_subscription_id,
        current_period_end: fetchedRanch?.current_period_end,
        cancel_at_period_end: fetchedRanch?.cancel_at_period_end
      });
      return fetchedRanch;
    },
    enabled: !!user?.active_ranch_id,
    staleTime: 0,
    cacheTime: 0,
  });

  // Refetch ranch data when component mounts
  useEffect(() => { // Changed from React.useEffect
    console.log('BillingManagement mounted - refetching ranch data');
    if (user?.active_ranch_id) {
      refetchRanch();
    }
  }, [user?.active_ranch_id, refetchRanch]);

  const plans = [
    {
      name: "Pro",
      price: "$24",
      period: "/month",
      description: "Perfect for growing ranches",
      features: [
        "Unlimited animals",
        "Team management (up to 10 members)",
        "Advanced reports",
        "Data export",
        "Priority support",
        "Mobile app access"
      ],
      priceId: "pro",
      highlighted: true
    },
    {
      name: "Enterprise",
      price: "$99",
      period: "/month",
      description: "For large-scale operations",
      features: [
        "Everything in Pro",
        "Unlimited team members",
        "Custom integrations",
        "Dedicated account manager",
        "SLA guarantee",
        "Advanced analytics",
        "API access"
      ],
      priceId: "enterprise",
      highlighted: false
    }
  ];

  const handleUpgrade = async (priceId, planName) => {
    setLoading(true);
    setError(null);

    try {
      console.log('Starting checkout for plan:', planName, 'priceId:', priceId);
      console.log('User:', user?.email, 'Ranch:', ranch?.id);

      const response = await base44.functions.invoke('createCheckoutSession', {
        priceId: priceId,
        planName: planName
      });

      console.log('Checkout response:', response);

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      if (response.data?.url) {
        console.log('Redirecting to:', response.data.url);
        queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
        queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        trackPlanUpgrade(planName); // Tracking event
        window.location.href = response.data.url;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      const errorMessage = error.message || 'Failed to start checkout process';
      setError(`Checkout failed: ${errorMessage}`);
      toast.error(`Checkout failed: ${errorMessage}`); // Use sonner toast
    } finally {
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    setPortalLoading(true);
    setError(null);

    try {
      console.log('Opening Stripe Customer Portal...');
      const response = await base44.functions.invoke('createCustomerPortalSession', {});

      console.log('Portal response:', response);

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      if (response.data?.url) {
        console.log('Redirecting to portal:', response.data.url);
        queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
        queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        trackBillingPortalOpen(); // Tracking event
        window.location.href = response.data.url;
      } else {
        throw new Error('No portal URL received');
      }
    } catch (error) {
      console.error('Portal error:', error);
      const errorMessage = error.message || 'Unknown error';
      setError(`Failed to open billing portal: ${errorMessage}`);
      toast.error(`Failed to open billing portal: ${errorMessage}`); // Use sonner toast
    } finally {
      setPortalLoading(false);
    }
  };

  const handleRefreshSubscription = async () => {
    setRefreshLoading(true);
    setError(null);

    try {
      console.log('Refreshing subscription data from Stripe...');
      const response = await base44.functions.invoke('refreshStripeSubscription', {});

      console.log('Refresh response:', response);

      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      if (response.data?.success) {
        // Invalidate queries to refresh data
        await queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
        await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        
        // Show success message
        toast.success(response.data.message || 'Subscription data refreshed successfully'); // Use sonner toast

        // Refetch ranch data
        await refetchRanch();
      }
    } catch (error) {
      console.error('Refresh error:', error);
      const errorMessage = error.message || 'Failed to refresh subscription data';
      setError(`Failed to refresh subscription: ${errorMessage}`);
      toast.error(errorMessage); // Use sonner toast
    } finally {
      setRefreshLoading(false);
    }
  };

  const handleDowngrade = async () => {
    if (!selectedDowngrade) return;

    setDowngradeLoading(true);
    setError(null);

    try {
      console.log('Starting downgrade to:', selectedDowngrade);
      const response = await base44.functions.invoke('downgradeSubscription', {
        target_plan: selectedDowngrade
      });

      console.log('Downgrade response:', response);

      if (response.data?.error) {
        throw new Error(response.data.message || response.data.error);
      }

      if (response.data?.success) {
        // Invalidate queries to refresh data
        await queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
        await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        
        setShowDowngradeDialog(false);
        setSelectedDowngrade(null);
        
        // Show success message
        toast.success(response.data.message || 'Downgrade successful'); // Use sonner toast

        // Refetch ranch data
        await refetchRanch();
      }
    } catch (error) {
      console.error('Downgrade error:', error);
      setError(`Downgrade failed: ${error.message}`);
      toast.error(`Downgrade failed: ${error.message}`); // Use sonner toast
      setShowDowngradeDialog(false);
    } finally {
      setDowngradeLoading(false);
    }
  };

  if (ranchLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#F5A623]" />
      </div>
    );
  }

  const currentPlan = ranch?.subscription_plan || "Free";
  const isSubscribed = ranch?.stripe_customer_id && ranch?.stripe_subscription_id;
  const isTrial = currentPlan === "Pro Trial";
  const isCanceling = ranch?.cancel_at_period_end;
  const isFree = currentPlan === "Free";

  // Calculate trial days remaining
  const trialDaysRemaining = useEffect(() => { // Changed from React.useMemo
    if (isTrial && ranch?.trial_end_date) {
      const today = new Date();
      const endDate = new Date(ranch.trial_end_date);
      const daysLeft = differenceInDays(endDate, today);
      return daysLeft >= 0 ? daysLeft : 0;
    }
    return null;
  }, [ranch, isTrial]);

  // Determine status badge
  const getStatusBadge = () => {
    if (isCanceling) {
      return (
        <Badge className="bg-orange-100 text-orange-800 border-orange-200">
          Canceling at Period End
        </Badge>
      );
    }
    if (isTrial) {
      return (
        <Badge className="bg-blue-100 text-blue-800 border-blue-200">
          <Sparkles className="w-3 h-3 mr-1" />
          Trial ({trialDaysRemaining} days left)
        </Badge>
      );
    }
    if (ranch?.subscription_status === 'past_due') {
      return (
        <Badge className="bg-red-100 text-red-800 border-red-200">
          <AlertCircle className="w-3 h-3 mr-1" />
          Payment Required
        </Badge>
      );
    }
    if (ranch?.subscription_status === 'active') {
      return (
        <Badge className="bg-green-100 text-green-800 border-green-200">
          <CheckCircle2 className="w-3 h-3 mr-1" />
          Active
        </Badge>
      );
    }
    return null;
  };

  // Downgrade options
  const getDowngradeOptions = () => {
    if (currentPlan === 'Enterprise') {
      return ['Pro', 'Free'];
    }
    if (currentPlan === 'Pro' || currentPlan === 'Pro Trial') {
      return ['Free'];
    }
    return [];
  };

  const downgradeOptions = getDowngradeOptions();
  const canDowngrade = downgradeOptions.length > 0 && isSubscribed;

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Current Plan Card */}
      <Card className="border-orange-200 dark:border-orange-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Current Subscription Plan
                {getStatusBadge()}
              </CardTitle>
              <CardDescription>Manage your HintFarms subscription and billing</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Plan Details */}
          <div className="flex items-center justify-between p-6 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-lg border border-orange-200 dark:border-orange-800">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#F5A623] rounded-full flex items-center justify-center">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{currentPlan}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {isFree && "Basic features for small ranches"}
                  {currentPlan === 'Pro' && "$24/month - Professional ranch management"}
                  {currentPlan === 'Pro Trial' && "Trial of Pro features"}
                  {currentPlan === 'Enterprise' && "$99/month - Enterprise-grade management"}
                </p>
              </div>
            </div>
            <div className="flex gap-3">
              {ranch?.stripe_customer_id && (
                <Button
                  onClick={handleRefreshSubscription}
                  disabled={refreshLoading}
                  variant="outline"
                  className="border-gray-300 dark:border-gray-700"
                >
                  {refreshLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Refreshing...
                    </>
                  ) : (
                    <>
                      <Settings className="w-4 h-4 mr-2" />
                      Refresh
                    </>
                  )}
                </Button>
              )}
              {isSubscribed && (
                <Button
                  onClick={handleManageSubscription}
                  disabled={portalLoading}
                  className="bg-[#F5A623] hover:bg-[#E09612]"
                >
                  {portalLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Opening...
                    </>
                  ) : (
                    <>
                      <Settings className="w-4 h-4 mr-2" />
                      Manage Subscription
                    </>
                  )}
                </Button>
              )}
              {canDowngrade && (
                <Button
                  onClick={() => setShowDowngradeDialog(true)}
                  variant="outline"
                  className="border-gray-300 dark:border-gray-700"
                >
                  <TrendingDown className="w-4 h-4 mr-2" />
                  Downgrade
                </Button>
              )}
            </div>
          </div>

          {/* Subscription Details */}
          {isSubscribed && (
            <div className="grid md:grid-cols-2 gap-4">
              {ranch?.current_period_end && (
                <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <Calendar className="w-5 h-5 text-gray-400 dark:text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {isCanceling ? "Active Until" : "Renews On"}
                    </p>
                    <p className="font-semibold text-gray-900 dark:text-gray-100">
                      {format(new Date(ranch.current_period_end), "MMMM d, yyyy")}
                    </p>
                  </div>
                </div>
              )}
              {(currentPlan === 'Pro' || currentPlan === 'Enterprise') && (
                <div className="flex items-center gap-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <DollarSign className="w-5 h-5 text-gray-400 dark:text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Monthly Cost</p>
                    <p className="font-semibold text-gray-900 dark:text-gray-100">
                      {currentPlan === 'Pro' ? '$24' : '$99'} USD
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Cancellation Notice */}
          {isCanceling && ranch?.current_period_end && (
            <Alert>
              <AlertCircle className="w-4 h-4" />
              <AlertTitle>Subscription Scheduled for Cancellation</AlertTitle>
              <AlertDescription>
                Your subscription will be canceled on {format(new Date(ranch.current_period_end), "MMMM d, yyyy")}. 
                You'll be moved to the Free plan and will lose access to premium features. You can reactivate anytime before this date.
              </AlertDescription>
            </Alert>
          )}

          {/* Trial Notice */}
          {isTrial && ranch?.trial_end_date && (
            <Alert className="border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/20">
              <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <AlertTitle className="text-blue-800 dark:text-blue-300">Pro Trial Active</AlertTitle>
              <AlertDescription className="text-blue-700 dark:text-blue-400">
                Your trial ends on {format(new Date(ranch.trial_end_date), "MMMM d, yyyy")} ({trialDaysRemaining} days remaining). 
                Upgrade to Pro to continue using premium features after your trial ends.
              </AlertDescription>
            </Alert>
          )}

          {/* Portal Info */}
          {isSubscribed && (
            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-800 dark:text-blue-300 font-semibold">Manage Everything in One Place</p>
                  <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
                    Use the "Manage Subscription" button to update payment methods, view invoices, change plans, or cancel your subscription through Stripe's secure portal.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Free Plan Info */}
          {isFree && !isSubscribed && (
            <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-gray-600 dark:text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-800 dark:text-gray-300 font-semibold">You're on the Free Plan</p>
                  <p className="text-sm text-gray-700 dark:text-gray-400 mt-1">
                    Upgrade to Pro or Enterprise to unlock advanced features like team management, data export, and priority support.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upgrade Options (if not on highest plan) */}
      {(!isSubscribed || isTrial || currentPlan === 'Pro') && (
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold mb-2 dark:text-gray-100">
              {isFree ? "Upgrade Your Plan" : "Upgrade to Enterprise"}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
              {isFree ? "Choose a plan that fits your ranch's needs" : "Unlock enterprise-grade features for large-scale operations"}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {plans.map((plan) => {
              // Only show Pro if on Free/Trial, only show Enterprise if on Pro/Free/Trial
              const shouldShow = (plan.name === 'Pro' && (isFree || isTrial)) || 
                                 (plan.name === 'Enterprise' && currentPlan !== 'Enterprise');
              
              if (!shouldShow) return null;

              return (
                <Card
                  key={plan.name}
                  className={`relative ${
                    plan.highlighted
                      ? "border-[#F5A623] border-2 shadow-lg"
                      : "border-gray-200 dark:border-gray-700"
                  }`}
                >
                  {plan.highlighted && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-[#F5A623] text-white px-4 py-1">
                        <Sparkles className="w-3 h-3 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                  )}

                  <CardHeader>
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold dark:text-gray-100">{plan.price}</span>
                      <span className="text-gray-500 dark:text-gray-400">{plan.period}</span>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <CheckCircle2 className="w-5 h-5 text-[#F5A623] flex-shrink-0 mt-0.5" />
                          <span className="text-sm dark:text-gray-300">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Button
                      onClick={() => handleUpgrade(plan.priceId, plan.name)}
                      disabled={loading}
                      className={`w-full ${
                        plan.highlighted
                          ? "bg-[#F5A623] hover:bg-[#E09612]"
                          : "bg-gray-900 hover:bg-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600"
                      }`}
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade to {plan.name}
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* Downgrade Dialog */}
      <Dialog open={showDowngradeDialog} onOpenChange={setShowDowngradeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Downgrade Subscription</DialogTitle>
            <DialogDescription>
              Are you sure you want to downgrade your subscription? You'll lose access to premium features.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <Alert variant="destructive">
              <AlertCircle className="h-4 h-4" />
              <AlertTitle>Warning</AlertTitle>
              <AlertDescription>
                Downgrading will restrict access to features included in your current plan. This action will take effect{" "}
                {ranch?.current_period_end ? `at the end of your billing period on ${format(new Date(ranch.current_period_end), "MMMM d, yyyy")}` : "immediately"}.
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <p className="text-sm font-semibold dark:text-gray-200">Select downgrade option:</p>
              {downgradeOptions.map(option => (
                <Button
                  key={option}
                  variant={selectedDowngrade === option ? "default" : "outline"}
                  className="w-full justify-start"
                  onClick={() => setSelectedDowngrade(option)}
                >
                  <TrendingDown className="w-4 h-4 mr-2" />
                  Downgrade to {option}
                </Button>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDowngradeDialog(false);
                setSelectedDowngrade(null);
              }}
              disabled={downgradeLoading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleDowngrade}
              disabled={!selectedDowngrade || downgradeLoading}
              variant="destructive"
            >
              {downgradeLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                'Confirm Downgrade'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}