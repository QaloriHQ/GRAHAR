import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Upload, X } from "lucide-react";
import AnimalSelector from "../animals/AnimalSelector";

export default function BreedingRecordForm({ open, onOpenChange, animalId, animalName, ranchId }) {
  const queryClient = useQueryClient();
  const [showSireSelector, setShowSireSelector] = useState(false);
  const [showDamSelector, setShowDamSelector] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const [formData, setFormData] = useState({
    record_type: "Service",
    breeding_date: new Date().toISOString().split('T')[0],
    expected_calving_date: "",
    actual_calving_date: "",
    breeding_method: "Natural",
    conception_confirmed: false,
    outcome: "N/A",
    bull_id: "",
    bull_name: "",
    calf_id: "",
    calf_gender: "Unknown",
    calf_weight: 0,
    notes: "",
    attachments_url: [],
    status: "Breeding"
  });

  const createRecordMutation = useMutation({
    mutationFn: (data) => base44.entities.BreedingRecord.create({
      ...data,
      ranch_id: ranchId,
      animal_id: animalId,
      animal_name: animalName
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['breedingRecords'] });
      onOpenChange(false);
      resetForm();
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Breeding record created successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const resetForm = () => {
    setFormData({
      record_type: "Service",
      breeding_date: new Date().toISOString().split('T')[0],
      expected_calving_date: "",
      actual_calving_date: "",
      breeding_method: "Natural",
      conception_confirmed: false,
      outcome: "N/A",
      bull_id: "",
      bull_name: "",
      calf_id: "",
      calf_gender: "Unknown",
      calf_weight: 0,
      notes: "",
      attachments_url: [],
      status: "Breeding"
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingFile(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({
        ...prev,
        attachments_url: [...(prev.attachments_url || []), data.file_url]
      }));
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'File uploaded successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    } catch (error) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Failed to upload file', type: 'error' }
      });
      window.dispatchEvent(event);
    } finally {
      setUploadingFile(false);
    }
  };

  const removeAttachment = (index) => {
    setFormData(prev => ({
      ...prev,
      attachments_url: prev.attachments_url.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validate: if outcome is Live Calf and no calf_id, show prompt
    if (formData.outcome === "Live Calf" && !formData.calf_id) {
      const shouldContinue = window.confirm(
        "You've marked this as 'Live Calf' but haven't linked a calf yet. Do you want to continue anyway?"
      );
      if (!shouldContinue) return;
    }

    createRecordMutation.mutate(formData);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-gray-100">Add Breeding Record for {animalName}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Record Type *</Label>
                <Select 
                  value={formData.record_type} 
                  onValueChange={(value) => setFormData({...formData, record_type: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Service" className="dark:text-gray-100">Service</SelectItem>
                    <SelectItem value="AI" className="dark:text-gray-100">AI (Artificial Insemination)</SelectItem>
                    <SelectItem value="Pregnancy Check" className="dark:text-gray-100">Pregnancy Check</SelectItem>
                    <SelectItem value="Calving" className="dark:text-gray-100">Calving</SelectItem>
                    <SelectItem value="Weaning" className="dark:text-gray-100">Weaning</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Date *</Label>
                <Input
                  type="date"
                  value={formData.breeding_date}
                  onChange={(e) => setFormData({...formData, breeding_date: e.target.value})}
                  required
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Breeding Method</Label>
                <Select 
                  value={formData.breeding_method} 
                  onValueChange={(value) => setFormData({...formData, breeding_method: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Natural" className="dark:text-gray-100">Natural</SelectItem>
                    <SelectItem value="Artificial Insemination" className="dark:text-gray-100">Artificial Insemination</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Outcome</Label>
                <Select 
                  value={formData.outcome} 
                  onValueChange={(value) => setFormData({...formData, outcome: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="N/A" className="dark:text-gray-100">N/A</SelectItem>
                    <SelectItem value="Pregnant" className="dark:text-gray-100">Pregnant</SelectItem>
                    <SelectItem value="Open" className="dark:text-gray-100">Open</SelectItem>
                    <SelectItem value="Live Calf" className="dark:text-gray-100">Live Calf</SelectItem>
                    <SelectItem value="Stillborn" className="dark:text-gray-100">Stillborn</SelectItem>
                    <SelectItem value="Aborted" className="dark:text-gray-100">Aborted</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Sire (Bull)</Label>
                <div className="flex gap-2">
                  <Input
                    value={formData.bull_name}
                    placeholder="Select bull..."
                    readOnly
                    className="flex-1 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowSireSelector(true)}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    Select
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Expected Calving Date</Label>
                <Input
                  type="date"
                  value={formData.expected_calving_date}
                  onChange={(e) => setFormData({...formData, expected_calving_date: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Actual Calving Date</Label>
                <Input
                  type="date"
                  value={formData.actual_calving_date}
                  onChange={(e) => setFormData({...formData, actual_calving_date: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-300">Calf Weight (lbs)</Label>
                <Input
                  type="number"
                  value={formData.calf_weight}
                  onChange={(e) => setFormData({...formData, calf_weight: parseFloat(e.target.value)})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="dark:text-gray-300">Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="Add any additional notes..."
                rows={3}
                className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label className="dark:text-gray-300">Attachments</Label>
              <div className="flex flex-wrap gap-2 mb-2">
                {formData.attachments_url?.map((url, index) => (
                  <div key={index} className="relative group">
                    <img src={url} alt="Attachment" className="w-20 h-20 object-cover rounded border dark:border-gray-700" />
                    <button
                      type="button"
                      onClick={() => removeAttachment(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
              <Button
                type="button"
                variant="outline"
                disabled={uploadingFile}
                className="w-full dark:border-gray-700 dark:text-gray-300"
                onClick={() => document.getElementById('file-upload').click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploadingFile ? "Uploading..." : "Upload File"}
              </Button>
              <input
                id="file-upload"
                type="file"
                accept="image/*,.pdf"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="dark:border-gray-700 dark:text-gray-300">
                Cancel
              </Button>
              <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700" disabled={createRecordMutation.isPending}>
                {createRecordMutation.isPending ? "Creating..." : "Create Record"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Sire Selector Dialog */}
      <Dialog open={showSireSelector} onOpenChange={setShowSireSelector}>
        <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
          <DialogHeader>
            <DialogTitle className="dark:text-gray-100">Select Sire (Bull)</DialogTitle>
          </DialogHeader>
          <AnimalSelector
            ranchId={ranchId}
            excludeIds={[animalId]}
            filterGender="Male"
            onSelect={(animal) => {
              setFormData({
                ...formData,
                bull_id: animal.id,
                bull_name: animal.name
              });
              setShowSireSelector(false);
            }}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}