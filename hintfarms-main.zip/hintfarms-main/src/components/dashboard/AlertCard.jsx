import React from 'react';
import { Card } from "@/components/ui/card";
import { AlertCircle, AlertTriangle, Info, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

const severityConfig = {
  Critical: {
    icon: AlertCircle,
    bg: "bg-red-50",
    border: "border-red-200",
    text: "text-red-800",
    iconColor: "text-red-600",
    badgeBg: "bg-red-100"
  },
  Urgent: {
    icon: AlertTriangle,
    bg: "bg-orange-50",
    border: "border-orange-200",
    text: "text-orange-800",
    iconColor: "text-orange-600",
    badgeBg: "bg-orange-100"
  },
  Warning: {
    icon: AlertTriangle,
    bg: "bg-yellow-50",
    border: "border-yellow-200",
    text: "text-yellow-800",
    iconColor: "text-yellow-600",
    badgeBg: "bg-yellow-100"
  },
  Info: {
    icon: Info,
    bg: "bg-blue-50",
    border: "border-blue-200",
    text: "text-blue-800",
    iconColor: "text-blue-600",
    badgeBg: "bg-blue-100"
  }
};

export default function AlertCard({ alert }) {
  const config = severityConfig[alert.severity];
  const Icon = config.icon;

  return (
    <Card className={`${config.bg} ${config.border} border`}>
      <div className="p-4">
        <div className="flex items-start gap-3">
          <Icon className={`w-5 h-5 ${config.iconColor} mt-0.5`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className={`font-semibold ${config.text}`}>{alert.title}</h4>
              <Badge className={`${config.badgeBg} ${config.text} text-xs`}>
                {alert.severity}
              </Badge>
            </div>
            <p className={`text-sm ${config.text} mb-2`}>{alert.message}</p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-500">
                {format(new Date(alert.date), "MMM d, yyyy")}
              </span>
              {alert.action_required && (
                <Button size="sm" variant="outline" className="h-7 text-xs">
                  {alert.action_required}
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}