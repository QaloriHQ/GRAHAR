import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Camera, Upload, Loader2, X } from "lucide-react";
import { toast } from "sonner";

export default function QuickHealthRecord({ open, onOpenChange, location, onSave, isOnline }) {
  const [formData, setFormData] = useState({
    animal_id: '',
    record_type: 'Treatment',
    description: '',
    medication_name: '',
    date: new Date().toISOString().split('T')[0]
  });
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const createRecordMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.HealthRecord.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
      toast.success('Health record saved');
      resetForm();
      onOpenChange(false);
    },
  });

  const handlePhotoCapture = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const uploadPhoto = async () => {
    if (!photoFile) return null;
    
    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file: photoFile });
      return response.file_url;
    } catch (error) {
      toast.error('Photo upload failed');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const selectedAnimal = animals.find(a => a.id === formData.animal_id);
    if (!selectedAnimal) {
      toast.error('Please select an animal');
      return;
    }

    let photoUrl = null;
    if (photoFile && isOnline) {
      photoUrl = await uploadPhoto();
    }

    const recordData = {
      ...formData,
      ranch_id: user.active_ranch_id,
      animal_name: selectedAnimal.name,
      notes: location ? `Location: ${location.lat.toFixed(4)}, ${location.lon.toFixed(4)}\n${formData.description}` : formData.description,
      ...(photoUrl && { receipt_url: photoUrl })
    };

    if (isOnline) {
      createRecordMutation.mutate(recordData);
    } else {
      onSave('health_record', recordData);
      resetForm();
      onOpenChange(false);
    }
  };

  const resetForm = () => {
    setFormData({
      animal_id: '',
      record_type: 'Treatment',
      description: '',
      medication_name: '',
      date: new Date().toISOString().split('T')[0]
    });
    setPhotoFile(null);
    setPhotoPreview(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Quick Health Record</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Animal</Label>
            <Select value={formData.animal_id} onValueChange={(value) => setFormData({...formData, animal_id: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select animal" />
              </SelectTrigger>
              <SelectContent>
                {animals.map(animal => (
                  <SelectItem key={animal.id} value={animal.id}>
                    {animal.name} - {animal.tag_number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Type</Label>
            <Select value={formData.record_type} onValueChange={(value) => setFormData({...formData, record_type: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Treatment">Treatment</SelectItem>
                <SelectItem value="Vaccination">Vaccination</SelectItem>
                <SelectItem value="Checkup">Checkup</SelectItem>
                <SelectItem value="Surgery">Surgery</SelectItem>
                <SelectItem value="Medication">Medication</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="What was observed or treated?"
              rows={3}
              required
            />
          </div>

          <div>
            <Label>Medication (Optional)</Label>
            <Input
              value={formData.medication_name}
              onChange={(e) => setFormData({...formData, medication_name: e.target.value})}
              placeholder="Medicine name"
            />
          </div>

          {/* Photo Capture */}
          <div>
            <Label>Photo (Optional)</Label>
            <div className="flex gap-2">
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => cameraInputRef.current?.click()}
              >
                <Camera className="w-4 h-4 mr-2" />
                Take Photo
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
            </div>
            {photoPreview && (
              <div className="mt-2 relative">
                <img src={photoPreview} alt="Preview" className="w-full h-40 object-cover rounded-lg" />
                <Button
                  type="button"
                  size="icon"
                  variant="destructive"
                  className="absolute top-2 right-2"
                  onClick={() => {
                    setPhotoFile(null);
                    setPhotoPreview(null);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700"
            disabled={createRecordMutation.isPending || uploading}
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading Photo...
              </>
            ) : createRecordMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Record'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}