import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function QuickInventoryLog({ open, onOpenChange, location, onSave, isOnline }) {
  const [formData, setFormData] = useState({
    item_name: '',
    quantity: '',
    unit: 'bags',
    action: 'used',
    notes: ''
  });
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const createInventoryMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Inventory.create(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
      toast.success('Inventory logged');
      resetForm();
      onOpenChange(false);
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const inventoryData = {
      ...formData,
      ranch_id: user.active_ranch_id,
      date: new Date().toISOString().split('T')[0],
      quantity: parseFloat(formData.quantity),
      notes: location 
        ? `Location: ${location.lat.toFixed(4)}, ${location.lon.toFixed(4)}\n${formData.notes}`
        : formData.notes
    };

    if (isOnline) {
      createInventoryMutation.mutate(inventoryData);
    } else {
      onSave('inventory_log', inventoryData);
      resetForm();
      onOpenChange(false);
    }
  };

  const resetForm = () => {
    setFormData({
      item_name: '',
      quantity: '',
      unit: 'bags',
      action: 'used',
      notes: ''
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Quick Inventory Log</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Item Name</Label>
            <Input
              value={formData.item_name}
              onChange={(e) => setFormData({...formData, item_name: e.target.value})}
              placeholder="e.g., Hay, Feed, Medicine"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Quantity</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                placeholder="0"
                required
              />
            </div>
            <div>
              <Label>Unit</Label>
              <Select value={formData.unit} onValueChange={(value) => setFormData({...formData, unit: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bags">Bags</SelectItem>
                  <SelectItem value="bales">Bales</SelectItem>
                  <SelectItem value="lbs">Pounds</SelectItem>
                  <SelectItem value="gallons">Gallons</SelectItem>
                  <SelectItem value="units">Units</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Action</Label>
            <Select value={formData.action} onValueChange={(value) => setFormData({...formData, action: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="used">Used</SelectItem>
                <SelectItem value="added">Added/Received</SelectItem>
                <SelectItem value="wasted">Wasted/Lost</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Notes (Optional)</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Additional details..."
              rows={2}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700"
            disabled={createInventoryMutation.isPending}
          >
            {createInventoryMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              'Log Inventory'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}