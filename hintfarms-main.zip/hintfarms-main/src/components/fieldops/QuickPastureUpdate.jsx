import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Camera, Upload, Loader2, X } from "lucide-react";
import { toast } from "sonner";

export default function QuickPastureUpdate({ open, onOpenChange, location, onSave, isOnline }) {
  const [formData, setFormData] = useState({
    pasture_id: '',
    condition: 'Good',
    grazing_quality: 'Good',
    notes: ''
  });
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const cameraInputRef = useRef(null);
  const fileInputRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const updatePastureMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Pasture.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      toast.success('Pasture updated');
      resetForm();
      onOpenChange(false);
    },
  });

  const handlePhotoCapture = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const uploadPhoto = async () => {
    if (!photoFile) return null;
    
    setUploading(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file: photoFile });
      return response.file_url;
    } catch (error) {
      toast.error('Photo upload failed');
      return null;
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.pasture_id) {
      toast.error('Please select a pasture');
      return;
    }

    let photoUrl = null;
    if (photoFile && isOnline) {
      photoUrl = await uploadPhoto();
    }

    const updateData = {
      id: formData.pasture_id,
      condition: formData.condition,
      grazing_quality: formData.grazing_quality,
      notes: location 
        ? `${new Date().toISOString()}\nLocation: ${location.lat.toFixed(4)}, ${location.lon.toFixed(4)}\n${formData.notes}`
        : `${new Date().toISOString()}\n${formData.notes}`,
      ...(photoUrl && { image_url: photoUrl })
    };

    if (isOnline) {
      updatePastureMutation.mutate(updateData);
    } else {
      onSave('pasture_update', updateData);
      resetForm();
      onOpenChange(false);
    }
  };

  const resetForm = () => {
    setFormData({
      pasture_id: '',
      condition: 'Good',
      grazing_quality: 'Good',
      notes: ''
    });
    setPhotoFile(null);
    setPhotoPreview(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Quick Pasture Update</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Pasture</Label>
            <Select value={formData.pasture_id} onValueChange={(value) => setFormData({...formData, pasture_id: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select pasture" />
              </SelectTrigger>
              <SelectContent>
                {pastures.map(pasture => (
                  <SelectItem key={pasture.id} value={pasture.id}>
                    {pasture.name} - {pasture.size_acres} acres
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Overall Condition</Label>
            <Select value={formData.condition} onValueChange={(value) => setFormData({...formData, condition: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="Fair">Fair</SelectItem>
                <SelectItem value="Poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Grazing Quality</Label>
            <Select value={formData.grazing_quality} onValueChange={(value) => setFormData({...formData, grazing_quality: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Excellent">Excellent</SelectItem>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="Fair">Fair</SelectItem>
                <SelectItem value="Poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Observations, issues, or improvements needed..."
              rows={3}
            />
          </div>

          {/* Photo Capture */}
          <div>
            <Label>Photo (Optional)</Label>
            <div className="flex gap-2">
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => cameraInputRef.current?.click()}
              >
                <Camera className="w-4 h-4 mr-2" />
                Take Photo
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
            </div>
            {photoPreview && (
              <div className="mt-2 relative">
                <img src={photoPreview} alt="Preview" className="w-full h-40 object-cover rounded-lg" />
                <Button
                  type="button"
                  size="icon"
                  variant="destructive"
                  className="absolute top-2 right-2"
                  onClick={() => {
                    setPhotoFile(null);
                    setPhotoPreview(null);
                  }}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-orange-600 hover:bg-orange-700"
            disabled={updatePastureMutation.isPending || uploading}
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading Photo...
              </>
            ) : updatePastureMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Updating...
              </>
            ) : (
              'Update Pasture'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}