import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Plus, Users, Loader2, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function SelectRanchDialog({ open, onOpenChange, user, onRanchSelected }) {
  const [activeTab, setActiveTab] = useState("owned");
  const [ranchName, setRanchName] = useState("");
  const [ranchLocation, setRanchLocation] = useState("");
  const queryClient = useQueryClient();

  // Fetch owned ranches
  const { data: ownedRanches = [], isLoading: isLoadingOwned } = useQuery({
    queryKey: ['ownedRanches', user?.email],
    queryFn: () => base44.entities.Ranch.filter({ owner_email: user.email.toLowerCase() }),
    enabled: !!user?.email && open,
  });

  // Fetch ranch memberships
  const { data: ranchMembers = [], isLoading: isLoadingMembers } = useQuery({
    queryKey: ['userRanchMembers', user?.email],
    queryFn: () => base44.entities.RanchMember.filter({ 
      user_email: user.email.toLowerCase(),
      status: 'Active'
    }),
    enabled: !!user?.email && open,
  });

  // Fetch the actual ranch objects for memberships
  const { data: memberRanches = [] } = useQuery({
    queryKey: ['memberRanches', ranchMembers],
    queryFn: async () => {
      if (!ranchMembers.length) return [];
      const ranchIds = ranchMembers.map(m => m.ranch_id);
      const ranches = await Promise.all(
        ranchIds.map(id => base44.entities.Ranch.filter({ id }).then(r => r[0]))
      );
      return ranches.filter(Boolean);
    },
    enabled: ranchMembers.length > 0 && open,
  });

  const createRanchMutation = useMutation({
    mutationFn: async (data) => {
      console.log('Creating ranch with data:', data);
      console.log('Current user:', user);
      
      if (!user || !user.email || !user.full_name) {
        throw new Error('User information is not available. Please refresh the page and try again.');
      }

      // Create the ranch
      const ranch = await base44.entities.Ranch.create({
        ...data,
        owner_email: user.email.toLowerCase(),
        owner_name: user.full_name,
        subscription_plan: 'Free',
        subscription_status: 'Active'
      });

      console.log('Ranch created:', ranch);

      // Create ranch member record for the owner
      await base44.entities.RanchMember.create({
        ranch_id: ranch.id,
        user_email: user.email.toLowerCase(),
        user_name: user.full_name,
        role: 'Owner',
        status: 'Active',
        joined_date: new Date().toISOString().split('T')[0],
      });

      console.log('RanchMember record created');

      // Seed default permissions for the newly created ranch
      try {
        console.log('Seeding default permissions for ranch:', ranch.id);
        const seedResponse = await base44.functions.invoke('seedRanchPermissions', {
          ranch_id: ranch.id
        });
        console.log('Default permissions seeded:', seedResponse.data);
      } catch (permissionError) {
        console.error('Failed to seed default ranch permissions:', permissionError);
        // Show warning but don't fail the entire ranch creation
        const warningEvent = new CustomEvent('showToast', {
          detail: { 
            message: 'Ranch created, but failed to set default permissions. Please check Ranch Settings.', 
            type: 'warning' 
          }
        });
        window.dispatchEvent(warningEvent);
      }

      return ranch;
    },
    onSuccess: async (ranch) => {
      console.log('Ranch creation successful, updating user active_ranch_id');
      
      try {
        // Set this ranch as the active ranch
        await base44.auth.updateMe({ active_ranch_id: ranch.id });
        console.log('User active_ranch_id updated to:', ranch.id);

        // Invalidate all relevant queries
        await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        await queryClient.invalidateQueries({ queryKey: ['ownedRanches'] });
        await queryClient.invalidateQueries({ queryKey: ['userRanchMembers'] });
        await queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
        
        console.log('Queries invalidated');

        // Show success message
        const event = new CustomEvent('showToast', {
          detail: { message: `Ranch "${ranch.name}" created successfully!`, type: 'success' }
        });
        window.dispatchEvent(event);

        // Reset form
        setRanchName("");
        setRanchLocation("");

        // Call the callback to close dialog and refresh
        if (onRanchSelected) {
          onRanchSelected();
        }
      } catch (error) {
        console.error('Error in post-creation steps:', error);
        const event = new CustomEvent('showToast', {
          detail: { message: 'Ranch created but failed to set as active. Please select it manually.', type: 'error' }
        });
        window.dispatchEvent(event);
      }
    },
    onError: (error) => {
      console.error("Error creating ranch:", error);
      const event = new CustomEvent('showToast', {
        detail: { 
          message: error.message || 'Failed to create ranch. Please try again.', 
          type: 'error' 
        }
      });
      window.dispatchEvent(event);
    },
  });

  const selectRanchMutation = useMutation({
    mutationFn: async (ranchId) => {
      console.log('Selecting ranch:', ranchId);
      await base44.auth.updateMe({ active_ranch_id: ranchId });
      return ranchId;
    },
    onSuccess: async (ranchId) => {
      console.log('Ranch selection successful');
      
      await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      await queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Ranch selected successfully!', type: 'success' }
      });
      window.dispatchEvent(event);

      if (onRanchSelected) {
        onRanchSelected();
      }
    },
    onError: (error) => {
      console.error("Error selecting ranch:", error);
      const event = new CustomEvent('showToast', {
        detail: { 
          message: error.message || 'Failed to select ranch. Please try again.', 
          type: 'error' 
        }
      });
      window.dispatchEvent(event);
    },
  });

  const handleCreateRanch = () => {
    if (!ranchName.trim()) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Please enter a ranch name', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }

    if (!user) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'User not loaded. Please refresh the page.', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }

    console.log('Initiating ranch creation...');
    createRanchMutation.mutate({
      name: ranchName.trim(),
      location: ranchLocation.trim() || '',
      herd_size: 0,
      total_acres: 0,
    });
  };

  const handleSelectRanch = (ranchId) => {
    console.log('User selecting ranch:', ranchId);
    selectRanchMutation.mutate(ranchId);
  };

  const isLoading = isLoadingOwned || isLoadingMembers;
  const allRanches = [...ownedRanches, ...memberRanches];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="text-2xl dark:text-gray-100">Select a Ranch</DialogTitle>
          <DialogDescription className="dark:text-gray-400">
            Choose a ranch to manage or create a new one
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 dark:bg-gray-900">
            <TabsTrigger value="owned" className="dark:data-[state=active]:bg-gray-800">
              <Building2 className="w-4 h-4 mr-2" />
              My Ranches
            </TabsTrigger>
            <TabsTrigger value="member" className="dark:data-[state=active]:bg-gray-800">
              <Users className="w-4 h-4 mr-2" />
              Team Member
            </TabsTrigger>
            <TabsTrigger value="create" className="dark:data-[state=active]:bg-gray-800">
              <Plus className="w-4 h-4 mr-2" />
              Create New
            </TabsTrigger>
          </TabsList>

          {/* Owned Ranches Tab */}
          <TabsContent value="owned" className="space-y-4 mt-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-[#F5A623]" />
              </div>
            ) : ownedRanches.length === 0 ? (
              <Card className="dark:bg-gray-900 dark:border-gray-800">
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Building2 className="w-12 h-12 text-gray-400 dark:text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-400 mb-4">You don't own any ranches yet</p>
                    <Button 
                      onClick={() => setActiveTab('create')}
                      className="bg-[#F5A623] hover:bg-[#E09612]"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Ranch
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {ownedRanches.map((ranch) => (
                  <Card 
                    key={ranch.id}
                    className="cursor-pointer hover:border-[#F5A623] transition-colors dark:bg-gray-900 dark:border-gray-800 dark:hover:border-[#F5A623]"
                    onClick={() => handleSelectRanch(ranch.id)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="dark:text-gray-100">{ranch.name}</CardTitle>
                          <CardDescription className="dark:text-gray-400">
                            {ranch.location || 'No location set'}
                          </CardDescription>
                        </div>
                        <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400">
                          Owner
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                        <span>{ranch.herd_size || 0} animals</span>
                        <span>•</span>
                        <span>{ranch.total_acres || 0} acres</span>
                        <span>•</span>
                        <span className="capitalize">{ranch.subscription_plan || 'Free'} Plan</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Member Ranches Tab */}
          <TabsContent value="member" className="space-y-4 mt-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-[#F5A623]" />
              </div>
            ) : memberRanches.length === 0 ? (
              <Card className="dark:bg-gray-900 dark:border-gray-800">
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Users className="w-12 h-12 text-gray-400 dark:text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-400">You're not a member of any ranches yet</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {memberRanches.map((ranch) => {
                  const membership = ranchMembers.find(m => m.ranch_id === ranch.id);
                  return (
                    <Card 
                      key={ranch.id}
                      className="cursor-pointer hover:border-[#F5A623] transition-colors dark:bg-gray-900 dark:border-gray-800 dark:hover:border-[#F5A623]"
                      onClick={() => handleSelectRanch(ranch.id)}
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="dark:text-gray-100">{ranch.name}</CardTitle>
                            <CardDescription className="dark:text-gray-400">
                              {ranch.location || 'No location set'}
                            </CardDescription>
                          </div>
                          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">
                            {membership?.role || 'Member'}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <span>{ranch.herd_size || 0} animals</span>
                          <span>•</span>
                          <span>{ranch.total_acres || 0} acres</span>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Create New Ranch Tab */}
          <TabsContent value="create" className="space-y-4 mt-6">
            <Card className="dark:bg-gray-900 dark:border-gray-800">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Create a New Ranch</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Set up your ranch management workspace
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ranchName" className="dark:text-gray-200">
                    Ranch Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="ranchName"
                    placeholder="e.g., Green Valley Ranch"
                    value={ranchName}
                    onChange={(e) => setRanchName(e.target.value)}
                    disabled={createRanchMutation.isPending}
                    className="dark:bg-gray-950 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ranchLocation" className="dark:text-gray-200">
                    Location (Optional)
                  </Label>
                  <Input
                    id="ranchLocation"
                    placeholder="e.g., Montana, USA"
                    value={ranchLocation}
                    onChange={(e) => setRanchLocation(e.target.value)}
                    disabled={createRanchMutation.isPending}
                    className="dark:bg-gray-950 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="pt-4">
                  <Button
                    onClick={handleCreateRanch}
                    disabled={createRanchMutation.isPending || !ranchName.trim() || !user}
                    className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                  >
                    {createRanchMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating Ranch...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 mr-2" />
                        Create Ranch
                      </>
                    )}
                  </Button>
                </div>

                <div className="pt-4 border-t dark:border-gray-800">
                  <div className="flex items-start gap-3 text-sm text-gray-600 dark:text-gray-400">
                    <CheckCircle2 className="w-5 h-5 text-[#F5A623] mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-gray-100 mb-1">What's included:</p>
                      <ul className="space-y-1">
                        <li>• Animal tracking and health records</li>
                        <li>• Financial management</li>
                        <li>• Pasture and breeding management</li>
                        <li>• Team collaboration tools</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}