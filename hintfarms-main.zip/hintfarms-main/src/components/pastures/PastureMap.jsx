
import React, { useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, MapPin, Move, AlertCircle } from "lucide-react";

// Fix for default marker icon in Leaflet with React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom markers with color coding
const createCustomIcon = (condition, needsPlacement = false) => {
  const colors = {
    'Good': '#10b981',
    'Fair': '#f59e0b',
    'Poor': '#ef4444'
  };
  
  const color = needsPlacement ? '#9ca3af' : (colors[condition] || '#6b7280');
  
  return L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 32px;
        height: 32px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid ${needsPlacement ? '#ef4444' : 'white'};
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        ${needsPlacement ? 'opacity: 0.7;' : ''}
      ">
        <svg style="transform: rotate(45deg); width: 16px; height: 16px;" fill="white" viewBox="0 0 24 24">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
        </svg>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  });
};

// Component to adjust map view when pastures change
function MapUpdater({ pastures }) {
  const map = useMap();
  
  useEffect(() => {
    if (pastures && pastures.length > 0) {
      const pasturesWithCoords = pastures.filter(p => p.lat && p.lon);
      
      if (pasturesWithCoords.length > 0) {
        const bounds = L.latLngBounds(
          pasturesWithCoords.map(p => [p.lat, p.lon])
        );
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    }
  }, [pastures, map]);
  
  return null;
}

// Draggable Marker Component
function DraggableMarker({ pasture, icon, onDragEnd, onViewDetails, conditionColors, typeColors, needsPlacement }) {
  const markerRef = useRef(null);
  // Use default center of US if no coordinates
  const defaultPosition = [39.8283, -98.5795];
  const [position, setPosition] = useState(
    pasture.lat && pasture.lon ? [pasture.lat, pasture.lon] : defaultPosition
  );
  const [isDragging, setIsDragging] = useState(false);

  // Update internal position if the pasture's coordinates change externally
  useEffect(() => {
    if (pasture.lat && pasture.lon) {
      setPosition([pasture.lat, pasture.lon]);
    }
  }, [pasture.lat, pasture.lon]);

  useEffect(() => {
    const marker = markerRef.current;
    if (marker) {
      marker.on('dragstart', () => setIsDragging(true));
      marker.on('dragend', (e) => {
        const newPos = e.target.getLatLng();
        setPosition([newPos.lat, newPos.lng]);
        setIsDragging(false);
        onDragEnd(pasture.id, newPos.lat, newPos.lng);
      });
    }

    return () => {
      if (marker) {
        marker.off('dragstart');
        marker.off('dragend');
      }
    };
  }, [pasture.id, onDragEnd]); // Dependencies include pasture.id and onDragEnd

  const formatAddress = () => {
    const parts = [
      pasture.address_line1,
      pasture.address_line2,
      pasture.city,
      pasture.state,
      pasture.postal_code,
      pasture.country
    ].filter(Boolean);
    return parts.join(', ');
  };

  return (
    <Marker
      ref={markerRef} // Add ref to the Marker component
      position={position}
      icon={icon}
      draggable={true}
      // eventHandlers={eventHandlers} // Remove eventHandlers prop
    >
      <Popup className="custom-popup" maxWidth={300} closeButton={true}>
        <div className="p-2">
          {needsPlacement && (
            <div className="bg-orange-50 dark:bg-orange-900/30 border border-orange-200 dark:border-orange-700 rounded p-2 mb-3 flex items-start gap-2 text-sm">
              <AlertCircle className="w-4 h-4 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-orange-700 dark:text-orange-300 mb-1">Location Not Set</div>
                <span className="text-orange-700 dark:text-orange-300">
                  Drag this marker to the correct location on the map
                </span>
              </div>
            </div>
          )}
          
          {isDragging && !needsPlacement && (
            <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded p-2 mb-3 flex items-center gap-2 text-sm">
              <Move className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="text-blue-700 dark:text-blue-300">Drag to reposition pasture</span>
            </div>
          )}
          
          <h3 className="font-bold text-lg mb-2 text-gray-900">{pasture.name}</h3>
          
          <div className="flex gap-2 mb-3 flex-wrap">
            <Badge className={`${typeColors[pasture.type]} border text-xs`}>
              {pasture.type}
            </Badge>
            <Badge className={`${conditionColors[pasture.condition]} border text-xs`}>
              {pasture.condition}
            </Badge>
          </div>
          
          <div className="space-y-2 text-sm text-gray-700 mb-3">
            <div className="flex justify-between">
              <span className="font-semibold">Acreage:</span>
              <span>{pasture.size_acres} acres</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">Capacity:</span>
              <span>{pasture.capacity || 'Not set'}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-semibold">Current Animals:</span>
              <span className="font-bold text-emerald-600">{pasture.current_animal_count || 0}</span>
            </div>
            {formatAddress() && (
              <div className="pt-2 border-t">
                <span className="font-semibold block mb-1">Address:</span>
                <span className="text-xs">{formatAddress()}</span>
              </div>
            )}
            <div className="pt-2 border-t">
              <span className="font-semibold block mb-1">Coordinates:</span>
              <span className="text-xs text-gray-600">
                {position[0].toFixed(6)}, {position[1].toFixed(6)}
              </span>
            </div>
          </div>
          
          <Button
            onClick={() => onViewDetails(pasture)}
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            size="sm"
          >
            <Eye className="w-4 h-4 mr-2" />
            View Full Details
          </Button>
          
          <p className="text-xs text-gray-500 mt-2 text-center">
            💡 Drag the marker to adjust location
          </p>
        </div>
      </Popup>
    </Marker>
  );
}

export default function PastureMap({ pastures, onViewDetails, onMarkerDragEnd }) {
  const pasturesWithCoords = pastures.filter(p => p.lat && p.lon);
  const pasturesWithoutCoords = pastures.filter(p => !p.lat || !p.lon);
  
  // Default center (US center) if no pastures with coordinates
  const defaultCenter = [39.8283, -98.5795];
  const defaultZoom = 4;
  
  const center = pasturesWithCoords.length > 0
    ? [pasturesWithCoords[0].lat, pasturesWithCoords[0].lon]
    : defaultCenter;

  const conditionColors = {
    "Good": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Fair": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Poor": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  const typeColors = {
    "Grazing": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Hay": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Breeding": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300",
    "Isolation": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  if (pastures.length === 0) {
    return (
      <div className="h-[600px] rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center p-8">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Pastures Yet</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            Add pastures to see them on the map
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[600px] rounded-lg overflow-hidden border-2 border-gray-200 dark:border-gray-700 shadow-lg relative">
      <style>{`
        .leaflet-container {
          z-index: 1 !important;
        }
        .leaflet-pane {
          z-index: 400 !important;
        }
        .leaflet-tile-pane {
          z-index: 200 !important;
        }
        .leaflet-overlay-pane {
          z-index: 400 !important;
        }
        .leaflet-shadow-pane {
          z-index: 500 !important;
        }
        .leaflet-marker-pane {
          z-index: 600 !important;
        }
        .leaflet-tooltip-pane {
          z-index: 650 !important;
        }
        .leaflet-popup-pane {
          z-index: 700 !important;
        }
        .leaflet-map-pane {
          z-index: 1 !important;
        }
        .leaflet-control {
          z-index: 800 !important;
        }
        .leaflet-marker-icon {
          cursor: grab !important;
        }
        .leaflet-dragging .leaflet-marker-icon {
          cursor: grabbing !important;
        }
      `}</style>
      <MapContainer
        center={center}
        zoom={defaultZoom}
        className="h-full w-full"
        scrollWheelZoom={true}
        zoomControl={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <MapUpdater pastures={pasturesWithCoords} />
        
        {/* Render pastures WITH coordinates */}
        {pasturesWithCoords.map(pasture => (
          <DraggableMarker
            key={pasture.id}
            pasture={pasture}
            icon={createCustomIcon(pasture.condition, false)}
            onDragEnd={onMarkerDragEnd}
            onViewDetails={onViewDetails}
            conditionColors={conditionColors}
            typeColors={typeColors}
            needsPlacement={false}
          />
        ))}
        
        {/* Render pastures WITHOUT coordinates (needs manual placement) */}
        {pasturesWithoutCoords.map(pasture => (
          <DraggableMarker
            key={pasture.id}
            pasture={pasture}
            icon={createCustomIcon(pasture.condition, true)}
            onDragEnd={onMarkerDragEnd}
            onViewDetails={onViewDetails}
            conditionColors={conditionColors}
            typeColors={typeColors}
            needsPlacement={true}
          />
        ))}
      </MapContainer>
      
      <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 z-[1000] max-w-xs">
        <p className="text-xs text-gray-600 dark:text-gray-400 flex items-center gap-2 mb-2">
          <Move className="w-4 h-4" />
          <span>Drag markers to adjust pasture locations</span>
        </p>
        {pasturesWithoutCoords.length > 0 && (
          <p className="text-xs text-orange-600 dark:text-orange-400 flex items-center gap-2 border-t pt-2">
            <AlertCircle className="w-4 h-4" />
            <span>{pasturesWithoutCoords.length} pasture(s) need manual placement (gray markers)</span>
          </p>
        )}
      </div>
    </div>
  );
}
