import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import {
  Shield,
  Lock,
  Sparkles,
  Info,
  Loader2
} from "lucide-react";

// Permission definitions grouped by domain
const PERMISSION_GROUPS = {
  "Animals": [
    { key: "animals.read", label: "View Animals", description: "View animal list and profiles" },
    { key: "animals.write", label: "Manage Animals", description: "Add, edit, and delete animals" },
  ],
  "Health Records": [
    { key: "health.read", label: "View Health Records", description: "View health records and history" },
    { key: "health.write", label: "Manage Health Records", description: "Add and edit health records" },
  ],
  "Breeding": [
    { key: "breeding.read", label: "View Breeding Records", description: "View breeding information" },
    { key: "breeding.write", label: "Manage Breeding", description: "Record breeding events and manage records" },
  ],
  "Pastures": [
    { key: "pastures.read", label: "View Pastures", description: "View pasture information" },
    { key: "pastures.write", label: "Manage Pastures", description: "Add and edit pastures" },
  ],
  "Tasks & Lists": [
    { key: "tasks.read", label: "View Tasks", description: "View all tasks and lists" },
    { key: "tasks.assign", label: "Assign Tasks", description: "Assign tasks to team members" },
    { key: "tasks.write", label: "Create, edit, and delete tasks", description: "Create, edit, and delete tasks" },
  ],
  "Financials": [
    { key: "financials.read", label: "View Financials", description: "View revenue and expenses" },
    { key: "financials.write", label: "Manage Financials", description: "Add and edit financial records" },
  ],
  "Reports & Export": [
    { key: "reports.read", label: "View Reports", description: "Access reports and analytics" },
    { key: "export.xlsx", label: "Export Data", description: "Export data to Excel (PRO+)", pro: true },
  ],
  "Team Management": [
    { key: "team.read", label: "View Team", description: "View team members and roles" },
    { key: "team.manage", label: "Manage Team", description: "Invite, remove, and manage team members", critical: true },
  ],
  "Notifications": [
    { key: "notifications.read", label: "View Notifications", description: "Receive notifications" },
    { key: "notifications.manage", label: "Manage Notifications", description: "Configure notification settings" },
  ],
  "Billing": [
    { key: "billing.view", label: "View Billing", description: "View subscription and invoices" },
    { key: "billing.manage", label: "Manage Billing", description: "Update payment method and plan" },
  ],
  "Banking": [
    { key: "banking.view", label: "View Banking", description: "View connected bank accounts", pro: true },
    { key: "banking.manage", label: "Manage Banking", description: "Connect and manage bank accounts", pro: true },
  ],
  "System": [
    { key: "integrations.manage", label: "Manage Integrations", description: "Configure system integrations" },
    { key: "data.manage", label: "Manage Data", description: "Import and export ranch data" },
  ]
};

export default function RanchPermissionsSettings({ ranch }) {
  const [selectedRole, setSelectedRole] = React.useState("Worker");

  const { data: permissionsData, isLoading } = useQuery({
    queryKey: ['ranchPermissions', ranch?.id],
    queryFn: async () => {
      const response = await base44.functions.invoke('getRanchPermissions', {
        ranch_id: ranch.id
      });
      return response.data;
    },
    enabled: !!ranch?.id,
  });

  // Get current permissions for selected role from static data
  const currentPermissions = React.useMemo(() => {
    if (!permissionsData?.permissions) return [];
    const rolePerms = permissionsData.permissions.find(p => p.role === selectedRole);
    return rolePerms?.permissions || [];
  }, [permissionsData, selectedRole]);

  // Check if user has PRO plan
  const isPro = ranch?.subscription_plan === 'Pro' || ranch?.subscription_plan === 'Enterprise' || ranch?.subscription_plan === 'Pro Trial';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/20">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-blue-800 dark:text-blue-300">Role-Based Permissions (Read-Only)</p>
              <p className="text-sm text-blue-700 dark:text-blue-400 mt-1">
                Permissions are locked to each role and cannot be customized. To grant a user different permissions, change their role in Team Management.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <Tabs value={selectedRole} onValueChange={setSelectedRole} className="w-full">
          <TabsList className="grid w-full grid-cols-5 dark:bg-gray-900">
            <TabsTrigger value="Owner">
              Owner
              <Lock className="w-3 h-3 ml-1" />
            </TabsTrigger>
            <TabsTrigger value="Manager">Manager</TabsTrigger>
            <TabsTrigger value="Worker">Worker</TabsTrigger>
            <TabsTrigger value="Veterinarian">Veterinarian</TabsTrigger>
            <TabsTrigger value="Assistant">Assistant</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Alert>
        <Shield className="w-4 h-4" />
        <AlertTitle>Viewing Permissions for: {selectedRole}</AlertTitle>
        <AlertDescription>
          These permissions are standard for all {selectedRole}s. To change a team member's access, update their role in Team Management.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        {Object.entries(PERMISSION_GROUPS).map(([group, permissions]) => (
          <Card key={group} className="dark:bg-gray-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-lg dark:text-gray-100">{group}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {permissions.map((perm) => {
                const isEnabled = currentPermissions.includes(perm.key);
                const isProPermission = perm.pro && !isPro;

                return (
                  <div key={perm.key} className="flex items-center justify-between p-4 rounded-lg border dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Label className="font-medium dark:text-gray-200">
                          {perm.label}
                        </Label>
                        {perm.pro && (
                          <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200 text-xs">
                            <Sparkles className="w-3 h-3 mr-1" />
                            PRO
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{perm.description}</p>
                      {isProPermission && (
                        <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                          Upgrade to PRO to enable this feature
                        </p>
                      )}
                    </div>
                    <Switch
                      checked={isEnabled}
                      disabled={true}
                      className="pointer-events-none"
                    />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}