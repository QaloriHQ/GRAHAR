import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function PLStatement({ expenses = [], revenues = [], startDate, endDate }) {
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalRevenue = revenues.reduce((sum, r) => sum + r.amount, 0);
  const netIncome = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? ((netIncome / totalRevenue) * 100).toFixed(1) : 0;

  // Group expenses by category
  const expensesByCategory = expenses.reduce((acc, expense) => {
    if (!acc[expense.category]) {
      acc[expense.category] = 0;
    }
    acc[expense.category] += expense.amount;
    return acc;
  }, {});

  // Group revenues by category
  const revenuesByCategory = revenues.reduce((acc, revenue) => {
    if (!acc[revenue.category]) {
      acc[revenue.category] = 0;
    }
    acc[revenue.category] += revenue.amount;
    return acc;
  }, {});

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="dark:text-gray-100">Profit & Loss Statement</CardTitle>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Period: {new Date(startDate).toLocaleDateString()} - {new Date(endDate).toLocaleDateString()}
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Revenue Section */}
        <div>
          <h3 className="font-semibold text-lg mb-3 dark:text-gray-100">Revenue</h3>
          <Table>
            <TableBody>
              {Object.entries(revenuesByCategory).map(([category, amount]) => (
                <TableRow key={category} className="dark:border-gray-700">
                  <TableCell className="dark:text-gray-300">{category}</TableCell>
                  <TableCell className="text-right dark:text-gray-300">
                    ${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold border-t-2 dark:border-gray-700">
                <TableCell className="dark:text-gray-100">Total Revenue</TableCell>
                <TableCell className="text-right text-green-600 dark:text-green-400">
                  ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        {/* Expenses Section */}
        <div>
          <h3 className="font-semibold text-lg mb-3 dark:text-gray-100">Expenses</h3>
          <Table>
            <TableBody>
              {Object.entries(expensesByCategory).map(([category, amount]) => (
                <TableRow key={category} className="dark:border-gray-700">
                  <TableCell className="dark:text-gray-300">{category}</TableCell>
                  <TableCell className="text-right dark:text-gray-300">
                    ${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="font-bold border-t-2 dark:border-gray-700">
                <TableCell className="dark:text-gray-100">Total Expenses</TableCell>
                <TableCell className="text-right text-red-600 dark:text-red-400">
                  ${totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        {/* Net Income */}
        <div className="border-t-4 border-gray-300 dark:border-gray-600 pt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-xl dark:text-gray-100">Net Income</h3>
            <div className={`flex items-center gap-2 text-xl font-bold ${netIncome >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {netIncome >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              ${Math.abs(netIncome).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
            <span>Profit Margin</span>
            <span className={netIncome >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
              {profitMargin}%
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}