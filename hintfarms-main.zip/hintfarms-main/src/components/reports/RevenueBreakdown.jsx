import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function RevenueBreakdown({ revenues = [] }) {
  const revenuesByCategory = revenues.reduce((acc, revenue) => {
    if (!acc[revenue.category]) {
      acc[revenue.category] = 0;
    }
    acc[revenue.category] += revenue.amount;
    return acc;
  }, {});

  const chartData = Object.entries(revenuesByCategory).map(([name, value]) => ({
    name,
    amount: value,
  }));

  const totalRevenue = revenues.reduce((sum, r) => sum + r.amount, 0);

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="dark:text-gray-100">Revenue Streams</CardTitle>
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          <>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                <Legend />
                <Bar dataKey="amount" fill="#10b981" name="Revenue" />
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-6 space-y-2">
              {chartData.map((item) => (
                <div key={item.name} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <span className="font-medium dark:text-gray-200">{item.name}</span>
                  <div className="text-right">
                    <p className="font-bold text-green-600 dark:text-green-400">
                      ${item.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {((item.amount / totalRevenue) * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-center text-gray-500 dark:text-gray-400 py-8">No revenue data available</p>
        )}
      </CardContent>
    </Card>
  );
}