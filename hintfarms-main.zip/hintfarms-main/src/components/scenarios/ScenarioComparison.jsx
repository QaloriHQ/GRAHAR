import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Beef, DollarSign, BarChart3 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ScenarioComparison({ scenario }) {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  const { data: revenue = [] } = useQuery({
    queryKey: ['revenue', user?.ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  if (!scenario) {
    return (
      <Card className="border-none shadow-lg">
        <CardContent className="py-12 text-center">
          <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Scenario data not available</p>
        </CardContent>
      </Card>
    );
  }

  // Calculate current ranch metrics
  const currentMetrics = {
    total_animals: animals.length,
    total_expenses: expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
    total_revenue: revenue.reduce((sum, r) => sum + (r.amount || 0), 0),
  };

  currentMetrics.net_profit = currentMetrics.total_revenue - currentMetrics.total_expenses;
  currentMetrics.profit_margin = currentMetrics.total_revenue > 0 
    ? (currentMetrics.net_profit / currentMetrics.total_revenue * 100).toFixed(1)
    : 0;

  // Calculate scenario metrics with risk adjustments
  const scenarioMetrics = {
    total_animals: scenario.baseline_data?.animals || currentMetrics.total_animals,
    total_revenue: (scenario.baseline_data?.total_revenue || currentMetrics.total_revenue) * 
      (1 - (scenario.predator_loss_rate || 0)) * 
      (1 - (scenario.mortality_rate || 0)) * 
      (1 - (scenario.shrink_rate || 0)),
    total_expenses: scenario.baseline_data?.total_expenses || currentMetrics.total_expenses,
  };

  scenarioMetrics.net_profit = scenarioMetrics.total_revenue - scenarioMetrics.total_expenses;
  scenarioMetrics.profit_margin = scenarioMetrics.total_revenue > 0 
    ? (scenarioMetrics.net_profit / scenarioMetrics.total_revenue * 100).toFixed(1)
    : 0;

  const comparisons = [
    {
      metric: "Total Revenue",
      current: currentMetrics.total_revenue,
      scenario: scenarioMetrics.total_revenue,
      format: "currency"
    },
    {
      metric: "Total Expenses",
      current: currentMetrics.total_expenses,
      scenario: scenarioMetrics.total_expenses,
      format: "currency"
    },
    {
      metric: "Net Profit",
      current: currentMetrics.net_profit,
      scenario: scenarioMetrics.net_profit,
      format: "currency"
    },
    {
      metric: "Profit Margin",
      current: currentMetrics.profit_margin,
      scenario: scenarioMetrics.profit_margin,
      format: "percent"
    }
  ];

  const formatValue = (value, format) => {
    if (format === "currency") {
      return `$${value.toLocaleString()}`;
    }
    if (format === "percent") {
      return `${value}%`;
    }
    return value.toLocaleString();
  };

  const calculateDelta = (current, scenario) => {
    const delta = scenario - current;
    const deltaPercent = current !== 0 ? ((delta / Math.abs(current)) * 100).toFixed(1) : 0;
    return { delta, deltaPercent };
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Scenario vs Current Ranch Performance
          </CardTitle>
          <CardDescription>
            Comparing scenario assumptions against {scenario.baseline_source} baseline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Metric</TableHead>
                <TableHead className="text-right">Current</TableHead>
                <TableHead className="text-right">Scenario</TableHead>
                <TableHead className="text-right">Delta ($)</TableHead>
                <TableHead className="text-right">Delta (%)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {comparisons.map((comp, idx) => {
                const { delta, deltaPercent } = calculateDelta(comp.current, comp.scenario);
                const isPositive = delta >= 0;
                
                return (
                  <TableRow key={idx}>
                    <TableCell className="font-medium">{comp.metric}</TableCell>
                    <TableCell className="text-right">
                      {formatValue(comp.current, comp.format)}
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatValue(comp.scenario, comp.format)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {comp.format === "currency" && formatValue(Math.abs(delta), comp.format)}
                        {isPositive ? (
                          <TrendingUp className="w-4 h-4 text-green-600" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-red-600" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge className={isPositive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                        {isPositive ? '+' : ''}{deltaPercent}%
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Risk Adjustments Card */}
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Risk Adjustments Applied</CardTitle>
          <CardDescription>
            How scenario assumptions impact projected outcomes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500 mb-1">Predator Loss</p>
              <p className="text-2xl font-bold text-red-600">
                {(scenario.predator_loss_rate * 100).toFixed(1)}%
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500 mb-1">Mortality</p>
              <p className="text-2xl font-bold text-orange-600">
                {(scenario.mortality_rate * 100).toFixed(1)}%
              </p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500 mb-1">Shrink</p>
              <p className="text-2xl font-bold text-yellow-600">
                {(scenario.shrink_rate * 100).toFixed(1)}%
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}