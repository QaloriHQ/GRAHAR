import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";

export default function ScenarioTimeframe({ formData, setFormData }) {
  const handlePreset = (preset) => {
    const end = new Date();
    end.setHours(23, 59, 59, 999);
    const start = new Date();
    start.setHours(0, 0, 0, 0);

    switch (preset) {
      case "last_12_months":
        start.setMonth(start.getMonth() - 12);
        break;
      case "last_6_months":
        start.setMonth(start.getMonth() - 6);
        break;
      case "ytd":
        start.setMonth(0);
        start.setDate(1);
        break;
      case "last_year":
        start.setFullYear(start.getFullYear() - 1);
        start.setMonth(0);
        start.setDate(1);
        end.setFullYear(end.getFullYear() - 1);
        end.setMonth(11);
        end.setDate(31);
        break;
    }

    setFormData({
      ...formData,
      timeframe_start: start.toISOString().split('T')[0],
      timeframe_end: end.toISOString().split('T')[0]
    });
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Time Period
        </CardTitle>
        <CardDescription>
          Define the reporting window for this scenario (default: last 12 months)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Quick Presets */}
        <div>
          <Label className="mb-3 block">Quick Presets</Label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" onClick={() => handlePreset("last_12_months")}>
              Last 12 Months
            </Button>
            <Button variant="outline" onClick={() => handlePreset("last_6_months")}>
              Last 6 Months
            </Button>
            <Button variant="outline" onClick={() => handlePreset("ytd")}>
              Year to Date
            </Button>
            <Button variant="outline" onClick={() => handlePreset("last_year")}>
              Last Year
            </Button>
          </div>
        </div>

        {/* Date Inputs */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>Start Date</Label>
            <Input
              type="date"
              value={formData.timeframe_start}
              onChange={(e) => setFormData({...formData, timeframe_start: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label>End Date</Label>
            <Input
              type="date"
              value={formData.timeframe_end}
              onChange={(e) => setFormData({...formData, timeframe_end: e.target.value})}
            />
          </div>
        </div>

        {/* Aggregation */}
        <div className="space-y-2">
          <Label>Data Aggregation</Label>
          <Select
            value={formData.aggregation}
            onValueChange={(value) => setFormData({...formData, aggregation: value})}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="annual">Annual</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
}