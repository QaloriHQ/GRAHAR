import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  UserPlus,
  MoreVertical,
  Mail,
  Crown,
  Users,
  Trash2,
  UserX,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { trackInviteSend } from "@/components/utils";
import { Card, CardContent, CardDescription } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Sparkles, AlertCircle } from 'lucide-react';

export default function TeamManagementContent({ onUpgradeClick }) {
  const { toast: useToastToast } = useToast();
  const queryClient = useQueryClient();
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("Worker");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  const { data: members = [] } = useQuery({
    queryKey: ['ranchMembers', user?.active_ranch_id],
    queryFn: () => base44.entities.RanchMember.filter({ ranch_id: user.active_ranch_id }, '-joined_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const inviteMemberMutation = useMutation({
    mutationFn: async (data) => {
      // Generate unique invite token
      const inviteToken = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

      // Set expiration to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      // Create invite record
      const invite = await base44.entities.RanchInvite.create({
        ranch_id: user.active_ranch_id,
        ranch_name: ranch.name,
        invited_email: data.user_email,
        invited_name: data.user_email.split('@')[0],
        role: data.role,
        invited_by_email: user.email,
        invited_by_name: user.full_name, // Assuming user.full_name is available from base44.auth.me()
        invite_token: inviteToken,
        status: 'Pending',
        expires_at: expiresAt.toISOString()
      });

      // Create pending ranch member
      // This member will be activated or removed based on the invite acceptance flow
      const member = await base44.entities.RanchMember.create({
        ranch_id: user.active_ranch_id,
        user_email: data.user_email,
        user_name: data.user_email.split('@')[0],
        role: data.role,
        invited_by: user.email,
        joined_date: new Date().toISOString().split('T')[0], // This will be the invitation date initially
        status: "Pending"
      });

      // Generate accept invite URL
      const appUrl = window.location.origin;
      const inviteAcceptUrl = `${appUrl}/AcceptInvite?token=${inviteToken}`;

      // Send invitation email with HTML template
      try {
        await base44.integrations.Core.SendEmail({
          to: data.user_email,
          subject: `You've been invited to join ${ranch.name} on GRAHAR`,
          body: `<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body style="font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f9fafb; margin: 0; padding: 40px 0;">
    <table align="center" width="600" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 12px; padding: 48px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
      <tr>
        <td align="center" style="padding-bottom: 32px;">
          <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/d74247bee_FindCash-6.png" alt="GRAHAR" style="height: 60px; width: 60px;" />
        </td>
      </tr>
      <tr>
        <td style="color: #111827; font-size: 24px; font-weight: 600; text-align: center; padding-bottom: 16px;">
          You've been invited to join a Ranch on GRAHAR
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #374151; font-size: 16px; line-height: 1.6; text-align: center;">
          Hello! You've been invited to join <strong style="color: #10b981;">${ranch.name}</strong> as a <strong>${data.role}</strong> on GRAHAR.
          <br><br>
          Click the button below to accept your invitation and start managing ranch operations together.
        </td>
      </tr>
      <tr>
        <td align="center" style="padding: 32px 0;">
          <a href="${inviteAcceptUrl}"
             style="background-color: #10b981; color: #ffffff; text-decoration: none; font-weight: 600; padding: 16px 32px; border-radius: 8px; display: inline-block; font-size: 16px;">
            Accept Invitation
          </a>
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #6b7280; font-size: 14px; line-height: 1.6; text-align: center; background: #f9fafb; border-radius: 8px; padding: 20px;">
          If you don't have an account yet, sign up using this email (<strong>${data.user_email}</strong>),
          and your invitation will automatically link once you log in.
        </td>
      </tr>
      <tr>
        <td style="padding: 16px 0; color: #9ca3af; font-size: 13px; text-align: center;">
          Or copy this link:<br>
          <a href="${inviteAcceptUrl}" style="color: #10b981; word-break: break-all;">${inviteAcceptUrl}</a>
        </td>
      </tr>
      <tr>
        <td style="padding-top: 32px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 13px; color: #9ca3af;">
          This invitation will expire in 7 days.<br><br>
          Best regards,<br />
          The GRAHAR Team
        </td>
      </tr>
    </table>
  </body>
</html>`
        });
      } catch (error) {
        console.error("Failed to send invitation email:", error);
        // Optionally, handle invite record cleanup or status update if email fails
      }

      return member; // Return the created RanchMember
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      setShowInviteDialog(false);
      setInviteEmail("");
      setInviteRole("Worker");
      trackInviteSend(inviteEmail, inviteRole);
      toast.success("Invitation sent successfully!", {
        duration: 3000,
      });
    },
    onError: (error) => {
      console.error("Error inviting member:", error);
      toast.error("Failed to send invitation. Please try again.", {
        duration: 3000,
      });
    }
  });

  const removeMemberMutation = useMutation({
    mutationFn: (id) => base44.entities.RanchMember.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      toast.success("Team member has been removed from your ranch.", {
        duration: 3000,
      });
    },
    onError: (error) => {
      console.error("Error removing member:", error);
      toast.error("Failed to remove member. Please try again.", {
        duration: 3000,
      });
    }
  });

  const updateMemberRoleMutation = useMutation({
    mutationFn: ({ id, role }) => base44.entities.RanchMember.update(id, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      toast.success("Team member's role has been updated.", {
        duration: 3000,
      });
    },
    onError: (error) => {
      console.error("Error updating member role:", error);
      toast.error("Failed to update member's role. Please try again.", {
        duration: 3000,
      });
    }
  });

  const resendInviteMutation = useMutation({
    mutationFn: async (member) => {
      // Find the existing invite record for this member
      const existingInvites = await base44.entities.RanchInvite.filter({
        ranch_id: member.ranch_id,
        invited_email: member.user_email,
        status: 'Pending'
      }, '-expires_at'); // Get the most recent pending invite

      let invite = existingInvites[0];
      let inviteToken = invite?.invite_token;

      // If no pending invite or expired, create a new one
      if (!invite || new Date(invite.expires_at) < new Date()) {
        const newInviteToken = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);

        invite = await base44.entities.RanchInvite.create({
          ranch_id: user.active_ranch_id,
          ranch_name: ranch.name,
          invited_email: member.user_email,
          invited_name: member.user_name,
          role: member.role,
          invited_by_email: user.email,
          invited_by_name: user.full_name,
          invite_token: newInviteToken,
          status: 'Pending',
          expires_at: expiresAt.toISOString()
        });
        inviteToken = newInviteToken;
      }

      // Generate accept invite URL
      const appUrl = window.location.origin;
      const inviteAcceptUrl = `${appUrl}/AcceptInvite?token=${inviteToken}`;

      await base44.integrations.Core.SendEmail({
        to: member.user_email,
        subject: `Reminder: You've been invited to join ${ranch.name} on GRAHAR`,
        body: `<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  </head>
  <body style="font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f9fafb; margin: 0; padding: 40px 0;">
    <table align="center" width="600" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 12px; padding: 48px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
      <tr>
        <td align="center" style="padding-bottom: 32px;">
          <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/d74247bee_FindCash-6.png" alt="GRAHAR" style="height: 60px; width: 60px;" />
        </td>
      </tr>
      <tr>
        <td style="color: #111827; font-size: 24px; font-weight: 600; text-align: center; padding-bottom: 16px;">
          You've been invited to join a Ranch on GRAHAR
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #374151; font-size: 16px; line-height: 1.6; text-align: center;">
          Hello! This is a reminder that you've been invited to join <strong style="color: #10b981;">${ranch.name}</strong> as a <strong>${member.role}</strong> on GRAHAR.
          <br><br>
          Click the button below to accept your invitation and start managing ranch operations together.
        </td>
      </tr>
      <tr>
        <td align="center" style="padding: 32px 0;">
          <a href="${inviteAcceptUrl}"
             style="background-color: #10b981; color: #ffffff; text-decoration: none; font-weight: 600; padding: 16px 32px; border-radius: 8px; display: inline-block; font-size: 16px;">
            Accept Invitation
          </a>
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #6b7280; font-size: 14px; line-height: 1.6; text-align: center; background: #f9fafb; border-radius: 8px; padding: 20px;">
          If you don't have an account yet, sign up using this email (<strong>${member.user_email}</strong>),
          and your invitation will automatically link once you log in.
        </td>
      </tr>
      <tr>
        <td style="padding: 16px 0; color: #9ca3af; font-size: 13px; text-align: center;">
          Or copy this link:<br>
          <a href="${inviteAcceptUrl}" style="color: #10b981; word-break: break-all;">${inviteAcceptUrl}</a>
        </td>
      </tr>
      <tr>
        <td style="padding-top: 32px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 13px; color: #9ca3af;">
          This invitation will expire in 7 days.<br><br>
          Best regards,<br />
          The GRAHAR Team
        </td>
      </tr>
    </table>
  </body>
</html>`
      });
    },
    onSuccess: () => {
      toast.success("The invitation has been sent again.", {
        duration: 3000,
      });
    },
    onError: (error) => {
      console.error("Error resending invitation:", error);
      toast.error("Failed to resend invitation. Please try again.", {
        duration: 3000,
      });
    }
  });

  const handleInvite = () => {
    if (!inviteEmail) {
      toast.error("Please enter an email address.", {
        duration: 3000,
      });
      return;
    }

    const existingMember = members.find(m => m.user_email === inviteEmail);
    if (existingMember) {
      toast.error("This user is already a member of your team (Active or Pending).", {
        duration: 3000,
      });
      return;
    }

    inviteMemberMutation.mutate({
      user_email: inviteEmail,
      user_name: inviteEmail.split('@')[0], // Default name from email
      role: inviteRole
    });
  };

  const canManageTeam = ranch?.subscription_plan === "Pro" || ranch?.subscription_plan === "Enterprise" || ranch?.subscription_plan === "Pro Trial";
  const canInviteOrRemove = user?.role_title === "Owner" || user?.role_title === "Manager";
  const activeMembers = members.filter(m => m.status === "Active").length;
  const pendingMembers = members.filter(m => m.status === "Pending").length;

  const roleColors = {
    "Owner": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300 dark:border-purple-800",
    "Manager": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800",
    "Worker": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800",
    "Veterinarian": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800",
    "Assistant": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"
  };

  const statusColors = {
    "Active": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-800",
    "Pending": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-800",
    "Removed": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800"
  };

  return (
    <div className="space-y-6">
      {/* Subscription Alert */}
      {!canManageTeam && (
        <Alert className="border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
          <AlertCircle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          <AlertTitle className="text-orange-800 dark:text-orange-300">Upgrade Required</AlertTitle>
          <AlertDescription className="text-orange-700 dark:text-orange-400">
            Team management is available on Pro and Enterprise plans.
            <Button
              variant="link"
              className="px-0 ml-2 text-orange-600 dark:text-orange-400 h-auto"
              onClick={onUpgradeClick}
            >
              <Sparkles className="w-4 h-4 mr-1" />
              Upgrade Now
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <Users className="w-8 h-8 text-emerald-600 dark:text-emerald-400 mx-auto mb-2" />
              <p className="text-2xl font-bold dark:text-gray-100">{activeMembers}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Active Members</p>
            </div>
          </CardContent>
        </Card>

        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <Mail className="w-8 h-8 text-yellow-600 dark:text-yellow-400 mx-auto mb-2" />
              <p className="text-2xl font-bold dark:text-gray-100">{pendingMembers}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Pending Invites</p>
            </div>
          </CardContent>
        </Card>

        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-4">
            <div className="text-center">
              <Sparkles className="w-8 h-8 text-purple-600 dark:text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold dark:text-gray-100">{ranch?.subscription_plan || "Free"}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Plan</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invite Button */}
      {canManageTeam && canInviteOrRemove && (
        <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
          <DialogTrigger asChild>
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Team Member
            </Button>
          </DialogTrigger>
          <DialogContent className="dark:bg-gray-900 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Invite Team Member</DialogTitle>
              {/* <DialogDescription className="dark:text-gray-400">
                Send an invitation to add a new member to your ranch team
              </DialogDescription> */}
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Email Address</Label>
                <Input
                  type="email"
                  placeholder="member@example.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Manager">Manager</SelectItem>
                    <SelectItem value="Worker">Worker</SelectItem>
                    <SelectItem value="Veterinarian">Veterinarian</SelectItem>
                    <SelectItem value="Assistant">Assistant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="submit"
                onClick={handleInvite}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
                disabled={inviteMemberMutation.isPending}
              >
                <Mail className="w-4 h-4 mr-2" />
                {inviteMemberMutation.isPending ? "Sending..." : "Send Invitation"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Team Members Table */}
      <Card className="dark:bg-gray-800 dark:border-gray-700">
        <CardContent className="p-4">
          <CardDescription className="mb-4 dark:text-gray-400">
            Manage roles and permissions for your ranch team
          </CardDescription>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-300">Name</TableHead>
                  <TableHead className="dark:text-gray-300">Email</TableHead>
                  <TableHead className="dark:text-gray-300">Role</TableHead>
                  <TableHead className="dark:text-gray-300">Status</TableHead>
                  <TableHead className="dark:text-gray-300">Joined</TableHead>
                  <TableHead className="dark:text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {members.map(member => (
                  <TableRow key={member.id} className="dark:border-gray-700">
                    <TableCell className="dark:text-gray-100">
                      <div className="flex items-center gap-2">
                        {member.role === "Owner" && <Crown className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />}
                        <span className="font-semibold">{member.user_name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400 text-sm">{member.user_email}</TableCell>
                    <TableCell>
                      {canManageTeam && canInviteOrRemove && member.role !== "Owner" ? (
                        <Select
                          value={member.role}
                          onValueChange={(value) => updateMemberRoleMutation.mutate({ id: member.id, role: value })}
                        >
                          <SelectTrigger className="w-32 h-8 dark:bg-gray-700 dark:border-gray-600">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Manager">Manager</SelectItem>
                            <SelectItem value="Worker">Worker</SelectItem>
                            <SelectItem value="Veterinarian">Veterinarian</SelectItem>
                            <SelectItem value="Assistant">Assistant</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={`${roleColors[member.role]} border text-xs`}>
                          {member.role}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statusColors[member.status]} border text-xs`}>
                        {member.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400 text-sm">
                      {member.joined_date ? format(new Date(member.joined_date), "MMM d, yyyy") : "-"}
                    </TableCell>
                    <TableCell>
                      {canManageTeam && canInviteOrRemove && member.role !== "Owner" && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="dark:bg-gray-800 dark:border-gray-700">
                            {member.status === "Pending" && (
                              <DropdownMenuItem
                                onClick={() => resendInviteMutation.mutate(member)}
                                className="dark:text-gray-200 dark:hover:bg-gray-700"
                              >
                                <Send className="w-4 h-4 mr-2" />
                                Resend Invitation
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              onClick={() => removeMemberMutation.mutate(member.id)}
                              className="text-red-600 dark:text-red-400 dark:hover:bg-gray-700"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Remove Member
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {members.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                      No team members yet. Start by inviting your first member!
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}