import React, { createContext, useContext, useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const ThemeContext = createContext({
  theme: 'light',
  setTheme: () => {},
  actualTheme: 'light',
});

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};

export function ThemeProvider({ children }) {
  const [mounted, setMounted] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Get actual theme (resolving 'system' to 'light' or 'dark')
  const getActualTheme = (themeMode) => {
    if (themeMode === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return themeMode;
  };

  // Initialize theme from localStorage or user preference
  const getInitialTheme = () => {
    // First check localStorage for immediate rendering
    const stored = localStorage.getItem('theme');
    if (stored) return stored;
    // Then check user preference
    if (user?.theme_mode) return user.theme_mode;
    // Default to light
    return 'light';
  };

  const [theme, setThemeState] = useState(getInitialTheme);
  const [actualTheme, setActualTheme] = useState(() => {
    const initial = getInitialTheme();
    return getActualTheme(initial);
  });

  const updateThemeMutation = useMutation({
    mutationFn: (newTheme) => base44.auth.updateMe({ theme_mode: newTheme }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  // Apply theme to document
  const applyTheme = (resolved) => {
    const root = document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(resolved);
    
    // Also set a data attribute for more specific targeting if needed
    root.setAttribute('data-theme', resolved);
  };

  // Initialize theme on mount
  useEffect(() => {
    setMounted(true);
    const initial = getInitialTheme();
    const resolved = getActualTheme(initial);
    setActualTheme(resolved);
    applyTheme(resolved);
  }, []);

  // Update theme when user preference changes
  useEffect(() => {
    if (user?.theme_mode && user.theme_mode !== theme) {
      setThemeState(user.theme_mode);
      const resolved = getActualTheme(user.theme_mode);
      setActualTheme(resolved);
      applyTheme(resolved);
      localStorage.setItem('theme', user.theme_mode);
    }
  }, [user?.theme_mode]);

  // Listen for system theme changes if using system preference
  useEffect(() => {
    if (!mounted || theme !== 'system') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e) => {
      const newTheme = e.matches ? 'dark' : 'light';
      setActualTheme(newTheme);
      applyTheme(newTheme);
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [theme, mounted]);

  const setTheme = (newTheme) => {
    console.log('Setting theme to:', newTheme);
    
    // Update state immediately
    setThemeState(newTheme);
    const resolved = getActualTheme(newTheme);
    setActualTheme(resolved);
    
    // Apply theme to DOM immediately
    applyTheme(resolved);
    
    // Save to localStorage for persistence
    localStorage.setItem('theme', newTheme);
    
    // Save to user preferences in background
    if (user) {
      updateThemeMutation.mutate(newTheme);
    }
  };

  // Show a minimal loading state to prevent flash
  if (!mounted) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900">
        {children}
      </div>
    );
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme, actualTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}