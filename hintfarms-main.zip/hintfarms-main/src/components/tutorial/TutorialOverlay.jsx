import React, { useEffect } from 'react';
import { useTutorial } from './TutorialProvider';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, ArrowLeft, ArrowRight, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export default function TutorialOverlay() {
  const {
    isActive,
    currentStep,
    totalSteps,
    currentStepData,
    nextStep,
    previousStep,
    skipTutorial,
    highlightedElement
  } = useTutorial();

  useEffect(() => {
    if (isActive && highlightedElement) {
      highlightedElement.classList.add('tutorial-highlight');
      
      return () => {
        highlightedElement.classList.remove('tutorial-highlight');
      };
    }
  }, [isActive, highlightedElement]);

  if (!isActive || !currentStepData) {
    return null;
  }

  const getTooltipPosition = () => {
    if (!highlightedElement) {
      return { top: '50%', left: '50%', transform: 'translate(-50%, -50%)' };
    }

    const rect = highlightedElement.getBoundingClientRect();
    const position = currentStepData.position || 'bottom';

    switch (position) {
      case 'top':
        return {
          bottom: `${window.innerHeight - rect.top + 20}px`,
          left: `${rect.left + rect.width / 2}px`,
          transform: 'translateX(-50%)',
        };
      case 'bottom':
        return {
          top: `${rect.bottom + 20}px`,
          left: `${rect.left + rect.width / 2}px`,
          transform: 'translateX(-50%)',
        };
      case 'left':
        return {
          top: `${rect.top + rect.height / 2}px`,
          right: `${window.innerWidth - rect.left + 20}px`,
          transform: 'translateY(-50%)',
        };
      case 'right':
        return {
          top: `${rect.top + rect.height / 2}px`,
          left: `${rect.right + 20}px`,
          transform: 'translateY(-50%)',
        };
      case 'center':
        return {
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
        };
      default:
        return {
          top: `${rect.bottom + 20}px`,
          left: `${rect.left + rect.width / 2}px`,
          transform: 'translateX(-50%)',
        };
    }
  };

  return (
    <>
      {/* Dark overlay - blocks background interaction */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity pointer-events-auto"
        style={{ zIndex: 9999 }}
        onClick={(e) => e.stopPropagation()}
      />

      {/* Spotlight effect on highlighted element */}
      {highlightedElement && (
        <div
          className="fixed pointer-events-none transition-all duration-300"
          style={{
            zIndex: 10000,
            top: highlightedElement.getBoundingClientRect().top - 8,
            left: highlightedElement.getBoundingClientRect().left - 8,
            width: highlightedElement.getBoundingClientRect().width + 16,
            height: highlightedElement.getBoundingClientRect().height + 16,
            boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.6), 0 0 20px 4px rgba(16, 185, 129, 0.5)',
            borderRadius: '12px',
          }}
        />
      )}

      {/* Tutorial tooltip card - ALWAYS ON TOP */}
      <div
        className="fixed pointer-events-auto"
        style={{
          ...getTooltipPosition(),
          zIndex: 10002,
        }}
      >
        <Card className="max-w-md border-2 border-emerald-500 shadow-2xl bg-white dark:bg-gray-900">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <h3 className="font-bold text-lg dark:text-gray-100">{currentStepData.title}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Step {currentStep + 1} of {totalSteps}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={skipTutorial}
                className="h-8 w-8 hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Description */}
            <p className="text-gray-700 dark:text-gray-300 mb-6">
              {currentStepData.description}
            </p>

            {/* Progress bar */}
            <div className="mb-4">
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
                />
              </div>
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between gap-3">
              <Button
                variant="outline"
                onClick={previousStep}
                disabled={currentStep === 0}
                className="flex-1"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              
              {currentStep < totalSteps - 1 ? (
                <Button
                  onClick={nextStep}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button
                  onClick={nextStep}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                >
                  Complete Tutorial
                  <Sparkles className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>

            {/* Skip link */}
            <div className="text-center mt-4">
              <button
                onClick={skipTutorial}
                className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 underline"
              >
                Skip tutorial
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Global styles for tutorial highlight */}
      <style jsx global>{`
        .tutorial-highlight {
          position: relative !important;
          z-index: 10001 !important;
          pointer-events: auto !important;
        }
        
        /* Ensure tutorial overlay is always on top */
        .tutorial-overlay-container {
          z-index: 10002 !important;
          pointer-events: auto !important;
        }
      `}</style>
    </>
  );
}