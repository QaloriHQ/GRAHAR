import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard,
  Beef,
  DollarSign,
  Heart,
  Sprout,
  MapPin,
  BarChart3,
  Bell,
  Search,
  User,
  CheckSquare,
  Sun,
  Moon,
  Users,
  CreditCard
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NotificationDrawer from "@/components/notifications/NotificationDrawer";
import AccountManagementDialog from "@/components/account/AccountManagementDialog";
import RanchSwitcher from "@/components/navigation/RanchSwitcher";
import { ThemeProvider, useTheme } from "@/components/theme/ThemeProvider";
import TeamManagementDialog from "@/components/team/TeamManagementDialog";

const navigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: "Animals", url: createPageUrl("Animals"), icon: Beef },
  { title: "Tasks & Lists", url: createPageUrl("Tasks"), icon: CheckSquare },
  { title: "Financials", url: createPageUrl("Financials"), icon: DollarSign },
  { title: "Health Records", url: createPageUrl("HealthRecords"), icon: Heart },
  { title: "Breeding", url: createPageUrl("Breeding"), icon: Sprout },
  { title: "Pastures", url: createPageUrl("Pastures"), icon: MapPin },
  { title: "Reports", url: createPageUrl("Reports"), icon: BarChart3 },
  { title: "Team", url: createPageUrl("TeamManagement"), icon: Users },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [notificationDrawerOpen, setNotificationDrawerOpen] = React.useState(false);
  const [accountDialogOpen, setAccountDialogOpen] = React.useState(false);
  const [teamDialogOpen, setTeamDialogOpen] = React.useState(false);
  const { theme, setTheme } = useTheme();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.ranch_id],
    queryFn: () => user?.ranch_id ? base44.entities.Ranch.filter({ id: user.ranch_id }).then(r => r[0]) : null,
    enabled: !!user?.ranch_id,
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.ranch_id],
    queryFn: () => base44.entities.Notification.filter({ ranch_id: user.ranch_id, user_email: user.email }, '-created_date', 20),
    initialData: [],
    enabled: !!user?.ranch_id,
    refetchInterval: 30000,
  });

  // Check if user needs onboarding
  React.useEffect(() => {
    if (user && !user.onboarding_completed && location.pathname !== createPageUrl("Onboarding")) {
      navigate(createPageUrl("Onboarding"));
    }
  }, [user, location.pathname, navigate]);

  const unreadCount = notifications.filter(n => n.status === "Unread").length;

  return (
    <ThemeProvider>
      <SidebarProvider>
        <div className="min-h-screen flex w-full bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
          <Sidebar className="border-r border-gray-200 dark:border-gray-800 dark:bg-gray-950">
            <SidebarHeader className="border-b border-gray-200 dark:border-gray-800 p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Beef className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-xl text-gray-900 dark:text-gray-100">HintFarms</h2>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{ranch?.name || "Ranch Management"}</p>
                </div>
              </div>
            </SidebarHeader>

            <SidebarContent className="p-3">
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider px-3 py-2">
                  Navigation
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {navigationItems.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          className={`hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-700 dark:hover:text-emerald-400 transition-all duration-200 rounded-xl mb-1 ${
                            location.pathname === item.url ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 shadow-sm' : 'dark:text-gray-300'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-gray-200 dark:border-gray-800 p-4 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-700 dark:hover:text-emerald-400 dark:text-gray-300 transition-colors"
                onClick={() => setTeamDialogOpen(true)}
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-purple-700 dark:text-purple-400" />
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="font-semibold text-gray-900 dark:text-gray-100 text-sm truncate">Team Management</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">Manage your ranch team</p>
                  </div>
                </div>
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-700 dark:hover:text-emerald-400 dark:text-gray-300 transition-colors"
                onClick={() => setAccountDialogOpen(true)}
              >
                <div className="flex items-center gap-3 w-full">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-100 to-green-100 dark:from-emerald-900 dark:to-green-900 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="font-semibold text-gray-900 dark:text-gray-100 text-sm truncate">Account Settings</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">Manage your profile</p>
                  </div>
                </div>
              </Button>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col">
            <header className="bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800 px-6 py-4 sticky top-0 z-10 transition-colors duration-200">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <SidebarTrigger className="lg:hidden hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-lg transition-colors" />
                  <RanchSwitcher />
                  <div className="hidden md:flex items-center gap-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-gray-500" />
                      <Input
                        placeholder="Search animals, records..."
                        className="pl-10 w-80 border-gray-200 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="dark:text-gray-300 dark:hover:bg-gray-800"
                    onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  >
                    {theme === "dark" ? (
                      <Sun className="h-5 w-5" />
                    ) : (
                      <Moon className="h-5 w-5" />
                    )}
                    <span className="sr-only">Toggle theme</span>
                  </Button>

                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative dark:text-gray-300 dark:hover:bg-gray-800"
                    onClick={() => setNotificationDrawerOpen(true)}
                  >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </Badge>
                    )}
                  </Button>
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-auto bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
              {children}
            </div>
          </main>

          <NotificationDrawer
            open={notificationDrawerOpen}
            onOpenChange={setNotificationDrawerOpen}
          />

          <AccountManagementDialog
            open={accountDialogOpen}
            onOpenChange={setAccountDialogOpen}
          />

          <TeamManagementDialog
            open={teamDialogOpen}
            onOpenChange={setTeamDialogOpen}
          />
        </div>
      </SidebarProvider>
    </ThemeProvider>
  );
}