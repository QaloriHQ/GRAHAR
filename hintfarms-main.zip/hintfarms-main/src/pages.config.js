import Dashboard from './pages/Dashboard';
import Animals from './pages/Animals';
import Financials from './pages/Financials';
import HealthRecords from './pages/HealthRecords';
import Breeding from './pages/Breeding';
import Pastures from './pages/Pastures';
import Reports from './pages/Reports';
import Tasks from './pages/Tasks';
import Notifications from './pages/Notifications';
import Onboarding from './pages/Onboarding';
import RanchSettings from './pages/RanchSettings';
import TeamManagement from './pages/TeamManagement';
import AnimalProfile from './pages/AnimalProfile';
import Expenses from './pages/Expenses';
import Revenue from './pages/Revenue';
import Scenarios from './pages/Scenarios';
import ScenarioBuilder from './pages/ScenarioBuilder';
import ScenarioPreview from './pages/ScenarioPreview';
import BankImports from './pages/BankImports';
import BillingReturn from './pages/BillingReturn';
import AcceptInvite from './pages/AcceptInvite';
import AccountSettings from './pages/AccountSettings';
import PastureProfile from './pages/PastureProfile';
import AdminPortal from './pages/AdminPortal';
import Inventory from './pages/Inventory';
import FieldOps from './pages/FieldOps';
import RanchInsights from './pages/RanchInsights';
import Market from './pages/Market';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Animals": Animals,
    "Financials": Financials,
    "HealthRecords": HealthRecords,
    "Breeding": Breeding,
    "Pastures": Pastures,
    "Reports": Reports,
    "Tasks": Tasks,
    "Notifications": Notifications,
    "Onboarding": Onboarding,
    "RanchSettings": RanchSettings,
    "TeamManagement": TeamManagement,
    "AnimalProfile": AnimalProfile,
    "Expenses": Expenses,
    "Revenue": Revenue,
    "Scenarios": Scenarios,
    "ScenarioBuilder": ScenarioBuilder,
    "ScenarioPreview": ScenarioPreview,
    "BankImports": BankImports,
    "BillingReturn": BillingReturn,
    "AcceptInvite": AcceptInvite,
    "AccountSettings": AccountSettings,
    "PastureProfile": PastureProfile,
    "AdminPortal": AdminPortal,
    "Inventory": Inventory,
    "FieldOps": FieldOps,
    "RanchInsights": RanchInsights,
    "Market": Market,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};