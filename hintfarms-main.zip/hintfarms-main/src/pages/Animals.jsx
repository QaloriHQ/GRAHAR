import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle } from
"@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue } from
"@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter } from
"@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
"@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import {
  Beef,
  Plus,
  Search,
  Filter,
  Edit,
  Upload,
  MoreVertical,
  Trash2,
  Eye,
  X } from
"lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger } from
"@/components/ui/dropdown-menu";
import { createPageUrl } from "@/components/utils";
import { useNavigate } from "react-router-dom";
import AnimalImporter from "../components/animals/AnimalImporter";
import { trackAnimalAdd, trackAnimalUpdate } from "@/components/utils";
import { format } from "date-fns";
import StatsCard from "@/components/dashboard/StatsCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LayoutGrid, List, Map } from "lucide-react";
import LivestockMapView from "../components/animals/LivestockMapView";

export default function Animals() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterHealth, setFilterHealth] = useState("all");
  const [viewMode, setViewMode] = useState("grid");

  // New states for editing and deleting
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedAnimalForAction, setSelectedAnimalForAction] = useState(null);

  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: animals = [], isLoading } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id
  });

  const [newAnimal, setNewAnimal] = useState({
    name: "",
    tag_number: "",
    type: "Cattle",
    breed: "",
    date_of_birth: "",
    gender: "Female",
    weight: 0,
    purchase_price: 0,
    current_value: 0,
    pasture_location: "",
    health_status: "Healthy",
    breeding_status: "Not Breeding",
    notes: ""
  });

  // Effect to manage newAnimal state for editing or resetting for adding
  useEffect(() => {
    if (selectedAnimalForAction && showEditDialog) {
      setNewAnimal({
        name: selectedAnimalForAction.name || "",
        tag_number: selectedAnimalForAction.tag_number || "",
        type: selectedAnimalForAction.type || "Cattle",
        breed: selectedAnimalForAction.breed || "",
        date_of_birth: selectedAnimalForAction.date_of_birth ? format(new Date(selectedAnimalForAction.date_of_birth), 'yyyy-MM-dd') : "",
        gender: selectedAnimalForAction.gender || "Female",
        weight: selectedAnimalForAction.weight || 0,
        purchase_price: selectedAnimalForAction.purchase_price || 0,
        current_value: selectedAnimalForAction.current_value || 0,
        pasture_location: selectedAnimalForAction.pasture_location || "",
        health_status: selectedAnimalForAction.health_status || "Healthy",
        breeding_status: selectedAnimalForAction.breeding_status || "Not Breeding",
        notes: selectedAnimalForAction.notes || ""
      });
    } else if (!showEditDialog && !showAddDialog && selectedAnimalForAction) {
      // If edit/add dialog is closed and an animal was selected, clear selected animal
      setSelectedAnimalForAction(null);
      // Also reset newAnimal form to default for a fresh start on next add
      setNewAnimal({
        name: "", tag_number: "", type: "Cattle", breed: "", date_of_birth: "", gender: "Female",
        weight: 0, purchase_price: 0, current_value: 0, pasture_location: "",
        health_status: "Healthy", breeding_status: "Not Breeding", notes: ""
      });
    } else if (showAddDialog && !selectedAnimalForAction) {
      // Ensure newAnimal is reset when opening Add Dialog if no animal is selected
      setNewAnimal({
        name: "", tag_number: "", type: "Cattle", breed: "", date_of_birth: "", gender: "Female",
        weight: 0, purchase_price: 0, current_value: 0, pasture_location: "",
        health_status: "Healthy", breeding_status: "Not Breeding", notes: ""
      });
    }
  }, [selectedAnimalForAction, showEditDialog, showAddDialog]);


  const createAnimalMutation = useMutation({
    mutationFn: async (animalData) => {
      const animal = await base44.entities.Animal.create({ ...animalData, ranch_id: user.active_ranch_id });

      // Track animal creation - Updated path
      if (user) {
        trackAnimalAdd(user.id, user.active_ranch_id, animalData.type);
      }

      return animal;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      setShowAddDialog(false);
      // newAnimal state reset is handled by useEffect
    }
  });

  // New: Edit animal mutation
  const editAnimalMutation = useMutation({
    mutationFn: async (updatedAnimalData) => {
      if (!selectedAnimalForAction?.id) throw new Error("No animal selected for edit.");
      const animal = await base44.entities.Animal.update(selectedAnimalForAction.id, updatedAnimalData);
      // Track animal update - Updated path
      if (user) {
        trackAnimalUpdate(user.id, user.active_ranch_id, updatedAnimalData.type);
      }
      return animal;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      setShowEditDialog(false);
      // selectedAnimalForAction and newAnimal state reset is handled by useEffect
    }
  });

  // New: Delete animal mutation
  const deleteAnimalMutation = useMutation({
    mutationFn: async (animalId) => {
      await base44.entities.Animal.delete(animalId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      setShowDeleteDialog(false);
      // selectedAnimalForAction state reset is handled by useEffect
    }
  });

  const filteredAnimals = animals.filter((animal) => {
    const matchesSearch = animal.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    animal.tag_number?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || animal.type === filterType;
    const matchesHealth = filterHealth === "all" || animal.health_status === filterHealth;
    return matchesSearch && matchesType && matchesHealth;
  });

  const totalValue = animals.reduce((sum, a) => sum + (a.current_value || 0), 0);
  const avgWeight = animals.length > 0 ? animals.reduce((sum, a) => sum + (a.weight || 0), 0) / animals.length : 0;
  const healthIssues = animals.filter((a) => a.health_status !== 'Healthy').length;

  const healthStatusColors = {
    "Healthy": "bg-green-100 text-green-800 border-green-200",
    "Under Treatment": "bg-yellow-100 text-yellow-800 border-yellow-200",
    "Urgent Attention": "bg-red-100 text-red-800 border-red-200",
    "Recovering": "bg-blue-100 text-blue-800 border-blue-200"
  };

  const breedingStatusColors = {
    "Active Breeding": "bg-purple-100 text-purple-800 border-purple-200",
    "Pregnant": "bg-pink-100 text-pink-800 border-pink-200",
    "Not Breeding": "bg-gray-100 text-gray-800 border-gray-200",
    "Retired": "bg-orange-100 text-orange-800 border-orange-200"
  };

  const handleViewDetails = (animal) => {
    navigate(`/AnimalProfile?id=${animal.id}`);
  };

  const handleEditClick = (animal) => {
    setSelectedAnimalForAction(animal);
    setShowEditDialog(true);
  };

  const handleDeleteClick = (animal) => {
    setSelectedAnimalForAction(animal);
    setShowDeleteDialog(true);
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-emerald-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Livestock Management</h1>
            <p className="text-gray-600">Track and manage your entire herd</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setShowImportDialog(true)}
              className="border-[#F5A623] text-[#F5A623] hover:bg-orange-50">

              <Upload className="w-4 h-4 mr-2" />
              Import CSV
            </Button>
            <Button
              data-tutorial="add-animal"
              onClick={() => setShowAddDialog(true)}
              className="bg-[#F5A623] hover:bg-[#E09612]">

              <Plus className="w-4 h-4 mr-2" />
              Add Animal
            </Button>
          </div>
        </div>

        {/* Add Animal Dialog */}
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Animal</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newAnimal.name}
                  onChange={(e) => setNewAnimal({ ...newAnimal, name: e.target.value })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="tag_number">Tag Number</Label>
                <Input
                  id="tag_number"
                  value={newAnimal.tag_number}
                  onChange={(e) => setNewAnimal({ ...newAnimal, tag_number: e.target.value })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select value={newAnimal.type} onValueChange={(value) => setNewAnimal({ ...newAnimal, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Cattle">Cattle</SelectItem>
                    <SelectItem value="Calf">Calf</SelectItem>
                    <SelectItem value="Bull">Bull</SelectItem>
                    <SelectItem value="Heifer">Heifer</SelectItem>
                    <SelectItem value="Steer">Steer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="breed">Breed</Label>
                <Input
                  id="breed"
                  value={newAnimal.breed}
                  onChange={(e) => setNewAnimal({ ...newAnimal, breed: e.target.value })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="date_of_birth">Date of Birth</Label>
                <Input
                  id="date_of_birth"
                  type="date"
                  value={newAnimal.date_of_birth}
                  onChange={(e) => setNewAnimal({ ...newAnimal, date_of_birth: e.target.value })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <Select value={newAnimal.gender} onValueChange={(value) => setNewAnimal({ ...newAnimal, gender: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="weight">Weight (lbs)</Label>
                <Input
                  id="weight"
                  type="number"
                  value={newAnimal.weight}
                  onChange={(e) => setNewAnimal({ ...newAnimal, weight: parseFloat(e.target.value) })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="purchase_price">Purchase Price ($)</Label>
                <Input
                  id="purchase_price"
                  type="number"
                  value={newAnimal.purchase_price}
                  onChange={(e) => setNewAnimal({ ...newAnimal, purchase_price: parseFloat(e.target.value) })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="current_value">Current Value ($)</Label>
                <Input
                  id="current_value"
                  type="number"
                  value={newAnimal.current_value}
                  onChange={(e) => setNewAnimal({ ...newAnimal, current_value: parseFloat(e.target.value) })} />

              </div>
              <div className="space-y-2">
                <Label htmlFor="pasture_location">Pasture</Label>
                <Select
                  value={newAnimal.pasture_id || "none"}
                  onValueChange={(value) => {
                    if (value === "none") {
                      setNewAnimal({ ...newAnimal, pasture_id: null, pasture_location: "" });
                    } else {
                      const selectedPasture = pastures.find((p) => p.id === value);
                      setNewAnimal({
                        ...newAnimal,
                        pasture_id: value,
                        pasture_location: selectedPasture?.name || ""
                      });
                    }
                  }}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select a pasture" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Pasture</SelectItem>
                    {pastures.map((pasture) =>
                    <SelectItem key={pasture.id} value={pasture.id}>
                        {pasture.name}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={newAnimal.notes}
                  onChange={(e) => setNewAnimal({ ...newAnimal, notes: e.target.value })} />

              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={() => createAnimalMutation.mutate(newAnimal)}
                className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                disabled={createAnimalMutation.isPending}>

                {createAnimalMutation.isPending ? "Adding..." : "Add Animal"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Animal Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Animal</DialogTitle>
            </DialogHeader>
            {selectedAnimalForAction &&
            <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Name</Label>
                  <Input
                  id="edit-name"
                  value={newAnimal.name}
                  onChange={(e) => setNewAnimal({ ...newAnimal, name: e.target.value })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-tag_number">Tag Number</Label>
                  <Input
                  id="edit-tag_number"
                  value={newAnimal.tag_number}
                  onChange={(e) => setNewAnimal({ ...newAnimal, tag_number: e.target.value })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-type">Type</Label>
                  <Select value={newAnimal.type} onValueChange={(value) => setNewAnimal({ ...newAnimal, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Cattle">Cattle</SelectItem>
                      <SelectItem value="Calf">Calf</SelectItem>
                      <SelectItem value="Bull">Bull</SelectItem>
                      <SelectItem value="Heifer">Heifer</SelectItem>
                      <SelectItem value="Steer">Steer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-breed">Breed</Label>
                  <Input
                  id="edit-breed"
                  value={newAnimal.breed}
                  onChange={(e) => setNewAnimal({ ...newAnimal, breed: e.target.value })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-date_of_birth">Date of Birth</Label>
                  <Input
                  id="edit-date_of_birth"
                  type="date"
                  value={newAnimal.date_of_birth}
                  onChange={(e) => setNewAnimal({ ...newAnimal, date_of_birth: e.target.value })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-gender">Gender</Label>
                  <Select value={newAnimal.gender} onValueChange={(value) => setNewAnimal({ ...newAnimal, gender: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-weight">Weight (lbs)</Label>
                  <Input
                  id="edit-weight"
                  type="number"
                  value={newAnimal.weight}
                  onChange={(e) => setNewAnimal({ ...newAnimal, weight: parseFloat(e.target.value) })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-purchase_price">Purchase Price ($)</Label>
                  <Input
                  id="edit-purchase_price"
                  type="number"
                  value={newAnimal.purchase_price}
                  onChange={(e) => setNewAnimal({ ...newAnimal, purchase_price: parseFloat(e.target.value) })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-current_value">Current Value ($)</Label>
                  <Input
                  id="edit-current_value"
                  type="number"
                  value={newAnimal.current_value}
                  onChange={(e) => setNewAnimal({ ...newAnimal, current_value: parseFloat(e.target.value) })} />

                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-pasture_location">Pasture</Label>
                  <Select
                  value={newAnimal.pasture_id || "none"}
                  onValueChange={(value) => {
                    if (value === "none") {
                      setNewAnimal({ ...newAnimal, pasture_id: null, pasture_location: "" });
                    } else {
                      const selectedPasture = pastures.find((p) => p.id === value);
                      setNewAnimal({
                        ...newAnimal,
                        pasture_id: value,
                        pasture_location: selectedPasture?.name || ""
                      });
                    }
                  }}>

                    <SelectTrigger>
                      <SelectValue placeholder="Select a pasture" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Pasture</SelectItem>
                      {pastures.map((pasture) =>
                    <SelectItem key={pasture.id} value={pasture.id}>
                          {pasture.name}
                        </SelectItem>
                    )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-health_status">Health Status</Label>
                  <Select value={newAnimal.health_status} onValueChange={(value) => setNewAnimal({ ...newAnimal, health_status: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Healthy">Healthy</SelectItem>
                      <SelectItem value="Under Treatment">Under Treatment</SelectItem>
                      <SelectItem value="Urgent Attention">Urgent Attention</SelectItem>
                      <SelectItem value="Recovering">Recovering</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-breeding_status">Breeding Status</Label>
                  <Select value={newAnimal.breeding_status} onValueChange={(value) => setNewAnimal({ ...newAnimal, breeding_status: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Not Breeding">Not Breeding</SelectItem>
                      <SelectItem value="Active Breeding">Active Breeding</SelectItem>
                      <SelectItem value="Pregnant">Pregnant</SelectItem>
                      <SelectItem value="Retired">Retired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="edit-notes">Notes</Label>
                  <Textarea
                  id="edit-notes"
                  value={newAnimal.notes}
                  onChange={(e) => setNewAnimal({ ...newAnimal, notes: e.target.value })} />

                </div>
              </div>
            }
            <DialogFooter>
              <Button
                onClick={() => editAnimalMutation.mutate(newAnimal)}
                className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                disabled={editAnimalMutation.isPending}>

                {editAnimalMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Animal Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              Are you sure you want to delete {selectedAnimalForAction?.name || "this animal"} (Tag: {selectedAnimalForAction?.tag_number})? This action cannot be undone.
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>Cancel</Button>
              <Button
                variant="destructive"
                onClick={() => deleteAnimalMutation.mutate(selectedAnimalForAction?.id)}
                disabled={deleteAnimalMutation.isPending}>

                {deleteAnimalMutation.isPending ? "Deleting..." : "Delete"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8" data-tutorial="animals-stats">
          <StatsCard
            title="Total Animals"
            value={animals.length}
            icon={Beef}
            bgColor="bg-orange-500"
            textColor="text-[#F5A623]" />

          <StatsCard
            title="Total Value"
            value={`$${totalValue.toLocaleString()}`}
            icon={Filter}
            bgColor="bg-blue-500"
            textColor="text-blue-600" />

          <StatsCard
            title="Avg Weight"
            value={`${avgWeight.toFixed(0)} lbs`}
            icon={Edit}
            bgColor="bg-purple-500"
            textColor="text-purple-600" />

          <StatsCard
            title="Health Issues"
            value={healthIssues}
            icon={Plus}
            bgColor="bg-red-500"
            textColor="text-red-600" />

        </div>

        {/* Filters & View Toggle */}
        <Card className="mb-6 border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search by name or tag number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10" />

              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Cattle">Cattle</SelectItem>
                  <SelectItem value="Calf">Calf</SelectItem>
                  <SelectItem value="Bull">Bull</SelectItem>
                  <SelectItem value="Heifer">Heifer</SelectItem>
                  <SelectItem value="Steer">Steer</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterHealth} onValueChange={setFilterHealth}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Health Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Health Status</SelectItem>
                  <SelectItem value="Healthy">Healthy</SelectItem>
                  <SelectItem value="Under Treatment">Under Treatment</SelectItem>
                  <SelectItem value="Urgent Attention">Urgent Attention</SelectItem>
                  <SelectItem value="Recovering">Recovering</SelectItem>
                </SelectContent>
              </Select>
              <Tabs value={viewMode} onValueChange={setViewMode} className="w-auto">
                <TabsList>
                  <TabsTrigger value="grid">
                    <LayoutGrid className="w-4 h-4" />
                  </TabsTrigger>
                  <TabsTrigger value="list">
                    <List className="w-4 h-4" />
                  </TabsTrigger>
                  <TabsTrigger value="map">
                    <Map className="w-4 h-4" />
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Animals Grid */}
        {viewMode === "grid" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAnimals.map((animal) =>
            <Card key={animal.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-48 w-full overflow-hidden bg-gray-100">
                <img
                src={animal.main_image_url || "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=400&h=300&fit=crop"}
                alt={animal.name}
                className="w-full h-full object-cover" />

              </div>
              <div className="h-2 bg-gradient-to-r from-orange-500 to-orange-600" />
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl mb-1">{animal.name}</CardTitle>
                    <p className="text-sm text-gray-500">Tag: {animal.tag_number}</p>
                  </div>
                  <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                    {animal.type}
                  </Badge>
                  {/* Dropdown Menu for actions */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleViewDetails(animal)}>
                        <Eye className="mr-2 h-4 w-4" /> View Full Profile
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEditClick(animal)}>
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleDeleteClick(animal)}>
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-gray-500">Breed</p>
                    <p className="font-semibold">{animal.breed}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Weight</p>
                    <p className="font-semibold">{animal.weight} lbs</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Value</p>
                    <p className="font-semibold text-emerald-600">${animal.current_value?.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Location</p>
                    <p className="font-semibold">{animal.pasture_location || "N/A"}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge className={`${healthStatusColors[animal.health_status]} border text-xs`}>
                    {animal.health_status}
                  </Badge>
                  <Badge className={`${breedingStatusColors[animal.breeding_status]} border text-xs`}>
                    {animal.breeding_status}
                  </Badge>
                </div>
                <Button
                variant="outline"
                className="w-full mt-4"
                onClick={() => handleViewDetails(animal)}>

                  <Eye className="w-4 h-4 mr-2" />
                  View Full Profile
                </Button>
                </CardContent>
                </Card>
            )}
          </div>
        )}

        {viewMode === "list" && (
          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Animal</TableHead>
                    <TableHead>Tag #</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Weight</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Pasture</TableHead>
                    <TableHead>Health</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAnimals.map((animal) => (
                    <TableRow key={animal.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <img
                            src={animal.main_image_url || "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=100&h=100&fit=crop"}
                            alt={animal.name}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                          <div>
                            <p className="font-semibold">{animal.name}</p>
                            <p className="text-sm text-gray-500">{animal.breed}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{animal.tag_number}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{animal.type}</Badge>
                      </TableCell>
                      <TableCell>{animal.weight} lbs</TableCell>
                      <TableCell>${animal.current_value?.toLocaleString()}</TableCell>
                      <TableCell>{animal.pasture_location || "Unassigned"}</TableCell>
                      <TableCell>
                        <Badge className={healthStatusColors[animal.health_status]}>
                          {animal.health_status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewDetails(animal)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {
                              setSelectedAnimalForAction(animal);
                              setShowEditDialog(true);
                            }}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedAnimalForAction(animal);
                                setShowDeleteDialog(true);
                              }}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {viewMode === "map" && (
          <LivestockMapView animals={filteredAnimals} pastures={pastures} onViewDetails={handleViewDetails} />
        )}
        <AnimalImporter
          open={showImportDialog}
          onOpenChange={setShowImportDialog} />

      </div>
    </div>);

}