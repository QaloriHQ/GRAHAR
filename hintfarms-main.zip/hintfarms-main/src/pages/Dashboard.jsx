import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { 
  Leaf,
  AlertCircle,
  FileText,
  Package
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { format, isPast } from "date-fns";
import RanchMapView from "@/components/dashboard/RanchMapView";

export default function Dashboard() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.active_ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.active_ranch_id }, '-date', 50),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: revenue = [] } = useQuery({
    queryKey: ['revenue', user?.active_ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.active_ranch_id }, '-date', 50),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks', user?.active_ranch_id],
    queryFn: () => base44.entities.Task.filter({ ranch_id: user.active_ranch_id }, '-created_date', 20),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  // Calculate stats
  const activeAnimals = animals.filter(a => a.type !== 'Sold').length;
  const heatCycleAnimals = animals.filter(a => a.breeding_status === 'Active Breeding').length;
  const healthIssues = animals.filter(a => a.health_status !== 'Healthy').length;

  // Calculate pasture utilization
  const totalCapacity = pastures.reduce((sum, p) => sum + (p.capacity || 0), 0);
  const totalAnimals = pastures.reduce((sum, p) => sum + (p.current_animal_count || 0), 0);
  const utilizationPercent = totalCapacity > 0 ? Math.round((totalAnimals / totalCapacity) * 100) : 0;

  // Get health alerts
  const healthAlerts = [
    ...animals.filter(a => a.health_status === 'Under Treatment' || a.health_status === 'Urgent Attention')
      .slice(0, 3)
      .map(a => ({
        condition: a.health_status === 'Urgent Attention' ? 'Critical Condition' : 'Under Treatment',
        animal: `${a.type} ${a.tag_number}`,
        location: a.pasture_location || 'Unknown'
      }))
  ];

  // Get recent tasks
  const recentTasks = tasks.filter(t => t.status !== 'Completed').slice(0, 4);

  // Financial data
  const totalExpenses = expenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
  const totalRevenue = revenue.reduce((sum, rev) => sum + (rev.amount || 0), 0);

  // Cattle distribution by location
  const locationCounts = animals.reduce((acc, animal) => {
    const location = animal.pasture_location || 'Unknown';
    acc[location] = (acc[location] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(locationCounts)
    .map(([name, count]) => ({ name, count }))
    .slice(0, 4);

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gray-50 min-h-screen">
      <div className="max-w-[1400px] mx-auto overflow-x-hidden">
        {/* Top Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6 mb-6">
          {/* Herd Overview */}
          <Card className="lg:col-span-3 border-none shadow">
            <CardContent className="p-6">
              <h3 className="text-sm font-semibold text-gray-600 mb-4">Herd Overview</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-4xl font-bold text-gray-900">{animals.length.toLocaleString()}</p>
                  <p className="text-sm text-gray-500">Total Cattle</p>
                </div>
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{activeAnimals}</p>
                    <p className="text-xs text-[#F5A623] uppercase font-medium">Heat Cycle</p>
                    <p className="text-xs text-gray-500">Active</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{healthIssues}</p>
                    <p className="text-xs text-red-500 uppercase font-medium">Concerns</p>
                    <p className="text-xs text-gray-500">Health Issues</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pasture Utilization */}
          <Card className="lg:col-span-3 border-none shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-gray-600 mb-1">Pasture</h3>
                  <h3 className="text-sm font-semibold text-gray-600">Utilization</h3>
                </div>
                <Leaf className="w-8 h-8 text-green-500" />
              </div>
              <div className="space-y-2">
                <p className="text-5xl font-bold text-gray-900">{utilizationPercent}%</p>
                <p className="text-sm text-gray-500">Current capacity across all pastures</p>
              </div>
            </CardContent>
          </Card>

          {/* Health Alerts */}
          <Card className="md:col-span-2 lg:col-span-6 border-none shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <AlertCircle className="w-5 h-5 text-red-500" />
                <h3 className="text-sm font-semibold text-gray-900">Health Alerts</h3>
              </div>
              <div className="space-y-3">
                {healthAlerts.length > 0 ? (
                  healthAlerts.map((alert, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5"></div>
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900 text-sm">{alert.condition}</p>
                        <p className="text-sm text-gray-600">{alert.animal} • {alert.location}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">No health alerts</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ranch Map */}
        <div className="mb-6">
          <Card className="border-none shadow">
            <CardContent className="p-0">
              <div className="h-[400px] rounded-lg overflow-hidden">
                <RanchMapView pastures={pastures} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Middle Row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
          {/* Upcoming Tasks */}
          <Card className="lg:col-span-4 border-none shadow">
            <CardContent className="p-6">
              <h3 className="text-sm font-semibold text-gray-900 mb-4">Upcoming Tasks</h3>
              <div className="space-y-3">
                {recentTasks.length > 0 ? (
                  recentTasks.map(task => {
                    const isCompleted = task.status === 'Completed';
                    return (
                      <div key={task.id} className="flex items-start gap-3">
                        <Checkbox checked={isCompleted} className="mt-0.5" />
                        <div className="flex-1">
                          <p className={`text-sm ${isCompleted ? 'line-through text-gray-400' : 'text-gray-900'}`}>
                            {task.title}
                          </p>
                          <p className="text-xs text-gray-500">
                            {task.due_date ? format(new Date(task.due_date), 'MMM d') : 'Upcoming'}
                          </p>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-sm text-gray-500">No upcoming tasks</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Cattle Distribution */}
          <Card className="lg:col-span-8 border-none shadow">
            <CardContent className="p-6">
              <h3 className="text-sm font-semibold text-gray-900 mb-4">Cattle Distribution by Location</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={chartData}>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: '#6B7280' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fontSize: 12, fill: '#6B7280' }}
                  />
                  <Bar dataKey="count" fill="#F5A623" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {/* Financial Snapshot */}
          <Card className="md:col-span-1 lg:col-span-4 border-none shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-yellow-100 rounded flex items-center justify-center">
                  <span className="text-xl">$</span>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Financial</p>
                  <p className="text-sm font-semibold text-gray-900">Snapshot</p>
                </div>
              </div>
              <div>
                <p className="text-3xl font-bold text-gray-900">
                  ${(totalRevenue - totalExpenses).toLocaleString()}
                </p>
                <p className="text-sm text-gray-500">Month to date</p>
              </div>
            </CardContent>
          </Card>

          {/* Reports */}
          <Card className="md:col-span-1 lg:col-span-4 border-none shadow hover:shadow-md transition-shadow cursor-pointer">
            <Link to={createPageUrl("Reports")}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <FileText className="w-5 h-5 text-gray-600" />
                  <h3 className="text-sm font-semibold text-gray-900">Reports</h3>
                </div>
                <p className="text-sm text-gray-500">View detailed analytics</p>
              </CardContent>
            </Link>
          </Card>

          {/* Inventory */}
          <Card className="md:col-span-2 lg:col-span-4 border-none shadow hover:shadow-md transition-shadow cursor-pointer">
            <Link to={createPageUrl("Inventory")}>
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <Package className="w-5 h-5 text-gray-600" />
                  <h3 className="text-sm font-semibold text-gray-900">Inventory</h3>
                </div>
                <p className="text-sm text-gray-500">Manage supplies</p>
              </CardContent>
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}