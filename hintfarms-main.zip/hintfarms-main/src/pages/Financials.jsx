import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, DollarSign, TrendingUp, TrendingDown, Wallet, Download } from "lucide-react";
import { format } from "date-fns";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import StatsCard from "../components/dashboard/StatsCard";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils";

export default function Financials() {
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [showRevenueDialog, setShowRevenueDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.active_ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: revenue = [] } = useQuery({
    queryKey: ['revenue', user?.active_ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newExpense, setNewExpense] = useState({
    date: new Date().toISOString().split('T')[0],
    category: "Feed",
    description: "",
    amount: 0,
    vendor: "",
    payment_method: "Cash",
    notes: ""
  });

  const [newRevenue, setNewRevenue] = useState({
    date: new Date().toISOString().split('T')[0],
    category: "Cattle Sale",
    description: "",
    amount: 0,
    buyer: "",
    payment_method: "Cash",
    notes: ""
  });

  const createExpenseMutation = useMutation({
    mutationFn: (data) => base44.entities.Expense.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses', user?.active_ranch_id] });
      setShowExpenseDialog(false);
      setNewExpense({
        date: new Date().toISOString().split('T')[0],
        category: "Feed",
        description: "",
        amount: 0,
        vendor: "",
        payment_method: "Cash",
        notes: ""
      });
    },
  });

  const createRevenueMutation = useMutation({
    mutationFn: (data) => base44.entities.Revenue.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['revenue', user?.active_ranch_id] });
      setShowRevenueDialog(false);
      setNewRevenue({
        date: new Date().toISOString().split('T')[0],
        category: "Cattle Sale",
        description: "",
        amount: 0,
        buyer: "",
        payment_method: "Cash",
        notes: ""
      });
    },
  });

  const totalExpenses = expenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
  const totalRevenue = revenue.reduce((sum, rev) => sum + (rev.amount || 0), 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : 0;

  // Expense by category for pie chart
  const expenseByCategory = expenses.reduce((acc, exp) => {
    acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
    return acc;
  }, {});

  const pieData = Object.entries(expenseByCategory).map(([name, value]) => ({ name, value }));
  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

  const handleExpenseClick = (expense) => {
    navigate(createPageUrl("Expenses") + `?id=${expense.id}`);
  };

  const handleRevenueClick = (rev) => {
    navigate(createPageUrl("Revenue") + `?id=${rev.id}`);
  };

  const recentExpenses = expenses.slice(0, 10);
  const recentRevenue = revenue.slice(0, 10);

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Financial Management</h1>
            <p className="text-gray-600 dark:text-gray-400">Track expenses, revenue, and profitability</p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("BankImports"))}
              className="shadow-lg"
            >
              <Download className="w-4 h-4 mr-2" />
              Bank Imports
            </Button>
            <Dialog open={showExpenseDialog} onOpenChange={setShowExpenseDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Expense
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Expense</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={newExpense.date}
                      onChange={(e) => setNewExpense({...newExpense, date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={newExpense.category} onValueChange={(value) => setNewExpense({...newExpense, category: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Feed">Feed</SelectItem>
                        <SelectItem value="Veterinary">Veterinary</SelectItem>
                        <SelectItem value="Labor">Labor</SelectItem>
                        <SelectItem value="Equipment">Equipment</SelectItem>
                        <SelectItem value="Utilities">Utilities</SelectItem>
                        <SelectItem value="Maintenance">Maintenance</SelectItem>
                        <SelectItem value="Supplies">Supplies</SelectItem>
                        <SelectItem value="Transportation">Transportation</SelectItem>
                        <SelectItem value="Insurance">Insurance</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      value={newExpense.description}
                      onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Amount ($)</Label>
                    <Input
                      type="number"
                      value={newExpense.amount}
                      onChange={(e) => setNewExpense({...newExpense, amount: parseFloat(e.target.value)})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Vendor</Label>
                    <Input
                      value={newExpense.vendor}
                      onChange={(e) => setNewExpense({...newExpense, vendor: e.target.value})}
                    />
                  </div>
                </div>
                <Button onClick={() => createExpenseMutation.mutate(newExpense)} className="w-full bg-[#F5A623] hover:bg-[#E09612]">
                  Add Expense
                </Button>
              </DialogContent>
            </Dialog>

            <Dialog open={showRevenueDialog} onOpenChange={setShowRevenueDialog}>
              <DialogTrigger asChild>
                <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Revenue
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Revenue</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={newRevenue.date}
                      onChange={(e) => setNewRevenue({...newRevenue, date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select value={newRevenue.category} onValueChange={(value) => setNewRevenue({...newRevenue, category: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cattle Sale">Cattle Sale</SelectItem>
                        <SelectItem value="Calf Sale">Calf Sale</SelectItem>
                        <SelectItem value="Milk">Milk</SelectItem>
                        <SelectItem value="Breeding Services">Breeding Services</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input
                      value={newRevenue.description}
                      onChange={(e) => setNewRevenue({...newRevenue, description: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Amount ($)</Label>
                    <Input
                      type="number"
                      value={newRevenue.amount}
                      onChange={(e) => setNewRevenue({...newRevenue, amount: parseFloat(e.target.value)})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Buyer</Label>
                    <Input
                      value={newRevenue.buyer}
                      onChange={(e) => setNewRevenue({...newRevenue, buyer: e.target.value})}
                    />
                  </div>
                </div>
                <Button onClick={() => createRevenueMutation.mutate(newRevenue)} className="w-full bg-[#F5A623] hover:bg-[#E09612]">
                  Add Revenue
                </Button>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Revenue"
            value={`$${totalRevenue.toLocaleString()}`}
            icon={DollarSign}
            bgColor="bg-green-500"
            textColor="text-green-600"
            trend="+12.5%"
            trendUp={true}
          />
          <StatsCard
            title="Total Expenses"
            value={`$${totalExpenses.toLocaleString()}`}
            icon={Wallet}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
          <StatsCard
            title="Net Profit"
            value={`$${netProfit.toLocaleString()}`}
            icon={netProfit >= 0 ? TrendingUp : TrendingDown}
            bgColor={netProfit >= 0 ? "bg-orange-500" : "bg-red-500"}
            textColor={netProfit >= 0 ? "text-[#F5A623]" : "text-red-600"}
          />
          <StatsCard
            title="Profit Margin"
            value={`${profitMargin}%`}
            icon={TrendingUp}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Expense Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => entry.name}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Revenue vs Expenses</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Revenue</span>
                    <span className="text-sm font-bold text-[#F5A623]">${totalRevenue.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-[#F5A623] h-3 rounded-full" style={{width: '100%'}} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Expenses</span>
                    <span className="text-sm font-bold text-red-600">${totalExpenses.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-red-500 h-3 rounded-full"
                      style={{width: `${totalRevenue > 0 ? (totalExpenses / totalRevenue * 100) : 0}%`}}
                    />
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold">Net Profit</span>
                    <span className={`text-2xl font-bold ${netProfit >= 0 ? 'text-[#F5A623]' : 'text-red-600'}`}>
                      ${netProfit.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <div className="grid lg:grid-cols-2 gap-6">
          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="dark:text-gray-100">Recent Expenses</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="dark:border-gray-700">
                    <TableHead className="dark:text-gray-400">Date</TableHead>
                    <TableHead className="dark:text-gray-400">Category</TableHead>
                    <TableHead className="dark:text-gray-400">Description</TableHead>
                    <TableHead className="text-right dark:text-gray-400">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentExpenses.map(expense => (
                    <TableRow
                      key={expense.id}
                      onClick={() => handleExpenseClick(expense)}
                      className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors dark:border-gray-700"
                    >
                      <TableCell className="dark:text-gray-300">{format(new Date(expense.date), "MMM d")}</TableCell>
                      <TableCell className="dark:text-gray-300">{expense.category}</TableCell>
                      <TableCell className="max-w-[200px] truncate dark:text-gray-300">{expense.description}</TableCell>
                      <TableCell className="text-right font-semibold text-red-600 dark:text-red-400">
                        ${expense.amount.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {recentExpenses.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No expenses recorded yet</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="dark:text-gray-100">Recent Revenue</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="dark:border-gray-700">
                    <TableHead className="dark:text-gray-400">Date</TableHead>
                    <TableHead className="dark:text-gray-400">Category</TableHead>
                    <TableHead className="dark:text-gray-400">Description</TableHead>
                    <TableHead className="text-right dark:text-gray-400">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentRevenue.map(rev => (
                    <TableRow
                      key={rev.id}
                      onClick={() => handleRevenueClick(rev)}
                      className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors dark:border-gray-700"
                    >
                      <TableCell className="dark:text-gray-300">{format(new Date(rev.date), "MMM d")}</TableCell>
                      <TableCell className="dark:text-gray-300">{rev.category}</TableCell>
                      <TableCell className="max-w-[200px] truncate dark:text-gray-300">{rev.description}</TableCell>
                      <TableCell className="text-right font-semibold text-[#F5A623]">
                        ${rev.amount.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {recentRevenue.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No revenue recorded yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}