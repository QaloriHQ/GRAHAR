import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Package, Plus, Edit, Trash2, AlertTriangle, TrendingDown, Search } from "lucide-react";
import StatsCard from "../components/dashboard/StatsCard";
import { toast } from "sonner";

export default function Inventory() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");

  const [newItem, setNewItem] = useState({
    name: "",
    category: "Feed",
    quantity: 0,
    unit: "lbs",
    reorder_level: 0,
    unit_cost: 0,
    supplier: "",
    location: "",
    last_restocked_date: "",
    expiry_date: "",
    notes: "",
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: items = [] } = useQuery({
    queryKey: ['inventory', user?.active_ranch_id],
    queryFn: () => base44.entities.Inventory.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const createItemMutation = useMutation({
    mutationFn: (data) => base44.entities.Inventory.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
      setShowDialog(false);
      resetForm();
      toast.success('Item added successfully');
    },
  });

  const updateItemMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Inventory.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
      setShowDialog(false);
      setEditingItem(null);
      resetForm();
      toast.success('Item updated successfully');
    },
  });

  const deleteItemMutation = useMutation({
    mutationFn: (id) => base44.entities.Inventory.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
      toast.success('Item deleted successfully');
    },
  });

  const resetForm = () => {
    setNewItem({
      name: "",
      category: "Feed",
      quantity: 0,
      unit: "lbs",
      reorder_level: 0,
      unit_cost: 0,
      supplier: "",
      location: "",
      last_restocked_date: "",
      expiry_date: "",
      notes: "",
    });
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setNewItem({
      ...item,
      last_restocked_date: item.last_restocked_date ? new Date(item.last_restocked_date).toISOString().split('T')[0] : "",
      expiry_date: item.expiry_date ? new Date(item.expiry_date).toISOString().split('T')[0] : "",
    });
    setShowDialog(true);
  };

  const handleSave = () => {
    if (editingItem) {
      updateItemMutation.mutate({ id: editingItem.id, data: newItem });
    } else {
      createItemMutation.mutate(newItem);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this item?')) {
      deleteItemMutation.mutate(id);
    }
  };

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.supplier?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === "all" || item.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const lowStockItems = items.filter(item => item.quantity <= item.reorder_level);
  const totalValue = items.reduce((sum, item) => sum + (item.quantity * (item.unit_cost || 0)), 0);
  const categories = [...new Set(items.map(item => item.category))];

  const categoryColors = {
    "Feed": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Medication": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300",
    "Supplies": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Equipment": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300",
    "Seeds": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Fertilizer": "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-purple-50/30 dark:from-gray-900 dark:to-purple-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">
              Inventory & Supplies
            </h1>
            <p className="text-gray-600 dark:text-gray-400">Track and manage your ranch supplies</p>
          </div>
          <Button
            onClick={() => {
              setEditingItem(null);
              resetForm();
              setShowDialog(true);
            }}
            className="bg-[#F5A623] hover:bg-[#E09612]"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Items"
            value={items.length}
            icon={Package}
            bgColor="bg-purple-500"
            textColor="text-purple-600"
          />
          <StatsCard
            title="Low Stock Alerts"
            value={lowStockItems.length}
            icon={AlertTriangle}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
          <StatsCard
            title="Categories"
            value={categories.length}
            icon={TrendingDown}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Total Value"
            value={`$${totalValue.toLocaleString()}`}
            icon={Package}
            bgColor="bg-green-500"
            textColor="text-green-600"
          />
        </div>

        {/* Filters */}
        <Card className="mb-6 dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 dark:bg-gray-900 dark:border-gray-700"
                />
              </div>
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-full md:w-48 dark:bg-gray-900 dark:border-gray-700">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Feed">Feed</SelectItem>
                  <SelectItem value="Medication">Medication</SelectItem>
                  <SelectItem value="Supplies">Supplies</SelectItem>
                  <SelectItem value="Equipment">Equipment</SelectItem>
                  <SelectItem value="Seeds">Seeds</SelectItem>
                  <SelectItem value="Fertilizer">Fertilizer</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Items Table */}
        <Card className="dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Inventory Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="dark:border-gray-700">
                    <TableHead className="dark:text-gray-300">Item</TableHead>
                    <TableHead className="dark:text-gray-300">Category</TableHead>
                    <TableHead className="dark:text-gray-300">Quantity</TableHead>
                    <TableHead className="dark:text-gray-300">Reorder Level</TableHead>
                    <TableHead className="dark:text-gray-300">Unit Cost</TableHead>
                    <TableHead className="dark:text-gray-300">Total Value</TableHead>
                    <TableHead className="dark:text-gray-300">Supplier</TableHead>
                    <TableHead className="dark:text-gray-300">Location</TableHead>
                    <TableHead className="dark:text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredItems.map((item) => (
                    <TableRow key={item.id} className="dark:border-gray-700">
                      <TableCell className="font-medium dark:text-gray-100">
                        <div>
                          {item.name}
                          {item.quantity <= item.reorder_level && (
                            <Badge variant="destructive" className="ml-2 text-xs">
                              Low Stock
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${categoryColors[item.category]} border`}>
                          {item.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        {item.quantity} {item.unit}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        {item.reorder_level} {item.unit}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        ${item.unit_cost?.toFixed(2) || '0.00'}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        ${((item.quantity * (item.unit_cost || 0)).toFixed(2))}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">{item.supplier || '-'}</TableCell>
                      <TableCell className="dark:text-gray-300">{item.location || '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(item)}
                            className="dark:hover:bg-gray-700"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(item.id)}
                            className="text-red-600 dark:hover:bg-gray-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {filteredItems.length === 0 && (
                <div className="text-center py-12">
                  <Package className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    No items found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    {searchQuery || filterCategory !== "all" 
                      ? "Try adjusting your filters"
                      : "Add your first inventory item to get started"}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Add/Edit Dialog */}
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800 max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">
                {editingItem ? 'Edit Item' : 'Add New Item'}
              </DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-4 py-4">
              <div className="col-span-2 space-y-2">
                <Label className="dark:text-gray-200">Item Name *</Label>
                <Input
                  value={newItem.name}
                  onChange={(e) => setNewItem({...newItem, name: e.target.value})}
                  placeholder="e.g., Hay Bales, Vaccines, Feed"
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Category *</Label>
                <Select value={newItem.category} onValueChange={(value) => setNewItem({...newItem, category: value})}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Feed">Feed</SelectItem>
                    <SelectItem value="Medication">Medication</SelectItem>
                    <SelectItem value="Supplies">Supplies</SelectItem>
                    <SelectItem value="Equipment">Equipment</SelectItem>
                    <SelectItem value="Seeds">Seeds</SelectItem>
                    <SelectItem value="Fertilizer">Fertilizer</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Unit *</Label>
                <Select value={newItem.unit} onValueChange={(value) => setNewItem({...newItem, unit: value})}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="lbs">Pounds (lbs)</SelectItem>
                    <SelectItem value="tons">Tons</SelectItem>
                    <SelectItem value="gallons">Gallons</SelectItem>
                    <SelectItem value="liters">Liters</SelectItem>
                    <SelectItem value="count">Count</SelectItem>
                    <SelectItem value="bags">Bags</SelectItem>
                    <SelectItem value="boxes">Boxes</SelectItem>
                    <SelectItem value="bales">Bales</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Quantity *</Label>
                <Input
                  type="number"
                  value={newItem.quantity}
                  onChange={(e) => setNewItem({...newItem, quantity: parseFloat(e.target.value) || 0})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Reorder Level</Label>
                <Input
                  type="number"
                  value={newItem.reorder_level}
                  onChange={(e) => setNewItem({...newItem, reorder_level: parseFloat(e.target.value) || 0})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Unit Cost ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={newItem.unit_cost}
                  onChange={(e) => setNewItem({...newItem, unit_cost: parseFloat(e.target.value) || 0})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Supplier</Label>
                <Input
                  value={newItem.supplier}
                  onChange={(e) => setNewItem({...newItem, supplier: e.target.value})}
                  placeholder="Vendor name"
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Storage Location</Label>
                <Input
                  value={newItem.location}
                  onChange={(e) => setNewItem({...newItem, location: e.target.value})}
                  placeholder="e.g., Barn A, Shed 2"
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Last Restocked</Label>
                <Input
                  type="date"
                  value={newItem.last_restocked_date}
                  onChange={(e) => setNewItem({...newItem, last_restocked_date: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Expiry Date</Label>
                <Input
                  type="date"
                  value={newItem.expiry_date}
                  onChange={(e) => setNewItem({...newItem, expiry_date: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>

              <div className="col-span-2 space-y-2">
                <Label className="dark:text-gray-200">Notes</Label>
                <Textarea
                  value={newItem.notes}
                  onChange={(e) => setNewItem({...newItem, notes: e.target.value})}
                  placeholder="Additional details..."
                  rows={3}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowDialog(false);
                  setEditingItem(null);
                  resetForm();
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSave}
                className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                disabled={!newItem.name || !newItem.quantity}
              >
                {editingItem ? 'Update Item' : 'Add Item'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}