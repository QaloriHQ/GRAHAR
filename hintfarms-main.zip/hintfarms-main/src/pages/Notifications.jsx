
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CheckSquare,
  Heart,
  Sprout,
  DollarSign,
  Settings,
  Check,
  Trash2,
  ExternalLink,
  Bell,
  Search,
  Filter
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import StatsCard from "../components/dashboard/StatsCard";

const typeIcons = {
  Task: CheckSquare,
  Health: Heart,
  Breeding: Sprout,
  Financial: DollarSign,
  System: Settings
};

const typeColors = {
  Task: "bg-blue-100 text-blue-800 border-blue-200",
  Health: "bg-red-100 text-red-800 border-red-200",
  Breeding: "bg-purple-100 text-purple-800 border-purple-200",
  Financial: "bg-green-100 text-green-800 border-green-200",
  System: "bg-gray-100 text-gray-800 border-gray-200"
};

const priorityColors = {
  Low: "border-l-blue-400",
  Medium: "border-l-yellow-400",
  High: "border-l-orange-400",
  Urgent: "border-l-red-500"
};

export default function Notifications() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.active_ranch_id],
    // The base44.entities.Notification.filter call already includes ranch_id based filtering.
    // This ensures only notifications relevant to the current user's ranch are fetched.
    queryFn: () => base44.entities.Notification.filter({ ranch_id: user.active_ranch_id, user_email: user.email }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id, // Only enable query if user and active_ranch_id are available
  });

  const markAsReadMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.update(id, { status: "Read" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', user?.active_ranch_id] }); // Invalidate with active_ranch_id for specific caching
    },
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', user?.active_ranch_id] }); // Invalidate with active_ranch_id for specific caching
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => n.status === "Unread");
      await Promise.all(
        unreadNotifications.map(n => base44.entities.Notification.update(n.id, { status: "Read" }))
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', user?.active_ranch_id] }); // Invalidate with active_ranch_id for specific caching
    },
  });

  const deleteAllReadMutation = useMutation({
    mutationFn: async () => {
      const readNotifications = notifications.filter(n => n.status === "Read");
      await Promise.all(
        readNotifications.map(n => base44.entities.Notification.delete(n.id))
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', user?.active_ranch_id] }); // Invalidate with active_ranch_id for specific caching
    },
  });

  const filteredNotifications = notifications.filter(notification => {
    const matchesSearch = notification.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         notification.message.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === "all" || notification.type === filterType;
    const matchesStatus = filterStatus === "all" || notification.status === filterStatus;
    // ranch_id filtering is handled at the query level, not here in local filter.
    return matchesSearch && matchesType && matchesStatus;
  });

  const unreadCount = notifications.filter(n => n.status === "Unread").length;
  const readCount = notifications.filter(n => n.status === "Read").length;
  const taskNotifications = notifications.filter(n => n.type === "Task").length;
  const healthNotifications = notifications.filter(n => n.type === "Health").length;

  return (
    <div className="p-6 md:p-8 bg-gradient-to-br from-gray-50 to-emerald-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Notification Center</h1>
            <p className="text-gray-600">Manage all your ranch notifications in one place</p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => deleteAllReadMutation.mutate()}
              disabled={readCount === 0}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Clear Read
            </Button>
            <Button
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={unreadCount === 0}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Check className="w-4 h-4 mr-2" />
              Mark All Read
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total"
            value={notifications.length}
            icon={Bell}
            bgColor="bg-gray-500"
            textColor="text-gray-600"
          />
          <StatsCard
            title="Unread"
            value={unreadCount}
            icon={Bell}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Task Notifications"
            value={taskNotifications}
            icon={CheckSquare}
            bgColor="bg-purple-500"
            textColor="text-purple-600"
          />
          <StatsCard
            title="Health Alerts"
            value={healthNotifications}
            icon={Heart}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
        </div>

        {/* Filters */}
        <Card className="mb-6 border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search notifications..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Task">Task</SelectItem>
                  <SelectItem value="Health">Health</SelectItem>
                  <SelectItem value="Breeding">Breeding</SelectItem>
                  <SelectItem value="Financial">Financial</SelectItem>
                  <SelectItem value="System">System</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Unread">Unread</SelectItem>
                  <SelectItem value="Read">Read</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Notifications List */}
        <div className="space-y-3">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map(notification => {
              const Icon = typeIcons[notification.type];
              return (
                <Card
                  key={notification.id}
                  className={`border-l-4 ${priorityColors[notification.priority]} ${
                    notification.status === "Unread" ? "bg-blue-50 shadow-md" : "shadow-lg"
                  } border-none hover:shadow-xl transition-shadow`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-xl ${typeColors[notification.type]}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-bold text-lg text-gray-900">{notification.title}</h3>
                              {notification.status === "Unread" && (
                                <Badge className="bg-blue-500 text-white">New</Badge>
                              )}
                            </div>
                            <p className="text-gray-600">{notification.message}</p>
                          </div>
                          <div className="flex gap-2">
                            {notification.status === "Unread" && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => markAsReadMutation.mutate(notification.id)}
                              >
                                <Check className="w-4 h-4 mr-2" />
                                Mark Read
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                              onClick={() => deleteNotificationMutation.mutate(notification.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 flex-wrap">
                          <Badge variant="outline" className={`${typeColors[notification.type]}`}>
                            {notification.type}
                          </Badge>
                          {notification.priority && (
                            <Badge variant="outline">
                              Priority: {notification.priority}
                            </Badge>
                          )}
                          {notification.related_record_name && (
                            <span className="text-sm text-gray-600">
                              Related to: <span className="font-semibold">{notification.related_record_name}</span>
                            </span>
                          )}
                          <span className="text-sm text-gray-400">
                            {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                          </span>
                        </div>
                        {notification.action_url && (
                          <Button variant="link" size="sm" className="px-0 mt-3" asChild>
                            <Link 
                              to={notification.action_url}
                              onClick={() => {
                                if (notification.status === "Unread") {
                                  markAsReadMutation.mutate(notification.id);
                                }
                              }}
                            >
                              View Details
                              <ExternalLink className="w-4 h-4 ml-2" />
                            </Link>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <Bell className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Notifications Found</h3>
                <p className="text-gray-500">
                  {searchQuery || filterType !== "all" || filterStatus !== "all"
                    ? "Try adjusting your search or filters"
                    : "You're all caught up! No notifications to display."}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
