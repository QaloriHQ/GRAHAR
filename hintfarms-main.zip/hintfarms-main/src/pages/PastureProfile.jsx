import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapPin, Calendar, Droplets, AlertCircle, ArrowLeft, Save, Trash2, Palette, Plus, FileText, CheckSquare, History, Edit2, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { toast } from "sonner";
import MapboxPastureMap from "../components/pastures/MapboxPastureMap";
import MapboxAddressInput from "../components/pastures/MapboxAddressInput";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { format } from "date-fns";

export default function PastureProfile() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const pastureId = urlParams.get('id');

  const [isEditing, setIsEditing] = useState(false);
  const [addressSearchValue, setAddressSearchValue] = useState("");
  const [mapboxToken, setMapboxToken] = useState(null);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [editingNote, setEditingNote] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [newNote, setNewNote] = useState({ note_text: "" });
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    due_date: "",
    priority: "Medium",
    assigned_to: ""
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: pasture, isLoading } = useQuery({
    queryKey: ['pasture', pastureId],
    queryFn: () => base44.entities.Pasture.filter({ id: pastureId }).then(r => r[0]),
    enabled: !!pastureId,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id, pasture_id: pastureId }),
    initialData: [],
    enabled: !!user?.active_ranch_id && !!pastureId,
  });

  const { data: notes = [] } = useQuery({
    queryKey: ['pasture-notes', pastureId],
    queryFn: async () => {
      // Notes don't have pasture_id field, so we'll store in note_text or use a workaround
      const allNotes = await base44.entities.Note.filter({ ranch_id: user.active_ranch_id });
      // Filter notes that mention this pasture in the note text or we can add a custom field
      return allNotes.filter(n => n.animal_id === pastureId || n.note_text?.includes(`[pasture:${pastureId}]`));
    },
    initialData: [],
    enabled: !!user?.active_ranch_id && !!pastureId,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['pasture-tasks', pastureId],
    queryFn: () => base44.entities.Task.filter({ ranch_id: user.active_ranch_id, related_pasture_id: pastureId }),
    initialData: [],
    enabled: !!user?.active_ranch_id && !!pastureId,
  });

  const { data: pastureHistory = [] } = useQuery({
    queryKey: ['pasture-history', pastureId],
    queryFn: () => base44.entities.PastureHistory.filter({ ranch_id: user.active_ranch_id, pasture_id: pastureId }, '-moved_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id && !!pastureId,
  });

  const { data: ranchMembers = [] } = useQuery({
    queryKey: ['ranch-members', user?.active_ranch_id],
    queryFn: () => base44.entities.RanchMember.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [editedPasture, setEditedPasture] = useState(null);

  useEffect(() => {
    if (pasture) {
      setEditedPasture({
        ...pasture,
        last_rotation_date: pasture.last_rotation_date ? new Date(pasture.last_rotation_date).toISOString().split('T')[0] : "",
        next_rotation_date: pasture.next_rotation_date ? new Date(pasture.next_rotation_date).toISOString().split('T')[0] : "",
      });
    }
  }, [pasture]);

  useEffect(() => {
    const fetchMapboxToken = async () => {
      try {
        const response = await base44.functions.invoke('getMapboxToken', {});
        if (response.data && response.data.token) {
          setMapboxToken(response.data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    
    if (user) {
      fetchMapboxToken();
    }
  }, [user]);

  const updatePastureMutation = useMutation({
    mutationFn: (data) => base44.entities.Pasture.update(pastureId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture', pastureId] });
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      setIsEditing(false);
      toast.success('Pasture updated successfully');
    },
  });

  const deletePastureMutation = useMutation({
    mutationFn: () => base44.entities.Pasture.delete(pastureId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      toast.success('Pasture deleted successfully');
      navigate(createPageUrl('Pastures'));
    },
  });

  const createNoteMutation = useMutation({
    mutationFn: (data) => base44.entities.Note.create({
      ...data,
      ranch_id: user.active_ranch_id,
      animal_id: pastureId, // Using animal_id field to store pasture reference
      animal_name: pasture.name,
      created_by_name: user.full_name,
      note_text: `[pasture:${pastureId}] ${data.note_text}` // Tag to identify pasture notes
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-notes'] });
      setShowNoteDialog(false);
      setNewNote({ note_text: "" });
      toast.success('Note added successfully');
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Note.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-notes'] });
      setShowNoteDialog(false);
      setEditingNote(null);
      toast.success('Note updated successfully');
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: (id) => base44.entities.Note.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-notes'] });
      toast.success('Note deleted successfully');
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: (data) => base44.entities.Task.create({
      ...data,
      ranch_id: user.active_ranch_id,
      related_pasture_id: pastureId,
      related_pasture_name: pasture.name,
      list_id: null, // No list for pasture tasks
      status: "Pending"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-tasks'] });
      setShowTaskDialog(false);
      setNewTask({ title: "", description: "", due_date: "", priority: "Medium", assigned_to: "" });
      toast.success('Task created successfully');
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Task.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-tasks'] });
      setShowTaskDialog(false);
      setEditingTask(null);
      toast.success('Task updated successfully');
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (id) => base44.entities.Task.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pasture-tasks'] });
      toast.success('Task deleted successfully');
    },
  });

  const handleSave = () => {
    updatePastureMutation.mutate(editedPasture);
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this pasture?')) {
      deletePastureMutation.mutate();
    }
  };

  const handleAddressSelect = (addressComponents) => {
    setEditedPasture(prev => ({
      ...prev,
      ...addressComponents,
      geocode_status: 'success',
      geocode_source: 'mapbox',
      geocode_updated_at: new Date().toISOString()
    }));
    toast.success('Address selected and coordinates set');
  };

  const handleMarkerDragEnd = async (pastureId, newLat, newLng) => {
    try {
      await base44.entities.Pasture.update(pastureId, {
        lat: newLat,
        lon: newLng,
        geocode_status: 'manual',
        geocode_source: 'manual',
        geocode_updated_at: new Date().toISOString()
      });
      queryClient.invalidateQueries({ queryKey: ['pasture', pastureId] });
      toast.success('Pasture location updated');
    } catch (error) {
      console.error('Error updating location:', error);
      toast.error('Failed to update location');
    }
  };

  const handleFenceUpdate = async (pastureId, coordinates) => {
    try {
      await base44.entities.Pasture.update(pastureId, {
        fence_coordinates: coordinates
      });
      queryClient.invalidateQueries({ queryKey: ['pasture', pastureId] });
      toast.success(coordinates ? 'Fence boundary saved' : 'Fence removed');
    } catch (error) {
      console.error('Error updating fence:', error);
      toast.error('Failed to update fence boundary');
    }
  };

  // Calculate area of polygon in square feet
  const calculateFenceArea = (coordinates) => {
    if (!coordinates || coordinates.length < 3) return 0;
    
    const toMeters = (coords) => {
      const avgLat = coords.reduce((sum, c) => sum + c[1], 0) / coords.length;
      const latToMeters = 111320;
      const lonToMeters = latToMeters * Math.cos(avgLat * Math.PI / 180);
      return coords.map(c => [c[0] * lonToMeters, c[1] * latToMeters]);
    };
    
    const metersCoords = toMeters(coordinates);
    let area = 0;
    for (let i = 0; i < metersCoords.length; i++) {
      const j = (i + 1) % metersCoords.length;
      area += metersCoords[i][0] * metersCoords[j][1];
      area -= metersCoords[j][0] * metersCoords[i][1];
    }
    area = Math.abs(area) / 2;
    return Math.round(area * 10.7639); // Convert to sqft
  };

  if (isLoading || !editedPasture) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-600 dark:text-gray-400">Loading pasture details...</p>
      </div>
    );
  }

  const typeColors = {
    "Grazing": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Hay": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Breeding": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300",
    "Isolation": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  const conditionColors = {
    "Good": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Fair": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Poor": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  const fenceColorOptions = [
    { value: "#10b981", label: "Green" },
    { value: "#3b82f6", label: "Blue" },
    { value: "#f59e0b", label: "Orange" },
    { value: "#ef4444", label: "Red" },
    { value: "#8b5cf6", label: "Purple" },
    { value: "#ec4899", label: "Pink" },
    { value: "#14b8a6", label: "Teal" },
    { value: "#f97316", label: "Coral" },
  ];

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl('Pastures'))}
              className="dark:border-gray-700"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100">
                {editedPasture.name}
              </h1>
              <div className="flex gap-2 mt-2">
                <Badge className={`${typeColors[editedPasture.type]} border`}>
                  {editedPasture.type}
                </Badge>
                <Badge className={`${conditionColors[editedPasture.condition]} border`}>
                  {editedPasture.condition}
                </Badge>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            {isEditing ? (
              <>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave} className="bg-[#F5A623] hover:bg-[#E09612]">
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={handleDelete} className="text-red-600 hover:text-red-700">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
                <Button onClick={() => setIsEditing(true)} className="bg-[#F5A623] hover:bg-[#E09612]">
                  Edit Pasture
                </Button>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Pasture Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Pasture Name</Label>
                    <Input
                      value={editedPasture.name}
                      onChange={(e) => setEditedPasture({...editedPasture, name: e.target.value})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Acreage</Label>
                    <Input
                      type="number"
                      value={editedPasture.size_acres}
                      onChange={(e) => setEditedPasture({...editedPasture, size_acres: parseFloat(e.target.value)})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Type</Label>
                    <Select
                      value={editedPasture.type}
                      onValueChange={(value) => setEditedPasture({...editedPasture, type: value})}
                      disabled={!isEditing}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="Grazing">Grazing</SelectItem>
                        <SelectItem value="Hay">Hay</SelectItem>
                        <SelectItem value="Breeding">Breeding</SelectItem>
                        <SelectItem value="Isolation">Isolation</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Overall Condition</Label>
                    <Select
                      value={editedPasture.condition}
                      onValueChange={(value) => setEditedPasture({...editedPasture, condition: value})}
                      disabled={!isEditing}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="Good">Good</SelectItem>
                        <SelectItem value="Fair">Fair</SelectItem>
                        <SelectItem value="Poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Capacity (Animals)</Label>
                    <Input
                      type="number"
                      value={editedPasture.capacity}
                      onChange={(e) => setEditedPasture({...editedPasture, capacity: parseInt(e.target.value)})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Current Animals</Label>
                    <Input
                      type="number"
                      value={editedPasture.current_animal_count}
                      onChange={(e) => setEditedPasture({...editedPasture, current_animal_count: parseInt(e.target.value)})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200 flex items-center gap-2">
                      <Palette className="w-4 h-4" />
                      Fence Color
                    </Label>
                    <Select
                      value={editedPasture.fence_color || "#10b981"}
                      onValueChange={(value) => setEditedPasture({...editedPasture, fence_color: value})}
                      disabled={!isEditing}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-4 h-4 rounded border border-gray-300" 
                            style={{backgroundColor: editedPasture.fence_color || "#10b981"}}
                          />
                          <span>{fenceColorOptions.find(c => c.value === (editedPasture.fence_color || "#10b981"))?.label}</span>
                        </div>
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        {fenceColorOptions.map(color => (
                          <SelectItem key={color.value} value={color.value}>
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-4 h-4 rounded border border-gray-300" 
                                style={{backgroundColor: color.value}}
                              />
                              <span>{color.label}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {isEditing && (
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200 font-semibold">Address Search</Label>
                    <MapboxAddressInput
                      value={addressSearchValue}
                      onChange={setAddressSearchValue}
                      onSelect={handleAddressSelect}
                      placeholder="Search for pasture address..."
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      mapboxToken={mapboxToken}
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Street Address</Label>
                  <Input
                    value={editedPasture.address_line1}
                    onChange={(e) => setEditedPasture({...editedPasture, address_line1: e.target.value})}
                    disabled={!isEditing}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">City</Label>
                    <Input
                      value={editedPasture.city}
                      onChange={(e) => setEditedPasture({...editedPasture, city: e.target.value})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">State</Label>
                    <Input
                      value={editedPasture.state}
                      onChange={(e) => setEditedPasture({...editedPasture, state: e.target.value})}
                      disabled={!isEditing}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Notes</Label>
                  <Textarea
                    value={editedPasture.notes}
                    onChange={(e) => setEditedPasture({...editedPasture, notes: e.target.value})}
                    disabled={!isEditing}
                    rows={4}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Map */}
            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Location & Boundaries</CardTitle>
              </CardHeader>
              <CardContent>
                <MapboxPastureMap
                  pastures={[editedPasture]}
                  onMarkerDragEnd={handleMarkerDragEnd}
                  onFenceUpdate={handleFenceUpdate}
                  mapboxToken={mapboxToken}
                />
              </CardContent>
            </Card>

            {/* Activity Tabs */}
            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Activity & Records</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="notes" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 dark:bg-gray-900">
                    <TabsTrigger value="notes">
                      <FileText className="w-4 h-4 mr-2" />
                      Notes ({notes.length})
                    </TabsTrigger>
                    <TabsTrigger value="tasks">
                      <CheckSquare className="w-4 h-4 mr-2" />
                      Tasks ({tasks.length})
                    </TabsTrigger>
                    <TabsTrigger value="history">
                      <History className="w-4 h-4 mr-2" />
                      History ({pastureHistory.length})
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="notes" className="space-y-4 mt-4">
                    <Button
                      onClick={() => {
                        setEditingNote(null);
                        setNewNote({ note_text: "" });
                        setShowNoteDialog(true);
                      }}
                      className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Note
                    </Button>
                    {notes.length > 0 ? (
                      <div className="space-y-3">
                        {notes.map(note => (
                          <div key={note.id} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <p className="font-semibold text-sm dark:text-gray-200">{note.created_by_name}</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                  {format(new Date(note.created_date), 'MMM dd, yyyy h:mm a')}
                                </p>
                              </div>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setEditingNote(note);
                                    setNewNote({ note_text: note.note_text.replace(`[pasture:${pastureId}] `, '') });
                                    setShowNoteDialog(true);
                                  }}
                                >
                                  <Edit2 className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-600"
                                  onClick={() => {
                                    if (confirm('Delete this note?')) {
                                      deleteNoteMutation.mutate(note.id);
                                    }
                                  }}
                                >
                                  <X className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-sm dark:text-gray-300">
                              {note.note_text.replace(`[pasture:${pastureId}] `, '')}
                            </p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-8">
                        No notes yet. Add your first note to track important information.
                      </p>
                    )}
                  </TabsContent>

                  <TabsContent value="tasks" className="space-y-4 mt-4">
                    <Button
                      onClick={() => {
                        setEditingTask(null);
                        setNewTask({ title: "", description: "", due_date: "", priority: "Medium", assigned_to: "" });
                        setShowTaskDialog(true);
                      }}
                      className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Task
                    </Button>
                    {tasks.length > 0 ? (
                      <div className="space-y-3">
                        {tasks.map(task => (
                          <div key={task.id} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1">
                                <p className="font-semibold dark:text-gray-200">{task.title}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{task.description}</p>
                                <div className="flex gap-2 mt-2 flex-wrap">
                                  <Badge variant="outline" className="text-xs">
                                    {task.status}
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {task.priority}
                                  </Badge>
                                  {task.due_date && (
                                    <Badge variant="outline" className="text-xs">
                                      Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}
                                    </Badge>
                                  )}
                                  {task.assigned_to_name && (
                                    <Badge variant="outline" className="text-xs">
                                      Assigned: {task.assigned_to_name}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <div className="flex gap-1 ml-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => {
                                    setEditingTask(task);
                                    setNewTask({
                                      title: task.title,
                                      description: task.description || "",
                                      due_date: task.due_date ? format(new Date(task.due_date), 'yyyy-MM-dd') : "",
                                      priority: task.priority,
                                      assigned_to: task.assigned_to || ""
                                    });
                                    setShowTaskDialog(true);
                                  }}
                                >
                                  <Edit2 className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-red-600"
                                  onClick={() => {
                                    if (confirm('Delete this task?')) {
                                      deleteTaskMutation.mutate(task.id);
                                    }
                                  }}
                                >
                                  <X className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-8">
                        No tasks yet. Add tasks to track work that needs to be done.
                      </p>
                    )}
                  </TabsContent>

                  <TabsContent value="history" className="space-y-4 mt-4">
                    {pastureHistory.length > 0 ? (
                      <div className="space-y-3">
                        {pastureHistory.map(history => (
                          <div key={history.id} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                            <div className="flex items-start justify-between">
                              <div>
                                <p className="font-semibold dark:text-gray-200">{history.animal_name}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                  Moved on {format(new Date(history.moved_date), 'MMM dd, yyyy')}
                                </p>
                                {history.moved_from && (
                                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                                    From: {history.moved_from}
                                  </p>
                                )}
                                {history.reason && (
                                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                    Reason: {history.reason}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-8">
                        No movement history yet. Animals moved to this pasture will appear here.
                      </p>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Utilization</p>
                  <p className="text-2xl font-bold dark:text-gray-100">
                    {editedPasture.capacity > 0 
                      ? `${((editedPasture.current_animal_count / editedPasture.capacity) * 100).toFixed(0)}%`
                      : 'N/A'}
                  </p>
                </div>
                {editedPasture.fence_coordinates && editedPasture.fence_coordinates.length > 2 && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Fenced Area</p>
                    <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {calculateFenceArea(editedPasture.fence_coordinates).toLocaleString()} sqft
                    </p>
                  </div>
                )}
                <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Grazing Quality</p>
                  <Badge className="border">{editedPasture.grazing_quality}</Badge>
                </div>
                <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Fence Condition</p>
                  <Badge className="border">{editedPasture.fence_condition}</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Animals in Pasture</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#F5A623] mb-4">{animals.length}</p>
                {animals.length > 0 ? (
                  <div className="space-y-2">
                    {animals.slice(0, 5).map(animal => (
                      <div key={animal.id} className="p-2 bg-gray-50 dark:bg-gray-900 rounded text-sm">
                        <p className="font-semibold dark:text-gray-100">{animal.name}</p>
                        <p className="text-gray-500 dark:text-gray-400 text-xs">Tag: {animal.tag_number}</p>
                      </div>
                    ))}
                    {animals.length > 5 && (
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        +{animals.length - 5} more animals
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">No animals currently in this pasture</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Note Dialog */}
        <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">
                {editingNote ? 'Edit Note' : 'Add Note'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Note</Label>
                <Textarea
                  value={newNote.note_text}
                  onChange={(e) => setNewNote({ ...newNote, note_text: e.target.value })}
                  placeholder="Enter your note..."
                  rows={4}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowNoteDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (editingNote) {
                    updateNoteMutation.mutate({
                      id: editingNote.id,
                      data: { note_text: `[pasture:${pastureId}] ${newNote.note_text}` }
                    });
                  } else {
                    createNoteMutation.mutate(newNote);
                  }
                }}
                className="bg-[#F5A623] hover:bg-[#E09612]"
                disabled={!newNote.note_text}
              >
                {editingNote ? 'Update Note' : 'Add Note'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Task Dialog */}
        <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">
                {editingTask ? 'Edit Task' : 'Add Task'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Title</Label>
                <Input
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  placeholder="Task title..."
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Description</Label>
                <Textarea
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  placeholder="Task description..."
                  rows={3}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Priority</Label>
                  <Select value={newTask.priority} onValueChange={(value) => setNewTask({ ...newTask, priority: value })}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Due Date</Label>
                  <Input
                    type="date"
                    value={newTask.due_date}
                    onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Assign To</Label>
                <Select value={newTask.assigned_to} onValueChange={(value) => setNewTask({ ...newTask, assigned_to: value })}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue placeholder="Select team member" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value={null}>Unassigned</SelectItem>
                    {ranchMembers.map(member => (
                      <SelectItem key={member.id} value={member.user_email}>
                        {member.user_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowTaskDialog(false)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  const taskData = {
                    ...newTask,
                    assigned_to_name: ranchMembers.find(m => m.user_email === newTask.assigned_to)?.user_name || ""
                  };
                  if (editingTask) {
                    updateTaskMutation.mutate({ id: editingTask.id, data: taskData });
                  } else {
                    createTaskMutation.mutate(taskData);
                  }
                }}
                className="bg-[#F5A623] hover:bg-[#E09612]"
                disabled={!newTask.title}
              >
                {editingTask ? 'Update Task' : 'Add Task'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}