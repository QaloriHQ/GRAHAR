import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import RanchInsightsAgent from "@/components/ai/RanchInsightsAgent";

export default function RanchInsights() {
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  if (!user?.active_ranch_id) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-600">Please select a ranch to use Ranch Assist</p>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gradient-to-br from-gray-50 to-orange-50/30">
      <RanchInsightsAgent ranchId={user.active_ranch_id} />
    </div>
  );
}