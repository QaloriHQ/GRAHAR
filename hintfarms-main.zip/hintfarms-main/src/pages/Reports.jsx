import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell,
  ComposedChart
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Beef,
  Heart,
  Download,
  Lock,
  Sparkles,
  AlertCircle,
  Calendar,
  Filter,
  FileText, // Added from outline
  Activity, // Added from outline
} from "lucide-react";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  format,
  subDays,
  startOfYear,
  endOfDay,
  startOfDay,
  differenceInDays,
  startOfMonth, // Added from outline
  endOfMonth,   // Added from outline
  subMonths,    // Added from outline
} from "date-fns";
import { trackReportExport } from "@/components/utils"; // Added from outline

export default function Reports() {
  const queryClient = useQueryClient();
  const [exporting, setExporting] = useState(false);
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    report_name: "",
    report_type: "Complete Financial",
    schedule: "Monthly",
    start_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    email_recipients: [],
    status: "Active"
  });

  // Filters
  const [dateRange, setDateRange] = useState("30");
  const [compareTo, setCompareTo] = useState("prev_period");
  const [animalTypeFilter, setAnimalTypeFilter] = useState("all");
  const [pastureFilter, setPastureFilter] = useState("all");
  const [healthStatusFilter, setHealthStatusFilter] = useState("all");
  const [customStartDate, setCustomStartDate] = useState("");
  const [customEndDate, setCustomEndDate] = useState("");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: () => user?.active_ranch_id ? base44.entities.Ranch.filter({ id: user.active_ranch_id }).then(r => r[0]) : null,
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.active_ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: revenue = [] } = useQuery({
    queryKey: ['revenue', user?.active_ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: healthRecords = [] } = useQuery({
    queryKey: ['healthRecords', user?.active_ranch_id],
    queryFn: () => base44.entities.HealthRecord.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: breedingRecords = [] } = useQuery({
    queryKey: ['breedingRecords', user?.active_ranch_id],
    queryFn: () => base44.entities.BreedingRecord.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: scheduledReports = [] } = useQuery({
    queryKey: ['financial-reports', user?.active_ranch_id],
    queryFn: () => base44.entities.FinancialReport.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const createScheduleMutation = useMutation({
    mutationFn: (data) => base44.entities.FinancialReport.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['financial-reports'] });
      setShowScheduleDialog(false);
      setNewSchedule({
        report_name: "",
        report_type: "Complete Financial",
        schedule: "Monthly",
        start_date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
        end_date: new Date().toISOString().split('T')[0],
        email_recipients: [],
        status: "Active"
      });
      toast.success('Report schedule created');
    },
  });

  const updateScheduleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.FinancialReport.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['financial-reports'] });
      toast.success('Schedule updated');
    },
  });

  const deleteScheduleMutation = useMutation({
    mutationFn: (id) => base44.entities.FinancialReport.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['financial-reports'] });
      toast.success('Schedule deleted');
    },
  });

  const toggleScheduleStatus = (schedule) => {
    updateScheduleMutation.mutate({
      id: schedule.id,
      data: { status: schedule.status === 'Active' ? 'Paused' : 'Active' }
    });
  };

  // Calculate date ranges with safety checks
  const { startDate, endDate, compareStartDate, compareEndDate } = useMemo(() => {
    const now = new Date();
    let start, end, compareStart, compareEnd;

    try {
      if (dateRange === "custom" && customStartDate && customEndDate) {
        start = startOfDay(new Date(customStartDate));
        end = endOfDay(new Date(customEndDate));

        // Validate dates
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
          // console.warn("Invalid custom date range provided, falling back to last 30 days.");
          start = startOfDay(subDays(now, 30));
          end = endOfDay(now);
        }
      } else if (dateRange === "ytd") {
        start = startOfYear(now);
        end = endOfDay(now);
      } else if (dateRange === "current_month") { // Added current_month filter
        start = startOfMonth(now);
        end = endOfDay(now);
      } else {
        const days = parseInt(dateRange) || 30; // Default to 30 if parsing fails
        start = startOfDay(subDays(now, days));
        end = endOfDay(now);
      }

      const daysDiff = differenceInDays(end, start);

      if (compareTo === "prev_period") {
        compareEnd = startOfDay(start);
        compareStart = startOfDay(subDays(compareEnd, daysDiff));
      } else if (compareTo === "prev_year") {
        compareStart = new Date(start);
        compareStart.setFullYear(compareStart.getFullYear() - 1);
        compareEnd = new Date(end);
        compareEnd.setFullYear(compareEnd.getFullYear() - 1);
      } else {
        compareStart = null;
        compareEnd = null;
      }

      return { startDate: start, endDate: end, compareStartDate: compareStart, compareEndDate: compareEnd };
    } catch (error) {
      console.error('Date range error:', error);
      // Fallback to last 30 days
      const fallbackStart = startOfDay(subDays(now, 30));
      const fallbackEnd = endOfDay(now);
      return {
        startDate: fallbackStart,
        endDate: fallbackEnd,
        compareStartDate: null,
        compareEndDate: null
      };
    }
  }, [dateRange, compareTo, customStartDate, customEndDate]);

  // Filter data with date validation
  const filteredAnimals = useMemo(() => {
    return animals.filter(a => {
      const typeMatch = animalTypeFilter === "all" || a.type === animalTypeFilter;
      const pastureMatch = pastureFilter === "all" || a.pasture_location === pastureFilter;
      const healthMatch = healthStatusFilter === "all" || a.health_status === healthStatusFilter;
      return typeMatch && pastureMatch && healthMatch;
    });
  }, [animals, animalTypeFilter, pastureFilter, healthStatusFilter]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      if (!e.date) return false;
      try {
        const date = new Date(e.date);
        if (isNaN(date.getTime())) return false; // Invalid date string
        return date >= startDate && date <= endDate;
      } catch (error) {
        // console.warn('Error parsing expense date:', e.date, error);
        return false; // Skip malformed date entries
      }
    });
  }, [expenses, startDate, endDate]);

  const filteredRevenue = useMemo(() => {
    return revenue.filter(r => {
      if (!r.date) return false;
      try {
        const date = new Date(r.date);
        if (isNaN(date.getTime())) return false; // Invalid date string
        return date >= startDate && date <= endDate;
      } catch (error) {
        // console.warn('Error parsing revenue date:', r.date, error);
        return false; // Skip malformed date entries
      }
    });
  }, [revenue, startDate, endDate]);

  // Comparison data with date validation
  const compareExpenses = useMemo(() => {
    if (!compareStartDate || !compareEndDate) return [];
    return expenses.filter(e => {
      if (!e.date) return false;
      try {
        const date = new Date(e.date);
        if (isNaN(date.getTime())) return false; // Invalid date string
        return date >= compareStartDate && date <= compareEndDate;
      } catch (error) {
        // console.warn('Error parsing comparison expense date:', e.date, error);
        return false; // Skip malformed date entries
      }
    });
  }, [expenses, compareStartDate, compareEndDate]);

  const compareRevenue = useMemo(() => {
    if (!compareStartDate || !compareEndDate) return [];
    return revenue.filter(r => {
      if (!r.date) return false;
      try {
        const date = new Date(r.date);
        if (isNaN(date.getTime())) return false; // Invalid date string
        return date >= compareStartDate && date <= compareEndDate;
      } catch (error) {
        // console.warn('Error parsing comparison revenue date:', r.date, error);
        return false; // Skip malformed date entries
      }
    });
  }, [revenue, compareStartDate, compareEndDate]);

  // Metrics
  const totalRevenue = filteredRevenue.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);
  const totalExpenses = filteredExpenses.reduce((sum, e) => sum + (parseFloat(e.amount) || 0), 0);
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(1) : 0;
  const totalValue = filteredAnimals.reduce((sum, a) => sum + (parseFloat(a.current_value) || 0), 0);
  const avgWeight = filteredAnimals.length > 0
    ? filteredAnimals.reduce((sum, a) => sum + (parseFloat(a.weight) || 0), 0) / filteredAnimals.length
    : 0;
  const healthAlerts = healthRecords.filter(h => h.status === "Overdue" || h.status === "Urgent").length;

  // Comparison metrics
  const compareRevTotal = compareRevenue.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);
  const compareExpTotal = compareExpenses.reduce((sum, e) => sum + (parseFloat(e.amount) || 0), 0);
  const compareNetProfit = compareRevTotal - compareExpTotal;

  // Deltas
  const revenueDelta = compareRevTotal > 0 ? (((totalRevenue - compareRevTotal) / compareRevTotal) * 100).toFixed(1) : null;
  const expenseDelta = compareExpTotal > 0 ? (((totalExpenses - compareExpTotal) / compareExpTotal) * 100).toFixed(1) : null;
  const profitDelta = compareNetProfit !== 0 ? (((netProfit - compareNetProfit) / Math.abs(compareNetProfit)) * 100).toFixed(1) : null;

  // TIME SERIES DATA - Revenue vs Expenses by Month
  const timeSeriesData = useMemo(() => {
    const monthlyData = {};

    // Process expenses
    filteredExpenses.forEach(exp => {
      try {
        if (!exp.date || exp.amount === undefined || exp.amount === null) return;
        const date = new Date(exp.date);
        if (isNaN(date.getTime())) return;
        const month = format(date, "MMM yyyy");
        if (!monthlyData[month]) {
          monthlyData[month] = { month, expenses: 0, revenue: 0, timestamp: date.getTime() };
        }
        monthlyData[month].expenses += parseFloat(exp.amount) || 0;
      } catch (error) {
        console.error('Error processing expense for time series:', exp, error);
      }
    });

    // Process revenue
    filteredRevenue.forEach(rev => {
      try {
        if (!rev.date || rev.amount === undefined || rev.amount === null) return;
        const date = new Date(rev.date);
        if (isNaN(date.getTime())) return;
        const month = format(date, "MMM yyyy");
        if (!monthlyData[month]) {
          monthlyData[month] = { month, expenses: 0, revenue: 0, timestamp: date.getTime() };
        }
        monthlyData[month].revenue += parseFloat(rev.amount) || 0;
      } catch (error) {
        console.error('Error processing revenue for time series:', rev, error);
      }
    });

    // Convert to sorted array
    return Object.values(monthlyData)
      .sort((a, b) => a.timestamp - b.timestamp)
      .map(({ month, expenses, revenue }) => ({ month, expenses, revenue }));
  }, [filteredExpenses, filteredRevenue]);

  // EXPENSE BREAKDOWN BY CATEGORY
  const expensesByCategory = useMemo(() => {
    const breakdown = filteredExpenses.reduce((acc, exp) => {
      const category = (exp.category || 'Other').trim();
      const amount = parseFloat(exp.amount) || 0;
      acc[category] = (acc[category] || 0) + amount;
      return acc;
    }, {});

    return Object.entries(breakdown)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10); // Top 10 categories
  }, [filteredExpenses]);

  const animalsByType = useMemo(() => {
    const distribution = filteredAnimals.reduce((acc, animal) => {
      if (!acc[animal.type]) {
        acc[animal.type] = { count: 0, value: 0 };
      }
      acc[animal.type].count += 1;
      acc[animal.type].value += parseFloat(animal.current_value) || 0;
      return acc;
    }, {});
    return Object.entries(distribution).map(([type, data]) => ({
      type,
      count: data.count,
      value: data.value
    }));
  }, [filteredAnimals]);

  const healthDistribution = useMemo(() => {
    const distribution = filteredAnimals.reduce((acc, animal) => {
      acc[animal.health_status] = (acc[animal.health_status] || 0) + 1;
      return acc;
    }, {});
    return Object.entries(distribution).map(([status, count]) => ({ status, count }));
  }, [filteredAnimals]);

  const breedingMetrics = useMemo(() => {
    const bred = breedingRecords.filter(r => r.status !== "Failed").length;
    const pregnant = breedingRecords.filter(r => r.status === "Pregnant" || r.status === "Calved").length;
    const calved = breedingRecords.filter(r => r.status === "Calved").length;

    const conceptionRate = bred > 0 ? ((pregnant / bred) * 100).toFixed(1) : 0;
    const calvingRate = pregnant > 0 ? ((calved / pregnant) * 100).toFixed(1) : 0;

    return { bred, pregnant, calved, conceptionRate, calvingRate };
  }, [breedingRecords]);

  const pastureUtilization = useMemo(() => {
    return pastures.map(pasture => {
      const animalCount = filteredAnimals.filter(a => a.pasture_location === pasture.name).length;
      const stockingRate = pasture.size_acres > 0 ? (animalCount / pasture.size_acres).toFixed(2) : 0;
      const overCapacity = pasture.capacity && animalCount > pasture.capacity;
      return {
        ...pasture,
        animalCount,
        stockingRate,
        overCapacity
      };
    });
  }, [pastures, filteredAnimals]);

  const handleExportData = async () => {
    setExporting(true);
    try {
      const response = await base44.functions.invoke('exportRanchData', {});

      if (response.data.error) {
        if (response.data.upgrade_required) {
          alert('Data export is only available for PRO and Enterprise plans.');
        } else {
          alert('Export failed: ' + response.data.error);
        }
        trackReportExport({ status: 'failed', error: response.data.error, ranchId: ranch?.id, plan: ranch?.subscription_plan });
        return;
      }

      const blob = new Blob([response.data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${ranch?.name?.replace(/[^a-z0-9]/gi, '_') || 'Ranch'}_Reports_${format(new Date(), 'yyyyMMdd')}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      trackReportExport({ status: 'success', ranchId: ranch?.id, plan: ranch?.subscription_plan });
    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export data.');
      trackReportExport({ status: 'failed', error: error.message, ranchId: ranch?.id, plan: ranch?.subscription_plan });
    } finally {
      setExporting(false);
    }
  };

  const canExport = ranch?.subscription_plan === 'Pro' || ranch?.subscription_plan === 'Enterprise' || ranch?.subscription_plan === 'Pro Trial';
  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316'];

  // Helper function to safely format dates
  const safeFormatDate = (date, formatString = "MMM d, yyyy") => {
    try {
      if (!date) return "N/A";
      const d = new Date(date);
      if (isNaN(d.getTime())) return "Invalid Date";
      return format(d, formatString);
    } catch (error) {
      // console.error("Error in safeFormatDate:", date, error);
      return "Invalid Date";
    }
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Reports & Analytics</h1>
            <p className="text-gray-600">Comprehensive insights into your ranch operations</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setShowScheduleDialog(true)} variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Schedule Report
            </Button>
            {canExport ? (
              <Button
                onClick={handleExportData}
                disabled={exporting}
                className="bg-[#F5A623] hover:bg-[#E09612] text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                {exporting ? 'Exporting...' : 'Export Data'}
              </Button>
            ) : (
              <div className="text-right">
                <Button disabled variant="outline">
                  <Lock className="w-4 h-4 mr-2" />
                  Export Data
                </Button>
                <p className="text-xs text-gray-500 mt-1">PRO plan required</p>
              </div>
            )}
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6 border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filters & Date Range
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div>
                <Label className="text-sm font-medium mb-2 block">Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 Days</SelectItem>
                    <SelectItem value="30">Last 30 Days</SelectItem>
                    <SelectItem value="90">Last 90 Days</SelectItem>
                    <SelectItem value="current_month">Current Month</SelectItem> {/* Added Current Month */}
                    <SelectItem value="ytd">Year to Date</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Compare To</Label>
                <Select value={compareTo} onValueChange={setCompareTo}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Comparison</SelectItem>
                    <SelectItem value="prev_period">Previous Period</SelectItem>
                    <SelectItem value="prev_year">Previous Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Animal Type</Label>
                <Select value={animalTypeFilter} onValueChange={setAnimalTypeFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Cattle">Cattle</SelectItem>
                    <SelectItem value="Calf">Calf</SelectItem>
                    <SelectItem value="Bull">Bull</SelectItem>
                    <SelectItem value="Heifer">Heifer</SelectItem>
                    <SelectItem value="Steer">Steer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Pasture</Label>
                <Select value={pastureFilter} onValueChange={setPastureFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Pastures</SelectItem>
                    {pastures.map(p => (
                      <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Health Status</Label>
                <Select value={healthStatusFilter} onValueChange={setHealthStatusFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="Healthy">Healthy</SelectItem>
                    <SelectItem value="Under Treatment">Under Treatment</SelectItem>
                    <SelectItem value="Urgent Attention">Urgent Attention</SelectItem>
                    <SelectItem value="Recovering">Recovering</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Actions</Label>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setDateRange("30");
                    setCompareTo("prev_period");
                    setAnimalTypeFilter("all");
                    setPastureFilter("all");
                    setHealthStatusFilter("all");
                    setCustomStartDate("");
                    setCustomEndDate("");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </div>

            {dateRange === "custom" && (
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <Label>Start Date</Label>
                  <Input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                  />
                </div>
                <div>
                  <Label>End Date</Label>
                  <Input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                  />
                </div>
              </div>
            )}

            <div className="mt-4 text-sm text-gray-600">
              <Calendar className="w-4 h-4 inline mr-2" />
              Showing data from {safeFormatDate(startDate)} to {safeFormatDate(endDate)}
              {compareTo !== "none" && compareStartDate && (
                <span className="ml-2">
                  • Comparing to {safeFormatDate(compareStartDate)} - {safeFormatDate(compareEndDate)}
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Beef className="w-6 h-6 text-[#F5A623]" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total Animals</p>
                  <p className="text-2xl font-bold">{filteredAnimals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total Value</p>
                  <p className="text-2xl font-bold">${totalValue.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Revenue</p>
                  <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
                  {revenueDelta && (
                    <div className="flex items-center gap-1">
                      {parseFloat(revenueDelta) >= 0 ? (
                        <TrendingUp className="w-3 h-3 text-green-600" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-600" />
                      )}
                      <span className={`text-xs ${parseFloat(revenueDelta) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {revenueDelta}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Expenses</p>
                  <p className="text-2xl font-bold">${totalExpenses.toLocaleString()}</p>
                  {expenseDelta && (
                    <div className="flex items-center gap-1">
                      {parseFloat(expenseDelta) >= 0 ? (
                        <TrendingUp className="w-3 h-3 text-red-600" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-green-600" />
                      )}
                      <span className={`text-xs ${parseFloat(expenseDelta) >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {expenseDelta}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 ${netProfit >= 0 ? 'bg-orange-100' : 'bg-red-100'} rounded-xl flex items-center justify-center`}>
                  {netProfit >= 0 ? (
                    <TrendingUp className="w-6 h-6 text-[#F5A623]" />
                  ) : (
                    <TrendingDown className="w-6 h-6 text-red-600" />
                  )}
                </div>
                <div>
                  <p className="text-sm text-gray-500">Net Profit</p>
                  <p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-[#F5A623]' : 'text-red-600'}`}>
                    ${netProfit.toLocaleString()}
                  </p>
                  {profitDelta && (
                    <div className="flex items-center gap-1">
                      {parseFloat(profitDelta) >= 0 ? (
                        <TrendingUp className="w-3 h-3 text-green-600" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-600" />
                      )}
                      <span className={`text-xs ${parseFloat(profitDelta) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {profitDelta}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Profit Margin</p>
                  <p className="text-2xl font-bold">{profitMargin}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Beef className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Avg Weight</p>
                  <p className="text-2xl font-bold">{avgWeight.toFixed(0)} lbs</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Health Alerts</p>
                  <p className="text-2xl font-bold">{healthAlerts}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue vs Expenses Time Series */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Revenue vs Expenses</CardTitle>
            </CardHeader>
            <CardContent>
              {timeSeriesData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={timeSeriesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value) => `$${value.toLocaleString()}`}
                      contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                    />
                    <Legend />
                    <Bar dataKey="revenue" fill="#10b981" name="Revenue" />
                    <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
                    <Line
                      type="monotone"
                      dataKey="revenue"
                      stroke="#059669"
                      strokeWidth={2}
                      name="Revenue Trend"
                      dot={false}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="text-center">
                    <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No transactions in selected range</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        setDateRange("ytd");
                        setAnimalTypeFilter("all");
                        setPastureFilter("all");
                        setHealthStatusFilter("all");
                        setCustomStartDate("");
                        setCustomEndDate("");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Expense Breakdown */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Expense Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              {expensesByCategory.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={expensesByCategory}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: $${value.toLocaleString()}`} // Use object destructuring
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {expensesByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value) => `$${value.toLocaleString()}`}
                      contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <div className="text-center">
                    <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No expenses in selected range</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        setDateRange("ytd");
                        setAnimalTypeFilter("all");
                        setPastureFilter("all");
                        setHealthStatusFilter("all");
                        setCustomStartDate("");
                        setCustomEndDate("");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Animals by Type */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Animals by Type</CardTitle>
            </CardHeader>
            <CardContent>
              {animalsByType.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={animalsByType}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="type" />
                    <YAxis />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                    />
                    <Legend />
                    <Bar dataKey="count" fill="#10b981" name="Count" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No animals found with current filters</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        setDateRange("30");
                        setAnimalTypeFilter("all");
                        setPastureFilter("all");
                        setHealthStatusFilter("all");
                        setCustomStartDate("");
                        setCustomEndDate("");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Health Status */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Health Status</CardTitle>
            </CardHeader>
            <CardContent>
              {healthDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={healthDistribution}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="status" />
                    <YAxis />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                    />
                    <Bar dataKey="count" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500">No health data available for selected animals</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        setDateRange("30");
                        setAnimalTypeFilter("all");
                        setPastureFilter("all");
                        setHealthStatusFilter("all");
                        setCustomStartDate("");
                        setCustomEndDate("");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Breeding */}
        <Card className="mb-6 border-none shadow-lg">
          <CardHeader>
            <CardTitle>Breeding Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6">
              <div>
                <p className="text-sm text-gray-500 mb-2">Total Bred</p>
                <p className="text-3xl font-bold">{breedingMetrics.bred}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-2">Pregnant</p>
                <p className="text-3xl font-bold text-pink-600">{breedingMetrics.pregnant}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-2">Conception Rate</p>
                <p className="text-3xl font-bold text-green-600">{breedingMetrics.conceptionRate}%</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-2">Calving Rate</p>
                <p className="text-3xl font-bold text-blue-600">{breedingMetrics.calvingRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pastures */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Pasture Utilization</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {pastureUtilization.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pasture</TableHead>
                    <TableHead>Size (Acres)</TableHead>
                    <TableHead>Animals</TableHead>
                    <TableHead>Capacity</TableHead>
                    <TableHead>Stocking Rate</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pastureUtilization.map(p => (
                    <TableRow key={p.id}>
                      <TableCell className="font-semibold">{p.name}</TableCell>
                      <TableCell>{p.size_acres}</TableCell>
                      <TableCell>{p.animalCount}</TableCell>
                      <TableCell>{p.capacity || '-'}</TableCell>
                      <TableCell>{p.stockingRate}/acre</TableCell>
                      <TableCell>
                        {p.overCapacity ? (
                          <Badge className="bg-red-100 text-red-800">Over</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800">Normal</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No pastures configured for this ranch or matching filters.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Financial Reports Section */}
        <Card className="mt-8 border-none shadow-lg">
          <CardHeader>
            <CardTitle>Financial Reports</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="pl">P&L</TabsTrigger>
                <TabsTrigger value="expenses">Expenses</TabsTrigger>
                <TabsTrigger value="revenue">Revenue</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <PLStatement expenses={filteredExpenses} revenues={filteredRevenue} startDate={startDate} endDate={endDate} />
                  <ExpenseBreakdown expenses={filteredExpenses} />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <RevenueBreakdown revenues={filteredRevenue} />
                  <LivestockValueTrends livestock={filteredAnimals} startDate={startDate} endDate={endDate} />
                </div>
              </TabsContent>

              <TabsContent value="pl">
                <PLStatement expenses={filteredExpenses} revenues={filteredRevenue} startDate={startDate} endDate={endDate} />
              </TabsContent>

              <TabsContent value="expenses">
                <ExpenseBreakdown expenses={filteredExpenses} />
              </TabsContent>

              <TabsContent value="revenue">
                <RevenueBreakdown revenues={filteredRevenue} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Scheduled Reports */}
        <Card className="mt-8 border-none shadow-lg">
          <CardHeader>
            <CardTitle>Scheduled Reports</CardTitle>
          </CardHeader>
          <CardContent>
            {scheduledReports.length > 0 ? (
              <div className="space-y-3">
                {scheduledReports.map((schedule) => (
                  <div key={schedule.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="w-5 h-5 text-[#F5A623]" />
                        <h4 className="font-semibold dark:text-gray-100">{schedule.report_name}</h4>
                        <Badge className={schedule.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                          {schedule.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                        <p>Type: {schedule.report_type}</p>
                        <p>Schedule: {schedule.schedule}</p>
                        <p>Period: {new Date(schedule.start_date).toLocaleDateString()} - {new Date(schedule.end_date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => toggleScheduleStatus(schedule)}
                      >
                        {schedule.status === 'Active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          if (confirm('Delete this schedule?')) {
                            deleteScheduleMutation.mutate(schedule.id);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 dark:text-gray-400 py-8">
                No scheduled reports. Click "Schedule Report" to create one.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Schedule Dialog */}
        <Dialog open={showScheduleDialog} onOpenChange={setShowScheduleDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Schedule Report</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-200">Report Name</Label>
                <Input
                  value={newSchedule.report_name}
                  onChange={(e) => setNewSchedule({ ...newSchedule, report_name: e.target.value })}
                  placeholder="e.g., Monthly Financial Summary"
                  className="dark:bg-gray-900 dark:border-gray-700"
                />
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Report Type</Label>
                <Select value={newSchedule.report_type} onValueChange={(value) => setNewSchedule({ ...newSchedule, report_type: value })}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="P&L Statement">P&L Statement</SelectItem>
                    <SelectItem value="Expense Breakdown">Expense Breakdown</SelectItem>
                    <SelectItem value="Revenue Analysis">Revenue Analysis</SelectItem>
                    <SelectItem value="Livestock Value">Livestock Value</SelectItem>
                    <SelectItem value="Complete Financial">Complete Financial</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="dark:text-gray-200">Schedule</Label>
                <Select value={newSchedule.schedule} onValueChange={(value) => setNewSchedule({ ...newSchedule, schedule: value })}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Weekly">Weekly</SelectItem>
                    <SelectItem value="Monthly">Monthly</SelectItem>
                    <SelectItem value="Quarterly">Quarterly</SelectItem>
                    <SelectItem value="Annually">Annually</SelectItem>
                    <SelectItem value="One-time">One-time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Start Date</Label>
                  <Input
                    type="date"
                    value={newSchedule.start_date}
                    onChange={(e) => setNewSchedule({ ...newSchedule, start_date: e.target.value })}
                    className="dark:bg-gray-900 dark:border-gray-700"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">End Date</Label>
                  <Input
                    type="date"
                    value={newSchedule.end_date}
                    onChange={(e) => setNewSchedule({ ...newSchedule, end_date: e.target.value })}
                    className="dark:bg-gray-900 dark:border-gray-700"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowScheduleDialog(false)} className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={() => createScheduleMutation.mutate(newSchedule)}
                className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                disabled={!newSchedule.report_name}
              >
                Create Schedule
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}