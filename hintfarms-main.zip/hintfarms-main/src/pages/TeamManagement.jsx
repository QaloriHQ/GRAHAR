
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Users,
  UserPlus,
  Mail,
  Shield,
  Trash2,
  Crown,
  Lock,
  Sparkles,
  AlertCircle,
  MoreVertical,
  Send
} from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/components/ui/use-toast";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

export default function TeamManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("Worker");

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: () => user?.active_ranch_id ? base44.entities.Ranch.filter({ id: user.active_ranch_id }).then(r => r[0]) : null,
    enabled: !!user?.active_ranch_id,
  });

  const { data: members = [] } = useQuery({
    queryKey: ['ranchMembers', user?.active_ranch_id],
    queryFn: () => base44.entities.RanchMember.filter({ ranch_id: user.active_ranch_id }, '-joined_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const inviteMemberMutation = useMutation({
    mutationFn: async (data) => {
      // Generate unique invite token
      const inviteToken = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;

      // Set expiration to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      // Create invite record
      const invite = await base44.entities.RanchInvite.create({
        ranch_id: user.active_ranch_id,
        ranch_name: ranch.name,
        invited_email: data.user_email,
        invited_name: data.user_email.split('@')[0],
        role: data.role,
        invited_by_email: user.email,
        invited_by_name: user.full_name || user.email,
        invite_token: inviteToken,
        status: 'Pending',
        expires_at: expiresAt.toISOString()
      });

      // Create pending ranch member
      const member = await base44.entities.RanchMember.create({
        ranch_id: user.active_ranch_id,
        user_email: data.user_email,
        user_name: data.user_email.split('@')[0],
        role: data.role,
        invited_by: user.email,
        joined_date: new Date().toISOString().split('T')[0],
        status: "Pending"
      });

      // Determine the app URL - always use production URL for invite emails
      const currentOrigin = window.location.origin;
      let appUrl;
      
      // Use app.hintfarms.com as the canonical production URL
      // If we're on the production domain or deno.dev, use the canonical URL
      if (currentOrigin.includes('hintfarms.com') || currentOrigin.includes('deno.dev')) {
        appUrl = 'https://app.hintfarms.com';
      } else if (currentOrigin.includes('modal.host')) {
        // For preview/development environments on modal.host, use current origin
        appUrl = currentOrigin;
      } else {
        // Fallback for local development
        appUrl = currentOrigin;
      }

      const inviteAcceptUrl = `${appUrl}/AcceptInvite?token=${inviteToken}`;

      // Send invitation email with HTML template
      try {
        await base44.integrations.Core.SendEmail({
          to: data.user_email,
          subject: `You've been invited to join ${ranch.name} on HintFarms`,
          body: `<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f9fafb; margin: 0; padding: 40px 0;">
    <table align="center" width="600" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 12px; padding: 48px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
      <tr>
        <td align="center" style="padding-bottom: 32px;">
          <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 16px; display: inline-flex; align-items: center; justify-content: center;">
            <span style="font-size: 32px; color: #ffffff;">🐄</span>
          </div>
        </td>
      </tr>
      <tr>
        <td style="color: #111827; font-size: 24px; font-weight: 600; text-align: center; padding-bottom: 16px;">
          You've been invited to join a Ranch on HintFarms
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #374151; font-size: 16px; line-height: 1.6; text-align: center;">
          Hello! You've been invited to join <strong style="color: #10b981;">${ranch.name}</strong> as a <strong>${data.role}</strong> on HintFarms.
          <br><br>
          Click the button below to accept your invitation and start managing ranch operations together.
        </td>
      </tr>
      <tr>
        <td align="center" style="padding: 32px 0;">
          <a href="${inviteAcceptUrl}"
             style="background-color: #10b981; color: #ffffff; text-decoration: none; font-weight: 600; padding: 16px 32px; border-radius: 8px; display: inline-block; font-size: 16px;">
            Accept Invitation
          </a>
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #6b7280; font-size: 14px; line-height: 1.6; text-align: center; background: #f9fafb; border-radius: 8px; padding: 20px;">
          If you don't have an account yet, sign up using this email (<strong>${data.user_email}</strong>),
          and your invitation will automatically link once you log in.
        </td>
      </tr>
      <tr>
        <td style="padding: 16px 0; color: #9ca3af; font-size: 13px; text-align: center;">
          Or copy this link:<br>
          <a href="${inviteAcceptUrl}" style="color: #10b981; word-break: break-all;">${inviteAcceptUrl}</a>
          <br><br>
          Invite Code: <strong style="font-family: monospace;">${inviteToken}</strong>
        </td>
      </tr>
      <tr>
        <td style="padding-top: 32px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 13px; color: #9ca3af;">
          This invitation will expire in 7 days.<br><br>
          Best regards,<br />
          The HintFarms Team
        </td>
      </tr>
    </table>
  </body>
</html>`
        });
      } catch (error) {
        console.error("Failed to send invitation email:", error);
      }

      return member;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      setShowInviteDialog(false);
      setInviteEmail("");
      setInviteRole("Worker");
      toast({
        title: "Invitation Sent",
        description: "Team member has been invited successfully.",
      });
    },
  });

  const removeMemberMutation = useMutation({
    mutationFn: (id) => base44.entities.RanchMember.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      toast({
        title: "Member Removed",
        description: "Team member has been removed from your ranch.",
      });
    },
  });

  const updateMemberRoleMutation = useMutation({
    mutationFn: ({ id, role }) => base44.entities.RanchMember.update(id, { role }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      toast({
        title: "Role Updated",
        description: "Team member's role has been updated.",
      });
    },
  });

  const resendInviteMutation = useMutation({
    mutationFn: async (member) => {
      // Find the pending invite for this member
      const invites = await base44.entities.RanchInvite.filter({
        invited_email: member.user_email,
        ranch_id: member.ranch_id,
        status: 'Pending'
      }, '-created_at');
      const latestInvite = invites[0];

      if (!latestInvite) {
        throw new Error("No pending invite found to resend.");
      }

      // Determine the app URL - use production domain or current origin
      const currentOrigin = window.location.origin;
      let appUrl;
      
      // If we're on a modal.host domain (development), use the deno.dev domain instead
      if (currentOrigin.includes('modal.host')) {
        // This assumes your production URL follows the pattern: https://[app-name].deno.dev
        appUrl = 'https://rich-hare-40-atzatwdjd0zj.deno.dev';
      } else {
        // Use current origin if it's already a proper domain
        appUrl = currentOrigin;
      }

      const inviteAcceptUrl = `${appUrl}/AcceptInvite?token=${latestInvite.invite_token}`;

      await base44.integrations.Core.SendEmail({
        to: member.user_email,
        subject: `Reminder: You've been invited to join ${ranch.name} on HintFarms`,
        body: `<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body style="font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background-color: #f9fafb; margin: 0; padding: 40px 0;">
    <table align="center" width="600" cellpadding="0" cellspacing="0" style="background: #ffffff; border-radius: 12px; padding: 48px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
      <tr>
        <td align="center" style="padding-bottom: 32px;">
          <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 16px; display: inline-flex; align-items: center; justify-content: center;">
            <span style="font-size: 32px; color: #ffffff;">🐄</span>
          </div>
        </td>
      </tr>
      <tr>
        <td style="color: #111827; font-size: 24px; font-weight: 600; text-align: center; padding-bottom: 16px;">
          Reminder: You've been invited to join a Ranch on HintFarms
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #374151; font-size: 16px; line-height: 1.6; text-align: center;">
          Hello! This is a reminder that you've been invited to join <strong style="color: #10b981;">${ranch.name}</strong> as a <strong>${member.role}</strong> on HintFarms.
          <br><br>
          Click the button below to accept your invitation and start managing ranch operations together.
        </td>
      </tr>
      <tr>
        <td align="center" style="padding: 32px 0;">
          <a href="${inviteAcceptUrl}"
             style="background-color: #10b981; color: #ffffff; text-decoration: none; font-weight: 600; padding: 16px 32px; border-radius: 8px; display: inline-block; font-size: 16px;">
            Accept Invitation
          </a>
        </td>
      </tr>
      <tr>
        <td style="padding: 24px 0; color: #6b7280; font-size: 14px; line-height: 1.6; text-align: center; background: #f9fafb; border-radius: 8px; padding: 20px;">
          If you don't have an account yet, sign up using this email (<strong>${member.user_email}</strong>),
          and your invitation will automatically link once you log in.
        </td>
      </tr>
      <tr>
        <td style="padding: 16px 0; color: #9ca3af; font-size: 13px; text-align: center;">
          Or copy this link:<br>
          <a href="${inviteAcceptUrl}" style="color: #10b981; word-break: break-all;">${inviteAcceptUrl}</a>
        </td>
      </tr>
      <tr>
        <td style="padding-top: 32px; border-top: 1px solid #e5e7eb; text-align: center; font-size: 13px; color: #9ca3af;">
          This invitation will expire soon.<br><br>
          Best regards,<br />
          The HintFarms Team
        </td>
      </tr>
    </table>
  </body>
</html>`
      });
    },
    onSuccess: () => {
      toast({
        title: "Invitation Resent",
        description: "The invitation has been sent again.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error Resending Invitation",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleInvite = () => {
    if (!inviteEmail) {
      toast({
        title: "Error",
        description: "Please enter an email address.",
        variant: "destructive",
      });
      return;
    }

    // Check if email already exists in team as active or pending member
    const existingMember = members.find(m => m.user_email === inviteEmail && (m.status === "Active" || m.status === "Pending"));
    if (existingMember) {
      toast({
        title: "Error",
        description: "This user is already an active or pending member of your team.",
        variant: "destructive",
      });
      return;
    }

    inviteMemberMutation.mutate({
      user_email: inviteEmail,
      user_name: inviteEmail.split('@')[0],
      role: inviteRole
    });
  };

  const handleUpgradeClick = () => {
    // Trigger opening account management with billing tab
    const event = new CustomEvent('openAccountBilling');
    window.dispatchEvent(event);
  };

  const canManageTeam = ranch?.subscription_plan === "Pro" || ranch?.subscription_plan === "Enterprise";
  const canInviteOrRemove = user?.role_title === "Owner" || user?.role_title === "Manager";
  const activeMembers = members.filter(m => m.status === "Active").length;
  const pendingMembers = members.filter(m => m.status === "Pending").length;

  const roleColors = {
    "Owner": "bg-purple-100 text-purple-800 border-purple-200",
    "Manager": "bg-blue-100 text-blue-800 border-blue-200",
    "Worker": "bg-green-100 text-green-800 border-green-200",
    "Veterinarian": "bg-red-100 text-red-800 border-red-200",
    "Assistant": "bg-gray-100 text-gray-800 border-gray-200"
  };

  const statusColors = {
    "Active": "bg-green-100 text-green-800 border-green-200",
    "Pending": "bg-yellow-100 text-yellow-800 border-yellow-200",
    "Removed": "bg-red-100 text-red-800 border-red-200"
  };

  return (
    <div className="p-6 md:p-8 bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-gray-800 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Team Management</h1>
            <p className="text-gray-600 dark:text-gray-400">Manage your ranch team members and their roles</p>
          </div>
          {canManageTeam && canInviteOrRemove ? (
            <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
              <DialogTrigger asChild>
                <Button className="bg-emerald-600 hover:bg-emerald-700 shadow-lg">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Invite Team Member
                </Button>
              </DialogTrigger>
              <DialogContent className="dark:bg-gray-900 dark:border-gray-800">
                <DialogHeader>
                  <DialogTitle className="dark:text-gray-100">Invite Team Member</DialogTitle>
                  <DialogDescription className="dark:text-gray-400">
                    Send an invitation to add a new member to your ranch team
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Email Address</Label>
                    <Input
                      type="email"
                      placeholder="member@example.com"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Role</Label>
                    <Select value={inviteRole} onValueChange={setInviteRole}>
                      <SelectTrigger className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Manager">Manager</SelectItem>
                        <SelectItem value="Worker">Worker</SelectItem>
                        <SelectItem value="Veterinarian">Veterinarian</SelectItem>
                        <SelectItem value="Assistant">Assistant</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button
                  onClick={handleInvite}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                  disabled={inviteMemberMutation.isPending}
                >
                  <Mail className="w-4 h-4 mr-2" />
                  {inviteMemberMutation.isPending ? "Sending..." : "Send Invitation"}
                </Button>
              </DialogContent>
            </Dialog>
          ) : !canManageTeam ? (
            <Button disabled className="bg-gray-300 dark:bg-gray-700 cursor-not-allowed">
              <Lock className="w-4 h-4 mr-2" />
              Upgrade to Invite Members
            </Button>
          ) : (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Only Owners and Managers can invite members
            </div>
          )}
        </div>

        {/* Subscription Alert */}
        {!canManageTeam && (
          <Alert className="mb-6 border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
            <AlertCircle className="h-4 w-4 text-orange-600 dark:text-orange-400" />
            <AlertTitle className="text-orange-800 dark:text-orange-300">Upgrade Required</AlertTitle>
            <AlertDescription className="text-orange-700 dark:text-orange-400">
              Team management is available on Pro and Enterprise plans. Upgrade your subscription to invite and manage team members.
              <Button
                variant="link"
                className="px-0 ml-2 text-orange-600 dark:text-orange-400"
                onClick={handleUpgradeClick}
              >
                <Sparkles className="w-4 h-4 mr-1" />
                Upgrade Now
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Active Members</p>
                  <p className="text-2xl font-bold dark:text-gray-100">{activeMembers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900 rounded-xl flex items-center justify-center">
                  <Mail className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Pending Invites</p>
                  <p className="text-2xl font-bold dark:text-gray-100">{pendingMembers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Subscription Plan</p>
                  <p className="text-2xl font-bold dark:text-gray-100">{ranch?.subscription_plan || "Free"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Team Members Table */}
        <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Team Members</CardTitle>
            <CardDescription className="dark:text-gray-400">
              Manage roles and permissions for your ranch team
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-300">Name</TableHead>
                  <TableHead className="dark:text-gray-300">Email</TableHead>
                  <TableHead className="dark:text-gray-300">Role</TableHead>
                  <TableHead className="dark:text-gray-300">Status</TableHead>
                  <TableHead className="dark:text-gray-300">Joined</TableHead>
                  <TableHead className="dark:text-gray-300">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {members.map(member => (
                  <TableRow key={member.id} className="dark:border-gray-700">
                    <TableCell className="dark:text-gray-100">
                      <div className="flex items-center gap-2">
                        {member.role === "Owner" && <Crown className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />}
                        <span className="font-semibold">{member.user_name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">{member.user_email}</TableCell>
                    <TableCell>
                      {canManageTeam && canInviteOrRemove && member.role !== "Owner" ? (
                        <Select
                          value={member.role}
                          onValueChange={(value) => updateMemberRoleMutation.mutate({ id: member.id, role: value })}
                          disabled={updateMemberRoleMutation.isPending}
                        >
                          <SelectTrigger className="w-32 dark:bg-gray-700 dark:border-gray-600">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Manager">Manager</SelectItem>
                            <SelectItem value="Worker">Worker</SelectItem>
                            <SelectItem value="Veterinarian">Veterinarian</SelectItem>
                            <SelectItem value="Assistant">Assistant</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={`${roleColors[member.role]} border`}>
                          {member.role}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statusColors[member.status]} border text-xs`}>
                        {member.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">
                      {member.joined_date ? format(new Date(member.joined_date), "MMM d, yyyy") : "-"}
                    </TableCell>
                    <TableCell>
                      {canManageTeam && canInviteOrRemove && member.role !== "Owner" && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="dark:bg-gray-800 dark:border-gray-700">
                            {member.status === "Pending" && (
                              <DropdownMenuItem
                                onClick={() => resendInviteMutation.mutate(member)}
                                className="dark:text-gray-200 dark:hover:bg-gray-700"
                                disabled={resendInviteMutation.isPending}
                              >
                                <Send className="w-4 h-4 mr-2" />
                                {resendInviteMutation.isPending ? "Resending..." : "Resend Invitation"}
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem
                              onClick={() => removeMemberMutation.mutate(member.id)}
                              className="text-red-600 dark:text-red-400 dark:hover:bg-gray-700"
                              disabled={removeMemberMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Remove Member
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {members.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                      No team members yet. Start by inviting your first member!
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
