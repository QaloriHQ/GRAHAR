import { base44 } from './base44Client';


export const Animal = base44.entities.Animal;

export const HealthRecord = base44.entities.HealthRecord;

export const BreedingRecord = base44.entities.BreedingRecord;

export const Expense = base44.entities.Expense;

export const Revenue = base44.entities.Revenue;

export const Pasture = base44.entities.Pasture;

export const Alert = base44.entities.Alert;

export const List = base44.entities.List;

export const Task = base44.entities.Task;

export const Notification = base44.entities.Notification;

export const Ranch = base44.entities.Ranch;

export const RanchMember = base44.entities.RanchMember;

export const PastureHistory = base44.entities.PastureHistory;

export const DataExport = base44.entities.DataExport;

export const Scenario = base44.entities.Scenario;

export const BankConnection = base44.entities.BankConnection;

export const BankTransaction = base44.entities.BankTransaction;

export const ImportRule = base44.entities.ImportRule;

export const RanchInvite = base44.entities.RanchInvite;

export const RanchNotificationSettings = base44.entities.RanchNotificationSettings;

export const NotificationReceipt = base44.entities.NotificationReceipt;

export const RanchRolePermissions = base44.entities.RanchRolePermissions;

export const Note = base44.entities.Note;

export const Ticket = base44.entities.Ticket;

export const Announcement = base44.entities.Announcement;

export const Lead = base44.entities.Lead;

export const Contact = base44.entities.Contact;

export const Deal = base44.entities.Deal;

export const Inventory = base44.entities.Inventory;

export const Livestock = base44.entities.Livestock;

export const FinancialReport = base44.entities.FinancialReport;

export const BankSyncHistory = base44.entities.BankSyncHistory;

export const RanchAssistConversation = base44.entities.RanchAssistConversation;

export const MarketInsightsPrice = base44.entities.MarketInsightsPrice;

export const RanchLocalMarket = base44.entities.RanchLocalMarket;

export const MarketInsightsSource = base44.entities.MarketInsightsSource;



// auth sdk:
export const User = base44.auth;