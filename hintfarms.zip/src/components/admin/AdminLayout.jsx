import React, { useState, useEffect } from "react";
import { Shield, TrendingUp, BarChart3, Users, UserPlus, Briefcase, DollarSign, Ticket, Megaphone, MessageSquare, Activity, Zap, Database, LogOut, User, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function AdminLayout({ children, activeSection, onSectionChange }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Close mobile menu when section changes
  useEffect(() => {
    setMobileOpen(false);
  }, [activeSection]);

  // Close mobile menu on escape key
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, []);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const menuItems = [
    { id: "stats", label: "System Stats", icon: TrendingUp },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "accounts", label: "Accounts", icon: Users },
    { id: "leads", label: "Lead Management", icon: UserPlus },
    { id: "contacts", label: "Contacts", icon: Briefcase },
    { id: "deals", label: "Deal Pipeline", icon: DollarSign },
    { id: "tickets", label: "Support Tickets", icon: Ticket },
    { id: "announcements", label: "Announcements", icon: Megaphone },
    { id: "communications", label: "Communications", icon: MessageSquare },
    { id: "logs", label: "System Logs", icon: Activity },
    { id: "integrations", label: "Integrations", icon: Zap },
    { id: "bulk", label: "Bulk Operations", icon: Database },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Mobile Overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile Header */}
      <div className="fixed top-0 left-0 right-0 h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 lg:hidden z-30">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          <Menu className="w-6 h-6" />
        </Button>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-blue-500" />
          <span className="font-bold text-gray-900 dark:text-white">Admin Portal</span>
        </div>
        <div className="w-10" />
      </div>

      {/* Sidebar */}
      <aside className={cn(
        "fixed left-0 top-0 h-screen bg-[#1a1a1a] border-r border-gray-800 transition-all duration-300 z-50",
        // Mobile
        mobileOpen ? "block w-64" : "hidden",
        // Desktop
        "lg:block",
        collapsed ? "lg:w-16" : "lg:w-64"
      )}>
        {/* Header */}
        <div className="h-16 border-b border-gray-800 flex items-center justify-between px-4">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 text-blue-500" />
              <span className="font-bold text-white">Admin Portal</span>
            </div>
          )}
          {collapsed && (
            <Shield className="w-6 h-6 text-blue-500 mx-auto" />
          )}
          {/* Close button for mobile */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileOpen(false)}
            className="lg:hidden text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Menu Items */}
        <nav className="p-2 space-y-1 overflow-y-auto" style={{ height: 'calc(100vh - 12rem)' }}>
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onSectionChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-colors text-left touch-manipulation",
                  "active:scale-95",
                  isActive 
                    ? "bg-[#F5A623] text-white" 
                    : "text-gray-400 hover:bg-gray-800 hover:text-white"
                )}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="text-sm font-medium">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Footer with User Info and Logout */}
        <div className="absolute bottom-0 left-0 right-0 border-t border-gray-800 p-4 bg-[#1a1a1a]">
          {!collapsed ? (
            <>
              <div className="text-xs text-gray-400 mb-3">
                <p className="font-medium text-gray-200 truncate flex items-center gap-2">
                  <User className="w-3 h-3" />
                  {user?.full_name}
                </p>
                <p className="truncate">{user?.email}</p>
                <Badge className="mt-1 bg-blue-600">Admin</Badge>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="w-full border-gray-700 hover:bg-gray-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </>
          ) : (
            <Button
              onClick={handleLogout}
              variant="ghost"
              size="icon"
              className="w-full hover:bg-gray-800"
            >
              <LogOut className="w-5 h-5" />
            </Button>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 transition-all duration-300 w-full",
        // Desktop
        "lg:ml-64",
        collapsed && "lg:ml-16",
        // Mobile
        "pt-16 lg:pt-0"
      )}>
        <div className="p-4 md:p-6 max-w-full overflow-x-hidden">
          {children}
        </div>
      </main>
    </div>
  );
}