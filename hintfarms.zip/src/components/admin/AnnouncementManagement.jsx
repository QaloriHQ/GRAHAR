import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, Edit2, Trash2, Send } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function AnnouncementManagement() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState(null);
  const [newAnnouncement, setNewAnnouncement] = useState({
    title: "",
    message: "",
    type: "General",
    priority: "Normal",
    target_audience: "All",
    send_email: false,
    send_sms: false,
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ['admin-announcements'],
    queryFn: () => base44.entities.Announcement.list('-created_date'),
    initialData: [],
  });

  const createAnnouncementMutation = useMutation({
    mutationFn: (data) => base44.entities.Announcement.create({
      ...data,
      created_by: user.email,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
      setShowDialog(false);
      resetForm();
      toast.success('Announcement created');
    },
  });

  const updateAnnouncementMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Announcement.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
      setShowDialog(false);
      setEditingAnnouncement(null);
      toast.success('Announcement updated');
    },
  });

  const deleteAnnouncementMutation = useMutation({
    mutationFn: (id) => base44.entities.Announcement.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
      toast.success('Announcement deleted');
    },
  });

  const publishAnnouncementMutation = useMutation({
    mutationFn: (id) => base44.entities.Announcement.update(id, {
      published: true,
      published_at: new Date().toISOString()
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
      toast.success('Announcement published');
    },
  });

  const resetForm = () => {
    setNewAnnouncement({
      title: "",
      message: "",
      type: "General",
      priority: "Normal",
      target_audience: "All",
      send_email: false,
      send_sms: false,
    });
  };

  const handleEdit = (announcement) => {
    setEditingAnnouncement(announcement);
    setNewAnnouncement({
      title: announcement.title,
      message: announcement.message,
      type: announcement.type,
      priority: announcement.priority,
      target_audience: announcement.target_audience,
      send_email: announcement.send_email,
      send_sms: announcement.send_sms,
    });
    setShowDialog(true);
  };

  const typeColors = {
    'Feature': 'bg-blue-100 text-blue-800',
    'Maintenance': 'bg-yellow-100 text-yellow-800',
    'Update': 'bg-green-100 text-green-800',
    'Alert': 'bg-red-100 text-red-800',
    'General': 'bg-gray-100 text-gray-800',
  };

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Announcements</CardTitle>
            <Button
              onClick={() => {
                setEditingAnnouncement(null);
                resetForm();
                setShowDialog(true);
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Announcement
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {announcements.map(announcement => (
              <Card key={announcement.id} className="dark:bg-gray-900">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{announcement.title}</h3>
                        <Badge className={typeColors[announcement.type]}>
                          {announcement.type}
                        </Badge>
                        {announcement.published && (
                          <Badge className="bg-green-100 text-green-800">Published</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {announcement.message}
                      </p>
                      <div className="flex gap-2 text-xs text-gray-500">
                        <span>Target: {announcement.target_audience}</span>
                        <span>•</span>
                        <span>Priority: {announcement.priority}</span>
                        <span>•</span>
                        <span>
                          Created {format(new Date(announcement.created_date), 'MMM dd, yyyy')}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4">
                      {!announcement.published && (
                        <Button
                          size="sm"
                          onClick={() => publishAnnouncementMutation.mutate(announcement.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Send className="w-4 h-4 mr-1" />
                          Publish
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(announcement)}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Delete this announcement?')) {
                            deleteAnnouncementMutation.mutate(announcement.id);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl dark:bg-gray-950">
          <DialogHeader>
            <DialogTitle>
              {editingAnnouncement ? 'Edit Announcement' : 'New Announcement'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                value={newAnnouncement.title}
                onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                placeholder="Announcement title..."
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Message</Label>
              <Textarea
                value={newAnnouncement.message}
                onChange={(e) => setNewAnnouncement({...newAnnouncement, message: e.target.value})}
                placeholder="Announcement message..."
                rows={4}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select
                  value={newAnnouncement.type}
                  onValueChange={(value) => setNewAnnouncement({...newAnnouncement, type: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Feature">Feature</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Update">Update</SelectItem>
                    <SelectItem value="Alert">Alert</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select
                  value={newAnnouncement.priority}
                  onValueChange={(value) => setNewAnnouncement({...newAnnouncement, priority: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Normal">Normal</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Target Audience</Label>
                <Select
                  value={newAnnouncement.target_audience}
                  onValueChange={(value) => setNewAnnouncement({...newAnnouncement, target_audience: value})}
                >
                  <SelectTrigger className="dark:bg-gray-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Users</SelectItem>
                    <SelectItem value="Pro">Pro Only</SelectItem>
                    <SelectItem value="Enterprise">Enterprise Only</SelectItem>
                    <SelectItem value="Trial">Trial Users</SelectItem>
                    <SelectItem value="Free">Free Users</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newAnnouncement.send_email}
                  onCheckedChange={(checked) => setNewAnnouncement({...newAnnouncement, send_email: checked})}
                />
                <Label>Send Email</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={newAnnouncement.send_sms}
                  onCheckedChange={(checked) => setNewAnnouncement({...newAnnouncement, send_sms: checked})}
                />
                <Label>Send SMS</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingAnnouncement) {
                  updateAnnouncementMutation.mutate({
                    id: editingAnnouncement.id,
                    data: newAnnouncement
                  });
                } else {
                  createAnnouncementMutation.mutate(newAnnouncement);
                }
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
              disabled={!newAnnouncement.title || !newAnnouncement.message}
            >
              {editingAnnouncement ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}