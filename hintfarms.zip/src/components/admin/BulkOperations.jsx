import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Database, Download, Upload, Trash2, RefreshCw, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function BulkOperations() {
  const queryClient = useQueryClient();
  const [selectedEntity, setSelectedEntity] = useState("Animal");
  const [isProcessing, setIsProcessing] = useState(false);

  const { data: users = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const entities = [
    'Animal', 'Pasture', 'HealthRecord', 'BreedingRecord',
    'Expense', 'Revenue', 'Task', 'Note', 'Lead', 'Deal'
  ];

  const handleExportData = async (entity) => {
    setIsProcessing(true);
    try {
      let data;
      switch (entity) {
        case 'Animal':
          data = await base44.entities.Animal.list();
          break;
        case 'Pasture':
          data = await base44.entities.Pasture.list();
          break;
        case 'HealthRecord':
          data = await base44.entities.HealthRecord.list();
          break;
        case 'Expense':
          data = await base44.entities.Expense.list();
          break;
        case 'Revenue':
          data = await base44.entities.Revenue.list();
          break;
        default:
          data = [];
      }

      // Create CSV
      const csv = convertToCSV(data);
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${entity.toLowerCase()}_export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      toast.success(`Exported ${data.length} ${entity} records`);
    } catch (error) {
      toast.error('Export failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const convertToCSV = (data) => {
    if (!data.length) return '';
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(obj => 
      Object.values(obj).map(val => 
        typeof val === 'string' ? `"${val.replace(/"/g, '""')}"` : val
      ).join(',')
    );
    return [headers, ...rows].join('\n');
  };

  const handleClearCache = async () => {
    setIsProcessing(true);
    try {
      // Invalidate all queries
      await queryClient.invalidateQueries();
      toast.success('Cache cleared successfully');
    } catch (error) {
      toast.error('Failed to clear cache');
    } finally {
      setIsProcessing(false);
    }
  };

  const stats = [
    { label: 'Total Users', value: users.length, icon: Database },
    { label: 'Total Ranches', value: ranches.length, icon: Database },
    { label: 'Active Operations', value: 0, icon: RefreshCw },
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map(stat => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="dark:bg-gray-800">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                  <Icon className="w-8 h-8 text-blue-500 opacity-20" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Export Data */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Select Entity Type</Label>
            <Select value={selectedEntity} onValueChange={setSelectedEntity}>
              <SelectTrigger className="dark:bg-gray-900">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {entities.map(entity => (
                  <SelectItem key={entity} value={entity}>
                    {entity}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            onClick={() => handleExportData(selectedEntity)}
            disabled={isProcessing}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            <Download className="w-4 h-4 mr-2" />
            {isProcessing ? 'Exporting...' : `Export ${selectedEntity} Data to CSV`}
          </Button>
        </CardContent>
      </Card>

      {/* System Operations */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            System Operations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button
            variant="outline"
            onClick={handleClearCache}
            disabled={isProcessing}
            className="w-full justify-start"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Clear Application Cache
          </Button>
          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded border border-yellow-200 dark:border-yellow-800">
            <div className="flex gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-yellow-800 dark:text-yellow-300">
                  Caution: Destructive Operations
                </p>
                <p className="text-xs text-yellow-700 dark:text-yellow-400 mt-1">
                  Bulk delete operations should be performed with extreme caution. 
                  Always backup data before performing destructive operations.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}