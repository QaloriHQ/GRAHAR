import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mail, MessageSquare, Send, Users } from "lucide-react";
import { toast } from "sonner";

export default function CommunicationCenter() {
  const [emailData, setEmailData] = useState({
    target: "all",
    subject: "",
    body: "",
  });

  const [smsData, setSmsData] = useState({
    target: "all",
    message: "",
  });

  const { data: users = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const sendEmailMutation = useMutation({
    mutationFn: async (data) => {
      // Filter users based on target
      let targetUsers = users;
      if (data.target !== 'all') {
        const targetRanches = ranches.filter(r => {
          if (data.target === 'pro') return r.subscription_plan === 'Pro';
          if (data.target === 'enterprise') return r.subscription_plan === 'Enterprise';
          if (data.target === 'trial') return r.subscription_status === 'Trialing';
          if (data.target === 'free') return !r.subscription_plan || r.subscription_plan === 'Free';
          return true;
        });
        const ranchOwnerEmails = targetRanches.map(r => r.owner_email);
        targetUsers = users.filter(u => ranchOwnerEmails.includes(u.email));
      }

      // Send emails to all target users
      const promises = targetUsers.map(user =>
        base44.integrations.Core.SendEmail({
          to: user.email,
          subject: data.subject,
          body: data.body,
          from_name: "GRAHAR Team"
        })
      );

      await Promise.all(promises);
      return targetUsers.length;
    },
    onSuccess: (count) => {
      toast.success(`Email sent to ${count} users`);
      setEmailData({ target: "all", subject: "", body: "" });
    },
    onError: () => {
      toast.error('Failed to send emails');
    }
  });

  const sendSmsMutation = useMutation({
    mutationFn: async (data) => {
      // SMS functionality would require Twilio or similar integration
      // For now, we'll show a toast
      toast.info('SMS feature requires Twilio integration');
      return 0;
    },
  });

  const getTargetCount = (target) => {
    if (target === 'all') return users.length;
    const targetRanches = ranches.filter(r => {
      if (target === 'pro') return r.subscription_plan === 'Pro';
      if (target === 'enterprise') return r.subscription_plan === 'Enterprise';
      if (target === 'trial') return r.subscription_status === 'Trialing';
      if (target === 'free') return !r.subscription_plan || r.subscription_plan === 'Free';
      return true;
    });
    return targetRanches.length;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Email */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Send Email
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Target Audience</Label>
            <Select
              value={emailData.target}
              onValueChange={(value) => setEmailData({...emailData, target: value})}
            >
              <SelectTrigger className="dark:bg-gray-900">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users ({getTargetCount('all')})</SelectItem>
                <SelectItem value="pro">Pro Users ({getTargetCount('pro')})</SelectItem>
                <SelectItem value="enterprise">Enterprise Users ({getTargetCount('enterprise')})</SelectItem>
                <SelectItem value="trial">Trial Users ({getTargetCount('trial')})</SelectItem>
                <SelectItem value="free">Free Users ({getTargetCount('free')})</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Subject</Label>
            <Input
              value={emailData.subject}
              onChange={(e) => setEmailData({...emailData, subject: e.target.value})}
              placeholder="Email subject..."
              className="dark:bg-gray-900"
            />
          </div>

          <div className="space-y-2">
            <Label>Message</Label>
            <Textarea
              value={emailData.body}
              onChange={(e) => setEmailData({...emailData, body: e.target.value})}
              placeholder="Email message..."
              rows={6}
              className="dark:bg-gray-900"
            />
          </div>

          <Button
            onClick={() => sendEmailMutation.mutate(emailData)}
            className="w-full bg-blue-600 hover:bg-blue-700"
            disabled={!emailData.subject || !emailData.body || sendEmailMutation.isPending}
          >
            <Send className="w-4 h-4 mr-2" />
            {sendEmailMutation.isPending ? 'Sending...' : `Send to ${getTargetCount(emailData.target)} Users`}
          </Button>
        </CardContent>
      </Card>

      {/* SMS */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Send SMS
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Target Audience</Label>
            <Select
              value={smsData.target}
              onValueChange={(value) => setSmsData({...smsData, target: value})}
            >
              <SelectTrigger className="dark:bg-gray-900">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users ({getTargetCount('all')})</SelectItem>
                <SelectItem value="pro">Pro Users ({getTargetCount('pro')})</SelectItem>
                <SelectItem value="enterprise">Enterprise Users ({getTargetCount('enterprise')})</SelectItem>
                <SelectItem value="trial">Trial Users ({getTargetCount('trial')})</SelectItem>
                <SelectItem value="free">Free Users ({getTargetCount('free')})</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Message</Label>
            <Textarea
              value={smsData.message}
              onChange={(e) => setSmsData({...smsData, message: e.target.value})}
              placeholder="SMS message (160 characters max)..."
              rows={4}
              maxLength={160}
              className="dark:bg-gray-900"
            />
            <p className="text-xs text-gray-500">
              {smsData.message.length}/160 characters
            </p>
          </div>

          <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded border border-yellow-200 dark:border-yellow-800">
            <p className="text-sm text-yellow-800 dark:text-yellow-300">
              SMS feature requires Twilio integration. Configure Twilio credentials to enable.
            </p>
          </div>

          <Button
            onClick={() => sendSmsMutation.mutate(smsData)}
            className="w-full bg-green-600 hover:bg-green-700"
            disabled={!smsData.message}
          >
            <Send className="w-4 h-4 mr-2" />
            Send SMS
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}