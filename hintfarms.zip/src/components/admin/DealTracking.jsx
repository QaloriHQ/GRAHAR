import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit2, Trash2, DollarSign, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function DealTracking() {
  const queryClient = useQueryClient();
  const [showDialog, setShowDialog] = useState(false);
  const [editingDeal, setEditingDeal] = useState(null);
  const [newDeal, setNewDeal] = useState({
    deal_name: "",
    ranch_id: "",
    contact_name: "",
    contact_email: "",
    deal_value: 0,
    plan_type: "Pro",
    stage: "Discovery",
    probability: 50,
    expected_close_date: "",
    notes: ""
  });

  const { data: deals = [] } = useQuery({
    queryKey: ['admin-deals'],
    queryFn: () => base44.entities.Deal.list('-created_date'),
    initialData: [],
  });

  const { data: ranches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const createDealMutation = useMutation({
    mutationFn: (data) => {
      const ranch = ranches.find(r => r.id === data.ranch_id);
      return base44.entities.Deal.create({
        ...data,
        ranch_name: ranch?.name || ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-deals'] });
      setShowDialog(false);
      resetForm();
      toast.success('Deal created');
    },
  });

  const updateDealMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Deal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-deals'] });
      setShowDialog(false);
      setEditingDeal(null);
      toast.success('Deal updated');
    },
  });

  const deleteDealMutation = useMutation({
    mutationFn: (id) => base44.entities.Deal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-deals'] });
      toast.success('Deal deleted');
    },
  });

  const resetForm = () => {
    setNewDeal({
      deal_name: "",
      ranch_id: "",
      contact_name: "",
      contact_email: "",
      deal_value: 0,
      plan_type: "Pro",
      stage: "Discovery",
      probability: 50,
      expected_close_date: "",
      notes: ""
    });
  };

  const handleEdit = (deal) => {
    setEditingDeal(deal);
    setNewDeal({
      deal_name: deal.deal_name,
      ranch_id: deal.ranch_id || "",
      contact_name: deal.contact_name || "",
      contact_email: deal.contact_email || "",
      deal_value: deal.deal_value,
      plan_type: deal.plan_type,
      stage: deal.stage,
      probability: deal.probability || 50,
      expected_close_date: deal.expected_close_date ? format(new Date(deal.expected_close_date), 'yyyy-MM-dd') : "",
      notes: deal.notes || ""
    });
    setShowDialog(true);
  };

  const stageColors = {
    'Discovery': 'bg-blue-100 text-blue-800',
    'Demo': 'bg-purple-100 text-purple-800',
    'Proposal': 'bg-yellow-100 text-yellow-800',
    'Negotiation': 'bg-orange-100 text-orange-800',
    'Closed Won': 'bg-green-100 text-green-800',
    'Closed Lost': 'bg-red-100 text-red-800',
  };

  const totalValue = deals.reduce((sum, d) => sum + (d.deal_value || 0), 0);
  const wonValue = deals.filter(d => d.stage === 'Closed Won').reduce((sum, d) => sum + (d.deal_value || 0), 0);
  const pipelineValue = deals.filter(d => !['Closed Won', 'Closed Lost'].includes(d.stage)).reduce((sum, d) => sum + (d.deal_value || 0), 0);
  const avgDealSize = deals.length > 0 ? Math.round(totalValue / deals.length) : 0;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Deals</p>
            <p className="text-2xl font-bold">{deals.length}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Pipeline Value</p>
            <p className="text-2xl font-bold text-blue-600">${pipelineValue.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Closed Won</p>
            <p className="text-2xl font-bold text-green-600">${wonValue.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-gray-800">
          <CardContent className="p-4">
            <p className="text-sm text-gray-500 dark:text-gray-400">Avg Deal Size</p>
            <p className="text-2xl font-bold">${avgDealSize.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Deals Table */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Sales Pipeline</CardTitle>
            <Button
              onClick={() => {
                setEditingDeal(null);
                resetForm();
                setShowDialog(true);
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Deal
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Deal Name</TableHead>
                <TableHead>Ranch</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Stage</TableHead>
                <TableHead>Probability</TableHead>
                <TableHead>Close Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deals.map(deal => (
                <TableRow key={deal.id}>
                  <TableCell className="font-medium">{deal.deal_name}</TableCell>
                  <TableCell>{deal.ranch_name || 'N/A'}</TableCell>
                  <TableCell>
                    <div>
                      <p className="text-sm">{deal.contact_name}</p>
                      <p className="text-xs text-gray-500">{deal.contact_email}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-semibold text-green-600">
                      ${deal.deal_value?.toLocaleString()}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge className={stageColors[deal.stage]}>
                      {deal.stage}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{deal.probability}%</Badge>
                  </TableCell>
                  <TableCell className="text-sm">
                    {deal.expected_close_date 
                      ? format(new Date(deal.expected_close_date), 'MMM dd, yyyy')
                      : 'N/A'}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="sm" onClick={() => handleEdit(deal)}>
                        <Edit2 className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm('Delete this deal?')) {
                            deleteDealMutation.mutate(deal.id);
                          }
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl dark:bg-gray-950">
          <DialogHeader>
            <DialogTitle>{editingDeal ? 'Edit Deal' : 'Add New Deal'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="space-y-2 col-span-2">
              <Label>Deal Name *</Label>
              <Input
                value={newDeal.deal_name}
                onChange={(e) => setNewDeal({...newDeal, deal_name: e.target.value})}
                placeholder="Ranch Pro Subscription"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Ranch</Label>
              <Select
                value={newDeal.ranch_id}
                onValueChange={(value) => setNewDeal({...newDeal, ranch_id: value})}
              >
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue placeholder="Select ranch..." />
                </SelectTrigger>
                <SelectContent>
                  {ranches.map(ranch => (
                    <SelectItem key={ranch.id} value={ranch.id}>
                      {ranch.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Contact Name</Label>
              <Input
                value={newDeal.contact_name}
                onChange={(e) => setNewDeal({...newDeal, contact_name: e.target.value})}
                placeholder="John Doe"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Contact Email</Label>
              <Input
                type="email"
                value={newDeal.contact_email}
                onChange={(e) => setNewDeal({...newDeal, contact_email: e.target.value})}
                placeholder="email@example.com"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Deal Value *</Label>
              <Input
                type="number"
                value={newDeal.deal_value}
                onChange={(e) => setNewDeal({...newDeal, deal_value: parseFloat(e.target.value) || 0})}
                placeholder="2400"
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Plan Type</Label>
              <Select value={newDeal.plan_type} onValueChange={(value) => setNewDeal({...newDeal, plan_type: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pro">Pro</SelectItem>
                  <SelectItem value="Enterprise">Enterprise</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Stage</Label>
              <Select value={newDeal.stage} onValueChange={(value) => setNewDeal({...newDeal, stage: value})}>
                <SelectTrigger className="dark:bg-gray-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Discovery">Discovery</SelectItem>
                  <SelectItem value="Demo">Demo</SelectItem>
                  <SelectItem value="Proposal">Proposal</SelectItem>
                  <SelectItem value="Negotiation">Negotiation</SelectItem>
                  <SelectItem value="Closed Won">Closed Won</SelectItem>
                  <SelectItem value="Closed Lost">Closed Lost</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Probability (%)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={newDeal.probability}
                onChange={(e) => setNewDeal({...newDeal, probability: parseInt(e.target.value) || 0})}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2">
              <Label>Expected Close Date</Label>
              <Input
                type="date"
                value={newDeal.expected_close_date}
                onChange={(e) => setNewDeal({...newDeal, expected_close_date: e.target.value})}
                className="dark:bg-gray-900"
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={newDeal.notes}
                onChange={(e) => setNewDeal({...newDeal, notes: e.target.value})}
                placeholder="Deal notes..."
                rows={3}
                className="dark:bg-gray-900"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (editingDeal) {
                  updateDealMutation.mutate({ id: editingDeal.id, data: newDeal });
                } else {
                  createDealMutation.mutate(newDeal);
                }
              }}
              className="bg-[#F5A623] hover:bg-[#E09612]"
              disabled={!newDeal.deal_name || !newDeal.deal_value}
            >
              {editingDeal ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}