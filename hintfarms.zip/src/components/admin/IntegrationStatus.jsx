import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertCircle, Zap, CreditCard, Map, Mail, Database } from "lucide-react";

export default function IntegrationStatus() {
  const integrations = [
    {
      name: "Stripe",
      icon: CreditCard,
      status: "connected",
      description: "Payment processing active",
      lastSync: "2 minutes ago",
      details: "Webhooks configured, subscriptions active"
    },
    {
      name: "Mapbox",
      icon: Map,
      status: "connected",
      description: "Mapping services active",
      lastSync: "Active",
      details: "Geocoding and maps working"
    },
    {
      name: "Email Service",
      icon: Mail,
      status: "connected",
      description: "Transactional emails",
      lastSync: "Active",
      details: "SendGrid/SMTP configured"
    },
    {
      name: "Database",
      icon: Database,
      status: "healthy",
      description: "All systems operational",
      lastSync: "Live",
      details: "Performance optimal"
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected':
      case 'healthy':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300';
      case 'error':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const getStatusIcon = (status) => {
    return status === 'connected' || status === 'healthy'
      ? <CheckCircle className="w-5 h-5 text-green-600" />
      : <AlertCircle className="w-5 h-5 text-red-600" />;
  };

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Integration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {integrations.map(integration => {
              const Icon = integration.icon;
              return (
                <Card key={integration.name} className="dark:bg-gray-900">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/30">
                          <Icon className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold dark:text-gray-100">{integration.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {integration.description}
                          </p>
                        </div>
                      </div>
                      {getStatusIcon(integration.status)}
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Status</span>
                        <Badge className={getStatusColor(integration.status)}>
                          {integration.status}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Last Sync</span>
                        <span className="text-sm font-medium dark:text-gray-300">
                          {integration.lastSync}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-500 pt-2 border-t dark:border-gray-800">
                        {integration.details}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* System Health */}
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle>System Health</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-semibold dark:text-gray-100">All Systems Operational</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    No issues detected
                  </p>
                </div>
              </div>
              <Badge className="bg-green-100 text-green-800">
                Healthy
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-400">API Response</p>
                <p className="text-2xl font-bold text-green-600">45ms</p>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-400">Uptime</p>
                <p className="text-2xl font-bold text-green-600">99.9%</p>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <p className="text-sm text-gray-600 dark:text-gray-400">Errors (24h)</p>
                <p className="text-2xl font-bold text-gray-600">0</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}