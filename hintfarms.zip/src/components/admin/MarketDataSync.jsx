import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, CheckCircle, AlertCircle, Clock } from "lucide-react";

export default function MarketDataSync() {
  const [syncResult, setSyncResult] = useState(null);

  const { data: lastSync } = useQuery({
    queryKey: ['lastMarketSync'],
    queryFn: async () => {
      const sources = await base44.entities.MarketInsightsSource.filter({}, '-fetched_at', 1);
      return sources[0] || null;
    }
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('syncUSDAAmsMarketData', {
        regions: ['Arkansas', 'Texas', 'Oklahoma', 'Missouri', 'Kansas', 'Nebraska']
      });
      return response.data;
    },
    onSuccess: (data) => {
      setSyncResult(data);
    }
  });

  const handleSync = () => {
    setSyncResult(null);
    syncMutation.mutate();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Market Data Synchronization</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Last Sync</p>
            <p className="font-semibold">
              {lastSync ? new Date(lastSync.fetched_at).toLocaleString() : 'Never'}
            </p>
          </div>
          <Button 
            onClick={handleSync}
            disabled={syncMutation.isPending}
          >
            {syncMutation.isPending ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Now
              </>
            )}
          </Button>
        </div>

        {syncResult && (
          <div className="p-4 rounded-lg bg-gray-50 space-y-2">
            <div className="flex items-center gap-2">
              {syncResult.success ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600" />
              )}
              <span className="font-semibold">
                {syncResult.success ? 'Sync Successful' : 'Sync Failed'}
              </span>
            </div>
            
            {syncResult.success && (
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-600">Inserted:</span>
                  <Badge variant="secondary" className="ml-2">
                    {syncResult.totalInserted}
                  </Badge>
                </div>
                <div>
                  <span className="text-gray-600">Updated:</span>
                  <Badge variant="secondary" className="ml-2">
                    {syncResult.totalUpdated}
                  </Badge>
                </div>
              </div>
            )}

            {syncResult.errors && syncResult.errors.length > 0 && (
              <div className="mt-2">
                <p className="text-sm font-semibold text-red-600 mb-1">Errors:</p>
                <ul className="text-xs text-red-600 space-y-1">
                  {syncResult.errors.slice(0, 5).map((error, idx) => (
                    <li key={idx}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="text-xs text-gray-500 p-3 bg-blue-50 rounded">
          <Clock className="w-4 h-4 inline mr-2" />
          <strong>Note:</strong> Market data syncs automatically every 6 hours. Manual sync is for immediate updates only.
        </div>
      </CardContent>
    </Card>
  );
}