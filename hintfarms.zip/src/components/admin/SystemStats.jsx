import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Building2, Beef, DollarSign, TrendingUp, Activity } from "lucide-react";
import StatsCard from "../dashboard/StatsCard";

export default function SystemStats() {
  const { data: allUsers = [] } = useQuery({
    queryKey: ['admin-all-users'],
    queryFn: async () => {
      // Admin can see all users
      return await base44.entities.User.list();
    },
    initialData: [],
  });

  const { data: allRanches = [] } = useQuery({
    queryKey: ['admin-all-ranches'],
    queryFn: () => base44.entities.Ranch.list(),
    initialData: [],
  });

  const { data: allAnimals = [] } = useQuery({
    queryKey: ['admin-all-animals'],
    queryFn: () => base44.entities.Animal.list(),
    initialData: [],
  });

  const activeSubscriptions = allRanches.filter(r => 
    r.subscription_status === 'Active' || r.subscription_status === 'Trialing'
  ).length;

  const proSubscriptions = allRanches.filter(r => r.subscription_plan === 'Pro').length;
  const enterpriseSubscriptions = allRanches.filter(r => r.subscription_plan === 'Enterprise').length;
  const mrr = (proSubscriptions * 24) + (enterpriseSubscriptions * 100);

  return (
    <div className="space-y-6 w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatsCard
          title="Total Users"
          value={allUsers.length}
          icon={Users}
          bgColor="bg-blue-500"
          textColor="text-blue-600"
        />
        <StatsCard
          title="Total Ranches"
          value={allRanches.length}
          icon={Building2}
          bgColor="bg-green-500"
          textColor="text-green-600"
        />
        <StatsCard
          title="Total Animals"
          value={allAnimals.length}
          icon={Beef}
          bgColor="bg-orange-500"
          textColor="text-orange-600"
        />
        <StatsCard
          title="Active Subscriptions"
          value={activeSubscriptions}
          icon={TrendingUp}
          bgColor="bg-purple-500"
          textColor="text-purple-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-lg">Subscription Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600 dark:text-gray-400">Free/Trial</span>
              <span className="font-bold">{allRanches.filter(r => !r.subscription_plan || r.subscription_plan === 'Free').length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600 dark:text-gray-400">Pro</span>
              <span className="font-bold text-blue-600">{proSubscriptions}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600 dark:text-gray-400">Enterprise</span>
              <span className="font-bold text-purple-600">{enterpriseSubscriptions}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-lg">Monthly Recurring Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">${mrr}</p>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
              Estimated MRR from active subscriptions
            </p>
          </CardContent>
        </Card>

        <Card className="dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="text-lg">System Health</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600 dark:text-gray-400">Status</span>
              <span className="text-green-600 font-semibold flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Operational
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600 dark:text-gray-400">Users Active (7d)</span>
              <span className="font-bold">{Math.floor(allUsers.length * 0.7)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {allRanches.slice(0, 5).map(ranch => (
              <div key={ranch.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded">
                <div>
                  <p className="font-semibold dark:text-gray-200">{ranch.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{ranch.owner_email}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{ranch.subscription_plan || 'Free'}</p>
                  <p className="text-xs text-gray-500">{ranch.subscription_status || 'N/A'}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}