import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function TicketManagement() {
  const queryClient = useQueryClient();
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [resolution, setResolution] = useState("");

  const { data: tickets = [] } = useQuery({
    queryKey: ['admin-tickets'],
    queryFn: () => base44.entities.Ticket.list('-created_date'),
    initialData: [],
  });

  const updateTicketMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Ticket.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-tickets'] });
      toast.success('Ticket updated successfully');
    },
  });

  const handleResolveTicket = () => {
    if (!selectedTicket || !resolution) return;
    updateTicketMutation.mutate({
      id: selectedTicket.id,
      data: {
        status: 'Resolved',
        resolution: resolution,
        resolved_at: new Date().toISOString()
      }
    });
    setShowDetailDialog(false);
    setResolution("");
  };

  const statusColors = {
    'Open': 'bg-blue-100 text-blue-800',
    'In Progress': 'bg-yellow-100 text-yellow-800',
    'Waiting': 'bg-orange-100 text-orange-800',
    'Resolved': 'bg-green-100 text-green-800',
    'Closed': 'bg-gray-100 text-gray-800',
  };

  const priorityColors = {
    'Low': 'bg-gray-100 text-gray-800',
    'Medium': 'bg-blue-100 text-blue-800',
    'High': 'bg-orange-100 text-orange-800',
    'Urgent': 'bg-red-100 text-red-800',
  };

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-800">
        <CardHeader>
          <CardTitle>Support Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ticket #</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tickets.map(ticket => (
                <TableRow key={ticket.id}>
                  <TableCell className="font-mono text-sm">
                    {ticket.ticket_number || `#${ticket.id.slice(0, 8)}`}
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{ticket.user_name}</p>
                      <p className="text-xs text-gray-500">{ticket.user_email}</p>
                    </div>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">{ticket.subject}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{ticket.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={priorityColors[ticket.priority]}>
                      {ticket.priority}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={statusColors[ticket.status]}>
                      {ticket.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-gray-600">
                    {format(new Date(ticket.created_date), 'MMM dd, yyyy')}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedTicket(ticket);
                        setShowDetailDialog(true);
                      }}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Ticket Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl dark:bg-gray-950">
          <DialogHeader>
            <DialogTitle>Ticket Details</DialogTitle>
          </DialogHeader>
          {selectedTicket && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Ticket Number</p>
                  <p className="font-mono font-semibold">
                    {selectedTicket.ticket_number || `#${selectedTicket.id.slice(0, 8)}`}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <Badge className={statusColors[selectedTicket.status]}>
                    {selectedTicket.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-500">User</p>
                  <p className="font-semibold">{selectedTicket.user_name}</p>
                  <p className="text-sm text-gray-600">{selectedTicket.user_email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Priority</p>
                  <Badge className={priorityColors[selectedTicket.priority]}>
                    {selectedTicket.priority}
                  </Badge>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-2">Subject</p>
                <p className="font-semibold">{selectedTicket.subject}</p>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-2">Description</p>
                <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded">
                  <p className="text-sm">{selectedTicket.description}</p>
                </div>
              </div>

              {selectedTicket.status !== 'Resolved' && selectedTicket.status !== 'Closed' && (
                <div className="space-y-2">
                  <Label>Resolution Notes</Label>
                  <Textarea
                    value={resolution}
                    onChange={(e) => setResolution(e.target.value)}
                    placeholder="Enter resolution details..."
                    rows={3}
                    className="dark:bg-gray-900"
                  />
                  <Button
                    onClick={handleResolveTicket}
                    className="w-full bg-green-600 hover:bg-green-700"
                    disabled={!resolution}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark as Resolved
                  </Button>
                </div>
              )}

              {selectedTicket.resolution && (
                <div>
                  <p className="text-sm text-gray-500 mb-2">Resolution</p>
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-800">
                    <p className="text-sm">{selectedTicket.resolution}</p>
                    {selectedTicket.resolved_at && (
                      <p className="text-xs text-gray-500 mt-2">
                        Resolved on {format(new Date(selectedTicket.resolved_at), 'MMM dd, yyyy h:mm a')}
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Select
                  value={selectedTicket.status}
                  onValueChange={(value) => {
                    updateTicketMutation.mutate({
                      id: selectedTicket.id,
                      data: { status: value }
                    });
                  }}
                >
                  <SelectTrigger className="flex-1 dark:bg-gray-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Waiting">Waiting</SelectItem>
                    <SelectItem value="Resolved">Resolved</SelectItem>
                    <SelectItem value="Closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={selectedTicket.priority}
                  onValueChange={(value) => {
                    updateTicketMutation.mutate({
                      id: selectedTicket.id,
                      data: { priority: value }
                    });
                  }}
                >
                  <SelectTrigger className="flex-1 dark:bg-gray-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}