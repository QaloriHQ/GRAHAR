import React, { useEffect, useState, useRef } from 'react';
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Beef, MapPin, DollarSign, Calendar, TrendingUp } from 'lucide-react';

export default function InlineSuggestions({ 
  trigger, 
  searchTerm, 
  position, 
  onSelect, 
  onClose,
  ranchId 
}) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const containerRef = useRef(null);

  useEffect(() => {
    if (!trigger || !searchTerm) {
      setSuggestions([]);
      return;
    }

    const fetchSuggestions = async () => {
      setLoading(true);
      try {
        const response = await base44.functions.invoke('getSuggestions', {
          trigger,
          search: searchTerm,
          ranch_id: ranchId
        });
        
        if (response.data?.suggestions) {
          setSuggestions(response.data.suggestions);
          setSelectedIndex(0);
        }
      } catch (error) {
        console.error('Error fetching suggestions:', error);
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(fetchSuggestions, 200);
    return () => clearTimeout(debounce);
  }, [trigger, searchTerm, ranchId]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!suggestions.length) return;

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex((prev) => (prev + 1) % suggestions.length);
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
          break;
        case 'Enter':
        case 'Tab':
          e.preventDefault();
          if (suggestions[selectedIndex]) {
            onSelect(suggestions[selectedIndex]);
          }
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [suggestions, selectedIndex, onSelect, onClose]);

  if (!suggestions.length || !trigger) return null;

  const getIcon = (type) => {
    switch (type) {
      case 'animal': return <Beef className="w-4 h-4" />;
      case 'pasture': return <MapPin className="w-4 h-4" />;
      case 'category': return <DollarSign className="w-4 h-4" />;
      case 'time': return <Calendar className="w-4 h-4" />;
      case 'metric': return <TrendingUp className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <Card 
      ref={containerRef}
      className="fixed z-[9999] w-[90vw] md:w-80 max-h-60 md:max-h-64 overflow-y-auto shadow-2xl border-2 border-[#F5A623] bg-white"
      style={{
        top: Math.min(position.top + 24, window.innerHeight - 280),
        left: Math.min(Math.max(position.left, 16), window.innerWidth - (window.innerWidth < 768 ? window.innerWidth * 0.9 : 350))
      }}
    >
      <div className="p-1.5 md:p-2">
        {loading ? (
          <div className="text-center py-4 text-xs md:text-sm text-gray-500">Loading...</div>
        ) : (
          suggestions.map((suggestion, index) => (
            <div
              key={suggestion.id || index}
              className={`flex items-start gap-2 md:gap-3 p-2 md:p-3 rounded-lg cursor-pointer transition-colors active:scale-95 ${
                index === selectedIndex 
                  ? 'bg-[#F5A623]/20 border border-[#F5A623]' 
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => onSelect(suggestion)}
            >
              <div className="text-gray-600 mt-0.5 md:mt-1">
                {getIcon(suggestion.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-xs md:text-sm text-gray-900 truncate">
                  {suggestion.display}
                </div>
                {suggestion.subtext && (
                  <div className="text-[10px] md:text-xs text-gray-500 mt-0.5 truncate">
                    {suggestion.subtext}
                  </div>
                )}
                {suggestion.badge && (
                  <Badge variant="outline" className="mt-1 text-[10px] md:text-xs">
                    {suggestion.badge}
                  </Badge>
                )}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="border-t px-2 md:px-3 py-1.5 md:py-2 text-[10px] md:text-xs text-gray-500 bg-gray-50">
        <span className="hidden md:inline">↑↓ Navigate • Enter/Tab Select • Esc Close</span>
        <span className="md:hidden">Tap to select</span>
      </div>
    </Card>
  );
}