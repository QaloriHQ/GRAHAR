import React, { useState, useRef, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Send, Loader2, ExternalLink, Plus, MessageSquare, Trash2, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from "@/components/utils";
import InlineSuggestions from './InlineSuggestions';
import ReactMarkdown from 'react-markdown';
import { format } from 'date-fns';

export default function RanchInsightsAgent({ ranchId }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState(null);
  const [showConversations, setShowConversations] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestionTrigger, setSuggestionTrigger] = useState(null);
  const [suggestionSearch, setSuggestionSearch] = useState('');
  const [suggestionPosition, setSuggestionPosition] = useState({ top: 0, left: 0 });
  const [proactiveSuggestions, setProactiveSuggestions] = useState([]);
  const [showProactiveSuggestions, setShowProactiveSuggestions] = useState(false);
  const inputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ['ranchAssistConversations', ranchId],
    queryFn: () => base44.entities.RanchAssistConversation.filter({ ranch_id: ranchId }, '-updated_date', 50),
    enabled: !!ranchId,
  });

  const createConversationMutation = useMutation({
    mutationFn: (data) => base44.entities.RanchAssistConversation.create(data),
    onSuccess: (newConversation) => {
      queryClient.invalidateQueries(['ranchAssistConversations', ranchId]);
      setCurrentConversationId(newConversation.id);
    },
  });

  const updateConversationMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RanchAssistConversation.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['ranchAssistConversations', ranchId]);
    },
  });

  const deleteConversationMutation = useMutation({
    mutationFn: (id) => base44.entities.RanchAssistConversation.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['ranchAssistConversations', ranchId]);
      if (currentConversationId === deleteConversationMutation.variables) {
        handleNewChat();
      }
    },
  });

  // Load latest conversation on mount
  useEffect(() => {
    if (conversations.length > 0 && !currentConversationId) {
      const latestConversation = conversations[0];
      setCurrentConversationId(latestConversation.id);
      setMessages(latestConversation.messages || []);
    }
  }, [conversations, currentConversationId]);

  // Load proactive suggestions on mount
  useEffect(() => {
    const loadProactiveSuggestions = async () => {
      try {
        const response = await base44.functions.invoke('analyzeRanchPatterns', {
          ranch_id: ranchId
        });
        if (response.data?.suggestions) {
          setProactiveSuggestions(response.data.suggestions);
          if (response.data.suggestions.length > 0) {
            setShowProactiveSuggestions(true);
          }
        }
      } catch (error) {
        console.error('Failed to load suggestions:', error);
      }
    };

    if (ranchId) {
      loadProactiveSuggestions();
    }
  }, [ranchId]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleNewChat = () => {
    setMessages([]);
    setCurrentConversationId(null);
    setShowConversations(false);
  };

  const handleSelectConversation = (conversation) => {
    setCurrentConversationId(conversation.id);
    setMessages(conversation.messages || []);
    setShowConversations(false);
  };

  const handleDeleteConversation = async (e, conversationId) => {
    e.stopPropagation();
    if (confirm('Delete this conversation?')) {
      deleteConversationMutation.mutate(conversationId);
    }
  };

  const saveConversation = async (updatedMessages) => {
    const lastUserMessage = updatedMessages.find(m => m.role === 'user');
    const title = lastUserMessage?.content.slice(0, 50) || 'New Conversation';
    const lastMessagePreview = updatedMessages[updatedMessages.length - 1]?.content.slice(0, 100) || '';

    if (currentConversationId) {
      await updateConversationMutation.mutateAsync({
        id: currentConversationId,
        data: {
          messages: updatedMessages,
          last_message_preview: lastMessagePreview,
        },
      });
    } else {
      const newConversation = await createConversationMutation.mutateAsync({
        ranch_id: ranchId,
        title,
        messages: updatedMessages,
        last_message_preview: lastMessagePreview,
      });
      setCurrentConversationId(newConversation.id);
    }
  };

  const detectShortcut = (text, cursorPosition) => {
    const beforeCursor = text.slice(0, cursorPosition);
    const lastChar = beforeCursor[beforeCursor.length - 1];
    
    const triggers = {
      '#': 'animal',
      '~': 'pasture',
      '/': 'category',
      '@': 'time'
    };

    if (triggers[lastChar]) {
      return { trigger: triggers[lastChar], position: cursorPosition };
    }

    // Check if we're in the middle of a shortcut
    const shortcutMatch = beforeCursor.match(/(#|~|\/|@)([^\s]*)$/);
    if (shortcutMatch) {
      const [, trigger, search] = shortcutMatch;
      const triggerType = triggers[trigger];
      if (triggerType) {
        return { 
          trigger: triggerType, 
          search,
          position: cursorPosition
        };
      }
    }

    return null;
  };

  const handleInputChange = (e) => {
    const value = e.target.value;
    const cursorPosition = e.target.selectionStart;
    setInput(value);

    const shortcut = detectShortcut(value, cursorPosition);
    
    if (shortcut) {
      const rect = inputRef.current.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
      
      setSuggestionTrigger(shortcut.trigger);
      setSuggestionSearch(shortcut.search || '');
      setSuggestionPosition({
        top: rect.bottom + scrollTop,
        left: rect.left + scrollLeft
      });
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSuggestionSelect = (suggestion) => {
    const cursorPosition = inputRef.current.selectionStart;
    const beforeCursor = input.slice(0, cursorPosition);
    const afterCursor = input.slice(cursorPosition);
    
    // Find the start of the current shortcut
    const shortcutMatch = beforeCursor.match(/(#|~|\/|@)([^\s]*)$/);
    if (shortcutMatch) {
      const shortcutStart = beforeCursor.lastIndexOf(shortcutMatch[0]);
      const newInput = 
        input.slice(0, shortcutStart) + 
        suggestion.token + 
        ' ' + 
        afterCursor;
      
      setInput(newInput);
      setShowSuggestions(false);
      
      // Focus back on input
      setTimeout(() => {
        inputRef.current.focus();
        const newPosition = shortcutStart + suggestion.token.length + 1;
        inputRef.current.setSelectionRange(newPosition, newPosition);
      }, 0);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = { role: 'user', content: input };
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    setInput('');
    setLoading(true);
    setShowSuggestions(false);

    try {
      const response = await base44.functions.invoke('ranchInsightsAgent', {
        message: input,
        ranch_id: ranchId,
        conversation_history: messages
      });

      if (response.data) {
        // Check if this is an action proposal
        if (response.data.type === 'action_proposal') {
          const assistantMessage = {
            role: 'assistant',
            type: 'action_proposal',
            action: response.data.action,
            proposal: response.data.proposal,
            content: response.data.message,
            entities: response.data.entities || []
          };
          const finalMessages = [...updatedMessages, assistantMessage];
          setMessages(finalMessages);
          await saveConversation(finalMessages);
        } else {
          const assistantMessage = {
            role: 'assistant',
            content: response.data.message,
            links: response.data.links,
            data: response.data.data,
            entities: response.data.entities || []
          };
          const finalMessages = [...updatedMessages, assistantMessage];
          setMessages(finalMessages);
          await saveConversation(finalMessages);
        }
      }
    } catch (error) {
      console.error('AI Agent error:', error);
      const errorMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        error: true
      };
      const finalMessages = [...updatedMessages, errorMessage];
      setMessages(finalMessages);
      await saveConversation(finalMessages);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmAction = async (proposal) => {
    setLoading(true);
    try {
      const response = await base44.functions.invoke('executeRanchAction', {
        action: proposal.action,
        data: proposal.data,
        ranch_id: ranchId
      });

      if (response.data.success) {
        const confirmMessage = {
          role: 'assistant',
          content: response.data.message,
          actionResult: true
        };
        const finalMessages = [...messages, confirmMessage];
        setMessages(finalMessages);
        await saveConversation(finalMessages);
        
        // Invalidate relevant queries
        queryClient.invalidateQueries({ queryKey: ['tasks'] });
        queryClient.invalidateQueries({ queryKey: ['expenses'] });
        queryClient.invalidateQueries({ queryKey: ['revenue'] });
        queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
        queryClient.invalidateQueries({ queryKey: ['breedingRecords'] });
        queryClient.invalidateQueries({ queryKey: ['animals'] });
      }
    } catch (error) {
      console.error('Action execution error:', error);
      const errorMessage = {
        role: 'assistant',
        content: 'Failed to execute action. Please try again.',
        error: true
      };
      const finalMessages = [...messages, errorMessage];
      setMessages(finalMessages);
      await saveConversation(finalMessages);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelAction = () => {
    const cancelMessage = {
      role: 'assistant',
      content: 'Action cancelled. How else can I help?',
      actionResult: false
    };
    const finalMessages = [...messages, cancelMessage];
    setMessages(finalMessages);
    saveConversation(finalMessages);
  };

  const handleLinkClick = (link) => {
    navigate(link);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Conversation Sidebar Toggle */}
      <div className="border-b p-2 md:p-3 bg-gray-50 flex items-center justify-between">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowConversations(!showConversations)}
          className="text-xs md:text-sm"
        >
          <MessageSquare className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
          {showConversations ? 'Hide' : 'Show'} History
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleNewChat}
          className="text-xs md:text-sm"
        >
          <Plus className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
          New Chat
        </Button>
      </div>

      {/* Proactive Suggestions Panel */}
      {showProactiveSuggestions && proactiveSuggestions.length > 0 && (
        <div className="border-b bg-gradient-to-r from-orange-50 to-amber-50 p-3 md:p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#F5A623]" />
              <h3 className="text-sm font-semibold text-gray-900">Smart Suggestions</h3>
              <Badge variant="secondary" className="text-xs">{proactiveSuggestions.length}</Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowProactiveSuggestions(false)}
              className="h-6 text-xs"
            >
              Hide
            </Button>
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {proactiveSuggestions.slice(0, 5).map((suggestion, idx) => (
              <Card
                key={idx}
                className={`p-3 cursor-pointer hover:shadow-md transition-all border-l-4 ${
                  suggestion.priority === 'urgent' ? 'border-l-red-500 bg-red-50' :
                  suggestion.priority === 'high' ? 'border-l-orange-500 bg-orange-50' :
                  suggestion.priority === 'medium' ? 'border-l-yellow-500 bg-yellow-50' :
                  'border-l-blue-500 bg-blue-50'
                }`}
                onClick={() => {
                  const actionText = suggestion.type === 'recurring_task'
                    ? `Create a recurring task: ${suggestion.action.task_title} every ${suggestion.action.frequency} days`
                    : suggestion.type === 'health_alert'
                    ? `Create health record for #${suggestion.action.animal_name}: ${suggestion.action.record_type}`
                    : `Create task: ${suggestion.action.task_title}`;
                  setInput(actionText);
                  setShowProactiveSuggestions(false);
                }}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900">{suggestion.title}</p>
                    <p className="text-xs text-gray-600 mt-1">{suggestion.description}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0" />
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Conversation List */}
      {showConversations && (
        <div className="border-b bg-white max-h-48 md:max-h-64 overflow-y-auto">
          {conversations.length > 0 ? (
            conversations.map((conv) => (
              <div
                key={conv.id}
                onClick={() => handleSelectConversation(conv)}
                className={`p-2 md:p-3 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                  currentConversationId === conv.id ? 'bg-blue-50 border-l-4 border-l-[#F5A623]' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-xs md:text-sm text-gray-900 truncate">{conv.title}</p>
                    <p className="text-[10px] md:text-xs text-gray-500 truncate">{conv.last_message_preview}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5 md:mt-1">
                      {format(new Date(conv.updated_date), 'MMM d, h:mm a')}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => handleDeleteConversation(e, conv.id)}
                    className="h-6 w-6 md:h-8 md:w-8 text-gray-400 hover:text-red-500 flex-shrink-0"
                  >
                    <Trash2 className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 md:p-6 text-center text-xs md:text-sm text-gray-500">
              No previous conversations
            </div>
          )}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 md:p-4 space-y-3 md:space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-8 md:py-12 px-4">
            <Sparkles className="w-10 h-10 md:w-12 md:h-12 text-[#F5A623] mx-auto mb-3 md:mb-4" />
            <h3 className="text-lg md:text-xl font-bold mb-2">Ranch Assist</h3>
            <p className="text-sm md:text-base text-gray-600 mb-4">Ask me anything about your ranch data</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-w-2xl mx-auto text-left">
              <Card className="p-2.5 md:p-3 cursor-pointer hover:bg-gray-50 active:bg-gray-100" onClick={() => setInput('Show me expenses for /feed in @last30d')}>
                <p className="text-xs md:text-sm font-medium">Feed expenses last 30 days</p>
                <p className="text-[10px] md:text-xs text-gray-500 mt-0.5 md:mt-1 truncate">Show me expenses for /feed in @last30d</p>
              </Card>
              <Card className="p-2.5 md:p-3 cursor-pointer hover:bg-gray-50 active:bg-gray-100" onClick={() => setInput('How is #29 doing?')}>
                <p className="text-xs md:text-sm font-medium">Animal health check</p>
                <p className="text-[10px] md:text-xs text-gray-500 mt-0.5 md:mt-1 truncate">How is #29 doing?</p>
              </Card>
              <Card className="p-2.5 md:p-3 cursor-pointer hover:bg-gray-50 active:bg-gray-100" onClick={() => setInput('What is the stocking rate for ~North40?')}>
                <p className="text-xs md:text-sm font-medium">Pasture utilization</p>
                <p className="text-[10px] md:text-xs text-gray-500 mt-0.5 md:mt-1 truncate">What is the stocking rate for ~North40?</p>
              </Card>
              <Card className="p-2.5 md:p-3 cursor-pointer hover:bg-gray-50 active:bg-gray-100" onClick={() => setInput('Show /netprofit for @2025Q1')}>
                <p className="text-xs md:text-sm font-medium">Quarterly profitability</p>
                <p className="text-[10px] md:text-xs text-gray-500 mt-0.5 md:mt-1 truncate">Show /netprofit for @2025Q1</p>
              </Card>
            </div>
          </div>
        )}

        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <Card className={`max-w-[85%] md:max-w-[80%] ${message.role === 'user' ? 'bg-[#F5A623] text-white' : 'bg-white'} ${message.error ? 'border-red-300' : ''}`}>
              <CardContent className="p-3 md:p-4">
                {message.role === 'assistant' ? (
                  <div className="prose prose-sm md:prose-base max-w-none text-sm md:text-base">
                    <ReactMarkdown>{message.content}</ReactMarkdown>
                    
                    {message.type === 'action_proposal' && message.proposal && (
                      <div className="mt-3 md:mt-4 p-3 md:p-4 bg-orange-50 border-2 border-[#F5A623] rounded-lg">
                        <div className="flex gap-2 mb-3">
                          <Button
                            onClick={() => handleConfirmAction(message.proposal)}
                            className="flex-1 bg-[#F5A623] hover:bg-[#E09612] text-white"
                            disabled={loading}
                          >
                            ✓ Confirm
                          </Button>
                          <Button
                            onClick={handleCancelAction}
                            variant="outline"
                            className="flex-1"
                            disabled={loading}
                          >
                            ✗ Cancel
                          </Button>
                        </div>
                      </div>
                    )}
                    
                    {message.links && message.links.length > 0 && (
                      <div className="mt-3 md:mt-4 space-y-2">
                        {message.links.map((link, idx) => (
                          <Button
                            key={idx}
                            variant="outline"
                            size="sm"
                            className="w-full justify-between text-xs md:text-sm"
                            onClick={() => handleLinkClick(link.url)}
                          >
                            <span className="truncate">{link.label}</span>
                            <ExternalLink className="w-3 h-3 ml-2 flex-shrink-0" />
                          </Button>
                        ))}
                      </div>
                    )}

                    {message.data && (
                      <div className="mt-3 p-2 md:p-3 bg-gray-50 rounded-lg">
                        <div className="flex flex-wrap gap-1.5 md:gap-2">
                          {Object.entries(message.data).map(([key, value]) => (
                            <Badge key={key} variant="secondary" className="text-[10px] md:text-xs">
                              {key}: {typeof value === 'number' ? value.toLocaleString() : value}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-xs md:text-sm">{message.content}</p>
                )}
              </CardContent>
            </Card>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <Card className="bg-white">
              <CardContent className="p-4 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm text-gray-600">Analyzing...</span>
              </CardContent>
            </Card>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t p-3 md:p-4 bg-white relative">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              placeholder="Ask about your ranch..."
              disabled={loading}
              className="pr-2 md:pr-10 text-sm md:text-base h-10 md:h-auto"
            />
            <div className="hidden md:flex absolute right-2 top-1/2 -translate-y-1/2 gap-1">
              <Badge variant="outline" className="text-xs">
                # Animals
              </Badge>
              <Badge variant="outline" className="text-xs">
                ~ Pastures
              </Badge>
            </div>
          </div>
          <Button type="submit" disabled={loading || !input.trim()} className="bg-[#F5A623] hover:bg-[#E09612] h-10 md:h-auto px-3 md:px-4">
            <Send className="w-4 h-4" />
          </Button>
        </form>
        
        <div className="flex md:hidden gap-1 mt-2 text-[10px] text-gray-500">
          <span># Animals</span>
          <span>•</span>
          <span>~ Pastures</span>
          <span>•</span>
          <span>/ Categories</span>
          <span>•</span>
          <span>@ Dates</span>
        </div>

        {showSuggestions && (
          <InlineSuggestions
            trigger={suggestionTrigger}
            searchTerm={suggestionSearch}
            position={suggestionPosition}
            onSelect={handleSuggestionSelect}
            onClose={() => setShowSuggestions(false)}
            ranchId={ranchId}
          />
        )}
      </div>
    </div>
  );
}