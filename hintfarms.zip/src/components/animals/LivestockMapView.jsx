import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, MapPin, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function LivestockMapView({ animals, pastures, onViewDetails }) {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const markers = useRef({});
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapboxToken, setMapboxToken] = useState(null);

  // Fetch Mapbox token
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const response = await base44.functions.invoke('getMapboxToken', {});
        if (response.data?.token) {
          setMapboxToken(response.data.token);
        }
      } catch (error) {
        console.error('Failed to fetch Mapbox token:', error);
      }
    };
    fetchToken();
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapboxToken || map.current) return;

    const link = document.createElement('link');
    link.href = 'https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    const script = document.createElement('script');
    script.src = 'https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.js';
    script.async = true;
    script.onload = () => {
      window.mapboxgl.accessToken = mapboxToken;

      // Find animals with pasture locations
      const animalsWithLocation = animals.filter(a => {
        const pasture = pastures.find(p => p.id === a.pasture_id);
        return pasture && pasture.lat && pasture.lon;
      });

      let center = [-98.5795, 39.8283];
      let zoom = 4;

      if (animalsWithLocation.length > 0) {
        const pasture = pastures.find(p => p.id === animalsWithLocation[0].pasture_id);
        center = [pasture.lon, pasture.lat];
        zoom = 10;
      }

      map.current = new window.mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/satellite-streets-v12',
        center: center,
        zoom: zoom,
      });

      map.current.addControl(new window.mapboxgl.NavigationControl());
      map.current.on('load', () => setMapLoaded(true));
    };

    document.body.appendChild(script);

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, [mapboxToken]);

  // Add markers
  useEffect(() => {
    if (!mapLoaded || !map.current) return;

    // Clear existing markers
    Object.values(markers.current).forEach(marker => marker.remove());
    markers.current = {};

    // Group animals by pasture
    const animalsByPasture = {};
    animals.forEach(animal => {
      if (animal.pasture_id) {
        if (!animalsByPasture[animal.pasture_id]) {
          animalsByPasture[animal.pasture_id] = [];
        }
        animalsByPasture[animal.pasture_id].push(animal);
      }
    });

    // Create markers for each pasture with animals
    Object.entries(animalsByPasture).forEach(([pastureId, pastureAnimals]) => {
      const pasture = pastures.find(p => p.id === pastureId);
      if (!pasture || !pasture.lat || !pasture.lon) return;

      const healthColors = {
        "Healthy": "#10b981",
        "Under Treatment": "#f59e0b",
        "Urgent Attention": "#ef4444",
        "Recovering": "#3b82f6"
      };

      const healthIssues = pastureAnimals.filter(a => a.health_status !== 'Healthy').length;
      const markerColor = healthIssues > 0 ? '#f59e0b' : '#10b981';

      const el = document.createElement('div');
      el.className = 'livestock-marker';
      el.style.cssText = `
        background-color: ${markerColor};
        width: 36px;
        height: 36px;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: white;
        font-size: 14px;
      `;
      el.innerHTML = pastureAnimals.length;

      const popupContent = `
        <div class="p-3 min-w-[280px]">
          <h3 class="font-bold text-lg mb-2">${pasture.name}</h3>
          <p class="text-sm text-gray-600 mb-3">${pastureAnimals.length} animal${pastureAnimals.length !== 1 ? 's' : ''} in this pasture</p>
          ${healthIssues > 0 ? `<p class="text-sm text-orange-600 mb-3">⚠️ ${healthIssues} health alert${healthIssues !== 1 ? 's' : ''}</p>` : ''}
          <div class="space-y-2 max-h-60 overflow-y-auto">
            ${pastureAnimals.map(animal => `
              <div class="flex items-center gap-2 p-2 bg-gray-50 rounded border cursor-pointer hover:bg-gray-100" onclick="window.viewAnimalDetails('${animal.id}')">
                <img src="${animal.main_image_url || 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=50&h=50&fit=crop'}" 
                     class="w-10 h-10 rounded-full object-cover" />
                <div class="flex-1">
                  <p class="font-semibold text-sm">${animal.name}</p>
                  <p class="text-xs text-gray-500">${animal.tag_number} • ${animal.type}</p>
                </div>
                <span class="px-2 py-1 rounded text-xs" style="background-color: ${healthColors[animal.health_status]}20; color: ${healthColors[animal.health_status]}">
                  ${animal.health_status}
                </span>
              </div>
            `).join('')}
          </div>
        </div>
      `;

      const popup = new window.mapboxgl.Popup({
        offset: 25,
        closeButton: true,
        maxWidth: '320px'
      }).setHTML(popupContent);

      const marker = new window.mapboxgl.Marker({ element: el })
        .setLngLat([pasture.lon, pasture.lat])
        .setPopup(popup)
        .addTo(map.current);

      markers.current[pastureId] = marker;
    });

    // Fit map to markers
    if (Object.keys(animalsByPasture).length > 0) {
      const bounds = new window.mapboxgl.LngLatBounds();
      Object.entries(animalsByPasture).forEach(([pastureId]) => {
        const pasture = pastures.find(p => p.id === pastureId);
        if (pasture && pasture.lat && pasture.lon) {
          bounds.extend([pasture.lon, pasture.lat]);
        }
      });
      map.current.fitBounds(bounds, { padding: 100, maxZoom: 14 });
    }
  }, [animals, pastures, mapLoaded]);

  // Global handler for viewing animal details
  useEffect(() => {
    window.viewAnimalDetails = (animalId) => {
      const animal = animals.find(a => a.id === animalId);
      if (animal && onViewDetails) {
        onViewDetails(animal);
      }
    };

    return () => {
      delete window.viewAnimalDetails;
    };
  }, [animals, onViewDetails]);

  const animalsWithoutLocation = animals.filter(a => {
    if (!a.pasture_id) return true;
    const pasture = pastures.find(p => p.id === a.pasture_id);
    return !pasture || !pasture.lat || !pasture.lon;
  });

  if (!mapboxToken) {
    return (
      <Card className="border-none shadow-lg">
        <CardContent className="p-12 text-center">
          <p className="text-gray-500">Loading map...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="border-none shadow-lg overflow-hidden">
        <div ref={mapContainer} className="w-full h-[600px]" />
      </Card>

      {animalsWithoutLocation.length > 0 && (
        <Card className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950/50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 dark:text-orange-400 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-orange-900 dark:text-orange-100 mb-1">
                  {animalsWithoutLocation.length} animal{animalsWithoutLocation.length !== 1 ? 's' : ''} not shown
                </p>
                <p className="text-sm text-orange-700 dark:text-orange-300">
                  Animals without a pasture location are not displayed on the map. 
                  Assign them to a pasture with GPS coordinates to see them here.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-green-500"></div>
          <span className="text-gray-600 dark:text-gray-400">All Healthy</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-orange-500"></div>
          <span className="text-gray-600 dark:text-gray-400">Health Alerts</span>
        </div>
      </div>
    </div>
  );
}