import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  RefreshCw,
  Unlink,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles
} from "lucide-react";
import { format } from "date-fns";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

export default function BankingManagement() {
  const [connecting, setConnecting] = useState(false);
  const [stripeLoaded, setStripeLoaded] = useState(false);
  const [publishableKey, setPublishableKey] = useState(null);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  const { data: connections = [], refetch: refetchConnections } = useQuery({
    queryKey: ['bankConnections', user?.active_ranch_id],
    queryFn: () => base44.entities.BankConnection.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  // Fetch Stripe publishable key
  useEffect(() => {
    const fetchKey = async () => {
      try {
        const response = await base44.functions.invoke('getStripePublishableKey', {});
        if (response.data?.publishableKey) {
          setPublishableKey(response.data.publishableKey);
        }
      } catch (error) {
        console.error('Failed to fetch Stripe key:', error);
      }
    };
    
    if (user) {
      fetchKey();
    }
  }, [user]);

  // Load Stripe.js from CDN
  useEffect(() => {
    if (window.Stripe) {
      setStripeLoaded(true);
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://js.stripe.com/v3/';
    script.async = true;
    script.onload = () => setStripeLoaded(true);
    document.body.appendChild(script);

    return () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, []);

  const syncMutation = useMutation({
    mutationFn: (connectionId) => {
      // Generate unique sync run ID for this manual refresh
      const bank_sync_id = crypto.randomUUID();
      console.log('Starting manual sync with ID:', bank_sync_id);
      
      return base44.functions.invoke('syncBankTransactions', { 
        connection_id: connectionId,
        bank_sync_id: bank_sync_id
      });
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['bankConnections'] });
      queryClient.invalidateQueries({ queryKey: ['bankTransactions'] });
      
      // Check if there's a specific message (e.g., no transactions available)
      if (response.data.message) {
        const event = new CustomEvent('showToast', {
          detail: { message: response.data.message, type: 'info' }
        });
        window.dispatchEvent(event);
      } else if (response.data.new_transactions > 0) {
        const event = new CustomEvent('showToast', {
          detail: { 
            message: `Synced ${response.data.new_transactions} new transaction${response.data.new_transactions !== 1 ? 's' : ''}!`, 
            type: 'success' 
          }
        });
        window.dispatchEvent(event);
      } else {
        const event = new CustomEvent('showToast', {
          detail: { message: 'No new transactions found', type: 'info' }
        });
        window.dispatchEvent(event);
      }
    },
    onError: (error) => {
      console.error('Sync error:', error);
      const event = new CustomEvent('showToast', {
        detail: { message: `Sync failed: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const disconnectMutation = useMutation({
    mutationFn: (connectionId) => base44.entities.BankConnection.update(connectionId, { 
      status: 'disconnected',
      sync_enabled: false 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankConnections'] });
      const event = new CustomEvent('showToast', {
        detail: { message: 'Bank account disconnected', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const handleConnectBank = async () => {
    if (!stripeLoaded) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Stripe is still loading, please wait...', type: 'info' }
      });
      window.dispatchEvent(event);
      return;
    }

    if (!publishableKey) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Stripe configuration missing. Please contact support.', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }

    setConnecting(true);
    try {
      console.log('Creating Financial Connections session...');
      const response = await base44.functions.invoke('createFinancialConnectionsSession', {});
      
      console.log('Session response:', response);
      
      if (response.data?.error) {
        throw new Error(response.data.error);
      }

      const { client_secret } = response.data;

      if (!client_secret) {
        throw new Error('No client secret returned from backend');
      }

      console.log('Initializing Stripe with key:', publishableKey.substring(0, 20) + '...');
      const stripe = window.Stripe(publishableKey);

      if (!stripe) {
        throw new Error('Failed to initialize Stripe');
      }

      console.log('Opening Financial Connections flow...');
      const { financialConnectionsSession, error } = await stripe.collectFinancialConnectionsAccounts({
        clientSecret: client_secret,
      });

      if (error) {
        throw new Error(error.message);
      }

      console.log('Financial Connections session completed:', financialConnectionsSession);
      
      // Wait a moment for webhook to process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Refresh connections list
      await queryClient.invalidateQueries({ queryKey: ['bankConnections'] });
      await refetchConnections();
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Bank account connected successfully! Syncing transactions...', type: 'success' }
      });
      window.dispatchEvent(event);

    } catch (error) {
      console.error('Connect bank error:', error);
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to connect: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    } finally {
      setConnecting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Feature Description */}
      <Alert className="border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950/50">
        <Sparkles className="h-4 w-4 text-blue-600 dark:text-blue-400" />
        <AlertTitle className="text-blue-800 dark:text-blue-100">Automatic Transaction Import</AlertTitle>
        <AlertDescription className="text-blue-700 dark:text-blue-200">
          Connect your ranch bank account to automatically import transactions into your Financials. 
          Review and categorize imported transactions before they're added to your records.
        </AlertDescription>
      </Alert>

      {/* Connect Button */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold dark:text-gray-100">Connected Bank Accounts</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {connections.length} account{connections.length !== 1 ? 's' : ''} connected
          </p>
        </div>
        <Button 
          onClick={handleConnectBank}
          disabled={connecting || !stripeLoaded || !publishableKey}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {connecting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Connecting...
            </>
          ) : !stripeLoaded ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Loading Stripe...
            </>
          ) : !publishableKey ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Loading Config...
            </>
          ) : (
            <>
              <Building2 className="w-4 h-4 mr-2" />
              Connect Bank Account
            </>
          )}
        </Button>
      </div>

      {/* Connections List */}
      <div className="space-y-4">
        {connections.map(connection => (
          <Card key={connection.id} className={connection.status === 'disconnected' ? 'opacity-60 dark:bg-gray-950' : 'dark:bg-gray-950'}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-xl flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <CardTitle className="text-lg dark:text-gray-100">{connection.institution_name}</CardTitle>
                    <CardDescription className="dark:text-gray-400">
                      {connection.account_type} •••• {connection.account_last4}
                    </CardDescription>
                  </div>
                </div>
                <Badge className={
                  connection.status === 'active' 
                    ? 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800' 
                    : connection.status === 'disconnected'
                      ? 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700'
                      : 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800'
                }>
                  {connection.status === 'active' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                  {connection.status === 'error' && <AlertCircle className="w-3 h-3 mr-1" />}
                  {connection.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Balance</p>
                  <p className="text-lg font-semibold dark:text-gray-100">
                    ${connection.balance != null ? connection.balance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : '0.00'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Last Synced</p>
                  <p className="text-sm font-medium dark:text-gray-200">
                    {connection.last_sync_at 
                      ? format(new Date(connection.last_sync_at), 'MMM d, yyyy h:mm a')
                      : 'Never'
                    }
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Auto-Sync</p>
                  <p className="text-sm font-medium dark:text-gray-200">
                    {connection.sync_enabled ? 'Enabled' : 'Disabled'}
                  </p>
                </div>
              </div>
              
              {connection.status === 'active' && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => syncMutation.mutate(connection.id)}
                    disabled={syncMutation.isPending}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (confirm('Are you sure you want to disconnect this account? Transaction syncing will stop.')) {
                        disconnectMutation.mutate(connection.id);
                      }
                    }}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    <Unlink className="w-4 h-4 mr-2" />
                    Disconnect
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {connections.length === 0 && (
        <Card className="dark:bg-gray-950">
          <CardContent className="p-12 text-center">
            <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Accounts Connected</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4">
              Connect your bank account to automatically import transactions
            </p>
            <Button onClick={handleConnectBank} disabled={connecting || !stripeLoaded}>
              <Building2 className="w-4 h-4 mr-2" />
              Connect Your First Account
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}