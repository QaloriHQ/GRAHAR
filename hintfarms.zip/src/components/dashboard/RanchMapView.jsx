import React, { useEffect, useRef, useState } from 'react';
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import { Loader2, Maximize2, X, Locate } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function RanchMapView({ pastures }) {
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);
  const [mapboxToken, setMapboxToken] = useState(null);
  const [mapboxLoaded, setMapboxLoaded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedPasture, setSelectedPasture] = useState(null);
  const [hoveredPasture, setHoveredPasture] = useState(null);
  const navigate = useNavigate();

  // Handle escape key to exit fullscreen
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isFullscreen]);

  // Fetch Mapbox access token
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const response = await base44.functions.invoke('getMapboxToken', {});
        if (response.data?.token) {
          setMapboxToken(response.data.token);
        }
      } catch (error) {
        console.error('Failed to fetch Mapbox token:', error);
      }
    };
    
    fetchToken();
  }, []);

  // Load Mapbox GL JS from CDN
  useEffect(() => {
    if (window.mapboxgl) {
      setMapboxLoaded(true);
      return;
    }

    const link = document.createElement('link');
    link.href = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    const script = document.createElement('script');
    script.src = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js';
    script.async = true;
    script.onload = () => setMapboxLoaded(true);
    document.body.appendChild(script);

    return () => {
      if (link.parentNode) link.parentNode.removeChild(link);
      if (script.parentNode) script.parentNode.removeChild(script);
    };
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapboxLoaded || !mapboxToken || !mapContainerRef.current || mapRef.current) return;

    // Find center point from pastures with coordinates
    const pasturesWithCoords = pastures.filter(p => p.lat && p.lon);
    
    let center = [-98.5795, 39.8283]; // Center of USA as default
    let zoom = 4;

    if (pasturesWithCoords.length > 0) {
      const avgLat = pasturesWithCoords.reduce((sum, p) => sum + p.lat, 0) / pasturesWithCoords.length;
      const avgLon = pasturesWithCoords.reduce((sum, p) => sum + p.lon, 0) / pasturesWithCoords.length;
      center = [avgLon, avgLat];
      zoom = 12;
    }

    window.mapboxgl.accessToken = mapboxToken;

    const map = new window.mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/satellite-streets-v12',
      center: center,
      zoom: zoom,
      attributionControl: false
    });

    map.addControl(new window.mapboxgl.NavigationControl(), 'top-right');

    map.once('load', () => {
      // Ensure map resizes properly after load
      setTimeout(() => {
        map.resize();
      }, 100);
      // Add pasture boundaries
      pasturesWithCoords.forEach((pasture) => {
        if (pasture.fence_coordinates && pasture.fence_coordinates.length > 0) {
          const sourceId = `pasture-${pasture.id}`;

          map.addSource(sourceId, {
            type: 'geojson',
            data: {
              type: 'Feature',
              properties: {
                id: pasture.id,
                name: pasture.name,
                size_acres: pasture.size_acres,
                current_animal_count: pasture.current_animal_count || 0,
                condition: pasture.condition,
                grazing_quality: pasture.grazing_quality
              },
              geometry: {
                type: 'Polygon',
                coordinates: [pasture.fence_coordinates]
              }
            }
          });

          map.addLayer({
            id: `${sourceId}-fill`,
            type: 'fill',
            source: sourceId,
            paint: {
              'fill-color': pasture.fence_color || '#10b981',
              'fill-opacity': [
                'case',
                ['boolean', ['feature-state', 'selected'], false],
                0.5,
                ['boolean', ['feature-state', 'hover'], false],
                0.35,
                0.2
              ]
            }
          });

          map.addLayer({
            id: `${sourceId}-outline`,
            type: 'line',
            source: sourceId,
            paint: {
              'line-color': pasture.fence_color || '#10b981',
              'line-width': [
                'case',
                ['boolean', ['feature-state', 'selected'], false],
                4,
                ['boolean', ['feature-state', 'hover'], false],
                3,
                2
              ]
            }
          });

          // Add hover effect
          map.on('mouseenter', `${sourceId}-fill`, (e) => {
            map.getCanvas().style.cursor = 'pointer';
            if (e.features.length > 0) {
              const feature = e.features[0];
              map.setFeatureState(
                { source: sourceId, id: feature.id },
                { hover: true }
              );
              setHoveredPasture(feature.properties.id);
            }
          });

          map.on('mouseleave', `${sourceId}-fill`, () => {
            map.getCanvas().style.cursor = '';
            if (hoveredPasture) {
              map.setFeatureState(
                { source: sourceId, id: hoveredPasture },
                { hover: false }
              );
              setHoveredPasture(null);
            }
          });

          // Add click handler
          map.on('click', `${sourceId}-fill`, (e) => {
            if (e.features.length > 0) {
              const feature = e.features[0];
              const properties = feature.properties;

              // Clear previous selection
              pasturesWithCoords.forEach((p) => {
                map.setFeatureState(
                  { source: `pasture-${p.id}`, id: p.id },
                  { selected: false }
                );
              });

              // Set new selection
              map.setFeatureState(
                { source: sourceId, id: properties.id },
                { selected: true }
              );

              setSelectedPasture({
                id: properties.id,
                name: properties.name,
                size_acres: properties.size_acres,
                current_animal_count: properties.current_animal_count,
                condition: properties.condition,
                grazing_quality: properties.grazing_quality
              });
            }
          });
        }

        // Add marker for pasture
        if (pasture.lat && pasture.lon) {
          const marker = document.createElement('div');
          marker.className = 'mapbox-marker';
          marker.style.cssText = `
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: ${pasture.fence_color || '#10b981'};
            border: 3px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            cursor: pointer;
          `;

          const popup = new window.mapboxgl.Popup({ offset: 25 })
            .setHTML(`
              <div style="padding: 8px;">
                <h3 style="font-weight: bold; margin-bottom: 4px;">${pasture.name}</h3>
                <p style="font-size: 12px; color: #666;">
                  ${pasture.size_acres} acres<br/>
                  ${pasture.current_animal_count || 0} animals
                </p>
              </div>
            `);

          new window.mapboxgl.Marker(marker)
            .setLngLat([pasture.lon, pasture.lat])
            .setPopup(popup)
            .addTo(map);
        }
      });

      // Fit bounds to show all pastures
      if (pasturesWithCoords.length > 1) {
        const bounds = new window.mapboxgl.LngLatBounds();
        pasturesWithCoords.forEach(p => bounds.extend([p.lon, p.lat]));
        map.fitBounds(bounds, { padding: 50 });
      }
    });

    mapRef.current = map;

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [mapboxLoaded, mapboxToken, pastures]);

  const toggleFullscreen = () => {
    const newFullscreenState = !isFullscreen;
    setIsFullscreen(newFullscreenState);
    
    if (newFullscreenState) {
      // Entering fullscreen
      document.body.style.overflow = 'hidden';
      setTimeout(() => {
        if (mapRef.current) {
          mapRef.current.resize();
        }
      }, 150);
    } else {
      // Exiting fullscreen
      document.body.style.overflow = '';
      setTimeout(() => {
        if (mapRef.current) {
          mapRef.current.resize();
        }
      }, 150);
    }
  };

  const handleLocateMe = () => {
    if (!mapRef.current) return;
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          mapRef.current.flyTo({
            center: [longitude, latitude],
            zoom: 14,
            duration: 2000
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Unable to get your location. Please enable location services.');
        }
      );
    } else {
      alert('Geolocation is not supported by your browser.');
    }
  };

  const handleViewPasture = () => {
    if (selectedPasture) {
      navigate(createPageUrl("PastureProfile") + `?id=${selectedPasture.id}`);
    }
  };

  const clearSelection = () => {
    setSelectedPasture(null);
    if (mapRef.current) {
      pastures.forEach((p) => {
        try {
          const sourceId = `pasture-${p.id}`;
          if (mapRef.current.getSource(sourceId)) {
            mapRef.current.setFeatureState(
              { source: sourceId },
              { selected: false }
            );
          }
        } catch (e) {
          // Ignore errors for pastures without features
        }
      });
    }
  };

  // Calculate polygon area in acres
  const calculatePolygonArea = (coordinates) => {
    if (!coordinates || coordinates.length < 3) return null;
    
    // Convert to radians
    const toRad = (deg) => deg * Math.PI / 180;
    
    // Calculate area using spherical excess (for small areas)
    let area = 0;
    const R = 6371000; // Earth's radius in meters
    
    for (let i = 0; i < coordinates.length; i++) {
      const p1 = coordinates[i];
      const p2 = coordinates[(i + 1) % coordinates.length];
      
      area += toRad(p2[0] - p1[0]) * (2 + Math.sin(toRad(p1[1])) + Math.sin(toRad(p2[1])));
    }
    
    area = Math.abs(area * R * R / 2.0);
    
    // Convert square meters to acres (1 acre = 4046.86 square meters)
    const acres = area / 4046.86;
    return acres;
  };

  // Get full pasture data for selected pasture
  const getFullPastureData = () => {
    if (!selectedPasture) return null;
    return pastures.find(p => p.id === selectedPasture.id);
  };

  if (!mapboxToken || !mapboxLoaded) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <>
      <div 
        className={`relative transition-all duration-300 ${
          isFullscreen 
            ? '' 
            : 'h-full min-h-[400px]'
        }`}
        style={isFullscreen ? {
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          width: '100vw',
          height: '100vh',
          zIndex: 30,
          backgroundColor: 'white'
        } : {}}
      >
        <div 
          ref={mapContainerRef} 
          className={`w-full ${isFullscreen ? 'h-screen' : 'h-full'}`}
          style={{ minHeight: isFullscreen ? '100vh' : '400px' }}
        />
        
        {/* Map Controls - Top Left */}
        <div className="absolute top-4 left-4 flex flex-col gap-2" style={{ zIndex: 31 }}>
          <Button
            onClick={toggleFullscreen}
            size="icon"
            variant="secondary"
            className="shadow-lg hover:shadow-xl transition-shadow bg-white hover:bg-gray-100"
            title={isFullscreen ? "Exit fullscreen (Esc)" : "Enter fullscreen"}
          >
            {isFullscreen ? <X className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </Button>
          <Button
            onClick={handleLocateMe}
            size="icon"
            variant="secondary"
            className="shadow-lg hover:shadow-xl transition-shadow bg-white hover:bg-gray-100"
            title="Find my location"
          >
            <Locate className="w-5 h-5" />
          </Button>
        </div>

        {/* Pasture Detail Popup */}
        {selectedPasture && (() => {
          const fullPasture = getFullPastureData();
          const calculatedAcres = fullPasture?.fence_coordinates 
            ? calculatePolygonArea(fullPasture.fence_coordinates)
            : null;
          const utilizationRate = fullPasture?.capacity 
            ? ((fullPasture.current_animal_count || 0) / fullPasture.capacity * 100).toFixed(0)
            : null;
          
          return (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[90%] max-w-[340px] md:left-4 md:translate-x-0 md:w-[340px] bg-white rounded-xl shadow-2xl p-4 border border-gray-200 animate-in slide-in-from-bottom-4 duration-300" style={{ zIndex: 32 }}>
              <button
                onClick={clearSelection}
                className="absolute top-2 right-2 text-gray-400 hover:text-gray-600 transition-colors p-1 hover:bg-gray-100 rounded-full"
                title="Close"
              >
                <X className="w-3 h-3" />
              </button>
              
              <div className="flex items-center gap-2 mb-3">
                <div 
                  className="w-3 h-3 rounded-full ring-2 ring-white shadow"
                  style={{ backgroundColor: fullPasture?.fence_color || '#10b981' }}
                />
                <h3 className="font-bold text-base text-gray-900">{selectedPasture.name}</h3>
              </div>
              
              <div className="space-y-2 mb-3">
                {/* Primary stats */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-2">
                    <p className="text-[10px] text-blue-600 font-medium mb-0.5">Size</p>
                    <p className="text-lg font-bold text-blue-900">{selectedPasture.size_acres}</p>
                    <p className="text-[10px] text-blue-700">acres</p>
                    {calculatedAcres && (
                      <p className="text-[10px] text-blue-600 mt-0.5">
                        Fenced: {calculatedAcres.toFixed(1)} ac
                      </p>
                    )}
                  </div>
                  <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-2">
                    <p className="text-[10px] text-orange-600 font-medium mb-0.5">Animals</p>
                    <p className="text-lg font-bold text-orange-900">{selectedPasture.current_animal_count || 0}</p>
                    <p className="text-[10px] text-orange-700">head</p>
                  </div>
                </div>

                {/* Capacity and utilization */}
                {fullPasture?.capacity && (
                  <div className="bg-gray-50 rounded-lg p-2">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] text-gray-600 font-medium">Capacity</span>
                      <span className="text-xs font-bold text-gray-900">
                        {fullPasture.current_animal_count || 0} / {fullPasture.capacity}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className={`h-1.5 rounded-full transition-all ${
                          parseInt(utilizationRate) > 100 
                            ? 'bg-red-500' 
                            : parseInt(utilizationRate) > 80 
                            ? 'bg-yellow-500' 
                            : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(parseInt(utilizationRate), 100)}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-gray-500 mt-0.5">{utilizationRate}% utilized</p>
                  </div>
                )}

                {/* Conditions & Type */}
                <div className="flex gap-2 flex-wrap">
                  {selectedPasture.condition && (
                    <span className={`inline-block text-[10px] font-semibold px-2 py-1 rounded ${
                      selectedPasture.condition === 'Good' 
                        ? 'bg-green-100 text-green-800' 
                        : selectedPasture.condition === 'Fair'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedPasture.condition}
                    </span>
                  )}
                  {selectedPasture.grazing_quality && (
                    <span className={`inline-block text-[10px] font-semibold px-2 py-1 rounded ${
                      selectedPasture.grazing_quality === 'Excellent' || selectedPasture.grazing_quality === 'Good'
                        ? 'bg-green-100 text-green-800' 
                        : selectedPasture.grazing_quality === 'Fair'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedPasture.grazing_quality}
                    </span>
                  )}
                  {fullPasture?.type && (
                    <span className="inline-block text-[10px] font-medium px-2 py-1 rounded bg-gray-100 text-gray-800">
                      {fullPasture.type}
                    </span>
                  )}
                </div>
              </div>

              <Button
                onClick={handleViewPasture}
                className="w-full bg-[#F5A623] hover:bg-[#E09612] shadow-md hover:shadow-lg transition-all text-sm py-2"
              >
                View Details
              </Button>
            </div>
          );
        })()}

        {/* Fullscreen Instructions Overlay */}
        {isFullscreen && !selectedPasture && (
          <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-4 py-2 rounded-lg text-sm animate-in fade-in duration-500">
            Click any pasture to view details • Press ESC to exit
          </div>
        )}
      </div>
    </>
  );
}