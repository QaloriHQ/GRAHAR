import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import SelectRanchDialog from './SelectRanchDialog';
import { Loader2 } from 'lucide-react';

export default function RanchGuard({ children }) {
  const [showSelectDialog, setShowSelectDialog] = useState(false);
  const [isValidating, setIsValidating] = useState(true);
  const queryClient = useQueryClient();

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: activeRanch, isLoading: ranchLoading } = useQuery({
    queryKey: ['activeRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  const { data: ranchMembers = [], isLoading: membersLoading } = useQuery({
    queryKey: ['userRanchMembers', user?.email?.toLowerCase()],
    queryFn: async () => {
      if (!user?.email) return [];
      
      const userEmail = user.email.toLowerCase();
      console.log('RanchGuard: Fetching RanchMembers for:', userEmail);
      
      // Fetch all active memberships and filter client-side for case-insensitive match
      const allMembers = await base44.entities.RanchMember.filter({ status: 'Active' });
      const userMembers = allMembers.filter(m => m.user_email.toLowerCase() === userEmail);
      
      console.log('RanchGuard: All active members:', allMembers.length);
      console.log('RanchGuard: User members:', userMembers);
      
      return userMembers;
    },
    enabled: !!user?.email,
  });

  const { data: ownedRanches = [], isLoading: ownedLoading } = useQuery({
    queryKey: ['ownedRanches', user?.email?.toLowerCase()],
    queryFn: async () => {
      if (!user?.email) return [];
      
      const userEmail = user.email.toLowerCase();
      console.log('RanchGuard: Fetching owned ranches for:', userEmail);
      
      // Fetch all ranches and filter client-side for case-insensitive match
      const allRanches = await base44.entities.Ranch.list();
      const userRanches = allRanches.filter(r => r.owner_email.toLowerCase() === userEmail);
      
      console.log('RanchGuard: All ranches:', allRanches.length);
      console.log('RanchGuard: User owned ranches:', userRanches);
      
      return userRanches;
    },
    enabled: !!user?.email,
  });

  useEffect(() => {
    const validateRanch = async () => {
      // Wait for all data to load
      if (userLoading || ranchLoading || membersLoading || ownedLoading) {
        console.log('RanchGuard: Still loading data...');
        return;
      }

      setIsValidating(true);

      console.log('RanchGuard: Validating ranch access', {
        user: user?.email,
        active_ranch_id: user?.active_ranch_id,
        activeRanch: activeRanch?.name,
        ownedRanches: ownedRanches.length,
        ranchMembers: ranchMembers.length
      });

      // If no active_ranch_id, show dialog
      if (!user?.active_ranch_id) {
        console.log('RanchGuard: No active_ranch_id set, showing ranch selection dialog');
        setShowSelectDialog(true);
        setIsValidating(false);
        return;
      }

      // If active_ranch_id is set but ranch doesn't exist
      if (user.active_ranch_id && !activeRanch) {
        console.log('RanchGuard: Active ranch not found, showing ranch selection dialog');
        setShowSelectDialog(true);
        setIsValidating(false);
        return;
      }

      // Verify user has access to this ranch (either owner or active member)
      const isOwner = ownedRanches.some(r => r.id === user.active_ranch_id);
      const isMember = ranchMembers.some(m => m.ranch_id === user.active_ranch_id);

      if (!isOwner && !isMember) {
        console.log('RanchGuard: User does not have access to active ranch, showing ranch selection dialog');
        setShowSelectDialog(true);
        setIsValidating(false);
        return;
      }

      // All good, ranch is valid
      console.log('RanchGuard: Ranch context validated:', activeRanch?.name);
      setShowSelectDialog(false);
      setIsValidating(false);
    };

    validateRanch();
  }, [user, activeRanch, ranchMembers, ownedRanches, userLoading, ranchLoading, membersLoading, ownedLoading]);

  const handleRanchSelected = async () => {
    console.log('RanchGuard: Ranch selected, invalidating queries and closing dialog');
    await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    await queryClient.invalidateQueries({ queryKey: ['activeRanch'] });
    await queryClient.invalidateQueries({ queryKey: ['userRanchMembers'] });
    await queryClient.invalidateQueries({ queryKey: ['ownedRanches'] });
    setShowSelectDialog(false);
  };

  // Show loading state while validating
  if (isValidating || userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-[#F5A623] mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading your ranch...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <SelectRanchDialog
        open={showSelectDialog}
        onRanchSelected={handleRanchSelected}
        user={user}
        ownedRanches={ownedRanches}
        ranchMembers={ranchMembers}
      />
      
      {!showSelectDialog && children}
    </>
  );
}