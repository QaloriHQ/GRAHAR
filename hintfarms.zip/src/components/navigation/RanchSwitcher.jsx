import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Plus, Building2, ChevronDown, Check, Loader2, Users } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trackRanchSwitch, trackRanchCreate } from "@/components/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import SelectRanchDialog from './SelectRanchDialog';

export default function RanchSwitcher() {
  const [showSelectDialog, setShowSelectDialog] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: activeRanch } = useQuery({
    queryKey: ['activeRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  const { data: ownedRanches = [] } = useQuery({
    queryKey: ['ownedRanches', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.Ranch.filter({ owner_email: user.email });
    },
    enabled: !!user?.email,
  });

  const { data: ranchMembers = [] } = useQuery({
    queryKey: ['userRanchMembers', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return await base44.entities.RanchMember.filter({ 
        user_email: user.email, 
        status: 'Active' 
      });
    },
    enabled: !!user?.email,
  });

  const { data: teamRanches = [] } = useQuery({
    queryKey: ['teamRanches', ranchMembers],
    queryFn: async () => {
      if (!ranchMembers || ranchMembers.length === 0) return [];
      const ranchIds = ranchMembers.map(m => m.ranch_id);
      const ranches = await Promise.all(
        ranchIds.map(async (id) => {
          const results = await base44.entities.Ranch.filter({ id });
          return results[0];
        })
      );
      return ranches.filter(Boolean);
    },
    enabled: !!ranchMembers && ranchMembers.length > 0,
  });

  const switchRanchMutation = useMutation({
    mutationFn: async (ranchId) => {
      await base44.auth.updateMe({ active_ranch_id: ranchId });
    },
    onSuccess: async (_, ranchId) => {
      // Invalidate all queries to refresh with new ranch context
      await queryClient.invalidateQueries();
      
      // Get the new ranch name
      const newRanch = [...ownedRanches, ...teamRanches].find(r => r.id === ranchId);
      
      const event = new CustomEvent('showToast', {
        detail: { 
          message: `Switched to ${newRanch?.name || 'ranch'}`, 
          type: 'success' 
        }
      });
      window.dispatchEvent(event);

      // Force page reload to ensure all components refresh
      window.location.reload();
    },
  });

  const handleSwitchRanch = (ranchId) => {
    if (ranchId === user?.active_ranch_id) return;
    switchRanchMutation.mutate(ranchId);
  };

  const handleRanchSelected = async () => {
    await queryClient.invalidateQueries();
    setShowSelectDialog(false);
    window.location.reload();
  };

  if (!activeRanch) {
    return (
      <Button variant="outline" className="dark:border-gray-700 dark:text-gray-300">
        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        Loading...
      </Button>
    );
  }

  const allRanches = [...ownedRanches, ...teamRanches];
  const hasMultipleRanches = allRanches.length > 1;

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            className="flex items-center gap-2 bg-[#2a2a2a] border-gray-700 text-gray-100 hover:bg-[#333333] dark:border-gray-700 dark:text-gray-100 dark:hover:bg-gray-800"
          >
            <Building2 className="w-4 h-4" />
            <span className="max-w-[150px] truncate">{activeRanch.name}</span>
            {hasMultipleRanches && <ChevronDown className="w-4 h-4 opacity-50" />}
          </Button>
        </DropdownMenuTrigger>
        
        <DropdownMenuContent align="start" className="w-64 dark:bg-gray-900 dark:border-gray-700">
          <DropdownMenuLabel className="dark:text-gray-400">
            Current Ranch
          </DropdownMenuLabel>
          <DropdownMenuItem className="font-semibold dark:text-gray-100 dark:focus:bg-gray-800">
            <Building2 className="w-4 h-4 mr-2" />
            {activeRanch.name}
            <Check className="w-4 h-4 ml-auto text-[#F5A623]" />
          </DropdownMenuItem>

          {hasMultipleRanches && (
            <>
              <DropdownMenuSeparator className="dark:bg-gray-700" />
              
              {ownedRanches.length > 0 && ownedRanches[0].id !== activeRanch.id && (
                <>
                  <DropdownMenuLabel className="dark:text-gray-400">
                    Your Ranches
                  </DropdownMenuLabel>
                  {ownedRanches
                    .filter(ranch => ranch.id !== activeRanch.id)
                    .map(ranch => (
                      <DropdownMenuItem
                        key={ranch.id}
                        onClick={() => handleSwitchRanch(ranch.id)}
                        className="cursor-pointer dark:text-gray-300 dark:focus:bg-gray-800"
                      >
                        <Building2 className="w-4 h-4 mr-2" />
                        <span className="flex-1">{ranch.name}</span>
                        <Badge variant="outline" className="text-xs dark:border-gray-600">
                          Owner
                        </Badge>
                      </DropdownMenuItem>
                    ))}
                </>
              )}

              {teamRanches.length > 0 && teamRanches.some(r => r.id !== activeRanch.id) && (
                <>
                  <DropdownMenuLabel className="dark:text-gray-400">
                    Teams
                  </DropdownMenuLabel>
                  {teamRanches
                    .filter(ranch => ranch.id !== activeRanch.id)
                    .map(ranch => {
                      const member = ranchMembers.find(m => m.ranch_id === ranch.id);
                      return (
                        <DropdownMenuItem
                          key={ranch.id}
                          onClick={() => handleSwitchRanch(ranch.id)}
                          className="cursor-pointer dark:text-gray-300 dark:focus:bg-gray-800"
                        >
                          <Users className="w-4 h-4 mr-2" />
                          <span className="flex-1">{ranch.name}</span>
                          <Badge variant="outline" className="text-xs dark:border-gray-600">
                            {member?.role || 'Member'}
                          </Badge>
                        </DropdownMenuItem>
                      );
                    })}
                </>
              )}
            </>
          )}

          <DropdownMenuSeparator className="dark:bg-gray-700" />
          <DropdownMenuItem
            onClick={() => setShowSelectDialog(true)}
            className="cursor-pointer dark:text-gray-300 dark:focus:bg-gray-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create or Join Ranch
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {switchRanchMutation.isPending && (
        <div className="fixed inset-0 bg-black/50 z-[9999] flex items-center justify-center">
          <div className="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-xl">
            <Loader2 className="w-8 h-8 animate-spin text-[#F5A623] mx-auto mb-3" />
            <p className="text-sm text-gray-600 dark:text-gray-400">Switching ranch...</p>
          </div>
        </div>
      )}

      <SelectRanchDialog
        open={showSelectDialog}
        onRanchSelected={handleRanchSelected}
        user={user}
        ownedRanches={ownedRanches}
        ranchMembers={ranchMembers}
      />
    </>
  );
}