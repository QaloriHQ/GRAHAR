
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CheckSquare,
  Heart,
  Sprout,
  DollarSign,
  Settings,
  Check,
  Trash2,
  ExternalLink,
  Bell,
  Mail,
  Building2,
  CreditCard,
  Banknote,
  Users,
  AlertCircle,
  X // Added X icon for close button
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";

const typeIcons = {
  Task: CheckSquare,
  Health: Heart,
  Breeding: Sprout,
  Financial: DollarSign,
  System: Settings,
  Invite: Mail,
  Team: Users,
  Billing: CreditCard,
  Banking: Banknote,
  Alert: AlertCircle
};

const typeColors = {
  Task: "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800",
  Health: "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800",
  Breeding: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800",
  Financial: "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
  System: "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600",
  Invite: "bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-900/20 dark:text-indigo-400 dark:border-indigo-800",
  Team: "bg-cyan-100 text-cyan-800 border-cyan-200 dark:bg-cyan-900/20 dark:text-cyan-400 dark:border-cyan-800",
  Billing: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-800",
  Banking: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800",
  Alert: "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800"
};

const priorityColors = {
  Low: "border-l-blue-400",
  Medium: "border-l-yellow-400",
  High: "border-l-orange-400",
  Urgent: "border-l-red-500"
};

export default function NotificationDrawer({ open, onOpenChange }) {
  const queryClient = useQueryClient();
  const [activeScope, setActiveScope] = useState(() => {
    return localStorage.getItem('notificationScope') || 'account';
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  // Fetch notifications for active scope
  const { data: notificationsData, isLoading } = useQuery({
    queryKey: ['notifications', activeScope, user?.active_ranch_id],
    queryFn: async () => {
      const payload = {
        scope: activeScope,
        ranch_id: activeScope === 'ranch' ? user?.active_ranch_id : undefined,
        limit: 50
      };
      const response = await base44.functions.invoke('getNotifications', payload);
      return response.data;
    },
    enabled: !!user && (activeScope === 'account' || !!user?.active_ranch_id),
    refetchInterval: 30000,
  });

  // Fetch unread counts
  const { data: countsData } = useQuery({
    queryKey: ['notificationCounts', user?.active_ranch_id],
    queryFn: async () => {
      const response = await base44.functions.invoke('getUnreadNotificationCounts', {
        ranch_id: user?.active_ranch_id
      });
      return response.data;
    },
    enabled: !!user,
    refetchInterval: 30000,
  });

  const markStatusMutation = useMutation({
    mutationFn: ({ notification_id, action }) => 
      base44.functions.invoke('markNotificationStatus', { notification_id, action }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notificationCounts'] });
    },
  });

  const notifications = notificationsData?.notifications || [];
  const unreadAccount = countsData?.unread_account || 0;
  const unreadRanch = countsData?.unread_ranch || 0;

  const handleScopeChange = (scope) => {
    setActiveScope(scope);
    localStorage.setItem('notificationScope', scope);
  };

  const handleMarkRead = (notificationId) => {
    markStatusMutation.mutate({ notification_id: notificationId, action: 'mark_read' });
  };

  const handleMarkUnread = (notificationId) => {
    markStatusMutation.mutate({ notification_id: notificationId, action: 'mark_unread' });
  };

  const handleArchive = (notificationId) => {
    markStatusMutation.mutate({ notification_id: notificationId, action: 'archive' });
  };

  const handleMarkAllAsRead = () => {
    const unreadNotifs = notifications.filter(n => n.status === 'Unread');
    unreadNotifs.forEach(n => {
      markStatusMutation.mutate({ notification_id: n.id, action: 'mark_read' });
    });
  };

  const filteredNotifications = notifications.filter(n => !n.archived_at);
  const unreadCount = filteredNotifications.filter(n => n.status === 'Unread').length;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:w-[540px] p-0 dark:bg-gray-950 dark:border-gray-800">
        <div className="flex flex-col h-full">
          <SheetHeader className="p-6 border-b bg-white dark:bg-gray-950 dark:border-gray-800 sticky top-0 z-10">
            <div className="flex items-start justify-between mb-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onOpenChange(false)}
                className="h-8 w-8 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </Button>
              <div className="flex-1 mx-4">
                <SheetTitle className="text-2xl font-bold dark:text-gray-100">Notifications</SheetTitle>
                <SheetDescription className="dark:text-gray-400">
                  {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
                </SheetDescription>
              </div>
              <div className="flex gap-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleMarkAllAsRead}
                    className="text-xs dark:text-gray-300"
                  >
                    <Check className="w-3 h-3 mr-1" />
                    Mark all read
                  </Button>
                )}
                <Button variant="outline" size="sm" asChild>
                  <Link to={createPageUrl("Notifications")} onClick={() => onOpenChange(false)}>
                    View All
                  </Link>
                </Button>
              </div>
            </div>

            {/* Scope Toggle */}
            <Tabs value={activeScope} onValueChange={handleScopeChange} className="w-full">
              <TabsList className="w-full grid grid-cols-2 dark:bg-gray-900">
                <TabsTrigger value="account" className="relative dark:data-[state=active]:bg-gray-800 dark:text-gray-300">
                  <Mail className="w-4 h-4 mr-2" />
                  Account
                  {unreadAccount > 0 && (
                    <Badge className="ml-2 bg-red-500 text-white text-xs px-1.5 py-0">
                      {unreadAccount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="ranch" className="relative dark:data-[state=active]:bg-gray-800 dark:text-gray-300">
                  <Building2 className="w-4 h-4 mr-2" />
                  Ranch
                  {unreadRanch > 0 && (
                    <Badge className="ml-2 bg-red-500 text-white text-xs px-1.5 py-0">
                      {unreadRanch}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Ranch Name Display */}
            {activeScope === 'ranch' && ranch && (
              <div className="mt-3 flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                <Building2 className="w-4 h-4" />
                <span>{ranch.name}</span>
              </div>
            )}
          </SheetHeader>

          <ScrollArea className="flex-1">
            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : filteredNotifications.length > 0 ? (
              <div className="p-4 space-y-3">
                {filteredNotifications.map(notification => {
                  const Icon = typeIcons[notification.type] || Bell;
                  return (
                    <div
                      key={notification.id}
                      className={`p-4 rounded-lg border-l-4 ${priorityColors[notification.priority]} ${
                        notification.status === "Unread" ? "bg-blue-50 dark:bg-blue-900/10 border dark:border-blue-800" : "bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800"
                      } hover:shadow-md transition-shadow`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${typeColors[notification.type]}`}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="font-semibold text-gray-900 dark:text-gray-100">{notification.title}</h4>
                              {notification.status === "Unread" && (
                                <Badge className="bg-blue-500 text-white text-xs">New</Badge>
                              )}
                            </div>
                            <div className="flex gap-1">
                              {notification.status === "Unread" ? (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 dark:text-gray-400"
                                  onClick={() => handleMarkRead(notification.id)}
                                >
                                  <Check className="w-3 h-3" />
                                </Button>
                              ) : (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 dark:text-gray-400"
                                  onClick={() => handleMarkUnread(notification.id)}
                                >
                                  <Bell className="w-3 h-3" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-500"
                                onClick={() => handleArchive(notification.id)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className={`${typeColors[notification.type]} text-xs`}>
                                {notification.type}
                              </Badge>
                              {notification.related_record_name && (
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                  • {notification.related_record_name}
                                </span>
                              )}
                            </div>
                            <span className="text-xs text-gray-400 dark:text-gray-500">
                              {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                            </span>
                          </div>
                          {notification.action_url && (
                            <Button variant="link" size="sm" className="px-0 mt-2 h-auto text-xs dark:text-emerald-400" asChild>
                              <Link 
                                to={notification.action_url}
                                onClick={() => {
                                  if (notification.status === "Unread") {
                                    handleMarkRead(notification.id);
                                  }
                                  onOpenChange(false);
                                }}
                              >
                                View Details
                                <ExternalLink className="w-3 h-3 ml-1" />
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center p-6">
                <Bell className="w-16 h-16 text-gray-300 dark:text-gray-600 mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">No notifications</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {activeScope === 'account' 
                    ? "You're all caught up! No account notifications to show."
                    : ranch
                      ? `No ranch notifications for ${ranch.name}.`
                      : "Select a ranch to view notifications."}
                </p>
              </div>
            )}
          </ScrollArea>
        </div>
      </SheetContent>
    </Sheet>
  );
}
