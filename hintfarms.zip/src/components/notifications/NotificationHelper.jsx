// Helper functions for creating notifications across the app
import { base44 } from "@/api/base44Client";

/**
 * Creates an in-app notification
 * @param {Object} params - Notification parameters
 * @returns {Promise<Object>} Created notification
 */
export async function createNotification({
  scope = "ranch", // "ranch" or "account"
  user_id = null,
  ranch_id = null,
  user_email = null,
  title,
  message,
  type, // "Task", "Health", "Breeding", "Financial", "System", "Invite", "Team", "Billing", "Banking", "Alert"
  related_record_id = null,
  related_record_type = null,
  related_record_name = null,
  action_url = null,
  priority = "Medium", // "Low", "Medium", "High", "Urgent"
  audience_role = null,
  audience_permissions = null,
  icon = null,
  severity = "info" // "info", "warning", "error", "success"
}) {
  try {
    const notificationData = {
      scope,
      user_id,
      ranch_id,
      user_email,
      title,
      message,
      type,
      related_record_id,
      related_record_type,
      related_record_name,
      action_url,
      priority,
      audience_role,
      audience_permissions,
      icon,
      severity
    };

    // Remove null/undefined values
    Object.keys(notificationData).forEach(key => {
      if (notificationData[key] === null || notificationData[key] === undefined) {
        delete notificationData[key];
      }
    });

    const notification = await base44.asServiceRole.entities.Notification.create(notificationData);
    return notification;
  } catch (error) {
    console.error('Error creating notification:', error);
    throw error;
  }
}

/**
 * Sends an email notification
 * @param {Object} params - Email parameters
 * @returns {Promise<Object>} Email response
 */
export async function sendEmailNotification({
  to,
  subject,
  body,
  from_name = "HintFarms"
}) {
  try {
    const response = await base44.asServiceRole.integrations.Core.SendEmail({
      from_name,
      to,
      subject,
      body
    });
    return response;
  } catch (error) {
    console.error('Error sending email notification:', error);
    throw error;
  }
}

/**
 * Creates both in-app and email notifications
 * @param {Object} params - Combined notification parameters
 */
export async function notifyUser({
  // In-app notification params
  scope,
  user_id,
  ranch_id,
  user_email,
  title,
  message,
  type,
  related_record_id,
  related_record_type,
  related_record_name,
  action_url,
  priority,
  audience_role,
  audience_permissions,
  icon,
  severity,
  
  // Email params
  sendEmail = true,
  emailSubject = null,
  emailBody = null,
  checkPreferences = true
}) {
  const results = {
    inApp: null,
    email: null
  };

  // Create in-app notification
  try {
    results.inApp = await createNotification({
      scope,
      user_id,
      ranch_id,
      user_email,
      title,
      message,
      type,
      related_record_id,
      related_record_type,
      related_record_name,
      action_url,
      priority,
      audience_role,
      audience_permissions,
      icon,
      severity
    });
  } catch (error) {
    console.error('Failed to create in-app notification:', error);
  }

  // Send email if requested
  if (sendEmail && user_email) {
    try {
      // Check user preferences if needed
      if (checkPreferences) {
        const users = await base44.asServiceRole.entities.User.filter({ email: user_email });
        const user = users?.[0];
        
        if (!user?.email_notifications) {
          console.log('User has email notifications disabled');
          return results;
        }

        // Check specific notification type preferences
        if (type === 'Task' && !user?.task_reminders) return results;
        if (type === 'Health' && !user?.health_alerts) return results;
        if (type === 'Breeding' && !user?.breeding_notifications) return results;
        if (type === 'Financial' && !user?.financial_alerts) return results;
      }

      results.email = await sendEmailNotification({
        to: user_email,
        subject: emailSubject || title,
        body: emailBody || message
      });
    } catch (error) {
      console.error('Failed to send email notification:', error);
    }
  }

  return results;
}

/**
 * Notifies multiple ranch members based on their roles
 * @param {Object} params - Multi-user notification params
 */
export async function notifyRanchRoles({
  ranch_id,
  roles = [], // Array of roles: ["Owner", "Manager", etc.]
  title,
  message,
  type,
  related_record_id,
  related_record_type,
  related_record_name,
  action_url,
  priority,
  icon,
  severity,
  sendEmail = true,
  emailSubject = null,
  emailBody = null
}) {
  try {
    // Get ranch info
    const ranches = await base44.asServiceRole.entities.Ranch.filter({ id: ranch_id });
    const ranch = ranches?.[0];
    
    if (!ranch) {
      console.error('Ranch not found:', ranch_id);
      return;
    }

    // Get all ranch members with matching roles
    const members = await base44.asServiceRole.entities.RanchMember.filter({
      ranch_id,
      status: 'Active'
    });

    // Also notify owner if Owner role is in the list
    const recipientEmails = new Set();
    
    if (roles.includes('Owner') && ranch.owner_email) {
      recipientEmails.add(ranch.owner_email.toLowerCase());
    }

    // Add members with matching roles
    members.forEach(member => {
      if (roles.includes(member.role)) {
        recipientEmails.add(member.user_email.toLowerCase());
      }
    });

    // Send notifications to all recipients
    const promises = Array.from(recipientEmails).map(email =>
      notifyUser({
        scope: 'ranch',
        ranch_id,
        user_email: email,
        title,
        message,
        type,
        related_record_id,
        related_record_type,
        related_record_name,
        action_url,
        priority,
        audience_role: roles.join(','),
        icon,
        severity,
        sendEmail,
        emailSubject,
        emailBody,
        checkPreferences: true
      })
    );

    await Promise.allSettled(promises);
  } catch (error) {
    console.error('Error notifying ranch roles:', error);
  }
}