import React, { useEffect, useRef, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, MapPin, AlertCircle, Move, Square, Edit3, Maximize2, Minimize2, X } from "lucide-react";
import { toast } from "sonner";

export default function MapboxPastureMap({ pastures, onViewDetails, onMarkerDragEnd, onFenceUpdate, mapboxToken, allowDrawing = true }) {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const markers = useRef({});
  const draw = useRef(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [drawMode, setDrawMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentDrawingId, setCurrentDrawingId] = useState(null);
  const lastPasturesRef = useRef({});
  const isUpdatingRef = useRef(false);
  const onMarkerDragEndRef = useRef(onMarkerDragEnd);
  const onFenceUpdateRef = useRef(onFenceUpdate);
  const onViewDetailsRef = useRef(onViewDetails);
  
  // Update refs when callbacks change
  useEffect(() => {
    onMarkerDragEndRef.current = onMarkerDragEnd;
    onFenceUpdateRef.current = onFenceUpdate;
    onViewDetailsRef.current = onViewDetails;
  }, [onMarkerDragEnd, onFenceUpdate, onViewDetails]);

  const conditionColors = {
    "Good": "#10b981",
    "Fair": "#f59e0b",
    "Poor": "#ef4444"
  };

  const typeColors = {
    "Grazing": "bg-green-100 text-green-800 border-green-200",
    "Hay": "bg-yellow-100 text-yellow-800 border-yellow-200",
    "Breeding": "bg-pink-100 text-pink-800 border-pink-200",
    "Isolation": "bg-red-100 text-red-800 border-red-200",
    "Other": "bg-gray-100 text-gray-800 border-gray-200"
  };

  // Calculate area of polygon in square feet
  const calculateFenceArea = (coordinates) => {
    if (!coordinates || coordinates.length < 3) return 0;
    
    // Convert lat/lon to meters using approximate conversion
    // 1 degree latitude ≈ 111,320 meters
    // 1 degree longitude varies by latitude
    const toMeters = (coords) => {
      const avgLat = coords.reduce((sum, c) => sum + c[1], 0) / coords.length;
      const latToMeters = 111320;
      const lonToMeters = latToMeters * Math.cos(avgLat * Math.PI / 180);
      return coords.map(c => [c[0] * lonToMeters, c[1] * latToMeters]);
    };
    
    const metersCoords = toMeters(coordinates);
    
    // Shoelace formula for polygon area
    let area = 0;
    for (let i = 0; i < metersCoords.length; i++) {
      const j = (i + 1) % metersCoords.length;
      area += metersCoords[i][0] * metersCoords[j][1];
      area -= metersCoords[j][0] * metersCoords[i][1];
    }
    area = Math.abs(area) / 2;
    
    // Convert square meters to square feet (1 m² = 10.7639 ft²)
    return Math.round(area * 10.7639);
  };

  // Initialize map
  useEffect(() => {
    if (!mapboxToken || map.current) return;

    // Load Mapbox GL JS and Draw plugin
    const link = document.createElement('link');
    link.href = 'https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    const drawLink = document.createElement('link');
    drawLink.href = 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.4.3/mapbox-gl-draw.css';
    drawLink.rel = 'stylesheet';
    document.head.appendChild(drawLink);

    const script = document.createElement('script');
    script.src = 'https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.js';
    script.async = true;
    script.onload = () => {
      // Load Draw plugin after main library
      const drawScript = document.createElement('script');
      drawScript.src = 'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.4.3/mapbox-gl-draw.js';
      drawScript.async = true;
      drawScript.onload = () => {
      window.mapboxgl.accessToken = mapboxToken;
      
      // Calculate center from pastures with coordinates
      const pasturesWithCoords = pastures.filter(p => p.lat && p.lon);
      let center = [-98.5795, 39.8283]; // US center default
      let zoom = 4;

      if (pasturesWithCoords.length > 0) {
        const avgLat = pasturesWithCoords.reduce((sum, p) => sum + p.lat, 0) / pasturesWithCoords.length;
        const avgLon = pasturesWithCoords.reduce((sum, p) => sum + p.lon, 0) / pasturesWithCoords.length;
        center = [avgLon, avgLat];
        zoom = pasturesWithCoords.length === 1 ? 14 : 10;
      }

      map.current = new window.mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/satellite-streets-v12',
        center: center,
        zoom: zoom,
      });

      map.current.addControl(new window.mapboxgl.NavigationControl());
      
      // Initialize Draw control
      draw.current = new window.MapboxDraw({
        displayControlsDefault: false,
        controls: allowDrawing ? {
          polygon: true,
          trash: true
        } : {},
        defaultMode: 'simple_select'
      });
      
      map.current.addControl(draw.current);
      
      // Handle polygon creation and updates
      map.current.on('draw.create', async (e) => {
        if (!e.features || e.features.length === 0) return;
        const feature = e.features[0];
        
        // Exit draw mode when polygon is completed
        setDrawMode(false);
        draw.current.changeMode('simple_select');
        
        // Find which pasture this fence should belong to
        // Check if any pasture marker is inside the polygon
        const polygon = feature.geometry.coordinates[0];
        let targetPasture = null;
        
        for (const pasture of pastures) {
          if (pasture.lat && pasture.lon) {
            if (isPointInPolygon([pasture.lon, pasture.lat], polygon)) {
              targetPasture = pasture;
              break;
            }
          }
        }
        
        if (targetPasture && onFenceUpdateRef.current) {
          // Auto-assign fence to the pasture
          const tempId = feature.id;
          await onFenceUpdateRef.current(targetPasture.id, polygon);
          // Delete the temporary drawing after successful save
          setTimeout(() => {
            if (draw.current) {
              try {
                draw.current.delete(tempId);
              } catch (e) {
                // Feature might already be removed
              }
            }
          }, 100);
          setCurrentDrawingId(null);
        } else {
          toast.info('Click a pasture marker to assign this fence', { duration: 5000 });
          setCurrentDrawingId(feature.id);
        }
      });
      
      map.current.on('draw.update', (e) => {
        if (!e.features || e.features.length === 0) return;
        const feature = e.features[0];
        if (!feature || !feature.id) return;
        
        // Find pasture by feature ID
        const pastureId = feature.id.replace('fence-', '');
        const pasture = pastures.find(p => p.id === pastureId);
        
        if (pasture && onFenceUpdateRef.current) {
          onFenceUpdateRef.current(pastureId, feature.geometry.coordinates);
          toast.success('Fence boundary updated');
        }
      });
      
      map.current.on('draw.delete', (e) => {
        if (!e.features || e.features.length === 0) return;
        const feature = e.features[0];
        if (!feature || !feature.id) return;
        
        const pastureId = feature.id.replace('fence-', '');
        
        if (onFenceUpdateRef.current) {
          onFenceUpdateRef.current(pastureId, null);
          toast.success('Fence removed');
        }
      });
      
      map.current.on('load', () => setMapLoaded(true));
      };
      
      drawScript.onerror = () => {
        console.error('Failed to load Mapbox Draw');
        setMapLoaded(true); // Still set loaded
      };
      document.body.appendChild(drawScript);
    };

    script.onerror = () => {
      console.error('Failed to load Mapbox GL');
    };
    document.body.appendChild(script);
    
    // Helper function to check if point is inside polygon
    function isPointInPolygon(point, polygon) {
      let inside = false;
      for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i][0], yi = polygon[i][1];
        const xj = polygon[j][0], yj = polygon[j][1];
        const intersect = ((yi > point[1]) !== (yj > point[1]))
          && (point[0] < (xj - xi) * (point[1] - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
      }
      return inside;
    }

    return () => {
      if (map.current) {
        map.current.remove();
        map.current = null;
      }
    };
  }, [mapboxToken]);

  // Add/update markers and polygons when pastures or map changes
  useEffect(() => {
    if (!mapLoaded || !map.current || !draw.current || isUpdatingRef.current) return;
    
    isUpdatingRef.current = true;

    // Track changes for each pasture
    const pasturesById = {};
    pastures.forEach(p => {
      pasturesById[p.id] = {
        lat: p.lat,
        lon: p.lon,
        fence: JSON.stringify(p.fence_coordinates),
        name: p.name,
        data: p
      };
    });

    // Remove markers that no longer exist
    Object.keys(markers.current).forEach(id => {
      if (!pasturesById[id]) {
        markers.current[id].marker.remove();
        delete markers.current[id];
      }
    });

    // Update or add markers only if changed
    pastures.forEach(pasture => {
      const lastPasture = lastPasturesRef.current[pasture.id];
      const locationChanged = !lastPasture || 
        lastPasture.lat !== pasture.lat || 
        lastPasture.lon !== pasture.lon;
      
      if (locationChanged) {
        const needsPlacement = !pasture.lat || !pasture.lon;
        const lat = pasture.lat || 39.8283;
        const lon = pasture.lon || -98.5795;
        
        const color = needsPlacement ? '#9ca3af' : (conditionColors[pasture.condition] || '#6b7280');
        const borderColor = needsPlacement ? '#ef4444' : '#ffffff';

        // Create popup content
        const popupContent = `
        <div class="p-3 min-w-[250px]">
          ${needsPlacement ? `
            <div class="bg-orange-50 border border-orange-200 rounded p-2 mb-3 flex items-start gap-2 text-sm">
              <div class="text-orange-600 mt-0.5">⚠</div>
              <div>
                <div class="font-semibold text-orange-700 mb-1">Location Not Set</div>
                <span class="text-orange-700">Drag this marker to set location</span>
              </div>
            </div>
          ` : ''}
          <h3 class="font-bold text-lg mb-2">${pasture.name}</h3>
          <div class="flex gap-2 mb-3 flex-wrap">
            <span class="px-2 py-1 rounded text-xs font-medium ${typeColors[pasture.type]}">
              ${pasture.type}
            </span>
            <span class="px-2 py-1 rounded text-xs font-medium" style="background-color: ${color}20; color: ${color}; border: 1px solid ${color}40;">
              ${pasture.condition}
            </span>
          </div>
          <div class="space-y-2 text-sm mb-3">
            <div class="flex justify-between">
              <span class="font-semibold">Acreage:</span>
              <span>${pasture.size_acres} acres</span>
            </div>
            <div class="flex justify-between">
              <span class="font-semibold">Capacity:</span>
              <span>${pasture.capacity || 'Not set'}</span>
            </div>
            <div class="flex justify-between">
              <span class="font-semibold">Current Animals:</span>
              <span class="font-bold text-emerald-600">${pasture.current_animal_count || 0}</span>
            </div>
            ${pasture.fence_coordinates && pasture.fence_coordinates.length > 2 ? `
              <div class="flex justify-between">
                <span class="font-semibold">Fenced Area:</span>
                <span class="font-bold text-blue-600">${calculateFenceArea(pasture.fence_coordinates).toLocaleString()} sqft</span>
              </div>
            ` : ''}
            <div class="pt-2 border-t">
              <span class="font-semibold block mb-1">Coordinates:</span>
              <span class="text-xs text-gray-600">${lat.toFixed(6)}, ${lon.toFixed(6)}</span>
            </div>
          </div>
          <button 
            class="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded font-medium text-sm transition-colors"
            onclick="window.handleViewPastureDetails('${pasture.id}')"
          >
            View Full Details
          </button>
          <p class="text-xs text-gray-500 mt-2 text-center">💡 Drag marker to adjust location</p>
        </div>
        `;

        // Create marker element
        const el = document.createElement('div');
      el.className = 'custom-marker';
      el.style.cssText = `
        background-color: ${color};
        width: 32px;
        height: 32px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 3px solid ${borderColor};
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        cursor: grab;
        ${needsPlacement ? 'opacity: 0.7;' : ''}
      `;
      el.innerHTML = `
        <svg style="transform: rotate(45deg); width: 16px; height: 16px; margin: 5px;" fill="white" viewBox="0 0 24 24">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
          </svg>
        `;

        if (markers.current[pasture.id]) {
          // Update existing marker
          markers.current[pasture.id].marker.setLngLat([lon, lat]);
          markers.current[pasture.id].popup.setHTML(popupContent);
        } else {
          // Create new marker
          const popup = new window.mapboxgl.Popup({ 
            offset: 25,
            closeButton: true,
            maxWidth: '300px'
          }).setHTML(popupContent);

          const marker = new window.mapboxgl.Marker({
            element: el,
            draggable: true
          })
            .setLngLat([lon, lat])
            .setPopup(popup)
            .addTo(map.current);

          marker.on('dragend', () => {
            const lngLat = marker.getLngLat();
            onMarkerDragEndRef.current(pasture.id, lngLat.lat, lngLat.lng);
          });
          
          // Handle clicking marker to assign unassigned fence
          const handleMarkerClick = async (e) => {
            e.stopPropagation();
            if (currentDrawingId) {
              const features = draw.current.getAll();
              const unassignedFeature = features.features.find(f => f.id === currentDrawingId);
              if (unassignedFeature && onFenceUpdateRef.current) {
                const coords = unassignedFeature.geometry.coordinates[0];
                const tempId = currentDrawingId;
                await onFenceUpdateRef.current(pasture.id, coords);
                setCurrentDrawingId(null);
                setTimeout(() => {
                  if (draw.current) {
                    try {
                      draw.current.delete(tempId);
                    } catch (e) {
                      // Feature might already be removed
                    }
                  }
                }, 100);
              }
            }
          };
          marker.getElement().addEventListener('click', handleMarkerClick);

          markers.current[pasture.id] = { marker, popup, pasture };
        }
      }
    });

    // Update fences only if changed
    pastures.forEach(pasture => {
      const lastPasture = lastPasturesRef.current[pasture.id];
      const fenceChanged = !lastPasture || 
        JSON.stringify(lastPasture.fence_coordinates) !== JSON.stringify(pasture.fence_coordinates);
      
      if (fenceChanged) {
        // Remove old fence if exists
        try {
          const existing = draw.current.get(`fence-${pasture.id}`);
          if (existing) {
            draw.current.delete(`fence-${pasture.id}`);
          }
        } catch (e) {
          // Feature doesn't exist
        }

        // Add new fence if exists
        if (pasture.fence_coordinates && Array.isArray(pasture.fence_coordinates) && pasture.fence_coordinates.length > 2) {
          try {
            const polygon = {
              id: `fence-${pasture.id}`,
              type: 'Feature',
              properties: {
                pastureId: pasture.id,
                pastureName: pasture.name,
                fenceColor: pasture.fence_color || '#10b981'
              },
              geometry: {
                type: 'Polygon',
                coordinates: [pasture.fence_coordinates]
              }
            };
            draw.current.add(polygon);
            
            // Apply custom color styling
            const color = pasture.fence_color || '#10b981';
            setTimeout(() => {
              const elements = document.querySelectorAll(`[data-feature-id="fence-${pasture.id}"]`);
              elements.forEach(el => {
                el.style.stroke = color;
                el.style.fill = `${color}33`; // Add transparency
              });
            }, 50);
          } catch (e) {
            console.error('Error adding fence polygon:', e);
          }
        }
      }
    });

    // Update lastPasturesRef
    lastPasturesRef.current = pasturesById;

    setTimeout(() => {
      isUpdatingRef.current = false;
    }, 100);

    // Add text labels for pasture names
    pastures.forEach(pasture => {
      if (pasture.lat && pasture.lon) {
        const labelId = `label-${pasture.id}`;
        
        // Remove existing label
        if (map.current.getLayer(labelId)) {
          map.current.removeLayer(labelId);
        }
        if (map.current.getSource(labelId)) {
          map.current.removeSource(labelId);
        }

        // Add new label
        map.current.addSource(labelId, {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'Point',
              coordinates: [pasture.lon, pasture.lat]
            },
            properties: {
              name: pasture.name
            }
          }
        });

        map.current.addLayer({
          id: labelId,
          type: 'symbol',
          source: labelId,
          layout: {
            'text-field': ['get', 'name'],
            'text-size': 14,
            'text-offset': [0, 2],
            'text-anchor': 'top'
          },
          paint: {
            'text-color': '#ffffff',
            'text-halo-color': '#000000',
            'text-halo-width': 2,
            'text-halo-blur': 1
          }
        });
      }
    });

    // Fit map to markers if we have pastures with coordinates
    const pasturesWithCoords = pastures.filter(p => p.lat && p.lon);
    if (pasturesWithCoords.length > 0) {
      const bounds = new window.mapboxgl.LngLatBounds();
      pasturesWithCoords.forEach(p => {
        bounds.extend([p.lon, p.lat]);
      });
      map.current.fitBounds(bounds, { 
        padding: 100,
        maxZoom: 14
      });
    }
  }, [pastures, mapLoaded, currentDrawingId]);

  // Global handler for view details button in popup
  useEffect(() => {
    window.handleViewPastureDetails = (pastureId) => {
      const pasture = pastures.find(p => p.id === pastureId);
      if (pasture && onViewDetailsRef.current) {
        onViewDetailsRef.current(pasture);
      }
    };

    return () => {
      delete window.handleViewPastureDetails;
    };
  }, [pastures]);

  const pasturesWithoutCoords = pastures.filter(p => !p.lat || !p.lon);

  const toggleFullscreen = () => {
    const container = mapContainer.current?.parentElement;
    if (!container) return;

    if (!document.fullscreenElement) {
      container.requestFullscreen().then(() => {
        setIsFullscreen(true);
        setTimeout(() => map.current?.resize(), 100);
      }).catch(err => {
        toast.error('Failed to enter fullscreen');
        console.error(err);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
        setTimeout(() => map.current?.resize(), 100);
      });
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
      setTimeout(() => map.current?.resize(), 100);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  if (pastures.length === 0) {
    return (
      <div className="h-[600px] rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center p-8">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Pastures Yet</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">
            Add pastures to see them on the map
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative rounded-lg overflow-hidden border-2 border-gray-200 dark:border-gray-700 shadow-lg ${isFullscreen ? 'h-screen' : 'h-[600px]'}`}>
      <div ref={mapContainer} className="w-full h-full" />
      
      <div className="absolute top-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-2 z-10 flex gap-2">
        {allowDrawing && (
          <>
            <Button
              size="sm"
              variant={drawMode ? "default" : "outline"}
              onClick={() => {
                if (draw.current) {
                  if (drawMode) {
                    draw.current.changeMode('simple_select');
                    setDrawMode(false);
                  } else {
                    draw.current.changeMode('draw_polygon');
                    setDrawMode(true);
                    toast.info('Click on the map to draw fence boundary');
                  }
                }
              }}
              className="dark:border-gray-700"
            >
              <Square className="w-4 h-4 mr-2" />
              {drawMode ? 'Stop Drawing' : 'Draw Fence'}
            </Button>
            {drawMode && (
              <Button
                size="sm"
                variant="destructive"
                onClick={() => {
                  if (draw.current) {
                    const features = draw.current.getAll();
                    if (features.features.length > 0) {
                      // Delete the last/current incomplete drawing
                      const lastFeature = features.features[features.features.length - 1];
                      draw.current.delete(lastFeature.id);
                      toast.success('Drawing cleared');
                    }
                    draw.current.changeMode('draw_polygon');
                  }
                }}
                className="dark:border-gray-700"
                title="Clear current drawing and start over"
              >
                <X className="w-4 h-4 mr-2" />
                Clear
              </Button>
            )}
          </>
        )}
        <Button
          size="sm"
          variant="outline"
          onClick={toggleFullscreen}
          className="dark:border-gray-700"
          title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
        >
          {isFullscreen ? (
            <Minimize2 className="w-4 h-4" />
          ) : (
            <Maximize2 className="w-4 h-4" />
          )}
        </Button>
      </div>
      
      <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 z-10 max-w-xs">
        <p className="text-xs text-gray-600 dark:text-gray-400 flex items-center gap-2 mb-2">
          <Move className="w-4 h-4" />
          <span>Drag markers to adjust locations</span>
        </p>
        <p className="text-xs text-gray-600 dark:text-gray-400 flex items-center gap-2 mb-2">
          <Square className="w-4 h-4" />
          <span>Use Draw Fence to add boundaries</span>
        </p>
        {pasturesWithoutCoords.length > 0 && (
          <p className="text-xs text-orange-600 dark:text-orange-400 flex items-center gap-2 border-t pt-2">
            <AlertCircle className="w-4 h-4" />
            <span>{pasturesWithoutCoords.length} pasture(s) need manual placement</span>
          </p>
        )}
      </div>
    </div>
  );
}