import React from "react";
import BankingManagement from "@/components/billing/BankingManagement";

export default function RanchBankingSettings({ ranch }) {
  return <BankingManagement />;
}