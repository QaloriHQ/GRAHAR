import React from "react";
import BillingManagement from "@/components/billing/BillingManagement";

export default function RanchBillingSettings({ ranch }) {
  return <BillingManagement />;
}