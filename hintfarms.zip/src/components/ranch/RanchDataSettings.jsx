import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Database, Download, FileText, Loader2 } from "lucide-react";

export default function RanchDataSettings({ ranch }) {
  const [exporting, setExporting] = React.useState(false);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const { data } = await base44.functions.invoke('exportRanchData', {});
      
      // Download the file
      const blob = new Blob([data], { type: 'application/zip' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${ranch.name.replace(/\s+/g, '_')}_export_${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

      const event = new CustomEvent('showToast', {
        detail: { message: 'Ranch data exported successfully!', type: 'success' }
      });
      window.dispatchEvent(event);
    } catch (error) {
      const event = new CustomEvent('showToast', {
        detail: { message: `Export failed: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="dark:bg-gray-950 dark:border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 dark:text-gray-100">
            <Database className="w-5 h-5" />
            Data Export
          </CardTitle>
          <CardDescription className="dark:text-gray-400">
            Export all ranch data for backup or migration
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
            <p className="text-sm text-blue-800 dark:text-blue-300">
              <strong>What's included:</strong> All animals, health records, breeding records, financials, 
              pastures, tasks, and team data for {ranch.name}.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              onClick={handleExport}
              disabled={exporting}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {exporting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Export Ranch Data
                </>
              )}
            </Button>
          </div>

          <div className="pt-4 border-t dark:border-gray-800">
            <h4 className="font-semibold mb-2 dark:text-gray-100">Export Format</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Data is exported as CSV files in a ZIP archive, ready for use in spreadsheets or other ranch management software.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}