import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Plus, MapPin, Trash2, Star } from "lucide-react";

export default function RanchMarketSettings({ ranch }) {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newMarket, setNewMarket] = useState({
    display_name: "",
    source_type: "USDA_AMS",
    source_market_code: "",
    city: "",
    state: "",
    is_primary: false
  });

  const queryClient = useQueryClient();

  const { data: localMarkets = [] } = useQuery({
    queryKey: ['localMarkets', ranch?.id],
    queryFn: () => base44.entities.RanchLocalMarket.filter({ ranch_id: ranch.id }),
    enabled: !!ranch?.id
  });

  const createMarketMutation = useMutation({
    mutationFn: (data) => base44.entities.RanchLocalMarket.create({ ...data, ranch_id: ranch.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['localMarkets'] });
      setShowAddDialog(false);
      setNewMarket({
        display_name: "",
        source_type: "USDA_AMS",
        source_market_code: "",
        city: "",
        state: "",
        is_primary: false
      });
    }
  });

  const deleteMarketMutation = useMutation({
    mutationFn: (id) => base44.entities.RanchLocalMarket.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['localMarkets'] });
    }
  });

  const updateMarketMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.RanchLocalMarket.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['localMarkets'] });
    }
  });

  const handleSetPrimary = async (marketId) => {
    // Unset all other primaries
    for (const market of localMarkets) {
      if (market.is_primary && market.id !== marketId) {
        await updateMarketMutation.mutateAsync({ id: market.id, data: { is_primary: false } });
      }
    }
    // Set this one as primary
    await updateMarketMutation.mutateAsync({ id: marketId, data: { is_primary: true } });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Market Configuration</h2>
          <p className="text-gray-600">Configure your local livestock markets for accurate pricing</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Market
        </Button>
      </div>

      {localMarkets.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Markets Configured</h3>
            <p className="text-gray-600 mb-4">
              Add your local livestock markets to get accurate pricing for your area.
            </p>
            <Button onClick={() => setShowAddDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Market
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {localMarkets.map((market) => (
            <Card key={market.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {market.display_name}
                      {market.is_primary && (
                        <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
                          <Star className="w-3 h-3" />
                          Primary
                        </Badge>
                      )}
                    </CardTitle>
                    <Badge variant="outline" className="mt-2">
                      {market.source_type === 'USDA_AMS' ? 'USDA AMS' : 'Manual'}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteMarketMutation.mutate(market.id)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  {market.city && market.state && (
                    <p className="text-gray-600">
                      <MapPin className="w-3 h-3 inline mr-1" />
                      {market.city}, {market.state}
                    </p>
                  )}
                  {market.source_market_code && (
                    <p className="text-gray-600">Market Code: {market.source_market_code}</p>
                  )}
                </div>
                {!market.is_primary && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-4"
                    onClick={() => handleSetPrimary(market.id)}
                  >
                    <Star className="w-3 h-3 mr-2" />
                    Set as Primary
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add Market Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Local Market</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label>Market Name</Label>
              <Input
                value={newMarket.display_name}
                onChange={(e) => setNewMarket({ ...newMarket, display_name: e.target.value })}
                placeholder="e.g., Texarkana Livestock Auction"
              />
            </div>
            
            <div>
              <Label>Source Type</Label>
              <Select value={newMarket.source_type} onValueChange={(v) => setNewMarket({ ...newMarket, source_type: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USDA_AMS">USDA AMS</SelectItem>
                  <SelectItem value="Manual">Manual</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {newMarket.source_type === 'USDA_AMS' && (
              <div>
                <Label>USDA Market Code (Optional)</Label>
                <Input
                  value={newMarket.source_market_code}
                  onChange={(e) => setNewMarket({ ...newMarket, source_market_code: e.target.value })}
                  placeholder="e.g., AMS_1234"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>City</Label>
                <Input
                  value={newMarket.city}
                  onChange={(e) => setNewMarket({ ...newMarket, city: e.target.value })}
                />
              </div>
              <div>
                <Label>State</Label>
                <Input
                  value={newMarket.state}
                  onChange={(e) => setNewMarket({ ...newMarket, state: e.target.value })}
                  placeholder="AR"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              onClick={() => createMarketMutation.mutate(newMarket)}
              disabled={!newMarket.display_name}
            >
              Add Market
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}