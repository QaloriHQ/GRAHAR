import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Save, CheckCircle2, Bell } from "lucide-react";

export default function RanchNotificationsSettings({ ranch }) {
  const queryClient = useQueryClient();
  const [showSuccess, setShowSuccess] = useState(false);

  const { data: notificationSettings, isLoading } = useQuery({
    queryKey: ['ranchNotificationSettings', ranch.id],
    queryFn: async () => {
      const settings = await base44.entities.RanchNotificationSettings.filter({ ranch_id: ranch.id });
      return settings[0] || {
        email_notifications: true,
        task_reminders: true,
        health_alerts: true,
        breeding_notifications: true,
        financial_alerts: true
      };
    },
  });

  const [settings, setSettings] = useState({
    email_notifications: true,
    task_reminders: true,
    health_alerts: true,
    breeding_notifications: true,
    financial_alerts: true
  });

  React.useEffect(() => {
    if (notificationSettings) {
      setSettings(notificationSettings);
    }
  }, [notificationSettings]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (data) => {
      if (notificationSettings?.id) {
        return await base44.asServiceRole.entities.RanchNotificationSettings.update(notificationSettings.id, data);
      } else {
        return await base44.asServiceRole.entities.RanchNotificationSettings.create({
          ranch_id: ranch.id,
          ...data
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ranchNotificationSettings'] });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    },
  });

  const handleSave = () => {
    saveSettingsMutation.mutate(settings);
  };

  if (isLoading) {
    return <div className="p-6 text-center text-gray-500 dark:text-gray-400">Loading settings...</div>;
  }

  return (
    <div className="space-y-6">
      {showSuccess && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
          <p className="text-green-800 dark:text-green-300 font-medium">Notification settings updated successfully!</p>
        </div>
      )}

      <Card className="dark:bg-gray-950 dark:border-gray-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 dark:text-gray-100">
            <Bell className="w-5 h-5" />
            Notification Preferences
          </CardTitle>
          <CardDescription className="dark:text-gray-400">
            Configure notification settings for {ranch.name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium dark:text-gray-100">Email Notifications</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Receive notifications via email</p>
              </div>
              <Switch
                checked={settings.email_notifications}
                onCheckedChange={(checked) =>
                  setSettings({...settings, email_notifications: checked})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium dark:text-gray-100">Task Reminders</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Get reminders for upcoming and overdue tasks</p>
              </div>
              <Switch
                checked={settings.task_reminders}
                onCheckedChange={(checked) =>
                  setSettings({...settings, task_reminders: checked})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium dark:text-gray-100">Health Alerts</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Notifications for animal health records and checkups</p>
              </div>
              <Switch
                checked={settings.health_alerts}
                onCheckedChange={(checked) =>
                  setSettings({...settings, health_alerts: checked})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium dark:text-gray-100">Breeding Notifications</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Updates on breeding cycles and calving</p>
              </div>
              <Switch
                checked={settings.breeding_notifications}
                onCheckedChange={(checked) =>
                  setSettings({...settings, breeding_notifications: checked})
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium dark:text-gray-100">Financial Alerts</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Notifications for expenses and revenue updates</p>
              </div>
              <Switch
                checked={settings.financial_alerts}
                onCheckedChange={(checked) =>
                  setSettings({...settings, financial_alerts: checked})
                }
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t dark:border-gray-800">
            <Button
              onClick={handleSave}
              className="bg-emerald-600 hover:bg-emerald-700"
              disabled={saveSettingsMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              Save Preferences
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}