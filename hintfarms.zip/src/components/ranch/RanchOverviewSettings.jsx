import React from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Building2, MapPin, Users, Save, CheckCircle2, Crown, Copy } from "lucide-react";

export default function RanchOverviewSettings({ ranch, userRole }) {
  const queryClient = useQueryClient();
  const [showSuccessMessage, setShowSuccessMessage] = React.useState(false);
  const [ranchData, setRanchData] = React.useState({
    name: "",
    location: "",
    address: "",
    total_acres: 0,
    contact_email: "",
    contact_phone: ""
  });

  React.useEffect(() => {
    if (ranch) {
      setRanchData({
        name: ranch.name || "",
        location: ranch.location || "",
        address: ranch.address || "",
        total_acres: ranch.total_acres || 0,
        contact_email: ranch.contact_email || "",
        contact_phone: ranch.contact_phone || ""
      });
    }
  }, [ranch]);

  const updateRanchMutation = useMutation({
    mutationFn: (data) => base44.asServiceRole.entities.Ranch.update(ranch.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
      setShowSuccessMessage(true);
      setTimeout(() => setShowSuccessMessage(false), 3000);
    },
  });

  const handleSave = () => {
    updateRanchMutation.mutate(ranchData);
  };

  const handleCopyRanchId = () => {
    navigator.clipboard.writeText(ranch.id);
    const event = new CustomEvent('showToast', {
      detail: { message: 'Ranch ID copied to clipboard', type: 'success' }
    });
    window.dispatchEvent(event);
  };

  const canEdit = ['Owner', 'Manager'].includes(userRole);

  return (
    <div className="space-y-6">
      {showSuccessMessage && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
          <p className="text-green-800 dark:text-green-300 font-medium">Changes saved successfully!</p>
        </div>
      )}

      <Card className="dark:bg-gray-950 dark:border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 dark:text-gray-100">
                <Building2 className="w-5 h-5" />
                Ranch Information
              </CardTitle>
              <CardDescription className="dark:text-gray-400">
                Basic details about your ranch
              </CardDescription>
            </div>
            {userRole && (
              <Badge className="flex items-center gap-1">
                {userRole === 'Owner' && <Crown className="w-3 h-3" />}
                {userRole}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Ranch ID - Read Only */}
          <div className="space-y-2">
            <Label htmlFor="ranch_id" className="dark:text-gray-200">Ranch ID</Label>
            <div className="flex gap-2">
              <Input
                id="ranch_id"
                value={ranch?.id || ""}
                disabled
                className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-400 font-mono text-sm"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleCopyRanchId}
                className="dark:border-gray-700 dark:text-gray-300"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              This is your unique ranch identifier. Use it for API integrations or when contacting support.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="dark:text-gray-200">Ranch Name</Label>
              <Input
                id="name"
                value={ranchData.name}
                onChange={(e) => setRanchData({...ranchData, name: e.target.value})}
                disabled={!canEdit}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location" className="dark:text-gray-200">Location (City, State)</Label>
              <Input
                id="location"
                value={ranchData.location}
                onChange={(e) => setRanchData({...ranchData, location: e.target.value})}
                disabled={!canEdit}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address" className="dark:text-gray-200">Full Address</Label>
            <Textarea
              id="address"
              value={ranchData.address}
              onChange={(e) => setRanchData({...ranchData, address: e.target.value})}
              disabled={!canEdit}
              rows={3}
              className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="total_acres" className="dark:text-gray-200">Total Acres</Label>
              <Input
                id="total_acres"
                type="number"
                value={ranchData.total_acres}
                onChange={(e) => setRanchData({...ranchData, total_acres: parseFloat(e.target.value) || 0})}
                disabled={!canEdit}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_email" className="dark:text-gray-200">Contact Email</Label>
              <Input
                id="contact_email"
                type="email"
                value={ranchData.contact_email}
                onChange={(e) => setRanchData({...ranchData, contact_email: e.target.value})}
                disabled={!canEdit}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contact_phone" className="dark:text-gray-200">Contact Phone</Label>
              <Input
                id="contact_phone"
                type="tel"
                value={ranchData.contact_phone}
                onChange={(e) => setRanchData({...ranchData, contact_phone: e.target.value})}
                disabled={!canEdit}
                className="dark:bg-gray-800 dark:border-gray-700 dark:text-gray-100"
              />
            </div>
          </div>

          {canEdit && (
            <div className="flex justify-end pt-4 border-t dark:border-gray-800">
              <Button
                onClick={handleSave}
                className="bg-emerald-600 hover:bg-emerald-700"
                disabled={updateRanchMutation.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="dark:bg-gray-950 dark:border-gray-800">
        <CardHeader>
          <CardTitle className="dark:text-gray-100">Subscription</CardTitle>
          <CardDescription className="dark:text-gray-400">Current plan and status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold text-lg dark:text-gray-100">{ranch.subscription_plan || "Free"}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Status: <span className="font-medium">{ranch.subscription_status || "Active"}</span>
              </p>
            </div>
            {canEdit && (
              <Button
                variant="outline"
                onClick={() => {
                  // Navigate to billing tab
                  const event = new CustomEvent('navigateToBilling');
                  window.dispatchEvent(event);
                }}
                className="dark:border-gray-700 dark:text-gray-300"
              >
                Manage Subscription
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}