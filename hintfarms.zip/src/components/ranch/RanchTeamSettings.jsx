import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Users, Crown, UserPlus, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import RanchPermissionsSettings from "./RanchPermissionsSettings";

export default function RanchTeamSettings({ ranch, userRole, canManage }) {
  const [activeSection, setActiveSection] = useState("members");

  const { data: members = [] } = useQuery({
    queryKey: ['ranchMembers', ranch.id],
    queryFn: () => base44.entities.RanchMember.filter({ ranch_id: ranch.id }, '-joined_date'),
    initialData: [],
  });

  const roleColors = {
    "Owner": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800",
    "Manager": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800",
    "Worker": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
    "Veterinarian": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800",
    "Assistant": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700"
  };

  const statusColors = {
    "Active": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
    "Pending": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800",
    "Removed": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800"
  };

  const activeMembers = members.filter(m => m.status === 'Active').length;
  const pendingMembers = members.filter(m => m.status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* Sub-navigation */}
      <Tabs value={activeSection} onValueChange={setActiveSection} className="w-full">
        <TabsList className="grid w-full grid-cols-2 dark:bg-gray-900">
          <TabsTrigger value="members" className="dark:data-[state=active]:bg-gray-800">
            <Users className="w-4 h-4 mr-2" />
            Team Members
          </TabsTrigger>
          <TabsTrigger 
            value="permissions" 
            disabled={!canManage}
            className={!canManage ? "opacity-50 cursor-not-allowed" : "dark:data-[state=active]:bg-gray-800"}
          >
            <Shield className="w-4 h-4 mr-2" />
            Role Permissions
          </TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="members" className="m-0 space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/20 rounded-xl flex items-center justify-center">
                      <Users className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Active Members</p>
                      <p className="text-2xl font-bold dark:text-gray-100">{activeMembers}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-xl flex items-center justify-center">
                      <UserPlus className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Pending Invites</p>
                      <p className="text-2xl font-bold dark:text-gray-100">{pendingMembers}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-xl flex items-center justify-center">
                      <Shield className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Your Role</p>
                      <p className="text-2xl font-bold dark:text-gray-100">{userRole}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Team Members Table */}
            <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="dark:text-gray-100">Team Members</CardTitle>
                    <CardDescription className="dark:text-gray-400">
                      {canManage ? 'Manage roles and permissions for your ranch team' : 'View your ranch team members'}
                    </CardDescription>
                  </div>
                  {canManage && (
                    <Link to={createPageUrl("TeamManagement")}>
                      <Button className="bg-emerald-600 hover:bg-emerald-700">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Manage Team
                      </Button>
                    </Link>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="dark:border-gray-800">
                      <TableHead className="dark:text-gray-300">Name</TableHead>
                      <TableHead className="dark:text-gray-300">Email</TableHead>
                      <TableHead className="dark:text-gray-300">Role</TableHead>
                      <TableHead className="dark:text-gray-300">Status</TableHead>
                      <TableHead className="dark:text-gray-300">Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {members.map(member => (
                      <TableRow key={member.id} className="dark:border-gray-800">
                        <TableCell className="dark:text-gray-100">
                          <div className="flex items-center gap-2">
                            {member.role === "Owner" && <Crown className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />}
                            <span className="font-semibold">{member.user_name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-600 dark:text-gray-400">{member.user_email}</TableCell>
                        <TableCell>
                          <Badge className={`${roleColors[member.role]} border`}>
                            {member.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${statusColors[member.status]} border text-xs`}>
                            {member.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-600 dark:text-gray-400">
                          {member.joined_date ? format(new Date(member.joined_date), "MMM d, yyyy") : "-"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="permissions" className="m-0">
            {canManage ? (
              <RanchPermissionsSettings ranch={ranch} />
            ) : (
              <Card className="border-orange-200 dark:border-orange-800 bg-orange-50 dark:bg-orange-900/20">
                <CardContent className="p-8 text-center">
                  <Shield className="w-12 h-12 text-orange-600 dark:text-orange-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-orange-800 dark:text-orange-300 mb-2">
                    Permission Required
                  </h3>
                  <p className="text-sm text-orange-700 dark:text-orange-400">
                    Only Owners and Managers can configure role permissions.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}