import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function LivestockValueTrends({ livestock = [], startDate, endDate }) {
  const totalCurrentValue = livestock.reduce((sum, l) => sum + (l.current_value || 0), 0);
  const totalPurchaseValue = livestock.reduce((sum, l) => sum + (l.purchase_price || 0), 0);
  const valueChange = totalCurrentValue - totalPurchaseValue;
  const percentChange = totalPurchaseValue > 0 ? ((valueChange / totalPurchaseValue) * 100).toFixed(1) : 0;

  // Group by type
  const valueByType = livestock.reduce((acc, animal) => {
    if (!acc[animal.type]) {
      acc[animal.type] = { count: 0, value: 0 };
    }
    acc[animal.type].count += 1;
    acc[animal.type].value += animal.current_value || 0;
    return acc;
  }, {});

  const chartData = Object.entries(valueByType).map(([type, data]) => ({
    type,
    count: data.count,
    value: data.value,
    avgValue: data.count > 0 ? (data.value / data.count).toFixed(0) : 0,
  }));

  return (
    <Card className="dark:bg-gray-800 dark:border-gray-700">
      <CardHeader>
        <CardTitle className="dark:text-gray-100">Livestock Value Analysis</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Total Livestock</p>
            <p className="text-2xl font-bold dark:text-gray-100">{livestock.length}</p>
          </div>
          <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Current Value</p>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400">
              ${totalCurrentValue.toLocaleString()}
            </p>
          </div>
          <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Value Change</p>
            <div className="flex items-center gap-2">
              <p className={`text-2xl font-bold ${valueChange >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                {valueChange >= 0 ? <TrendingUp className="w-5 h-5 inline" /> : <TrendingDown className="w-5 h-5 inline" />}
                ${Math.abs(valueChange).toLocaleString()}
              </p>
            </div>
            <p className={`text-sm ${valueChange >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
              {percentChange}% from purchase
            </p>
          </div>
        </div>

        {/* Chart */}
        {chartData.length > 0 && (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="type" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="value" stroke="#10b981" name="Total Value ($)" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="count" stroke="#3b82f6" name="Count" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        )}

        {/* Breakdown by Type */}
        <div className="space-y-2">
          <h4 className="font-semibold dark:text-gray-100">Value by Type</h4>
          {chartData.map((item) => (
            <div key={item.type} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <div>
                <p className="font-medium dark:text-gray-200">{item.type}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{item.count} head</p>
              </div>
              <div className="text-right">
                <p className="font-bold dark:text-gray-100">${item.value.toLocaleString()}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Avg: ${item.avgValue}/head</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}