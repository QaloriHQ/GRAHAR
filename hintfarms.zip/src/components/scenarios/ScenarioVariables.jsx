import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings, AlertTriangle, DollarSign, TrendingUp } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ScenarioVariables({ formData, setFormData }) {
  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Variable Overrides
          </CardTitle>
          <CardDescription>
            Customize assumptions for this scenario. Leave blank to use actual ranch data.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="risk">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="risk">
                <AlertTriangle className="w-4 h-4 mr-2" />
                Risk Factors
              </TabsTrigger>
              <TabsTrigger value="finance">
                <DollarSign className="w-4 h-4 mr-2" />
                Finance
              </TabsTrigger>
              <TabsTrigger value="operations">
                <TrendingUp className="w-4 h-4 mr-2" />
                Operations
              </TabsTrigger>
            </TabsList>

            <TabsContent value="risk" className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Predator Loss Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="0.5"
                    value={formData.predator_loss_rate}
                    onChange={(e) => setFormData({...formData, predator_loss_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">0.00 - 0.50 (e.g., 0.03 = 3%)</p>
                </div>
                <div className="space-y-2">
                  <Label>Mortality Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="0.2"
                    value={formData.mortality_rate}
                    onChange={(e) => setFormData({...formData, mortality_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">0.00 - 0.20</p>
                </div>
                <div className="space-y-2">
                  <Label>Shrink Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="0.1"
                    value={formData.shrink_rate}
                    onChange={(e) => setFormData({...formData, shrink_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">0.00 - 0.10</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="finance" className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Discount Rate (Annual)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.discount_rate}
                    onChange={(e) => setFormData({...formData, discount_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">e.g., 0.08 = 8%</p>
                </div>
                <div className="space-y-2">
                  <Label>Interest Rate (Operating)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.interest_rate}
                    onChange={(e) => setFormData({...formData, interest_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">e.g., 0.095 = 9.5%</p>
                </div>
                <div className="space-y-2">
                  <Label>Tax Rate (Effective)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.tax_rate}
                    onChange={(e) => setFormData({...formData, tax_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">e.g., 0.22 = 22%</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="operations" className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Cost Allocation Rule</Label>
                  <Select
                    value={formData.allocation_rule}
                    onValueChange={(value) => setFormData({...formData, allocation_rule: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="by_GUM">By Grazing Unit Months (GUM)</SelectItem>
                      <SelectItem value="by_Revenue">By Revenue</SelectItem>
                      <SelectItem value="even_split">Even Split</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Target Replacement % (Annual)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="0.5"
                    value={formData.target_replacement_pct}
                    onChange={(e) => setFormData({...formData, target_replacement_pct: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">e.g., 0.18 = 18% of herd per year</p>
                </div>
                <div className="space-y-2">
                  <Label>Heifer Keep Rate</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={formData.heifer_keep_rate}
                    onChange={(e) => setFormData({...formData, heifer_keep_rate: parseFloat(e.target.value)})}
                  />
                  <p className="text-xs text-gray-500">e.g., 0.25 = keep 25% of heifers</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}