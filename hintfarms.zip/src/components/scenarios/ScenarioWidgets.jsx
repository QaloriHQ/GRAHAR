import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  BarChart3, 
  Plus, 
  GripVertical,
  Table,
  BarChart,
  LineChart,
  PieChart
} from "lucide-react";

const WIDGET_CATALOG = [
  { id: "herd_size", title: "Herd Size", icon: BarChart3, defaultVis: "line", description: "Track animal counts over time" },
  { id: "purchases", title: "Purchases", icon: Table, defaultVis: "table", description: "Purchase transactions and costs" },
  { id: "sales", title: "Sales", icon: Table, defaultVis: "table", description: "Sales revenue by animal type" },
  { id: "grazing_demands", title: "Grazing Demands", icon: BarChart, defaultVis: "column", description: "GUM calculations by enterprise" },
  { id: "gross_margins", title: "Gross Margins", icon: BarChart, defaultVis: "bar", description: "Revenue minus variable costs" },
  { id: "enterprise_eff", title: "Enterprise Efficiency", icon: BarChart, defaultVis: "bar", description: "$ per GUM by enterprise" },
  { id: "replacement_costs", title: "Replacement Costs", icon: Table, defaultVis: "table", description: "Breeding replacement expenses" },
  { id: "breakeven", title: "Breakeven Analysis", icon: Table, defaultVis: "table", description: "Breakeven prices per head/lb" },
  { id: "cash_flow", title: "Cash Flow", icon: LineChart, defaultVis: "line", description: "Inflows vs outflows over time" },
  { id: "pnl", title: "Profit & Loss", icon: Table, defaultVis: "table", description: "Full P&L statement" }
];

export default function ScenarioWidgets({ formData, setFormData }) {
  const [selectedWidgets, setSelectedWidgets] = useState(formData.widgets?.map(w => w.widget_id) || []);

  const toggleWidget = (widgetId) => {
    const isSelected = selectedWidgets.includes(widgetId);
    let newSelected;
    let newWidgets;

    if (isSelected) {
      newSelected = selectedWidgets.filter(id => id !== widgetId);
      newWidgets = formData.widgets?.filter(w => w.widget_id !== widgetId) || [];
    } else {
      const widget = WIDGET_CATALOG.find(w => w.id === widgetId);
      newSelected = [...selectedWidgets, widgetId];
      newWidgets = [
        ...(formData.widgets || []),
        {
          widget_id: widgetId,
          visualization: widget.defaultVis,
          group_by: [],
          filters: [],
          sort: [],
          columns: []
        }
      ];
    }

    setSelectedWidgets(newSelected);
    setFormData({...formData, widgets: newWidgets});
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          Select Widgets
        </CardTitle>
        <CardDescription>
          Choose which metrics and visualizations to include in this scenario
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {WIDGET_CATALOG.map(widget => {
            const Icon = widget.icon;
            const isSelected = selectedWidgets.includes(widget.id);
            
            return (
              <Card
                key={widget.id}
                className={`cursor-pointer transition-all ${
                  isSelected 
                    ? 'border-2 border-blue-500 bg-blue-50' 
                    : 'hover:border-gray-300'
                }`}
                onClick={() => toggleWidget(widget.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox checked={isSelected} className="mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Icon className="w-4 h-4 text-blue-600" />
                        <h4 className="font-semibold text-sm">{widget.title}</h4>
                      </div>
                      <p className="text-xs text-gray-600">{widget.description}</p>
                      <Badge variant="outline" className="mt-2 text-xs">
                        {widget.defaultVis}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {selectedWidgets.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <BarChart3 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>Select widgets to add to your scenario</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}