
import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Users } from "lucide-react";
import TeamManagementContent from "./TeamManagementContent";

export default function TeamManagementDialog({ open, onOpenChange }) {
  const handleUpgradeClick = () => {
    // Close team dialog and signal to open billing
    onOpenChange(false);
    // Small delay to allow dialog to close before opening account settings
    setTimeout(() => {
      // Trigger opening account management with billing tab
      const event = new CustomEvent('openAccountBilling');
      window.dispatchEvent(event);
    }, 300);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold dark:text-gray-100 flex items-center gap-2">
            <Users className="w-6 h-6" />
            Team Management
          </DialogTitle>
          <DialogDescription className="dark:text-gray-400">
            Manage your ranch team members, roles, and invitations
          </DialogDescription>
        </DialogHeader>

        <TeamManagementContent onUpgradeClick={handleUpgradeClick} />
      </DialogContent>
    </Dialog>
  );
}
