
import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";

const TutorialContext = createContext();

export const useTutorial = () => {
  const context = useContext(TutorialContext);
  if (!context) {
    throw new Error('useTutorial must be used within TutorialProvider');
  }
  return context;
};

export const tutorialSteps = [
  {
    id: 1,
    target: '[data-tutorial="dashboard"]',
    page: 'Dashboard',
    title: 'Welcome to Your Dashboard',
    description: 'This is your command center. Here you can see an overview of your ranch operations, including animals, tasks, and financial summaries.',
    position: 'bottom'
  },
  {
    id: 2,
    target: '[data-tutorial="animals-nav"]',
    page: 'Dashboard',
    title: 'Animal Management',
    description: 'Click here to view and manage your entire herd. You can add new animals, track their health, and monitor breeding status.',
    position: 'right'
  },
  {
    id: 3,
    target: '[data-tutorial="animals-stats"]',
    page: 'Animals',
    title: 'Herd Statistics',
    description: 'Keep track of your total animal count, herd value, average weight, and any health issues at a glance.',
    position: 'bottom'
  },
  {
    id: 4,
    target: '[data-tutorial="add-animal"]',
    page: 'Animals',
    title: 'Adding Animals',
    description: 'Use this button to add new animals to your herd. You can record details like name, tag number, breed, weight, and more.',
    position: 'bottom'
  },
  {
    id: 5,
    target: '[data-tutorial="tasks-nav"]',
    page: 'Animals',
    title: 'Tasks & Lists',
    description: 'Stay organized with tasks and lists. Create to-do items, assign them to team members, and set priorities and due dates.',
    position: 'right'
  },
  {
    id: 6,
    target: '[data-tutorial="financials-nav"]',
    page: 'Dashboard',
    title: 'Financial Tracking',
    description: 'Monitor your ranch\'s financial health. Track expenses, revenue, and view profit margins in real-time.',
    position: 'right'
  },
  {
    id: 7,
    target: '[data-tutorial="health-nav"]',
    page: 'Dashboard',
    title: 'Health Records',
    description: 'Maintain comprehensive health records for your animals. Log vaccinations, treatments, and schedule upcoming check-ups.',
    position: 'right'
  },
  {
    id: 8,
    target: '[data-tutorial="breeding-nav"]',
    page: 'Dashboard',
    title: 'Breeding Management',
    description: 'Track breeding cycles, record pregnancies, and manage your herd\'s reproduction program effectively.',
    position: 'right'
  },
  {
    id: 9,
    target: '[data-tutorial="pastures-nav"]',
    page: 'Dashboard',
    title: 'Pasture Management',
    description: 'Manage your pastures, track grazing rotation, and view pasture locations on an interactive map.',
    position: 'right'
  },
  {
    id: 10,
    target: '[data-tutorial="reports-nav"]',
    page: 'Dashboard',
    title: 'Reports & Analytics',
    description: 'Access detailed reports and analytics about your ranch operations. Export data and visualize trends over time.',
    position: 'right'
  },
  {
    id: 11,
    target: '[data-tutorial="account-settings"]',
    page: 'Dashboard',
    title: 'Account Settings',
    description: 'Manage your profile, billing, and subscription preferences here. You can also restart this tutorial anytime from settings.',
    position: 'top'
  },
  {
    id: 12,
    target: '[data-tutorial="complete"]',
    page: 'Dashboard',
    title: 'Tutorial Complete!',
    description: 'You\'re all set! You can now explore HintFarms on your own. Need help? You can restart this tutorial anytime from your account settings.',
    position: 'center'
  }
];

export function TutorialProvider({ children }) {
  const [isActive, setIsActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [highlightedElement, setHighlightedElement] = useState(null);
  const [hasNavigated, setHasNavigated] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const updateTutorialMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
    },
  });

  // Handle navigation when step changes
  useEffect(() => {
    if (isActive && tutorialSteps[currentStep]) {
      const step = tutorialSteps[currentStep];
      const currentPage = location.pathname.split('/').pop() || 'Dashboard';
      
      // Only navigate if we're on the wrong page and haven't navigated yet for this step
      if (step.page !== currentPage && !hasNavigated) {
        setHasNavigated(true);
        navigate(createPageUrl(step.page));
      }
    }
  }, [currentStep, isActive, navigate, hasNavigated, location.pathname]); // Added hasNavigated and location.pathname to dependencies for proper re-evaluation

  // Handle element highlighting after navigation completes
  useEffect(() => {
    if (isActive && tutorialSteps[currentStep]) {
      const step = tutorialSteps[currentStep];
      const currentPage = location.pathname.split('/').pop() || 'Dashboard';
      
      // Only highlight when we're on the correct page
      if (step.page === currentPage) {
        // Reset navigation flag
        setHasNavigated(false);
        
        // Wait for DOM to update
        const timer = setTimeout(() => {
          const element = document.querySelector(step.target);
          if (element) {
            setHighlightedElement(element);
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
        }, 300);

        return () => clearTimeout(timer);
      }
    }
  }, [location.pathname, currentStep, isActive]);

  const startTutorial = () => {
    setIsActive(true);
    setCurrentStep(0);
    setHasNavigated(false); // Reset navigation flag
    updateTutorialMutation.mutate({
      tutorial_status: "In Progress",
      tutorial_progress: 0
    });
    navigate(createPageUrl('Dashboard'));
  };

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      const newStep = currentStep + 1;
      setCurrentStep(newStep);
      setHasNavigated(false); // Reset navigation flag for the next step
      updateTutorialMutation.mutate({
        tutorial_progress: newStep
      });
    } else {
      completeTutorial();
    }
  };

  const previousStep = () => {
    if (currentStep > 0) {
      const newStep = currentStep - 1;
      setCurrentStep(newStep);
      setHasNavigated(false); // Reset navigation flag for the previous step
      updateTutorialMutation.mutate({
        tutorial_progress: newStep
      });
    }
  };

  const skipTutorial = () => {
    setIsActive(false);
    setHighlightedElement(null);
    setHasNavigated(false); // Reset navigation flag
    updateTutorialMutation.mutate({
      tutorial_status: "Skipped",
      tutorial_completed: true
    });
  };

  const completeTutorial = () => {
    setIsActive(false);
    setHighlightedElement(null);
    setHasNavigated(false); // Reset navigation flag
    updateTutorialMutation.mutate({
      tutorial_status: "Completed",
      tutorial_completed: true,
      tutorial_progress: tutorialSteps.length
    });

    const event = new CustomEvent('showToast', {
      detail: { 
        message: 'Tutorial completed! Welcome to HintFarms 🎉',
        type: 'success'
      }
    });
    window.dispatchEvent(event);
  };

  const restartTutorial = () => {
    setCurrentStep(0);
    setHasNavigated(false); // Reset navigation flag
    updateTutorialMutation.mutate({
      tutorial_status: "In Progress",
      tutorial_progress: 0,
      tutorial_completed: false
    });
    startTutorial();
  };

  const pauseTutorial = () => {
    setIsActive(false);
    setHighlightedElement(null);
  };

  const resumeTutorial = () => {
    setIsActive(true);
    setHasNavigated(false); // Reset navigation flag
    const step = user?.tutorial_progress || 0;
    setCurrentStep(step);
  };

  const value = {
    isActive,
    currentStep,
    highlightedElement,
    totalSteps: tutorialSteps.length,
    currentStepData: tutorialSteps[currentStep],
    startTutorial,
    nextStep,
    previousStep,
    skipTutorial,
    completeTutorial,
    restartTutorial,
    pauseTutorial,
    resumeTutorial,
    user
  };

  return (
    <TutorialContext.Provider value={value}>
      {children}
    </TutorialContext.Provider>
  );
}
