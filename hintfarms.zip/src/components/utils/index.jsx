export function createPageUrl(pageName) {
  return `/${pageName}`;
}

const GA_MEASUREMENT_ID = import.meta.env.VITE_GA_MEASUREMENT_ID;
const IS_PRODUCTION = import.meta.env.MODE === 'production';
const IS_STAGING = import.meta.env.MODE === 'staging';

let isInitialized = false;

export function initGA() {
  if (!GA_MEASUREMENT_ID || (!IS_PRODUCTION && !IS_STAGING)) {
    return;
  }

  if (isInitialized) {
    return;
  }

  try {
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    function gtag() {
      window.dataLayer.push(arguments);
    }
    window.gtag = gtag;

    gtag('js', new Date());
    gtag('config', GA_MEASUREMENT_ID, {
      send_page_view: false
    });

    isInitialized = true;
  } catch (error) {
    console.error('[GA4] Error:', error);
  }
}

export function trackPageView(pageName, pageUrl) {
  if (!isInitialized) return;

  try {
    window.gtag('event', 'page_view', {
      page_title: pageName,
      page_location: window.location.href,
      page_path: pageUrl || window.location.pathname
    });
  } catch (error) {
    console.error('[GA4] Error:', error);
  }
}

export function trackEvent(eventName, eventParams) {
  if (!isInitialized) return;

  try {
    window.gtag('event', eventName, eventParams || {});
  } catch (error) {
    console.error('[GA4] Error:', error);
  }
}

export function setUserProperties(userId, properties) {
  if (!isInitialized) return;

  try {
    window.gtag('set', 'user_properties', {
      user_id: userId,
      ...(properties || {})
    });
  } catch (error) {
    console.error('[GA4] Error:', error);
  }
}

export const trackSignupComplete = (userId) => 
  trackEvent('signup_complete', { user_id: userId });

export const trackOnboardingFinish = (userId, ranchId) => 
  trackEvent('onboarding_finish', { user_id: userId, ranch_id: ranchId });

export const trackRanchSwitch = (userId, ranchId, ranchName) => 
  trackEvent('ranch_switch', { user_id: userId, ranch_id: ranchId, ranch_name: ranchName });

export const trackRanchCreate = (userId, ranchId, ranchName) => 
  trackEvent('ranch_create', { user_id: userId, ranch_id: ranchId, ranch_name: ranchName });

export const trackAnimalAdd = (userId, ranchId, animalType) => 
  trackEvent('animal_add', { user_id: userId, ranch_id: ranchId, animal_type: animalType });

export const trackAnimalUpdate = (userId, ranchId, animalId) => 
  trackEvent('animal_update', { user_id: userId, ranch_id: ranchId, animal_id: animalId });

export const trackTaskCreate = (userId, ranchId, priority, assigned) => 
  trackEvent('task_create', { user_id: userId, ranch_id: ranchId, priority, assigned_to: assigned });

export const trackTaskComplete = (userId, ranchId, taskId) => 
  trackEvent('task_complete', { user_id: userId, ranch_id: ranchId, task_id: taskId });

export const trackExpenseAdd = (userId, ranchId, category, amount) => 
  trackEvent('expense_add', { user_id: userId, ranch_id: ranchId, category, amount });

export const trackRevenueAdd = (userId, ranchId, category, amount) => 
  trackEvent('revenue_add', { user_id: userId, ranch_id: ranchId, category, amount });

export const trackReportExport = (userId, ranchId, reportType) => 
  trackEvent('report_export', { user_id: userId, ranch_id: ranchId, report_type: reportType });

export const trackInviteSend = (userId, ranchId, role) => 
  trackEvent('invite_send', { user_id: userId, ranch_id: ranchId, role });

export const trackInviteAccept = (userId, ranchId, role) => 
  trackEvent('invite_accept', { user_id: userId, ranch_id: ranchId, role });

export const trackPlanUpgrade = (userId, ranchId, fromPlan, toPlan) => 
  trackEvent('plan_upgrade', { user_id: userId, ranch_id: ranchId, from_plan: fromPlan, to_plan: toPlan });

export const trackPlanDowngrade = (userId, ranchId, fromPlan, toPlan) => 
  trackEvent('plan_downgrade', { user_id: userId, ranch_id: ranchId, from_plan: fromPlan, to_plan: toPlan });

export const trackBillingPortalOpen = (userId, ranchId) => 
  trackEvent('billing_portal_open', { user_id: userId, ranch_id: ranchId });

export const trackHealthRecordAdd = (userId, ranchId, recordType) => 
  trackEvent('health_record_add', { user_id: userId, ranch_id: ranchId, record_type: recordType });

export const trackBreedingRecordAdd = (userId, ranchId, recordType) => 
  trackEvent('breeding_record_add', { user_id: userId, ranch_id: ranchId, record_type: recordType });

export const trackBankConnect = (userId, ranchId, institutionName) => 
  trackEvent('bank_connect', { user_id: userId, ranch_id: ranchId, institution: institutionName });

export const trackBankSyncSuccess = (userId, ranchId, transactionCount) => 
  trackEvent('bank_sync_success', { user_id: userId, ranch_id: ranchId, transaction_count: transactionCount });

export const trackPastureAdd = (userId, ranchId, pastureName) => 
  trackEvent('pasture_add', { user_id: userId, ranch_id: ranchId, pasture_name: pastureName });

export const trackError = (userId, ranchId, errorType, errorMessage) => 
  trackEvent('error_message', { user_id: userId, ranch_id: ranchId, error_type: errorType, error_message: errorMessage });