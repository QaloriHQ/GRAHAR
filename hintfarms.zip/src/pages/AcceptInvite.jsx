import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, CheckCircle2, XCircle, AlertCircle, Building2, Mail, UserCheck } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { trackInviteAccept } from "@/components/utils";

export default function AcceptInvite() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [inviteToken, setInviteToken] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [ranchName, setRanchName] = useState('');

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      try {
        return await base44.auth.me();
      } catch {
        return null;
      }
    },
  });

  // Extract token from URL on mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    if (token) {
      setInviteToken(token);
    } else {
      setError('No invitation token provided. Please use the link from your invitation email.');
    }
  }, []);

  // Handle authentication redirect
  useEffect(() => {
    if (!userLoading && !user && inviteToken) {
      console.log('User not authenticated, redirecting to login');
      const nextUrl = `/AcceptInvite?token=${encodeURIComponent(inviteToken)}`;
      base44.auth.redirectToLogin(nextUrl);
    }
  }, [user, userLoading, inviteToken]);

  const acceptInviteMutation = useMutation({
    mutationFn: async (token) => {
      const response = await base44.functions.invoke('acceptRanchInvite', { token });
      return response.data;
    },
    onSuccess: async (data) => {
      console.log('Invite accepted successfully:', data);
      
      setSuccess(true);
      setRanchName(data.ranch_name);
      
      // Track the invite acceptance
      trackInviteAccept(data.ranch_id, data.ranch_name, data.invited_email);

      // Show success toast
      const event = new CustomEvent('showToast', {
        detail: { 
          message: `You've successfully joined ${data.ranch_name}!`, 
          type: 'success' 
        }
      });
      window.dispatchEvent(event);

      // Invalidate all relevant queries
      await queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      await queryClient.invalidateQueries({ queryKey: ['userRanchMembers'] });
      await queryClient.invalidateQueries({ queryKey: ['ownedRanches'] });
      await queryClient.invalidateQueries({ queryKey: ['activeRanch'] });
      await queryClient.invalidateQueries({ queryKey: ['ranchMembers'] });
      await queryClient.invalidateQueries({ queryKey: ['pendingInvites'] });
      
      // CRITICAL: Explicitly fetch the latest currentUser data to ensure active_ranch_id is updated
      console.log('Fetching updated user data...');
      const updatedUser = await queryClient.fetchQuery({
        queryKey: ['currentUser'],
        queryFn: () => base44.auth.me()
      });
      
      console.log('Updated user data:', updatedUser);
      console.log('Expected ranch_id:', data.ranch_id);
      console.log('User active_ranch_id:', updatedUser?.active_ranch_id);
      
      // Verify that the active_ranch_id matches what we expect
      if (updatedUser?.active_ranch_id === data.ranch_id) {
        console.log('Active ranch ID verified, navigating to dashboard');
        // Short delay to allow toast to be visible
        setTimeout(() => {
          navigate(createPageUrl('Dashboard'));
        }, 1000);
      } else {
        console.error('Active ranch ID mismatch after acceptance');
        setError('Your ranch access was granted, but there was an issue setting it as active. Please refresh the page or select the ranch manually.');
      }
    },
    onError: (error) => {
      console.error('Accept invite error:', error);
      
      const errorData = error.response?.data || error.data || {};
      const errorType = errorData.error;
      const errorMessage = errorData.message;
      
      if (errorType === 'expired') {
        setError('This invitation has expired. Please request a new invitation from your ranch administrator.');
      } else if (errorType === 'invalid') {
        setError('Invalid invitation link. Please check your email for the correct link or request a new invitation.');
      } else if (errorType === 'email_mismatch') {
        setError(`This invitation was sent to ${errorData.invited_email}. Please sign out and sign in with that email address to accept this invitation.`);
      } else if (errorType === 'used') {
        setError('This invitation has already been used.');
      } else {
        setError(errorMessage || 'Failed to accept invitation. Please try again or contact support.');
      }
    },
  });

  // Trigger invitation acceptance when user is authenticated and token is available
  useEffect(() => {
    if (user && inviteToken && !success && !error && !acceptInviteMutation.isPending) {
      console.log('User authenticated, accepting invite');
      acceptInviteMutation.mutate(inviteToken);
    }
  }, [user, inviteToken, success, error]);

  // Show loading state while checking authentication or processing invite
  if (userLoading || (user && inviteToken && acceptInviteMutation.isPending && !success && !error)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 flex items-center justify-center p-6">
        <Card className="w-full max-w-md dark:bg-gray-950 dark:border-gray-800">
          <CardContent className="p-12 text-center">
            <Loader2 className="w-16 h-16 animate-spin text-[#F5A623] mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
              Processing Your Invitation
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Please wait while we set up your ranch access...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 flex items-center justify-center p-6">
        <Card className="w-full max-w-md dark:bg-gray-950 dark:border-gray-800">
          <CardHeader>
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
            </div>
            <CardTitle className="text-center dark:text-gray-100">Invitation Error</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="destructive" className="dark:border-red-800">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Unable to Accept Invitation</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
            <div className="flex flex-col gap-2">
              <Button onClick={() => navigate(createPageUrl('Dashboard'))} variant="outline" className="w-full">
                Go to Dashboard
              </Button>
              <Button 
                onClick={() => window.location.href = 'mailto:support@grahar.com'} 
                variant="ghost" 
                className="w-full"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show success state
  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 flex items-center justify-center p-6">
        <Card className="w-full max-w-md dark:bg-gray-950 dark:border-gray-800">
          <CardHeader>
            <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-[#F5A623]" />
            </div>
            <CardTitle className="text-center dark:text-gray-100">Welcome to the Team!</CardTitle>
            <CardDescription className="text-center dark:text-gray-400">
              You've successfully joined {ranchName}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Building2 className="w-5 h-5 text-[#F5A623] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-orange-900 dark:text-orange-100">
                    Ranch Access Granted
                  </p>
                  <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
                    You can now access and contribute to {ranchName}'s operations.
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <Loader2 className="w-5 h-5 animate-spin text-[#F5A623] mr-2" />
              <p className="text-sm text-gray-600 dark:text-gray-400">Taking you to the dashboard...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}