import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Shield } from "lucide-react";
import AdminLayout from "../components/admin/AdminLayout";
import AccountManagement from "../components/admin/AccountManagement";
import TicketManagement from "../components/admin/TicketManagement";
import AnnouncementManagement from "../components/admin/AnnouncementManagement";
import CommunicationCenter from "../components/admin/CommunicationCenter";
import SystemStats from "../components/admin/SystemStats";
import LeadManagement from "../components/admin/LeadManagement";
import ContactManagement from "../components/admin/ContactManagement";
import DealTracking from "../components/admin/DealTracking";
import AnalyticsDashboard from "../components/admin/AnalyticsDashboard";
import SystemLogs from "../components/admin/SystemLogs";
import IntegrationStatus from "../components/admin/IntegrationStatus";
import BulkOperations from "../components/admin/BulkOperations";

export default function AdminPortal() {
  const [activeSection, setActiveSection] = useState("stats");

  const { data: user, isLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <p className="text-gray-600 dark:text-gray-400">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Admin access control
  if (!user || user.role !== 'admin') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-900">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <Shield className="w-16 h-16 mx-auto mb-4 text-red-500" />
            <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
            <p className="text-gray-600 dark:text-gray-400">
              You don't have permission to access the admin portal.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const renderSection = () => {
    switch (activeSection) {
      case "stats":
        return <SystemStats />;
      case "analytics":
        return <AnalyticsDashboard />;
      case "accounts":
        return <AccountManagement />;
      case "leads":
        return <LeadManagement />;
      case "contacts":
        return <ContactManagement />;
      case "deals":
        return <DealTracking />;
      case "tickets":
        return <TicketManagement />;
      case "announcements":
        return <AnnouncementManagement />;
      case "communications":
        return <CommunicationCenter />;
      case "logs":
        return <SystemLogs />;
      case "integrations":
        return <IntegrationStatus />;
      case "bulk":
        return <BulkOperations />;
      default:
        return <SystemStats />;
    }
  };

  return (
    <AdminLayout activeSection={activeSection} onSectionChange={setActiveSection}>
      {renderSection()}
    </AdminLayout>
  );
}