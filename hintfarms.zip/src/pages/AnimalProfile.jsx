import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter, // Added DialogFooter
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ArrowLeft,
  Edit,
  Trash2,
  Plus,
  Heart,
  Syringe,
  Calendar,
  DollarSign,
  TrendingUp,
  MapPin,
  Beef,
  Save,
  X,
  Camera,
  Upload,
  CheckSquare,
  Baby, // Added Baby icon
  Weight, // Added Weight icon
  Activity, // Added Activity icon
  FileText, // Added FileText icon
  AlertCircle, // Added AlertCircle icon
} from "lucide-react";
import { format } from "date-fns";
import BreedingRecordForm from "../components/breeding/BreedingRecordForm";
import AnimalSelector from "../components/animals/AnimalSelector";
import { trackAnimalUpdate } from "@/components/utils"; // Added trackAnimalUpdate

export default function AnimalProfile() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showHealthDialog, setShowHealthDialog] = useState(false);
  const [showBreedingDialog, setShowBreedingDialog] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [showSireSelector, setShowSireSelector] = useState(false);
  const [showDamSelector, setShowDamSelector] = useState(false);
  const fileInputRef = useRef(null);

  // Get animal ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const animalId = urlParams.get('id');

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Fetch animal data
  const { data: animals = [], isLoading: isLoadingAnimal, error: animalError } = useQuery({
    queryKey: ['animal', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.Animal.filter({
        id: animalId,
        ranch_id: user.active_ranch_id
      });
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  const animal = animals[0];

  // Fetch health records for this animal
  const { data: healthRecords = [] } = useQuery({
    queryKey: ['healthRecords', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.HealthRecord.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch breeding records
  const { data: breedingRecords = [] } = useQuery({
    queryKey: ['breedingRecords', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.BreedingRecord.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-breeding_date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch pasture history
  const { data: pastureHistory = [] } = useQuery({
    queryKey: ['pastureHistory', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.PastureHistory.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-moved_date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch related revenue
  const { data: relatedRevenue = [] } = useQuery({
    queryKey: ['relatedRevenue', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.Revenue.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch related expenses
  const { data: relatedExpenses = [] } = useQuery({
    queryKey: ['relatedExpenses', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.Expense.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch related tasks
  const { data: relatedTasks = [] } = useQuery({
    queryKey: ['relatedTasks', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.Task.filter({
        related_animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-due_date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch notes for this animal
  const { data: notes = [] } = useQuery({
    queryKey: ['notes', animalId, user?.active_ranch_id],
    queryFn: async () => {
      if (!animalId || !user?.active_ranch_id) return [];
      return await base44.entities.Note.filter({
        animal_id: animalId,
        ranch_id: user.active_ranch_id
      }, '-created_date');
    },
    enabled: !!animalId && !!user?.active_ranch_id,
  });

  // Fetch pastures
  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return [];
      return await base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id });
    },
    enabled: !!user?.active_ranch_id,
  });

  const [editedAnimal, setEditedAnimal] = useState(null);
  const [newHealthRecord, setNewHealthRecord] = useState({
    record_type: "Vaccination",
    date: new Date().toISOString().split('T')[0],
    description: "",
    medication_name: "",
    dosage: "",
    veterinarian: "",
    cost: 0,
    status: "Completed"
  });

  const [newNote, setNewNote] = useState("");

  // Initialize editedAnimal when animal data loads
  useEffect(() => {
    if (animal && !editedAnimal) {
      setEditedAnimal({ ...animal });
    }
  }, [animal, editedAnimal]);

  const updateAnimalMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Animal.update(id, data),
    onSuccess: (updatedAnimal) => {
      queryClient.invalidateQueries({ queryKey: ['animal', animalId] });
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      setEditMode(false);

      if (animal && updatedAnimal && user?.active_ranch_id) {
        trackAnimalUpdate({
          oldData: animal,
          newData: updatedAnimal,
          animalId: animal.id,
          ranchId: user.active_ranch_id,
          userId: user.id
        });
      }

      const event = new CustomEvent('showToast', {
        detail: { message: 'Animal updated successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to update animal: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const deleteAnimalMutation = useMutation({
    mutationFn: (id) => base44.entities.Animal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['animals'] });
      navigate(createPageUrl("Animals"));

      const event = new CustomEvent('showToast', {
        detail: { message: 'Animal deleted successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to delete animal: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const createHealthRecordMutation = useMutation({
    mutationFn: (data) => base44.entities.HealthRecord.create({
      ...data,
      ranch_id: user.active_ranch_id,
      animal_id: animalId,
      animal_name: animal.name
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
      setShowHealthDialog(false);
      setNewHealthRecord({
        record_type: "Vaccination",
        date: new Date().toISOString().split('T')[0],
        description: "",
        medication_name: "",
        dosage: "",
        veterinarian: "",
        cost: 0,
        status: "Completed"
      });

      const event = new CustomEvent('showToast', {
        detail: { message: 'Health record added successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to add health record: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const createBreedingRecordMutation = useMutation({
    mutationFn: (data) => base44.entities.BreedingRecord.create({
      ...data,
      ranch_id: user.active_ranch_id,
      animal_id: animalId,
      animal_name: animal.name
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['breedingRecords'] });
      setShowBreedingDialog(false);
      const event = new CustomEvent('showToast', {
        detail: { message: 'Breeding record added successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to add breeding record: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const createNoteMutation = useMutation({
    mutationFn: (noteText) => base44.entities.Note.create({
      ranch_id: user.active_ranch_id,
      animal_id: animalId,
      animal_name: animal.name,
      note_text: noteText,
      created_by_name: user.full_name
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      setNewNote("");
      const event = new CustomEvent('showToast', {
        detail: { message: 'Note added successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to add note: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const handleSave = () => {
    if (editedAnimal && animal) {
      updateAnimalMutation.mutate({ id: animal.id, data: editedAnimal });
    }
  };

  const handleDelete = () => {
    if (animal) {
      deleteAnimalMutation.mutate(animal.id);
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      await updateAnimalMutation.mutateAsync({
        id: animal.id,
        data: { main_image_url: response.file_url }
      });

      const event = new CustomEvent('showToast', {
        detail: { message: 'Photo updated successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    } catch (error) {
      const event = new CustomEvent('showToast', {
        detail: { message: `Failed to upload photo: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleAddSire = (sireAnimal) => {
    if (sireAnimal.id === animal.id) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Cannot set animal as its own sire', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }
    if (sireAnimal.id === animal.dam_id) {
        const event = new CustomEvent('showToast', {
            detail: { message: 'Cannot set dam as sire', type: 'error' }
        });
        window.dispatchEvent(event);
        return;
    }

    updateAnimalMutation.mutate({
      id: animal.id,
      data: {
        sire_id: sireAnimal.id,
        sire_name: sireAnimal.name
      }
    });
    setShowSireSelector(false);
  };

  const handleAddDam = (damAnimal) => {
    if (damAnimal.id === animal.id) {
      const event = new CustomEvent('showToast', {
        detail: { message: 'Cannot set animal as its own dam', type: 'error' }
      });
      window.dispatchEvent(event);
      return;
    }
    if (damAnimal.id === animal.sire_id) {
        const event = new CustomEvent('showToast', {
            detail: { message: 'Cannot set sire as dam', type: 'error' }
        });
        window.dispatchEvent(event);
        return;
    }

    updateAnimalMutation.mutate({
      id: animal.id,
      data: {
        dam_id: damAnimal.id,
        dam_name: damAnimal.name
      }
    });
    setShowDamSelector(false);
  };

  // Loading and error states
  if (!animalId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 p-6">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 text-center">
            <p className="text-gray-600 dark:text-gray-400 mb-4">No animal ID provided</p>
            <Button onClick={() => navigate(createPageUrl("Animals"))}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Animals
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  if (isLoadingAnimal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 p-6 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading animal profile...</p>
        </div>
      </div>
    );
  }

  if (animalError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 p-6">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 text-center border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800">
            <p className="text-red-600 dark:text-red-400 mb-4">Error loading animal: {animalError.message}</p>
            <Button onClick={() => navigate(createPageUrl("Animals"))}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Animals
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  if (!animal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 p-6">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 text-center">
            <Beef className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400 mb-4">Animal not found</p>
            <Button onClick={() => navigate(createPageUrl("Animals"))}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Animals
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  const healthStatusColors = {
    "Healthy": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
    "Under Treatment": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800",
    "Urgent Attention": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800",
    "Recovering": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800"
  };

  const breedingStatusColors = {
    "Active Breeding": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800",
    "Pregnant": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/20 dark:text-pink-400 dark:border-pink-800",
    "Not Breeding": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-800",
    "Retired": "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/20 dark:text-orange-400 dark:border-orange-800"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 p-4 md:p-6">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header with Main Image */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("Animals"))}
            className="mb-4 dark:text-gray-300 dark:hover:bg-gray-800"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Animals
          </Button>

          <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700 overflow-hidden">
            {/* Main Image Section */}
            <div className="relative h-64 bg-gradient-to-br from-emerald-500 to-green-600">
              {animal.main_image_url ? (
                <img
                  src={animal.main_image_url}
                  alt={animal.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Beef className="w-24 h-24 text-white/30" />
                </div>
              )}

              {/* Change Photo Button */}
              <Button
                variant="secondary"
                size="sm"
                className="absolute bottom-4 right-4 shadow-lg"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingImage}
              >
                {uploadingImage ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Uploading...
                  </>
                ) : (
                  <>
                    <Camera className="w-4 h-4 mr-2" />
                    Change Photo
                  </>
                )}
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageUpload}
              />
            </div>

            {/* Profile Info */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">{animal.name}</h1>
                  <p className="text-gray-600 dark:text-gray-400">Tag: {animal.tag_number}</p>

                  {/* Pedigree Links */}
                  <div className="flex flex-wrap gap-3 mt-3">
                    {animal.sire_id ? (
                      <Link to={`${createPageUrl("AnimalProfile")}?id=${animal.sire_id}`}>
                        <Badge className="bg-blue-100 text-blue-800 border-blue-200 hover:bg-blue-200 cursor-pointer dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800">
                          Sire: {animal.sire_name}
                        </Badge>
                      </Link>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowSireSelector(true)}
                        className="text-xs dark:border-gray-700 dark:text-gray-300"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Add Sire
                      </Button>
                    )}

                    {animal.dam_id ? (
                      <Link to={`${createPageUrl("AnimalProfile")}?id=${animal.dam_id}`}>
                        <Badge className="bg-pink-100 text-pink-800 border-pink-200 hover:bg-pink-200 cursor-pointer dark:bg-pink-900/20 dark:text-pink-400 dark:border-pink-800">
                          Dam: {animal.dam_name}
                        </Badge>
                      </Link>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowDamSelector(true)}
                        className="text-xs dark:border-gray-700 dark:text-gray-300"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Add Dam
                      </Button>
                    )}
                  </div>
                </div>

                <div className="flex gap-3">
                  {!editMode ? (
                    <>
                      <Button
                        variant="outline"
                        onClick={() => setEditMode(true)}
                        className="dark:border-gray-700 dark:text-gray-300"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowDeleteDialog(true)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setEditMode(false);
                          setEditedAnimal({ ...animal });
                        }}
                        className="dark:border-gray-700 dark:text-gray-300"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </Button>
                      <Button
                        onClick={handleSave}
                        className="bg-emerald-600 hover:bg-emerald-700"
                        disabled={updateAnimalMutation.isPending}
                      >
                        {updateAnimalMutation.isPending ? (
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        ) : (
                            <Save className="w-4 h-4 mr-2" />
                        )}
                        Save Changes
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Tabs for Different Sections */}
        <Tabs defaultValue="details" className="space-y-6">
          <TabsList className="dark:bg-gray-800 grid w-full grid-cols-3 md:grid-cols-7 md:w-fit">
            <TabsTrigger value="details" className="dark:data-[state=active]:bg-gray-700">Details</TabsTrigger>
            <TabsTrigger value="health" className="dark:data-[state=active]:bg-gray-700">Health</TabsTrigger>
            <TabsTrigger value="breeding" className="dark:data-[state=active]:bg-gray-700">Breeding</TabsTrigger>
            <TabsTrigger value="financials" className="dark:data-[state=active]:bg-gray-700">Financials</TabsTrigger>
            <TabsTrigger value="pastures" className="dark:data-[state=active]:bg-gray-700">Pastures</TabsTrigger>
            <TabsTrigger value="tasks" className="dark:data-[state=active]:bg-gray-700">Tasks</TabsTrigger>
            <TabsTrigger value="notes" className="dark:data-[state=active]:bg-gray-700">Notes</TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent value="details" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100">Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="dark:text-gray-300">Name</Label>
                    {editMode ? (
                      <Input
                        value={editedAnimal?.name || ''}
                        onChange={(e) => setEditedAnimal({...editedAnimal, name: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.name}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Tag Number</Label>
                    {editMode ? (
                      <Input
                        value={editedAnimal?.tag_number || ''}
                        onChange={(e) => setEditedAnimal({...editedAnimal, tag_number: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.tag_number}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Type</Label>
                    {editMode ? (
                      <Select value={editedAnimal?.type} onValueChange={(value) => setEditedAnimal({...editedAnimal, type: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Cattle" className="dark:text-gray-100">Cattle</SelectItem>
                          <SelectItem value="Calf" className="dark:text-gray-100">Calf</SelectItem>
                          <SelectItem value="Bull" className="dark:text-gray-100">Bull</SelectItem>
                          <SelectItem value="Heifer" className="dark:text-gray-100">Heifer</SelectItem>
                          <SelectItem value="Steer" className="dark:text-gray-100">Steer</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.type}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Breed</Label>
                    {editMode ? (
                      <Input
                        value={editedAnimal?.breed || ''}
                        onChange={(e) => setEditedAnimal({...editedAnimal, breed: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.breed}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Gender</Label>
                    {editMode ? (
                      <Select value={editedAnimal?.gender} onValueChange={(value) => setEditedAnimal({...editedAnimal, gender: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Male" className="dark:text-gray-100">Male</SelectItem>
                          <SelectItem value="Female" className="dark:text-gray-100">Female</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.gender}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Date of Birth</Label>
                    {editMode ? (
                      <Input
                        type="date"
                        value={editedAnimal?.date_of_birth || ''}
                        onChange={(e) => setEditedAnimal({...editedAnimal, date_of_birth: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">
                        {animal.date_of_birth ? format(new Date(animal.date_of_birth), "MMM d, yyyy") : "N/A"}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Weight (lbs)</Label>
                    {editMode ? (
                      <Input
                        type="number"
                        value={editedAnimal?.weight || 0}
                        onChange={(e) => setEditedAnimal({...editedAnimal, weight: parseFloat(e.target.value)})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.weight} lbs</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Current Value</Label>
                    {editMode ? (
                      <Input
                        type="number"
                        value={editedAnimal?.current_value || 0}
                        onChange={(e) => setEditedAnimal({...editedAnimal, current_value: parseFloat(e.target.value)})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                        ${animal.current_value?.toLocaleString()}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Pasture</Label>
                    {editMode ? (
                      <Select 
                        value={editedAnimal?.pasture_id || "none"} 
                        onValueChange={(value) => {
                          if (value === "none") {
                            setEditedAnimal({...editedAnimal, pasture_id: null, pasture_location: ""});
                          } else {
                            const selectedPasture = pastures.find(p => p.id === value);
                            setEditedAnimal({
                              ...editedAnimal, 
                              pasture_id: value,
                              pasture_location: selectedPasture?.name || ""
                            });
                          }
                        }}
                      >
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue placeholder="Select a pasture" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="none" className="dark:text-gray-100">No Pasture</SelectItem>
                          {pastures.map(pasture => (
                            <SelectItem key={pasture.id} value={pasture.id} className="dark:text-gray-100">
                              {pasture.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{animal.pasture_location || "N/A"}</p>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Health Status</Label>
                    {editMode ? (
                      <Select value={editedAnimal?.health_status} onValueChange={(value) => setEditedAnimal({...editedAnimal, health_status: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Healthy" className="dark:text-gray-100">Healthy</SelectItem>
                          <SelectItem value="Under Treatment" className="dark:text-gray-100">Under Treatment</SelectItem>
                          <SelectItem value="Urgent Attention" className="dark:text-gray-100">Urgent Attention</SelectItem>
                          <SelectItem value="Recovering" className="dark:text-gray-100">Recovering</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge className={`${healthStatusColors[animal.health_status]} border`}>
                        {animal.health_status}
                      </Badge>
                    )}
                  </div>
                  <div>
                    <Label className="dark:text-gray-300">Breeding Status</Label>
                    {editMode ? (
                      <Select value={editedAnimal?.breeding_status} onValueChange={(value) => setEditedAnimal({...editedAnimal, breeding_status: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Active Breeding" className="dark:text-gray-100">Active Breeding</SelectItem>
                          <SelectItem value="Pregnant" className="dark:text-gray-100">Pregnant</SelectItem>
                          <SelectItem value="Not Breeding" className="dark:text-gray-100">Not Breeding</SelectItem>
                          <SelectItem value="Retired" className="dark:text-gray-100">Retired</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge className={`${breedingStatusColors[animal.breeding_status]} border`}>
                        {animal.breeding_status}
                      </Badge>
                    )}
                  </div>
                </div>
                {(editMode || animal.notes) && (
                  <div>
                    <Label className="dark:text-gray-300">Notes</Label>
                    {editMode ? (
                      <Textarea
                        value={editedAnimal?.notes || ''}
                        onChange={(e) => setEditedAnimal({...editedAnimal, notes: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                        rows={3}
                      />
                    ) : (
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{animal.notes}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Financial Summary Card */}
            <Card className="border-none shadow-lg bg-gradient-to-br from-emerald-500 to-green-600 text-white">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 opacity-90">Financial Summary</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm opacity-80 mb-1">Purchase Price</p>
                    <p className="text-2xl font-bold">${animal.purchase_price?.toLocaleString()}</p>
                  </div>
                  <div className="pt-4 border-t border-white/20">
                    <p className="text-sm opacity-80 mb-1">Current Value</p>
                    <p className="text-2xl font-bold">${animal.current_value?.toLocaleString()}</p>
                  </div>
                  <div className="pt-4 border-t border-white/20">
                    <p className="text-sm opacity-80 mb-1">Value Gain</p>
                    <p className="text-2xl font-bold">
                      ${((animal.current_value || 0) - (animal.purchase_price || 0)).toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Health Tab */}
          <TabsContent value="health" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                    <Heart className="w-5 h-5" />
                    Health Records
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={() => setShowHealthDialog(true)}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Record
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {healthRecords.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Date</TableHead>
                        <TableHead className="dark:text-gray-400">Type</TableHead>
                        <TableHead className="dark:text-gray-400">Description</TableHead>
                        <TableHead className="dark:text-gray-400">Cost</TableHead>
                        <TableHead className="dark:text-gray-400">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {healthRecords.map((record) => (
                        <TableRow key={record.id} className="dark:border-gray-700">
                          <TableCell className="dark:text-gray-300">{format(new Date(record.date), "MMM d, yyyy")}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.record_type}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.description}</TableCell>
                          <TableCell className="font-semibold dark:text-gray-200">${record.cost?.toLocaleString()}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.status}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <Heart className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No health records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Health Summary Card */}
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="text-lg font-bold dark:text-gray-100">Health Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 dark:text-gray-400">Total Records</span>
                    <span className="font-bold text-xl dark:text-gray-200">{healthRecords.length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 dark:text-gray-400">Total Health Cost</span>
                    <span className="font-bold text-xl text-emerald-600 dark:text-emerald-400">
                      ${healthRecords.reduce((sum, r) => sum + (r.cost || 0), 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 dark:text-gray-400">Last Checkup</span>
                    <span className="font-semibold dark:text-gray-200">
                      {healthRecords.length > 0
                        ? format(new Date(healthRecords[0].date), "MMM d")
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Breeding Tab */}
          <TabsContent value="breeding" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                    <Syringe className="w-5 h-5" />
                    Breeding Records
                  </CardTitle>
                  <Button
                    size="sm"
                    onClick={() => setShowBreedingDialog(true)}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Breeding Record
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {breedingRecords.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Date</TableHead>
                        <TableHead className="dark:text-gray-400">Type</TableHead>
                        <TableHead className="dark:text-gray-400">Sire</TableHead>
                        <TableHead className="dark:text-gray-400">Outcome</TableHead>
                        <TableHead className="dark:text-gray-400">Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {breedingRecords.map((record) => (
                        <TableRow key={record.id} className="dark:border-gray-700">
                          <TableCell className="dark:text-gray-300">{format(new Date(record.breeding_date), "MMM d, yyyy")}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.record_type || '-'}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.bull_name || '-'}</TableCell>
                          <TableCell>
                            <Badge className="dark:bg-purple-900/20 dark:text-purple-400">
                              {record.outcome || '-'}
                            </Badge>
                          </TableCell>
                          <TableCell className="dark:text-gray-300 max-w-[200px] truncate">{record.notes || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <Syringe className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No breeding records yet</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Breeding Summary Card */}
            {animal.gender === 'Female' && (
              <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-lg font-bold dark:text-gray-100">Breeding Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Total Breedings</span>
                      <span className="font-bold text-xl dark:text-gray-200">{breedingRecords.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Successful Calves</span>
                      <span className="font-bold text-xl text-emerald-600 dark:text-emerald-400">
                        {breedingRecords.filter(r => r.outcome === "Calved").length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 dark:text-gray-400">Last Breeding</span>
                      <span className="font-semibold dark:text-gray-200">
                        {breedingRecords.length > 0
                          ? format(new Date(breedingRecords[0].breeding_date), "MMM d")
                          : "N/A"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Financials Tab */}
          <TabsContent value="financials" className="space-y-6">
            {/* Related Revenue */}
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
                    Related Revenue
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(createPageUrl("Revenue") + `?animal_id=${animalId}`)}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Revenue
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {relatedRevenue.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Date</TableHead>
                        <TableHead className="dark:text-gray-400">Category</TableHead>
                        <TableHead className="dark:text-gray-400">Description</TableHead>
                        <TableHead className="dark:text-gray-400">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {relatedRevenue.map((rev) => (
                        <TableRow key={rev.id} className="dark:border-gray-700 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                          <TableCell className="dark:text-gray-300">{format(new Date(rev.date), "MMM d, yyyy")}</TableCell>
                          <TableCell className="dark:text-gray-300">{rev.category}</TableCell>
                          <TableCell className="dark:text-gray-300">{rev.description}</TableCell>
                          <TableCell className="font-semibold text-green-600 dark:text-green-400">${rev.amount?.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <DollarSign className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No revenue linked yet. Add one.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Related Expenses */}
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-red-600 dark:text-red-400" />
                    Related Expenses
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(createPageUrl("Expenses") + `?animal_id=${animalId}`)}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Expense
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {relatedExpenses.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Date</TableHead>
                        <TableHead className="dark:text-gray-400">Category</TableHead>
                        <TableHead className="dark:text-gray-400">Description</TableHead>
                        <TableHead className="dark:text-gray-400">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {relatedExpenses.map((exp) => (
                        <TableRow key={exp.id} className="dark:border-gray-700 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                          <TableCell className="dark:text-gray-300">{format(new Date(exp.date), "MMM d, yyyy")}</TableCell>
                          <TableCell className="dark:text-gray-300">{exp.category}</TableCell>
                          <TableCell className="dark:text-gray-300">{exp.description}</TableCell>
                          <TableCell className="font-semibold text-red-600 dark:text-red-400">${exp.amount?.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <DollarSign className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No expenses linked yet. Add one.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pastures Tab */}
          <TabsContent value="pastures" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Pasture Movements
                </CardTitle>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {pastureHistory.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Date Moved</TableHead>
                        <TableHead className="dark:text-gray-400">Pasture</TableHead>
                        <TableHead className="dark:text-gray-400">Moved From</TableHead>
                        <TableHead className="dark:text-gray-400">Reason</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pastureHistory.map((record) => (
                        <TableRow key={record.id} className="dark:border-gray-700">
                          <TableCell className="dark:text-gray-300">{format(new Date(record.moved_date), "MMM d, yyyy")}</TableCell>
                          <TableCell className="dark:text-gray-300">
                            <Link
                              to={`${createPageUrl("Pastures")}?id=${record.pasture_id}`}
                              className="text-emerald-600 dark:text-emerald-400 hover:underline"
                            >
                              {record.pasture_name}
                            </Link>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">{record.moved_from || "-"}</TableCell>
                          <TableCell className="dark:text-gray-300">{record.reason || "-"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <MapPin className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No pasture movements recorded yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                    <CheckSquare className="w-5 h-5" />
                    Related Tasks
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigate(createPageUrl("Tasks") + `?related_animal_id=${animalId}`)}
                    className="dark:border-gray-700 dark:text-gray-300"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                {relatedTasks.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-400">Title</TableHead>
                        <TableHead className="dark:text-gray-400">Status</TableHead>
                        <TableHead className="dark:text-gray-400">Due Date</TableHead>
                        <TableHead className="dark:text-gray-400">Assigned To</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {relatedTasks.map((task) => (
                        <TableRow key={task.id} className="dark:border-gray-700 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                          <TableCell className="dark:text-gray-300">{task.title}</TableCell>
                          <TableCell>
                            <Badge className="dark:bg-blue-900/20 dark:text-blue-400">
                              {task.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">
                            {task.due_date ? format(new Date(task.due_date), "MMM d, yyyy") : "-"}
                          </TableCell>
                          <TableCell className="dark:text-gray-300">{task.assigned_to_name || "-"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <CheckSquare className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No tasks linked yet. Add one.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="space-y-6">
            <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
              <CardHeader>
                <CardTitle className="dark:text-gray-100 flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Add Note Form */}
                <div className="mb-6 space-y-3">
                  <Textarea
                    placeholder="Add a note about this animal..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    rows={3}
                  />
                  <Button
                    onClick={() => newNote.trim() && createNoteMutation.mutate(newNote.trim())}
                    disabled={!newNote.trim() || createNoteMutation.isPending}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    {createNoteMutation.isPending ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    ) : (
                      <Plus className="w-4 h-4 mr-2" />
                    )}
                    Add Note
                  </Button>
                </div>

                {/* Notes List */}
                {notes.length > 0 ? (
                  <div className="space-y-4">
                    {notes.map((note) => (
                      <div
                        key={note.id}
                        className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700"
                      >
                        <p className="text-gray-900 dark:text-gray-100 whitespace-pre-wrap mb-3">
                          {note.note_text}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                          <span className="font-medium">{note.created_by_name}</span>
                          <span>•</span>
                          <span>{format(new Date(note.created_date), "MMM d, yyyy 'at' h:mm a")}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-500 dark:text-gray-400">No notes yet. Add one above.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Delete Confirmation Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Delete Animal</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Are you sure you want to delete <strong className="dark:text-gray-200">{animal.name}</strong>? This action cannot be undone.
              </p>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowDeleteDialog(false)} className="dark:border-gray-700 dark:text-gray-300">
                  Cancel
                </Button>
                <Button
                  onClick={handleDelete}
                  className="bg-red-600 hover:bg-red-700 text-white"
                  disabled={deleteAnimalMutation.isPending}
                >
                  {deleteAnimalMutation.isPending ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Trash2 className="w-4 h-4 mr-2" />
                  )}
                  Delete Animal
                </Button>
              </DialogFooter>
            </div>
          </DialogContent>
        </Dialog>

        {/* Add Health Record Dialog */}
        <Dialog open={showHealthDialog} onOpenChange={setShowHealthDialog}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Add Health Record</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Record Type</Label>
                <Select value={newHealthRecord.record_type} onValueChange={(value) => setNewHealthRecord({...newHealthRecord, record_type: value})}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Vaccination" className="dark:text-gray-100">Vaccination</SelectItem>
                    <SelectItem value="Treatment" className="dark:text-gray-100">Treatment</SelectItem>
                    <SelectItem value="Checkup" className="dark:text-gray-100">Checkup</SelectItem>
                    <SelectItem value="Surgery" className="dark:text-gray-100">Surgery</SelectItem>
                    <SelectItem value="Medication" className="dark:text-gray-100">Medication</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Date</Label>
                <Input
                  type="date"
                  value={newHealthRecord.date}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, date: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Description</Label>
                <Textarea
                  value={newHealthRecord.description}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, description: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Medication Name</Label>
                <Input
                  value={newHealthRecord.medication_name}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, medication_name: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Dosage</Label>
                <Input
                  value={newHealthRecord.dosage}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, dosage: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Veterinarian</Label>
                <Input
                  value={newHealthRecord.veterinarian}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, veterinarian: e.target.value})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Cost ($)</Label>
                <Input
                  type="number"
                  value={newHealthRecord.cost}
                  onChange={(e) => setNewHealthRecord({...newHealthRecord, cost: parseFloat(e.target.value) || 0})}
                  className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="dark:text-gray-300">Status</Label>
                <Select value={newHealthRecord.status} onValueChange={(value) => setNewHealthRecord({...newHealthRecord, status: value})}>
                  <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="Completed" className="dark:text-gray-100">Completed</SelectItem>
                    <SelectItem value="Pending" className="dark:text-gray-100">Pending</SelectItem>
                    <SelectItem value="Scheduled" className="dark:text-gray-100">Scheduled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button
              onClick={() => createHealthRecordMutation.mutate(newHealthRecord)}
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={createHealthRecordMutation.isPending}
            >
              {createHealthRecordMutation.isPending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                  <Plus className="w-4 h-4 mr-2" />
              )}
              Add Health Record
            </Button>
          </DialogContent>
        </Dialog>

        {/* Breeding Record Form */}
        <BreedingRecordForm
          open={showBreedingDialog}
          onOpenChange={setShowBreedingDialog}
          animalId={animalId}
          animalName={animal.name}
          ranchId={user?.active_ranch_id}
          onCreateSuccess={createBreedingRecordMutation.onSuccess}
          isCreating={createBreedingRecordMutation.isPending}
        />

        {/* Sire Selector Dialog */}
        <Dialog open={showSireSelector} onOpenChange={setShowSireSelector}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Select Sire</DialogTitle>
            </DialogHeader>
            <AnimalSelector
              ranchId={user?.active_ranch_id}
              excludeIds={[animalId, animal.dam_id].filter(Boolean)}
              filterGender="Male"
              onSelect={handleAddSire}
              selectedAnimalId={animal.sire_id}
            />
          </DialogContent>
        </Dialog>

        {/* Dam Selector Dialog */}
        <Dialog open={showDamSelector} onOpenChange={setShowDamSelector}>
          <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Select Dam</DialogTitle>
            </DialogHeader>
            <AnimalSelector
              ranchId={user?.active_ranch_id}
              excludeIds={[animalId, animal.sire_id].filter(Boolean)}
              filterGender="Female"
              onSelect={handleAddDam}
              selectedAnimalId={animal.dam_id}
            />
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}