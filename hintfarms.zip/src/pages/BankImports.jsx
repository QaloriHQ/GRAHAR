import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Plus,
  Building2,
  RefreshCw,
  Check,
  X,
  DollarSign,
  Calendar,
  Tag,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Link as LinkIcon,
  Unlink,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { trackBankConnect, trackBankSyncSuccess, trackError } from "@/components/utils";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function BankImports() {
  const [selectedTxns, setSelectedTxns] = useState([]);
  const [editingTxn, setEditingTxn] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [filterState, setFilterState] = useState("new");
  const [selectedConnection, setSelectedConnection] = useState(""); // New state for selected bank connection

  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: async () => {
      if (!user?.active_ranch_id) return null;
      const ranches = await base44.entities.Ranch.filter({ id: user.active_ranch_id });
      return ranches?.[0] || null;
    },
    enabled: !!user?.active_ranch_id,
  });

  const { data: connections = [], refetch: refetchConnections } = useQuery({
    queryKey: ['bankConnections', user?.active_ranch_id],
    queryFn: () => base44.entities.BankConnection.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: transactions = [], refetch: refetchTransactions } = useQuery({
    queryKey: ['bankTransactions', user?.active_ranch_id, filterState, selectedConnection],
    queryFn: async () => {
      const filters = { ranch_id: user.active_ranch_id };
      if (filterState !== "all") {
        filters.import_state = filterState;
      }
      if (selectedConnection) {
        filters.connection_id = selectedConnection;
      }
      return await base44.entities.BankTransaction.filter(
        filters,
        '-posted_at',
        100
      );
    },
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: importRules = [] } = useQuery({
    queryKey: ['importRules', user?.active_ranch_id],
    queryFn: () => base44.entities.ImportRule.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: syncHistory = [] } = useQuery({
    queryKey: ['bankSyncHistory', user?.active_ranch_id],
    queryFn: () => base44.entities.BankSyncHistory.filter({ ranch_id: user.active_ranch_id }, '-sync_started_at', 20),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const createRecordMutation = useMutation({
    mutationFn: async ({ txn, recordType, data }) => {
      // Create Revenue or Expense
      const entityName = recordType === 'Revenue' ? 'Revenue' : 'Expense';
      const record = await base44.entities[entityName].create({
        ...data,
        ranch_id: user.active_ranch_id
      });

      // Update transaction
      await base44.entities.BankTransaction.update(txn.id, {
        linked_record_id: record.id,
        linked_type: recordType,
        import_state: 'created'
      });

      return record;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankTransactions'] });
      queryClient.invalidateQueries({ queryKey: ['revenue'] });
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      setSelectedTxns([]);
      const event = new CustomEvent('showToast', {
        detail: { message: 'Transaction imported successfully!', type: 'success' }
      });
      window.dispatchEvent(event);
    }
  });

  const ignoreMutation = useMutation({
    mutationFn: (txnId) => base44.entities.BankTransaction.update(txnId, {
      import_state: 'ignored'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankTransactions'] });
      setSelectedTxns([]);
    }
  });

  const handleCreateRevenue = (txn, customData = {}) => {
    const amount = Math.abs(txn.amount);
    createRecordMutation.mutate({
      txn,
      recordType: 'Revenue',
      data: {
        date: txn.posted_at,
        amount: amount,
        category: customData.category || txn.category || 'Other',
        description: customData.description || txn.description,
        buyer: txn.merchant_name || '',
        payment_method: 'Bank Transfer',
        notes: customData.notes || `Imported from ${txn.merchant_name || 'bank'}`,
        ...(customData.animal_id && { animal_id: customData.animal_id }),
        ...(customData.pasture_id && { pasture_id: customData.pasture_id })
      }
    });
  };

  const handleCreateExpense = (txn, customData = {}) => {
    const amount = Math.abs(txn.amount);
    createRecordMutation.mutate({
      txn,
      recordType: 'Expense',
      data: {
        date: txn.posted_at,
        amount: amount,
        category: customData.category || txn.category || 'Other',
        description: customData.description || txn.description,
        vendor: txn.merchant_name || '',
        payment_method: 'Bank Transfer',
        notes: customData.notes || `Imported from ${txn.merchant_name || 'bank'}`,
        ...(customData.animal_id && { animal_id: customData.animal_id }),
        ...(customData.pasture_id && { pasture_id: customData.pasture_id })
      }
    });
  };

  const handleBulkApprove = () => {
    selectedTxns.forEach(txnId => {
      const txn = transactions.find(t => t.id === txnId);
      if (txn) {
        if (txn.amount > 0) {
          handleCreateRevenue(txn);
        } else {
          handleCreateExpense(txn);
        }
      }
    });
  };

  const handleBulkIgnore = () => {
    selectedTxns.forEach(txnId => {
      ignoreMutation.mutate(txnId);
    });
  };

  const newTransactions = transactions.filter(t => t.import_state === 'new');

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Bank Import Review</h1>
            <p className="text-gray-600 dark:text-gray-400">Review and categorize imported transactions</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={selectedConnection} onValueChange={setSelectedConnection}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="All Connections" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>All Connections</SelectItem>
                {connections.map(connection => (
                  <SelectItem key={connection.id} value={connection.id}>
                    {connection.institution_name} ({connection.account_type} ••{connection.account_last4})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterState} onValueChange={setFilterState}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Transactions</SelectItem>
                <SelectItem value="new">New ({newTransactions.length})</SelectItem>
                <SelectItem value="reviewed">Reviewed</SelectItem>
                <SelectItem value="created">Imported</SelectItem>
                <SelectItem value="ignored">Ignored</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Bulk Actions */}
        {selectedTxns.length > 0 && (
          <Card className="mb-6 border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950/50">
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <p className="font-medium text-blue-900 dark:text-blue-100">
                  <CheckCircle2 className="w-4 h-4 inline mr-2" />
                  {selectedTxns.length} transaction{selectedTxns.length !== 1 ? 's' : ''} selected
                </p>
                <div className="flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    onClick={handleBulkApprove}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Approve & Import
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleBulkIgnore}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Ignore
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setSelectedTxns([])}
                  >
                    Clear
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Transactions Table */}
        <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Transactions</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {transactions.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="dark:border-gray-800">
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedTxns.length === newTransactions.length && newTransactions.length > 0}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedTxns(newTransactions.map(t => t.id));
                          } else {
                            setSelectedTxns([]);
                          }
                        }}
                      />
                    </TableHead>
                    <TableHead className="dark:text-gray-400">Date</TableHead>
                    <TableHead className="dark:text-gray-400">Description</TableHead>
                    <TableHead className="dark:text-gray-400">Category</TableHead>
                    <TableHead className="text-right dark:text-gray-400">Amount</TableHead>
                    <TableHead className="dark:text-gray-400">Status</TableHead>
                    <TableHead className="text-right dark:text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map(txn => (
                    <TableRow key={txn.id} className="dark:border-gray-800">
                      <TableCell>
                        {txn.import_state === 'new' && (
                          <Checkbox
                            checked={selectedTxns.includes(txn.id)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedTxns([...selectedTxns, txn.id]);
                              } else {
                                setSelectedTxns(selectedTxns.filter(id => id !== txn.id));
                              }
                            }}
                          />
                        )}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        {format(new Date(txn.posted_at), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        <div>
                          <p className="font-medium">{txn.description}</p>
                          {txn.merchant_name && (
                            <p className="text-sm text-gray-500 dark:text-gray-400">{txn.merchant_name}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="dark:border-gray-700 dark:text-gray-300">
                          {txn.category}
                        </Badge>
                      </TableCell>
                      <TableCell className={`text-right font-semibold ${txn.amount > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                        {txn.amount > 0 ? '+' : ''}${Math.abs(txn.amount).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          txn.import_state === 'new' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100' :
                          txn.import_state === 'created' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                          txn.import_state === 'ignored' ? 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100' :
                          'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                        }>
                          {txn.import_state}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {txn.import_state === 'new' && (
                          <div className="flex gap-1 justify-end">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                setEditingTxn(txn);
                                setShowEditDialog(true);
                              }}
                            >
                              Edit & Import
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => ignoreMutation.mutate(txn.id)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-12">
                <DollarSign className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Transactions</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  Connect your bank account to start importing transactions
                </p>
                <Button
                  onClick={() => navigate(createPageUrl("RanchSettings") + "?tab=banking")}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  <Building2 className="w-4 h-4 mr-2" />
                  Go to Banking Settings
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Sync History */}
        <Card className="border-none shadow-lg dark:bg-gray-950 dark:border-gray-800 mt-6">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Sync History</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            {syncHistory.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="dark:border-gray-800">
                    <TableHead className="dark:text-gray-400">Date & Time</TableHead>
                    <TableHead className="dark:text-gray-400">Bank Account</TableHead>
                    <TableHead className="text-center dark:text-gray-400">New</TableHead>
                    <TableHead className="text-center dark:text-gray-400">Skipped</TableHead>
                    <TableHead className="text-center dark:text-gray-400">Errors</TableHead>
                    <TableHead className="dark:text-gray-400">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {syncHistory.map(sync => (
                    <TableRow key={sync.id} className="dark:border-gray-800">
                      <TableCell className="dark:text-gray-300">
                        <div>
                          <p className="font-medium">{format(new Date(sync.sync_started_at), 'MMM d, yyyy')}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{format(new Date(sync.sync_started_at), 'h:mm a')}</p>
                        </div>
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        <div>
                          <p className="font-medium">{sync.institution_name}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{sync.account_type} ••{sync.account_last4}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                          {sync.transactions_new}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="dark:border-gray-700 dark:text-gray-300">
                          {sync.transactions_skipped}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {sync.transactions_errors > 0 ? (
                          <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100">
                            {sync.transactions_errors}
                          </Badge>
                        ) : (
                          <span className="text-gray-400">0</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          sync.status === 'success' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                          sync.status === 'partial' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100' :
                          'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100'
                        }>
                          {sync.status}
                        </Badge>
                        {sync.error_message && (
                          <p className="text-xs text-red-600 dark:text-red-400 mt-1">{sync.error_message}</p>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <RefreshCw className="w-12 h-12 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
                <p className="text-gray-500 dark:text-gray-400">No sync history yet</p>
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Sync history will appear here after your first bank sync</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Transaction Dialog */}
        {editingTxn && (
          <EditTransactionDialog
            transaction={editingTxn}
            open={showEditDialog}
            onOpenChange={setShowEditDialog}
            animals={animals}
            pastures={pastures}
            onSave={(data) => {
              if (editingTxn.amount > 0) {
                handleCreateRevenue(editingTxn, data);
              } else {
                handleCreateExpense(editingTxn, data);
              }
              setShowEditDialog(false);
              setEditingTxn(null);
            }}
          />
        )}
        </div>
        </div>
        );
        }

function EditTransactionDialog({ transaction, open, onOpenChange, animals, pastures, onSave }) {
  const [formData, setFormData] = useState({
    category: transaction.category,
    description: transaction.description,
    animal_id: '',
    pasture_id: '',
    notes: ''
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800">
        <DialogHeader>
          <DialogTitle className="dark:text-gray-100">Edit Transaction Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="dark:text-gray-300">Date</Label>
              <Input
                value={format(new Date(transaction.posted_at), 'MMM d, yyyy')}
                disabled
                className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300"
              />
            </div>
            <div>
              <Label className="dark:text-gray-300">Amount</Label>
              <Input
                value={`$${Math.abs(transaction.amount).toLocaleString()}`}
                disabled
                className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300"
              />
            </div>
          </div>

          <div>
            <Label className="dark:text-gray-300">Category</Label>
            <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
              <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {transaction.amount > 0 ? (
                  <>
                    <SelectItem value="Cattle Sale">Cattle Sale</SelectItem>
                    <SelectItem value="Calf Sale">Calf Sale</SelectItem>
                    <SelectItem value="Milk">Milk</SelectItem>
                    <SelectItem value="Breeding Services">Breeding Services</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </>
                ) : (
                  <>
                    <SelectItem value="Feed">Feed</SelectItem>
                    <SelectItem value="Veterinary">Veterinary</SelectItem>
                    <SelectItem value="Labor">Labor</SelectItem>
                    <SelectItem value="Equipment">Equipment</SelectItem>
                    <SelectItem value="Utilities">Utilities</SelectItem>
                    <SelectItem value="Transportation">Transportation</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </>
                )}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="dark:text-gray-300">Description</Label>
            <Input
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="dark:text-gray-300">Related Animal (Optional)</Label>
              <Select value={formData.animal_id} onValueChange={(value) => setFormData({...formData, animal_id: value})}>
                <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300">
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None</SelectItem>
                  {animals.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="dark:text-gray-300">Related Pasture (Optional)</Label>
              <Select value={formData.pasture_id} onValueChange={(value) => setFormData({...formData, pasture_id: value})}>
                <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300">
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>None</SelectItem>
                  {pastures.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="dark:text-gray-300">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
              className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-300"
            />
          </div>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="flex-1 dark:border-gray-700 dark:text-gray-300"
          >
            Cancel
          </Button>
          <Button
            onClick={() => onSave(formData)}
            className="flex-1 bg-orange-600 hover:bg-orange-700"
          >
            Import Transaction
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}