import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2, CreditCard } from "lucide-react";

export default function BillingReturn() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [status, setStatus] = React.useState('loading');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionType = urlParams.get('session');
    const success = urlParams.get('success');
    const canceled = urlParams.get('canceled');

    console.log('BillingReturn params:', { sessionType, success, canceled });

    // Invalidate queries to refresh data
    queryClient.invalidateQueries({ queryKey: ['currentRanch'] });
    queryClient.invalidateQueries({ queryKey: ['currentUser'] });

    // Determine status
    if (sessionType === 'portal') {
      setStatus('portal');
      
      const event = new CustomEvent('showToast', {
        detail: { 
          message: 'Your billing information has been updated.',
          type: 'success'
        }
      });
      window.dispatchEvent(event);

      // Redirect to ranch settings billing tab after a short delay
      setTimeout(() => {
        navigate(createPageUrl('RanchSettings') + '?tab=billing');
      }, 2000);
    } else if (success === 'true') {
      setStatus('success');
      
      const event = new CustomEvent('showToast', {
        detail: { 
          message: 'Subscription activated successfully! Welcome to HintFarms Pro.',
          type: 'success'
        }
      });
      window.dispatchEvent(event);

      setTimeout(() => {
        navigate(createPageUrl('Dashboard'));
      }, 3000);
    } else if (canceled === 'true') {
      setStatus('canceled');
      
      setTimeout(() => {
        navigate(createPageUrl('RanchSettings') + '?tab=billing');
      }, 3000);
    } else {
      setStatus('unknown');
      setTimeout(() => {
        navigate(createPageUrl('Dashboard'));
      }, 2000);
    }
  }, [navigate, queryClient]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 flex items-center justify-center p-6">
      <Card className="max-w-md w-full border-none shadow-xl">
        <CardHeader>
          <div className="flex justify-center mb-4">
            {status === 'loading' && (
              <Loader2 className="w-16 h-16 text-emerald-600 animate-spin" />
            )}
            {(status === 'success' || status === 'portal') && (
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
            )}
            {status === 'canceled' && (
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                <XCircle className="w-10 h-10 text-orange-600" />
              </div>
            )}
            {status === 'unknown' && (
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                <CreditCard className="w-10 h-10 text-gray-600" />
              </div>
            )}
          </div>
          <CardTitle className="text-center text-2xl">
            {status === 'loading' && 'Processing...'}
            {status === 'success' && 'Subscription Activated!'}
            {status === 'portal' && 'Billing Updated'}
            {status === 'canceled' && 'Checkout Canceled'}
            {status === 'unknown' && 'Returning to Dashboard'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-center text-gray-600">
            {status === 'loading' && 'Please wait while we process your request...'}
            {status === 'success' && 'Thank you for subscribing to HintFarms Pro. You now have access to all premium features.'}
            {status === 'portal' && 'Your billing information has been successfully updated.'}
            {status === 'canceled' && 'Your checkout was canceled. No charges were made.'}
            {status === 'unknown' && 'Redirecting you back to the dashboard...'}
          </p>
          
          {(status === 'success' || status === 'portal' || status === 'canceled') && (
            <div className="flex justify-center mt-6">
              <Button
                onClick={() => {
                  if (status === 'success') {
                    navigate(createPageUrl('Dashboard'));
                  } else {
                    navigate(createPageUrl('RanchSettings') + '?tab=billing');
                  }
                }}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {status === 'success' ? 'Go to Dashboard' : 'Return to Billing'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}