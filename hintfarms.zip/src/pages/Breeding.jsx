import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Sprout, Heart, TrendingUp, Calendar } from "lucide-react";
import { format } from "date-fns";
import StatsCard from "../components/dashboard/StatsCard";
import { trackBreedingRecordAdd } from "@/components/utils";

export default function Breeding() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: breedingRecords = [] } = useQuery({
    queryKey: ['breedingRecords', user?.active_ranch_id],
    queryFn: () => base44.entities.BreedingRecord.filter({ ranch_id: user.active_ranch_id }, '-breeding_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newRecord, setNewRecord] = useState({
    animal_id: "",
    animal_name: "",
    bull_id: "",
    bull_name: "",
    breeding_date: new Date().toISOString().split('T')[0],
    expected_calving_date: "",
    breeding_method: "Natural",
    conception_confirmed: false,
    status: "Breeding",
    notes: ""
  });

  const createRecordMutation = useMutation({
    mutationFn: (data) => base44.entities.BreedingRecord.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['breedingRecords'] });
      setShowAddDialog(false);
      setNewRecord({
        animal_id: "",
        animal_name: "",
        bull_id: "",
        bull_name: "",
        breeding_date: new Date().toISOString().split('T')[0],
        expected_calving_date: "",
        breeding_method: "Natural",
        conception_confirmed: false,
        status: "Breeding",
        notes: ""
      });
      trackBreedingRecordAdd(data.id); // Assuming data.id is available from the successful creation
    },
  });

  const totalBreeding = breedingRecords.length;
  const activeBreeding = breedingRecords.filter(r => r.status === "Breeding").length;
  const pregnant = breedingRecords.filter(r => r.status === "Pregnant").length;
  const conceptionRate = breedingRecords.length > 0
    ? ((breedingRecords.filter(r => r.conception_confirmed).length / breedingRecords.length) * 100).toFixed(1)
    : 0;

  const statusColors = {
    "Breeding": "bg-blue-100 text-blue-800 border-blue-200",
    "Pregnant": "bg-pink-100 text-pink-800 border-pink-200",
    "Calved": "bg-green-100 text-green-800 border-green-200",
    "Failed": "bg-red-100 text-red-800 border-red-200"
  };

  const femaleAnimals = animals.filter(a => a.gender === "Female");
  const bulls = animals.filter(a => a.type === "Bull");

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Breeding Management</h1>
            <p className="text-gray-600">Track breeding cycles and conception rates</p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Add Breeding Record
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Breeding Record</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label>Female Animal</Label>
                  <Select
                    value={newRecord.animal_id}
                    onValueChange={(value) => {
                      const animal = femaleAnimals.find(a => a.id === value);
                      setNewRecord({
                        ...newRecord,
                        animal_id: value,
                        animal_name: animal?.name || ""
                      });
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select female" />
                    </SelectTrigger>
                    <SelectContent>
                      {femaleAnimals.map(animal => (
                        <SelectItem key={animal.id} value={animal.id}>
                          {animal.name} ({animal.tag_number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Bull</Label>
                  <Select
                    value={newRecord.bull_id}
                    onValueChange={(value) => {
                      const bull = bulls.find(a => a.id === value);
                      setNewRecord({
                        ...newRecord,
                        bull_id: value,
                        bull_name: bull?.name || ""
                      });
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select bull" />
                    </SelectTrigger>
                    <SelectContent>
                      {bulls.map(bull => (
                        <SelectItem key={bull.id} value={bull.id}>
                          {bull.name} ({bull.tag_number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Breeding Date</Label>
                  <Input
                    type="date"
                    value={newRecord.breeding_date}
                    onChange={(e) => setNewRecord({...newRecord, breeding_date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Expected Calving Date</Label>
                  <Input
                    type="date"
                    value={newRecord.expected_calving_date}
                    onChange={(e) => setNewRecord({...newRecord, expected_calving_date: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Breeding Method</Label>
                  <Select value={newRecord.breeding_method} onValueChange={(value) => setNewRecord({...newRecord, breeding_method: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Natural">Natural</SelectItem>
                      <SelectItem value="Artificial Insemination">Artificial Insemination</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={newRecord.status} onValueChange={(value) => setNewRecord({...newRecord, status: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Breeding">Breeding</SelectItem>
                      <SelectItem value="Pregnant">Pregnant</SelectItem>
                      <SelectItem value="Calved">Calved</SelectItem>
                      <SelectItem value="Failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Notes</Label>
                  <Input
                    value={newRecord.notes}
                    onChange={(e) => setNewRecord({...newRecord, notes: e.target.value})}
                  />
                </div>
              </div>
              <Button onClick={() => createRecordMutation.mutate(newRecord)} className="w-full bg-[#F5A623] hover:bg-[#E09612]">
                Add Breeding Record
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Records"
            value={totalBreeding}
            icon={Sprout}
            bgColor="bg-orange-500"
            textColor="text-[#F5A623]"
          />
          <StatsCard
            title="Active Breeding"
            value={activeBreeding}
            icon={Heart}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Pregnant"
            value={pregnant}
            icon={Calendar}
            bgColor="bg-pink-500"
            textColor="text-pink-600"
          />
          <StatsCard
            title="Conception Rate"
            value={`${conceptionRate}%`}
            icon={TrendingUp}
            bgColor="bg-purple-500"
            textColor="text-purple-600"
          />
        </div>

        {/* Records Table */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Breeding Records</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Breeding Date</TableHead>
                  <TableHead>Female</TableHead>
                  <TableHead>Bull</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Expected Calving</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {breedingRecords.map(record => (
                  <TableRow key={record.id}>
                    <TableCell>{format(new Date(record.breeding_date), "MMM d, yyyy")}</TableCell>
                    <TableCell className="font-semibold">{record.animal_name}</TableCell>
                    <TableCell className="font-semibold">{record.bull_name}</TableCell>
                    <TableCell>{record.breeding_method}</TableCell>
                    <TableCell>
                      {record.expected_calving_date
                        ? format(new Date(record.expected_calving_date), "MMM d, yyyy")
                        : "-"}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${statusColors[record.status]} border text-xs`}>
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-[200px] truncate">{record.notes || "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}