import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  DollarSign,
  Receipt,
  Eye,
  Edit,
  Upload,
  Loader2,
  X,
  Calendar,
  Tag,
  FileText,
  MoreVertical,
  Trash2,
  Search,
  Filter,
  TrendingDown,
} from "lucide-react";
import { format } from "date-fns";
import StatsCard from "../components/dashboard/StatsCard";
import { useNavigate } from "react-router-dom";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trackExpenseAdd } from "@/components/utils";

export default function Expenses() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [editingExpense, setEditingExpense] = useState(null);
  const [filterCategory, setFilterCategory] = useState("all");
  const [uploadingReceipt, setUploadingReceipt] = useState(false);
  const queryClient = useQueryClient();
  const navigate = useNavigate(); // Added initialization

  // Helper function for navigation (assuming a simple mapping for now)
  const createPageUrl = (pageName, params = {}) => {
    let url = '';
    switch (pageName) {
      case "Financials":
        url = "/financials";
        break;
      case "Expenses":
        url = "/expenses";
        break;
      // Add other pages as needed
      default:
        url = "/";
    }
    if (Object.keys(params).length > 0) {
      const queryString = new URLSearchParams(params).toString();
      url += `?${queryString}`;
    }
    return url;
  };

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.active_ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newExpense, setNewExpense] = useState({
    date: new Date().toISOString().split('T')[0],
    category: "Feed",
    description: "",
    amount: 0,
    animal_id: "",
    animal_name: "",
    pasture_id: "",
    pasture_name: "",
    vendor: "",
    payment_method: "Cash",
    receipt_url: "",
    notes: ""
  });

  const createExpenseMutation = useMutation({
    mutationFn: (data) => base44.entities.Expense.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      setShowAddDialog(false);
      resetForm();
    },
  });

  const updateExpenseMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Expense.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      setShowAddDialog(false);
      setEditingExpense(null);
      resetForm();
    },
  });

  const deleteExpenseMutation = useMutation({
    mutationFn: (id) => base44.entities.Expense.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenses'] });
      setShowDetailsDialog(false);
      setSelectedExpense(null);
    },
  });

  const resetForm = () => {
    setNewExpense({
      date: new Date().toISOString().split('T')[0],
      category: "Feed",
      description: "",
      amount: 0,
      animal_id: "",
      animal_name: "",
      pasture_id: "",
      pasture_name: "",
      vendor: "",
      payment_method: "Cash",
      receipt_url: "",
      notes: ""
    });
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingReceipt(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await base44.integrations.Core.UploadFile({ file });
      
      if (response.file_url) {
        setNewExpense({ ...newExpense, receipt_url: response.file_url });
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload receipt. Please try again.');
    } finally {
      setUploadingReceipt(false);
    }
  };

  const handleEdit = (expense) => {
    setEditingExpense(expense);
    setNewExpense(expense);
    setShowAddDialog(true);
  };

  const handleSave = () => {
    if (editingExpense) {
      updateExpenseMutation.mutate({ id: editingExpense.id, data: newExpense });
    } else {
      createExpenseMutation.mutate(newExpense);
    }
  };

  const handleViewDetails = (expense) => {
    setSelectedExpense(expense);
    setShowDetailsDialog(true);
  };

  // Check for URL parameter to auto-open detail dialog
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const expenseId = urlParams.get('id');
    
    // Only proceed if an ID is present and expenses data is loaded
    if (expenseId && expenses.length > 0) {
      const expense = expenses.find(e => e.id === expenseId);
      if (expense) {
        handleViewDetails(expense);
        // Clean up URL: remove the 'id' parameter after handling
        // It's important to replace state to prevent back button issues
        window.history.replaceState({}, '', createPageUrl('Expenses'));
      }
    }
  }, [expenses, handleViewDetails]); // Added handleViewDetails to dependencies

  const filteredExpenses = filterCategory === "all" 
    ? expenses 
    : expenses.filter(e => e.category === filterCategory);

  const totalExpenses = expenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
  const thisMonthExpenses = expenses.filter(e => {
    const expDate = new Date(e.date);
    const now = new Date();
    return expDate.getMonth() === now.getMonth() && expDate.getFullYear() === now.getFullYear();
  }).reduce((sum, exp) => sum + (exp.amount || 0), 0);

  const categoryColors = {
    "Feed": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Veterinary": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300",
    "Labor": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Equipment": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300",
    "Utilities": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Maintenance": "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300",
    "Supplies": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300",
    "Transportation": "bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300",
    "Insurance": "bg-teal-100 text-teal-800 border-teal-200 dark:bg-teal-900/30 dark:text-teal-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div className="flex items-center gap-4"> {/* Added this div for the back button and title */}
            <Button 
              variant="outline" 
              onClick={() => navigate(createPageUrl("Financials"))}
              className="dark:bg-gray-800 dark:border-gray-700"
            >
              ← Back to Financials
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Expense Management</h1>
              <p className="text-gray-600 dark:text-gray-400">Track and manage your ranch expenses</p>
            </div>
          </div>
          <Dialog open={showAddDialog} onOpenChange={(open) => {
            setShowAddDialog(open);
            if (!open) {
              setEditingExpense(null);
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Add Expense
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
              <DialogHeader>
                <DialogTitle className="dark:text-gray-100">
                  {editingExpense ? 'Edit Expense' : 'Add New Expense'}
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Date *</Label>
                  <Input
                    type="date"
                    value={newExpense.date}
                    onChange={(e) => setNewExpense({...newExpense, date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Category *</Label>
                  <Select value={newExpense.category} onValueChange={(value) => setNewExpense({...newExpense, category: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Feed">Feed</SelectItem>
                      <SelectItem value="Veterinary">Veterinary</SelectItem>
                      <SelectItem value="Labor">Labor</SelectItem>
                      <SelectItem value="Equipment">Equipment</SelectItem>
                      <SelectItem value="Utilities">Utilities</SelectItem>
                      <SelectItem value="Maintenance">Maintenance</SelectItem>
                      <SelectItem value="Supplies">Supplies</SelectItem>
                      <SelectItem value="Transportation">Transportation</SelectItem>
                      <SelectItem value="Insurance">Insurance</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Description *</Label>
                  <Input
                    value={newExpense.description}
                    onChange={(e) => setNewExpense({...newExpense, description: e.target.value})}
                    placeholder="Brief description of the expense"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Amount ($) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={newExpense.amount}
                    onChange={(e) => setNewExpense({...newExpense, amount: parseFloat(e.target.value) || 0})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Payment Method</Label>
                  <Select value={newExpense.payment_method} onValueChange={(value) => setNewExpense({...newExpense, payment_method: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Cash">Cash</SelectItem>
                      <SelectItem value="Check">Check</SelectItem>
                      <SelectItem value="Credit Card">Credit Card</SelectItem>
                      <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Vendor/Supplier</Label>
                  <Input
                    value={newExpense.vendor}
                    onChange={(e) => setNewExpense({...newExpense, vendor: e.target.value})}
                    placeholder="Who did you pay?"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Related Animal (Optional)</Label>
                  <Select 
                    value={newExpense.animal_id || "none"} 
                    onValueChange={(value) => {
                      if (value === "none") {
                        setNewExpense({...newExpense, animal_id: "", animal_name: ""});
                      } else {
                        const animal = animals.find(a => a.id === value);
                        setNewExpense({...newExpense, animal_id: value, animal_name: animal?.name || ""});
                      }
                    }}
                  >
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue placeholder="Select animal" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="none">None</SelectItem>
                      {animals.map(animal => (
                        <SelectItem key={animal.id} value={animal.id}>
                          {animal.name} ({animal.tag_number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Related Pasture (Optional)</Label>
                  <Select 
                    value={newExpense.pasture_id || "none"} 
                    onValueChange={(value) => {
                      if (value === "none") {
                        setNewExpense({...newExpense, pasture_id: "", pasture_name: ""});
                      } else {
                        const pasture = pastures.find(p => p.id === value);
                        setNewExpense({...newExpense, pasture_id: value, pasture_name: pasture?.name || ""});
                      }
                    }}
                  >
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue placeholder="Select pasture" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="none">None</SelectItem>
                      {pastures.map(pasture => (
                        <SelectItem key={pasture.id} value={pasture.id}>
                          {pasture.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Upload Receipt (Optional)</Label>
                  <div className="flex items-center gap-3">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      disabled={uploadingReceipt}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                    {uploadingReceipt && <Loader2 className="w-5 h-5 animate-spin text-[#F5A623]" />}
                  </div>
                  {newExpense.receipt_url && (
                    <div className="relative inline-block mt-2">
                      <img 
                        src={newExpense.receipt_url} 
                        alt="Receipt" 
                        className="h-24 w-24 object-cover rounded-lg border-2 border-[#F5A623]"
                      />
                      <button
                        type="button"
                        onClick={() => setNewExpense({...newExpense, receipt_url: ""})}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Notes</Label>
                  <Textarea
                    value={newExpense.notes}
                    onChange={(e) => setNewExpense({...newExpense, notes: e.target.value})}
                    placeholder="Additional information..."
                    rows={3}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowAddDialog(false);
                    setEditingExpense(null);
                    resetForm();
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                  className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                  disabled={!newExpense.date || !newExpense.category || !newExpense.description || !newExpense.amount}
                >
                  {editingExpense ? 'Update Expense' : 'Add Expense'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatsCard
            title="Total Expenses"
            value={`$${totalExpenses.toLocaleString()}`}
            icon={DollarSign}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
          <StatsCard
            title="This Month"
            value={`$${thisMonthExpenses.toLocaleString()}`}
            icon={Calendar}
            bgColor="bg-orange-500"
            textColor="text-orange-600"
          />
          <StatsCard
            title="Total Records"
            value={expenses.length}
            icon={Receipt}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
        </div>

        {/* Filter */}
        <Card className="mb-6 border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-64 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Feed">Feed</SelectItem>
                  <SelectItem value="Veterinary">Veterinary</SelectItem>
                  <SelectItem value="Labor">Labor</SelectItem>
                  <SelectItem value="Equipment">Equipment</SelectItem>
                  <SelectItem value="Utilities">Utilities</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Supplies">Supplies</SelectItem>
                  <SelectItem value="Transportation">Transportation</SelectItem>
                  <SelectItem value="Insurance">Insurance</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Expenses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExpenses.map(expense => (
            <Card key={expense.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300 dark:bg-gray-900 dark:border-gray-800">
              <div className="h-2 bg-gradient-to-r from-red-500 to-orange-600" />
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg mb-1 dark:text-gray-100">{expense.description}</CardTitle>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{format(new Date(expense.date), "MMM d, yyyy")}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleViewDetails(expense)}
                      className="dark:hover:bg-gray-800"
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleEdit(expense)}
                      className="dark:hover:bg-gray-800"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <Badge className={`${categoryColors[expense.category]} border text-xs`}>
                    {expense.category}
                  </Badge>
                  <p className="text-2xl font-bold text-red-600 dark:text-red-400">${expense.amount.toLocaleString()}</p>
                </div>
                {expense.receipt_url && (
                  <div className="pt-3 border-t dark:border-gray-800">
                    <img 
                      src={expense.receipt_url} 
                      alt="Receipt" 
                      className="h-20 w-full object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => handleViewDetails(expense)}
                    />
                  </div>
                )}
                {(expense.animal_name || expense.pasture_name) && (
                  <div className="pt-3 border-t dark:border-gray-800 text-xs space-y-1">
                    {expense.animal_name && (
                      <p className="text-blue-600 dark:text-blue-400">🐄 {expense.animal_name}</p>
                    )}
                    {expense.pasture_name && (
                      <p className="text-green-600 dark:text-green-400">🌾 {expense.pasture_name}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredExpenses.length === 0 && (
          <Card className="border-none shadow-lg dark:bg-gray-900 dark:border-gray-800">
            <CardContent className="p-12 text-center">
              <Receipt className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Expenses Yet</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Start tracking your ranch expenses</p>
              <Button onClick={() => setShowAddDialog(true)} className="bg-[#F5A623] hover:bg-[#E09612]">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Expense
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Expense Details Dialog */}
        <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Expense Details</DialogTitle>
            </DialogHeader>
            {selectedExpense && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">{selectedExpense.description}</h3>
                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge className={`${categoryColors[selectedExpense.category]} border`}>
                      {selectedExpense.category}
                    </Badge>
                    <p className="text-3xl font-bold text-red-600 dark:text-red-400">
                      ${selectedExpense.amount.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Date</p>
                    <p className="font-semibold dark:text-gray-100">{format(new Date(selectedExpense.date), "MMMM d, yyyy")}</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Payment Method</p>
                    <p className="font-semibold dark:text-gray-100">{selectedExpense.payment_method}</p>
                  </div>
                </div>

                {selectedExpense.vendor && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Vendor/Supplier</p>
                    <p className="font-semibold dark:text-gray-100">{selectedExpense.vendor}</p>
                  </div>
                )}

                {(selectedExpense.animal_name || selectedExpense.pasture_name) && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg space-y-2">
                    <p className="text-sm font-semibold dark:text-gray-200">Related To</p>
                    {selectedExpense.animal_name && (
                      <p className="text-blue-600 dark:text-blue-400">🐄 Animal: {selectedExpense.animal_name}</p>
                    )}
                    {selectedExpense.pasture_name && (
                      <p className="text-green-600 dark:text-green-400">🌾 Pasture: {selectedExpense.pasture_name}</p>
                    )}
                  </div>
                )}

                {selectedExpense.receipt_url && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Receipt</p>
                    <a href={selectedExpense.receipt_url} target="_blank" rel="noopener noreferrer">
                      <img 
                        src={selectedExpense.receipt_url} 
                        alt="Receipt" 
                        className="w-full max-h-96 object-contain rounded-lg border-2 border-[#F5A623] cursor-pointer hover:opacity-80 transition-opacity"
                      />
                    </a>
                  </div>
                )}

                {selectedExpense.notes && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Notes</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedExpense.notes}</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowDetailsDialog(false);
                      handleEdit(selectedExpense);
                    }}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      if (confirm('Are you sure you want to delete this expense?')) {
                        deleteExpenseMutation.mutate(selectedExpense.id);
                      }
                    }}
                    className="flex-1"
                  >
                    Delete Expense
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}