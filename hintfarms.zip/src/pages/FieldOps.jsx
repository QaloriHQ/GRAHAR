import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Camera,
  MapPin,
  Activity,
  Plus,
  Wifi,
  WifiOff,
  CheckCircle2,
  Clock,
  Upload
} from "lucide-react";
import QuickHealthRecord from "@/components/fieldops/QuickHealthRecord";
import QuickPastureUpdate from "@/components/fieldops/QuickPastureUpdate";
import QuickInventoryLog from "@/components/fieldops/QuickInventoryLog";
import { toast } from "sonner";

export default function FieldOps() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [location, setLocation] = useState(null);
  const [activeAction, setActiveAction] = useState(null);
  const [pendingActions, setPendingActions] = useState([]);
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      syncPendingActions();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load pending actions from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('pendingFieldActions');
    if (stored) {
      setPendingActions(JSON.parse(stored));
    }
  }, []);

  // Save pending actions to localStorage
  useEffect(() => {
    localStorage.setItem('pendingFieldActions', JSON.stringify(pendingActions));
  }, [pendingActions]);

  // Get current location
  const getCurrentLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
            accuracy: position.coords.accuracy
          });
          toast.success('Location captured');
        },
        (error) => {
          toast.error('Could not get location');
        }
      );
    }
  };

  // Sync pending actions when back online
  const syncPendingActions = async () => {
    if (pendingActions.length === 0) return;

    toast.info('Syncing offline data...');
    
    const synced = [];
    const failed = [];

    for (const action of pendingActions) {
      try {
        if (action.type === 'health_record') {
          await base44.entities.HealthRecord.create(action.data);
        } else if (action.type === 'pasture_update') {
          await base44.entities.Pasture.update(action.data.id, action.data);
        } else if (action.type === 'inventory_log') {
          await base44.entities.Inventory.create(action.data);
        }
        synced.push(action.id);
      } catch (error) {
        failed.push(action.id);
      }
    }

    setPendingActions(prev => prev.filter(a => !synced.includes(a.id)));
    
    if (synced.length > 0) {
      queryClient.invalidateQueries();
      toast.success(`Synced ${synced.length} action${synced.length !== 1 ? 's' : ''}`);
    }
    if (failed.length > 0) {
      toast.error(`Failed to sync ${failed.length} action${failed.length !== 1 ? 's' : ''}`);
    }
  };

  const addPendingAction = (type, data) => {
    const action = {
      id: Date.now().toString(),
      type,
      data,
      timestamp: new Date().toISOString(),
      location
    };
    setPendingActions(prev => [...prev, action]);
    toast.success('Saved offline - will sync when online');
  };

  const quickActions = [
    {
      id: 'health',
      title: 'Health Record',
      icon: Activity,
      color: 'bg-red-500',
      description: 'Log animal health'
    },
    {
      id: 'pasture',
      title: 'Pasture Update',
      icon: MapPin,
      color: 'bg-green-500',
      description: 'Update conditions'
    },
    {
      id: 'inventory',
      title: 'Inventory Log',
      icon: Plus,
      color: 'bg-blue-500',
      description: 'Track supplies'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Mobile Header */}
      <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-6 pb-8 rounded-b-3xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Field Operations</h1>
          <Badge className={isOnline ? 'bg-green-500' : 'bg-gray-500'}>
            {isOnline ? <Wifi className="w-3 h-3 mr-1" /> : <WifiOff className="w-3 h-3 mr-1" />}
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
        </div>

        {/* Location Card */}
        <Card className="bg-white/10 backdrop-blur border-none">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                <div>
                  <p className="font-semibold text-sm">Location</p>
                  {location ? (
                    <p className="text-xs opacity-90">
                      {location.lat.toFixed(4)}, {location.lon.toFixed(4)}
                    </p>
                  ) : (
                    <p className="text-xs opacity-90">Not captured</p>
                  )}
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={getCurrentLocation}
                className="border-white text-white hover:bg-white/20"
              >
                <MapPin className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="p-4 space-y-6 -mt-4">
        {/* Quick Actions */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-3">
            {quickActions.map((action) => (
              <button
                key={action.id}
                onClick={() => setActiveAction(action.id)}
                className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors text-left"
              >
                <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center`}>
                  <action.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{action.title}</p>
                  <p className="text-sm text-gray-500">{action.description}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Pending Sync */}
        {pendingActions.length > 0 && (
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="font-semibold text-orange-900">
                      {pendingActions.length} pending action{pendingActions.length !== 1 ? 's' : ''}
                    </p>
                    <p className="text-xs text-orange-700">Will sync when online</p>
                  </div>
                </div>
                {isOnline && (
                  <Button
                    size="sm"
                    onClick={syncPendingActions}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Upload className="w-4 h-4 mr-1" />
                    Sync Now
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Activity */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Today's Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {pendingActions.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-4">No activity yet today</p>
            ) : (
              <div className="space-y-2">
                {pendingActions.slice(-5).reverse().map((action) => (
                  <div key={action.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <div className="flex-1">
                      <p className="text-sm font-medium capitalize">{action.type.replace('_', ' ')}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(action.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {isOnline ? 'Synced' : 'Pending'}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Action Dialogs */}
      <QuickHealthRecord
        open={activeAction === 'health'}
        onOpenChange={(open) => !open && setActiveAction(null)}
        location={location}
        onSave={addPendingAction}
        isOnline={isOnline}
      />
      <QuickPastureUpdate
        open={activeAction === 'pasture'}
        onOpenChange={(open) => !open && setActiveAction(null)}
        location={location}
        onSave={addPendingAction}
        isOnline={isOnline}
      />
      <QuickInventoryLog
        open={activeAction === 'inventory'}
        onOpenChange={(open) => !open && setActiveAction(null)}
        location={location}
        onSave={addPendingAction}
        isOnline={isOnline}
      />
    </div>
  );
}