import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Heart, Syringe, Pill, Calendar, Edit, ArrowLeft, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { trackHealthRecordAdd } from "@/components/utils";

export default function HealthRecords() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [filterType, setFilterType] = useState("all");
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: healthRecords = [] } = useQuery({
    queryKey: ['healthRecords', user?.active_ranch_id],
    queryFn: () => base44.entities.HealthRecord.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newRecord, setNewRecord] = useState({
    animal_id: "",
    animal_name: "",
    record_type: "Vaccination",
    date: new Date().toISOString().split('T')[0],
    description: "",
    medication_name: "",
    dosage: "",
    veterinarian: "",
    cost: 0,
    next_due_date: "",
    status: "Completed",
    notes: ""
  });

  const [editedRecord, setEditedRecord] = useState(null);

  const createRecordMutation = useMutation({
    mutationFn: (data) => base44.entities.HealthRecord.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
      setShowAddDialog(false);
      setNewRecord({
        animal_id: "",
        animal_name: "",
        record_type: "Vaccination",
        date: new Date().toISOString().split('T')[0],
        description: "",
        medication_name: "",
        dosage: "",
        veterinarian: "",
        cost: 0,
        next_due_date: "",
        status: "Completed",
        notes: ""
      });
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Health record created successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const updateRecordMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.HealthRecord.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
      setEditMode(false);
      setShowDetailsDialog(false);
      setSelectedRecord(null);
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Health record updated successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const deleteRecordMutation = useMutation({
    mutationFn: (id) => base44.entities.HealthRecord.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['healthRecords'] });
      setShowDetailsDialog(false);
      setSelectedRecord(null);
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Health record deleted successfully', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const handleRowClick = (record) => {
    setSelectedRecord(record);
    setEditedRecord({ ...record });
    setEditMode(false);
    setShowDetailsDialog(true);
  };

  const handleEdit = () => {
    setEditMode(true);
  };

  const handleSave = () => {
    updateRecordMutation.mutate({ 
      id: selectedRecord.id, 
      data: editedRecord 
    });
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this health record?')) {
      deleteRecordMutation.mutate(selectedRecord.id);
    }
  };

  const filteredRecords = filterType === "all" 
    ? healthRecords 
    : healthRecords.filter(r => r.record_type === filterType);

  const vaccinations = healthRecords.filter(r => r.record_type === "Vaccination").length;
  const treatments = healthRecords.filter(r => r.record_type === "Treatment").length;
  const overdue = healthRecords.filter(r => r.status === "Overdue").length;
  const totalCost = healthRecords.reduce((sum, r) => sum + (r.cost || 0), 0);

  const statusColors = {
    "Completed": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
    "Scheduled": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800",
    "Overdue": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800"
  };

  const typeIcons = {
    "Vaccination": Syringe,
    "Treatment": Heart,
    "Checkup": Heart,
    "Surgery": Heart,
    "Medication": Pill
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Health Records</h1>
            <p className="text-gray-600 dark:text-gray-400">Track medical history and treatments</p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Add Health Record
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800">
              <DialogHeader>
                <DialogTitle className="dark:text-gray-100">Add New Health Record</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Animal</Label>
                  <Select 
                    value={newRecord.animal_id} 
                    onValueChange={(value) => {
                      const animal = animals.find(a => a.id === value);
                      setNewRecord({
                        ...newRecord, 
                        animal_id: value,
                        animal_name: animal?.name || ""
                      });
                    }}
                  >
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue placeholder="Select animal" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      {animals.map(animal => (
                        <SelectItem key={animal.id} value={animal.id} className="dark:text-gray-100">
                          {animal.name} ({animal.tag_number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Record Type</Label>
                  <Select value={newRecord.record_type} onValueChange={(value) => setNewRecord({...newRecord, record_type: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Vaccination" className="dark:text-gray-100">Vaccination</SelectItem>
                      <SelectItem value="Treatment" className="dark:text-gray-100">Treatment</SelectItem>
                      <SelectItem value="Checkup" className="dark:text-gray-100">Checkup</SelectItem>
                      <SelectItem value="Surgery" className="dark:text-gray-100">Surgery</SelectItem>
                      <SelectItem value="Medication" className="dark:text-gray-100">Medication</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Date</Label>
                  <Input
                    type="date"
                    value={newRecord.date}
                    onChange={(e) => setNewRecord({...newRecord, date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Status</Label>
                  <Select value={newRecord.status} onValueChange={(value) => setNewRecord({...newRecord, status: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Completed" className="dark:text-gray-100">Completed</SelectItem>
                      <SelectItem value="Scheduled" className="dark:text-gray-100">Scheduled</SelectItem>
                      <SelectItem value="Overdue" className="dark:text-gray-100">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Description</Label>
                  <Textarea
                    value={newRecord.description}
                    onChange={(e) => setNewRecord({...newRecord, description: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Medication Name</Label>
                  <Input
                    value={newRecord.medication_name}
                    onChange={(e) => setNewRecord({...newRecord, medication_name: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Dosage</Label>
                  <Input
                    value={newRecord.dosage}
                    onChange={(e) => setNewRecord({...newRecord, dosage: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Veterinarian</Label>
                  <Input
                    value={newRecord.veterinarian}
                    onChange={(e) => setNewRecord({...newRecord, veterinarian: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Cost ($)</Label>
                  <Input
                    type="number"
                    value={newRecord.cost}
                    onChange={(e) => setNewRecord({...newRecord, cost: parseFloat(e.target.value)})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Next Due Date</Label>
                  <Input
                    type="date"
                    value={newRecord.next_due_date}
                    onChange={(e) => setNewRecord({...newRecord, next_due_date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Notes</Label>
                  <Textarea
                    value={newRecord.notes}
                    onChange={(e) => setNewRecord({...newRecord, notes: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>
              <Button onClick={() => createRecordMutation.mutate(newRecord)} className="w-full bg-[#F5A623] hover:bg-[#E09612]">
                Add Health Record
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-none shadow-lg dark:bg-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-orange-500 bg-opacity-10">
                  <Heart className="w-6 h-6 text-[#F5A623]" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Records</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">{healthRecords.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-lg dark:bg-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-blue-500 bg-opacity-10">
                  <Syringe className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Vaccinations</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">{vaccinations}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-lg dark:bg-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-red-500 bg-opacity-10">
                  <Calendar className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Overdue</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">{overdue}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-lg dark:bg-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-purple-500 bg-opacity-10">
                  <Heart className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Cost</p>
                  <p className="text-3xl font-bold text-gray-900 dark:text-gray-100">${totalCost.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter */}
        <Card className="mb-6 border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-64 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all" className="dark:text-gray-100">All Types</SelectItem>
                  <SelectItem value="Vaccination" className="dark:text-gray-100">Vaccination</SelectItem>
                  <SelectItem value="Treatment" className="dark:text-gray-100">Treatment</SelectItem>
                  <SelectItem value="Checkup" className="dark:text-gray-100">Checkup</SelectItem>
                  <SelectItem value="Surgery" className="dark:text-gray-100">Surgery</SelectItem>
                  <SelectItem value="Medication" className="dark:text-gray-100">Medication</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Records Table */}
        <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Health Records History</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-400">Date</TableHead>
                  <TableHead className="dark:text-gray-400">Animal</TableHead>
                  <TableHead className="dark:text-gray-400">Type</TableHead>
                  <TableHead className="dark:text-gray-400">Description</TableHead>
                  <TableHead className="dark:text-gray-400">Medication</TableHead>
                  <TableHead className="dark:text-gray-400">Veterinarian</TableHead>
                  <TableHead className="dark:text-gray-400">Cost</TableHead>
                  <TableHead className="dark:text-gray-400">Status</TableHead>
                  <TableHead className="dark:text-gray-400">Next Due</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.map(record => {
                  const TypeIcon = typeIcons[record.record_type] || Heart;
                  return (
                    <TableRow 
                      key={record.id}
                      onClick={() => handleRowClick(record)}
                      className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors dark:border-gray-700"
                    >
                      <TableCell className="dark:text-gray-300">{format(new Date(record.date), "MMM d, yyyy")}</TableCell>
                      <TableCell className="font-semibold dark:text-gray-200">{record.animal_name}</TableCell>
                      <TableCell className="dark:text-gray-300">
                        <div className="flex items-center gap-2">
                          <TypeIcon className="w-4 h-4 text-[#F5A623]" />
                          {record.record_type}
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate dark:text-gray-300">{record.description}</TableCell>
                      <TableCell className="dark:text-gray-300">{record.medication_name || "-"}</TableCell>
                      <TableCell className="dark:text-gray-300">{record.veterinarian || "-"}</TableCell>
                      <TableCell className="font-semibold dark:text-gray-200">${record.cost?.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge className={`${statusColors[record.status]} border text-xs`}>
                          {record.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="dark:text-gray-300">
                        {record.next_due_date ? format(new Date(record.next_due_date), "MMM d, yyyy") : "-"}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
            {filteredRecords.length === 0 && (
              <div className="text-center py-12">
                <Heart className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">No health records found</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Health Record Details Dialog */}
        <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800 z-[9999]">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <DialogTitle className="dark:text-gray-100 flex items-center gap-2">
                  {selectedRecord && typeIcons[selectedRecord.record_type] && 
                    React.createElement(typeIcons[selectedRecord.record_type], { className: "w-5 h-5" })
                  }
                  Health Record Details
                </DialogTitle>
                {!editMode && (
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={handleEdit} className="dark:border-gray-700 dark:text-gray-300">
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={handleDelete}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                )}
              </div>
            </DialogHeader>

            {selectedRecord && editedRecord && (
              <div className="space-y-6 py-4">
                {/* Status Badge */}
                <div className="flex items-center gap-3">
                  <Badge className={`${statusColors[editMode ? editedRecord.status : selectedRecord.status]} border text-sm px-3 py-1`}>
                    {editMode ? editedRecord.status : selectedRecord.status}
                  </Badge>
                  {selectedRecord.next_due_date && (
                    <Badge variant="outline" className="dark:border-gray-700 dark:text-gray-300">
                      <Calendar className="w-3 h-3 mr-1" />
                      Next Due: {format(new Date(selectedRecord.next_due_date), "MMM d, yyyy")}
                    </Badge>
                  )}
                </div>

                {/* Record Information Grid */}
                <div className="grid grid-cols-2 gap-6">
                  {/* Date */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Date</Label>
                    {editMode ? (
                      <Input
                        type="date"
                        value={editedRecord.date}
                        onChange={(e) => setEditedRecord({...editedRecord, date: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">
                        {format(new Date(selectedRecord.date), "MMMM d, yyyy")}
                      </p>
                    )}
                  </div>

                  {/* Animal */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Animal</Label>
                    {editMode ? (
                      <Select 
                        value={editedRecord.animal_id}
                        onValueChange={(value) => {
                          const animal = animals.find(a => a.id === value);
                          setEditedRecord({
                            ...editedRecord,
                            animal_id: value,
                            animal_name: animal?.name || ""
                          });
                        }}
                      >
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          {animals.map(animal => (
                            <SelectItem key={animal.id} value={animal.id} className="dark:text-gray-100">
                              {animal.name} ({animal.tag_number})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{selectedRecord.animal_name}</p>
                    )}
                  </div>

                  {/* Record Type */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Record Type</Label>
                    {editMode ? (
                      <Select value={editedRecord.record_type} onValueChange={(value) => setEditedRecord({...editedRecord, record_type: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Vaccination" className="dark:text-gray-100">Vaccination</SelectItem>
                          <SelectItem value="Treatment" className="dark:text-gray-100">Treatment</SelectItem>
                          <SelectItem value="Checkup" className="dark:text-gray-100">Checkup</SelectItem>
                          <SelectItem value="Surgery" className="dark:text-gray-100">Surgery</SelectItem>
                          <SelectItem value="Medication" className="dark:text-gray-100">Medication</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{selectedRecord.record_type}</p>
                    )}
                  </div>

                  {/* Status */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Status</Label>
                    {editMode ? (
                      <Select value={editedRecord.status} onValueChange={(value) => setEditedRecord({...editedRecord, status: value})}>
                        <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                          <SelectItem value="Completed" className="dark:text-gray-100">Completed</SelectItem>
                          <SelectItem value="Scheduled" className="dark:text-gray-100">Scheduled</SelectItem>
                          <SelectItem value="Overdue" className="dark:text-gray-100">Overdue</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge className={`${statusColors[selectedRecord.status]} border`}>
                        {selectedRecord.status}
                      </Badge>
                    )}
                  </div>

                  {/* Medication */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Medication</Label>
                    {editMode ? (
                      <Input
                        value={editedRecord.medication_name}
                        onChange={(e) => setEditedRecord({...editedRecord, medication_name: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{selectedRecord.medication_name || "-"}</p>
                    )}
                  </div>

                  {/* Dosage */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Dosage</Label>
                    {editMode ? (
                      <Input
                        value={editedRecord.dosage}
                        onChange={(e) => setEditedRecord({...editedRecord, dosage: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{selectedRecord.dosage || "-"}</p>
                    )}
                  </div>

                  {/* Veterinarian */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Veterinarian</Label>
                    {editMode ? (
                      <Input
                        value={editedRecord.veterinarian}
                        onChange={(e) => setEditedRecord({...editedRecord, veterinarian: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">{selectedRecord.veterinarian || "-"}</p>
                    )}
                  </div>

                  {/* Cost */}
                  <div>
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Cost</Label>
                    {editMode ? (
                      <Input
                        type="number"
                        value={editedRecord.cost}
                        onChange={(e) => setEditedRecord({...editedRecord, cost: parseFloat(e.target.value)})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold text-[#F5A623]">
                        ${selectedRecord.cost?.toLocaleString()}
                      </p>
                    )}
                  </div>

                  {/* Next Due Date */}
                  <div className="col-span-2">
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Next Due Date</Label>
                    {editMode ? (
                      <Input
                        type="date"
                        value={editedRecord.next_due_date}
                        onChange={(e) => setEditedRecord({...editedRecord, next_due_date: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                      />
                    ) : (
                      <p className="text-lg font-semibold dark:text-gray-200">
                        {selectedRecord.next_due_date 
                          ? format(new Date(selectedRecord.next_due_date), "MMMM d, yyyy")
                          : "-"}
                      </p>
                    )}
                  </div>

                  {/* Description */}
                  <div className="col-span-2">
                    <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Description</Label>
                    {editMode ? (
                      <Textarea
                        value={editedRecord.description}
                        onChange={(e) => setEditedRecord({...editedRecord, description: e.target.value})}
                        className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                        rows={3}
                      />
                    ) : (
                      <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{selectedRecord.description}</p>
                    )}
                  </div>

                  {/* Notes */}
                  {(editMode || selectedRecord.notes) && (
                    <div className="col-span-2">
                      <Label className="text-sm text-gray-500 dark:text-gray-400 mb-2 block">Notes</Label>
                      {editMode ? (
                        <Textarea
                          value={editedRecord.notes}
                          onChange={(e) => setEditedRecord({...editedRecord, notes: e.target.value})}
                          className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                          rows={3}
                        />
                      ) : (
                        <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{selectedRecord.notes || "-"}</p>
                      )}
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                {editMode && (
                  <div className="flex justify-end gap-3 pt-4 border-t dark:border-gray-700">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setEditMode(false);
                        setEditedRecord({ ...selectedRecord });
                      }}
                      className="dark:border-gray-700 dark:text-gray-300"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleSave}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      Save Changes
                    </Button>
                  </div>
                )}

                {!editMode && (
                  <div className="flex justify-start pt-4 border-t dark:border-gray-700">
                    <Button 
                      variant="outline"
                      onClick={() => setShowDetailsDialog(false)}
                      className="dark:border-gray-700 dark:text-gray-300"
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Back to Health Records
                    </Button>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}