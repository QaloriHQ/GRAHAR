import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, DollarSign, Calendar, MapPin } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";

export default function Market() {
  const [commodity, setCommodity] = useState("feeder_steer");
  const [targetWeight, setTargetWeight] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: priceData, isLoading, error: priceError } = useQuery({
    queryKey: ['marketPrices', user?.active_ranch_id, commodity, targetWeight],
    queryFn: async () => {
      const response = await base44.functions.invoke('getMarketPrices', {
        species: commodity,
        weight_lbs: targetWeight,
        ranch_id: user.active_ranch_id
      });
      if (!response.data?.success) {
        throw new Error(response.data.message || response.data.error || 'Failed to fetch market prices');
      }
      return response.data;
    },
    enabled: !!user?.active_ranch_id,
    retry: 1
  });

  const { data: historyData } = useQuery({
    queryKey: ['marketHistory', user?.active_ranch_id, commodity, targetWeight],
    queryFn: async () => {
      const response = await base44.functions.invoke('queryMarketInsightsPriceHistory', {
        commodity_type: commodity,
        ranch_id: user.active_ranch_id,
        months_back: 6,
        target_weight_lbs: targetWeight
      });
      return response.data;
    },
    enabled: !!user?.active_ranch_id
  });

  const prices = priceData?.results || [];
  const history = historyData?.history || [];
  const summary = priceData?.summary;

  const avgPrice = summary?.avg_price_per_cwt || (prices.length > 0 ? prices.reduce((sum, p) => sum + p.price_per_cwt, 0) / prices.length : 0);
  
  const trend = history.length >= 2 ? 
    ((history[history.length - 1].avg_price - history[0].avg_price) / history[0].avg_price * 100) : 0;

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-green-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Market Insights</h1>
            <p className="text-gray-600">Live cattle market prices and trends</p>
          </div>
          <Button
            variant="outline"
            onClick={() => window.location.href = '/RanchSettings?tab=market'}
          >
            <MapPin className="w-4 h-4 mr-2" />
            Configure Markets
          </Button>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">Commodity Type</label>
                <Select value={commodity} onValueChange={setCommodity}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="feeder_steer">Feeder Steers</SelectItem>
                    <SelectItem value="feeder_heifer">Feeder Heifers</SelectItem>
                    <SelectItem value="calf">Calves</SelectItem>
                    <SelectItem value="slaughter_cow">Slaughter Cows</SelectItem>
                    <SelectItem value="slaughter_bull">Slaughter Bulls</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">Target Weight (lbs)</label>
                <Select value={targetWeight?.toString() || "all"} onValueChange={(v) => setTargetWeight(v === "all" ? null : parseInt(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Weights</SelectItem>
                    <SelectItem value="400">400 lbs</SelectItem>
                    <SelectItem value="500">500 lbs</SelectItem>
                    <SelectItem value="600">600 lbs</SelectItem>
                    <SelectItem value="700">700 lbs</SelectItem>
                    <SelectItem value="800">800 lbs</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Average Price</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span className="text-3xl font-bold">${avgPrice.toFixed(2)}</span>
                <span className="text-gray-600">/cwt</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">6-Month Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {trend >= 0 ? (
                  <TrendingUp className="w-5 h-5 text-green-600" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-600" />
                )}
                <span className={`text-3xl font-bold ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {Math.abs(trend).toFixed(1)}%
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Markets Tracked</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-blue-600" />
                <span className="text-3xl font-bold">{prices.length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Price Trend Chart */}
        {history.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Price Trend (Last 6 Months)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="month" 
                    tickFormatter={(value) => format(new Date(value + '-01'), 'MMM yyyy')}
                  />
                  <YAxis 
                    label={{ value: '$/cwt', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip 
                    formatter={(value) => `$${value.toFixed(2)}/cwt`}
                    labelFormatter={(label) => format(new Date(label + '-01'), 'MMMM yyyy')}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="avg_price" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Current Prices */}
        <Card>
          <CardHeader>
            <CardTitle>Current Market Prices</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-center py-8 text-gray-500">Loading market data...</p>
            ) : priceError ? (
              <div className="text-center py-8">
                <p className="text-red-600 mb-2 font-semibold">Unable to load market data</p>
                <p className="text-gray-600 mb-4">{priceError.message}</p>
                <Button onClick={() => window.location.href = '/RanchSettings?tab=market'}>
                  Configure Local Markets
                </Button>
              </div>
            ) : prices.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-600 mb-4">No market data available for your area.</p>
                <Button onClick={() => window.location.href = '/RanchSettings?tab=market'}>
                  Configure Local Markets
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {prices.map((price, idx) => (
                  <div key={idx} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{price.market_name}</h3>
                        <p className="text-sm text-gray-600">{price.region}</p>
                      </div>
                      {price.is_local_market && (
                        <Badge className="bg-green-100 text-green-800">Local Market</Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-gray-600">Weight Range</p>
                        <p className="font-semibold">{price.weight_min}-{price.weight_max} lbs</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Average Price</p>
                        <p className="font-semibold text-green-600">${price.price_per_cwt.toFixed(2)}/cwt</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Price Range</p>
                        <p className="font-semibold">${price.price_low.toFixed(2)} - ${price.price_high.toFixed(2)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Sale Date</p>
                        <p className="font-semibold flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(price.sale_date), 'MMM d, yyyy')}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}