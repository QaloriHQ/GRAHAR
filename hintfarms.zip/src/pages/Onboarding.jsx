import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; // Added Textarea import
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress"; // Added Progress import
import { Check, Loader2, ArrowRight, Beef } from "lucide-react"; // Updated lucide-react imports
import { trackSignupComplete, trackOnboardingFinish, trackRanchCreate } from "@/components/utils"; // Updated tracking functions path and added trackSignupComplete

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [ranchData, setRanchData] = useState({
    name: "",
    location: "",
    total_acres: 0,
    herd_size: 0,
    contact_email: "",
    contact_phone: ""
  });
  const [selectedRanchId, setSelectedRanchId] = useState(null);
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("Worker");

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: userRanchMembers = [] } = useQuery({
    queryKey: ['userRanchMembers', user?.email],
    queryFn: () => base44.entities.RanchMember.filter({ user_email: user.email, status: 'Active' }),
    initialData: [],
    enabled: !!user?.email,
  });

  const { data: ownedRanches = [] } = useQuery({
    queryKey: ['ownedRanches', user?.email],
    queryFn: () => base44.entities.Ranch.filter({ owner_email: user.email }),
    initialData: [],
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (user?.onboarding_completed) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const createRanchMutation = useMutation({
    mutationFn: async (data) => {
      const ranch = await base44.entities.Ranch.create({
        ...data,
        owner_email: user.email,
        owner_name: user.full_name,
        subscription_plan: "Pro Trial",
        subscription_status: "Trial",
        trial_start_date: new Date().toISOString().split('T')[0],
        trial_end_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      });
      
      // Track ranch creation
      trackRanchCreate(user.id, ranch.id, data.name);
      
      return ranch;
    },
    onSuccess: async (ranch) => {
      await base44.auth.updateMe({ active_ranch_id: ranch.id });
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      queryClient.invalidateQueries({ queryKey: ['ownedRanches'] });
      setStep(3);
    },
  });

  const selectRanchMutation = useMutation({
    mutationFn: async (ranchId) => {
      await base44.auth.updateMe({ active_ranch_id: ranchId });
      return ranchId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      setStep(3);
    },
  });

  const finishOnboardingMutation = useMutation({
    mutationFn: async () => {
      await base44.auth.updateMe({ 
        onboarding_completed: true,
        tutorial_status: "Not Started"
      });
      
      // Track onboarding completion
      const updatedUser = await base44.auth.me();
      trackOnboardingFinish(updatedUser.id, updatedUser.active_ranch_id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      navigate('/dashboard');
    },
  });

  const sendInviteMutation = useMutation({
    mutationFn: async ({ email, role }) => {
      const inviteToken = Math.random().toString(36).substring(2) + Date.now().toString(36);
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      
      const ranch = ownedRanches.find(r => r.id === user.active_ranch_id);
      
      await base44.asServiceRole.entities.RanchInvite.create({
        ranch_id: user.active_ranch_id,
        ranch_name: ranch?.name || "Your Ranch",
        invited_email: email,
        invited_name: "",
        role: role,
        invited_by_email: user.email,
        invited_by_name: user.full_name,
        invite_token: inviteToken,
        status: "Pending",
        expires_at: expiresAt
      });

      const inviteUrl = `${window.location.origin}/accept-invite?token=${inviteToken}`;
      
      await base44.integrations.Core.SendEmail({
        from_name: "GRAHAR",
        to: email,
        subject: `You're invited to join ${ranch?.name || "a ranch"} on GRAHAR`,
        body: `Hi,\n\n${user.full_name} has invited you to join their ranch "${ranch?.name || "a ranch"}" on GRAHAR as a ${role}.\n\nClick the link below to accept the invitation:\n${inviteUrl}\n\nThis invitation will expire in 7 days.\n\nBest regards,\nThe GRAHAR Team`
      });
    },
    onSuccess: () => {
      setInviteEmail("");
      setInviteRole("Worker");
      setShowInviteForm(false);
      
      const event = new CustomEvent('showToast', {
        detail: { message: 'Invitation sent successfully!', type: 'success' }
      });
      window.dispatchEvent(event);
    },
  });

  const availableRanches = [...ownedRanches, ...userRanchMembers.map(member => ({
    id: member.ranch_id,
    name: `${member.ranch_id} (Member)`,
    isMember: true
  }))];

  const progress = (step / 3) * 100; // Re-added progress calculation

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl dark:bg-gray-950 dark:border-gray-800">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68f918ca6fc28d2cc722a501/d74247bee_FindCash-6.png"
              alt="GRAHAR Logo"
              className="w-16 h-16"
            />
          </div>
          <CardTitle className="text-3xl font-bold dark:text-gray-100">Welcome to GRAHAR</CardTitle>
          <CardDescription className="text-lg dark:text-gray-400">
            Let's get your ranch set up in just a few steps
          </CardDescription>
          <div className="mt-6">
            <Progress value={progress} className="h-2" /> {/* Re-added Progress component */}
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Step {step} of 3</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <Beef className="w-16 h-16 text-[#F5A623] mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">Choose Your Ranch</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Create a new ranch or select an existing one
                </p>
              </div>

              {availableRanches.length > 0 && (
                <div className="space-y-3">
                  <Label className="text-lg font-semibold dark:text-gray-200">Available Ranches</Label>
                  {availableRanches.map(ranch => (
                    <div
                      key={ranch.id}
                      onClick={() => {
                        setSelectedRanchId(ranch.id);
                        selectRanchMutation.mutate(ranch.id);
                      }}
                      className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        selectedRanchId === ranch.id
                          ? 'border-[#F5A623] bg-orange-50 dark:bg-orange-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-orange-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold dark:text-gray-100">{ranch.name}</p>
                          {ranch.location && <p className="text-sm text-gray-500 dark:text-gray-400">{ranch.location}</p>}
                          {ranch.isMember && <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200 mt-1 inline-block">Team Member</span>}
                        </div>
                        <Check 
                          className={`w-6 h-6 ${
                            selectedRanchId === ranch.id ? 'text-[#F5A623]' : 'text-gray-300'
                          }`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300 dark:border-gray-700"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white dark:bg-gray-950 text-gray-500 dark:text-gray-400">Or create a new ranch</span>
                </div>
              </div>

              <Button
                onClick={() => setStep(2)}
                className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                size="lg"
              >
                <Beef className="w-5 h-5 mr-2" />
                Create New Ranch
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <Beef className="w-16 h-16 text-[#F5A623] mx-auto mb-4" /> {/* Changed from MapPin to Beef */}
                <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">Create Your Ranch</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Tell us a bit about your operation
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ranch_name" className="dark:text-gray-200">Ranch Name *</Label>
                  <Input
                    id="ranch_name"
                    value={ranchData.name}
                    onChange={(e) => setRanchData({...ranchData, name: e.target.value})}
                    placeholder="e.g., Green Valley Ranch"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location" className="dark:text-gray-200">Location *</Label>
                  <Input
                    id="location"
                    value={ranchData.location}
                    onChange={(e) => setRanchData({...ranchData, location: e.target.value})}
                    placeholder="e.g., Austin, TX"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="total_acres" className="dark:text-gray-200">Total Acres</Label>
                    <Input
                      id="total_acres"
                      type="number"
                      value={ranchData.total_acres}
                      onChange={(e) => setRanchData({...ranchData, total_acres: parseFloat(e.target.value) || 0})}
                      placeholder="0"
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="herd_size" className="dark:text-gray-200">Herd Size</Label>
                    <Input
                      id="herd_size"
                      type="number"
                      value={ranchData.herd_size}
                      onChange={(e) => setRanchData({...ranchData, herd_size: parseFloat(e.target.value) || 0})}
                      placeholder="0"
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contact_email" className="dark:text-gray-200">Contact Email</Label>
                  <Input
                    id="contact_email"
                    type="email"
                    value={ranchData.contact_email}
                    onChange={(e) => setRanchData({...ranchData, contact_email: e.target.value})}
                    placeholder="ranch@example.com"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contact_phone" className="dark:text-gray-200">Contact Phone</Label>
                  <Input
                    id="contact_phone"
                    value={ranchData.contact_phone}
                    onChange={(e) => setRanchData({...ranchData, contact_phone: e.target.value})}
                    placeholder="(555) 123-4567"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  onClick={() => createRanchMutation.mutate(ranchData)}
                  disabled={!ranchData.name || !ranchData.location || createRanchMutation.isPending}
                  className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                >
                  {createRanchMutation.isPending && <Loader2 className="animate-spin w-4 h-4 mr-2" />}
                  Create Ranch
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <Check className="w-16 h-16 text-[#F5A623] mx-auto mb-4" /> {/* Changed from CheckCircle to Check */}
                <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">You're All Set!</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Your ranch is ready. Would you like to invite team members?
                </p>

                <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-lg p-4 mb-6">
                  <div className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" /> {/* Changed from CheckCircle to Check */}
                    <div className="text-left">
                      <p className="text-sm font-semibold text-emerald-900 dark:text-emerald-100 mb-1">
                        🎉 14-Day PRO Trial Activated!
                      </p>
                      <p className="text-xs text-emerald-700 dark:text-emerald-300">
                        Enjoy full access to all premium features. No credit card required.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {showInviteForm ? (
                <div className="space-y-4 p-4 border-2 border-orange-200 dark:border-orange-800 rounded-lg">
                  <div className="space-y-2">
                    <Label htmlFor="invite_email" className="dark:text-gray-200">Team Member Email</Label>
                    <Input
                      id="invite_email"
                      type="email"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      placeholder="teammate@example.com"
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="invite_role" className="dark:text-gray-200">Role</Label>
                    <Select value={inviteRole} onValueChange={setInviteRole}>
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="Manager" className="dark:text-gray-100">Manager</SelectItem>
                        <SelectItem value="Worker" className="dark:text-gray-100">Worker</SelectItem>
                        <SelectItem value="Veterinarian" className="dark:text-gray-100">Veterinarian</SelectItem>
                        <SelectItem value="Assistant" className="dark:text-gray-100">Assistant</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      onClick={() => setShowInviteForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={() => sendInviteMutation.mutate({ email: inviteEmail, role: inviteRole })}
                      disabled={!inviteEmail || sendInviteMutation.isPending}
                      className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                    >
                      {sendInviteMutation.isPending && <Loader2 className="animate-spin w-4 h-4 mr-2" />}
                      Send Invitation
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => setShowInviteForm(true)}
                  className="w-full"
                >
                  <ArrowRight className="w-4 h-4 mr-2" /> {/* Changed from Users to ArrowRight */}
                  Invite Team Members
                </Button>
              )}

              <Button
                onClick={() => finishOnboardingMutation.mutate()}
                disabled={finishOnboardingMutation.isPending}
                className="w-full bg-[#F5A623] hover:bg-[#E09612]"
                size="lg"
              >
                {finishOnboardingMutation.isPending && <Loader2 className="animate-spin w-4 h-4 mr-2" />}
                Go to Dashboard
                <ArrowRight className="w-4 h-4 ml-2" /> {/* Changed from CheckCircle to ArrowRight */}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}