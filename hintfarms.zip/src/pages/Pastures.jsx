import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Droplets, Fence, TrendingUp, Plus, Edit, Eye, Map, LayoutGrid, Loader2, AlertCircle } from "lucide-react";
import StatsCard from "../components/dashboard/StatsCard";
import MapboxPastureMap from "../components/pastures/MapboxPastureMap";
import MapboxAddressInput from "../components/pastures/MapboxAddressInput";
import { toast } from "sonner";
import { trackPastureAdd } from "@/components/utils";
import { useNavigate } from "react-router-dom";

export default function Pastures() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  
  // All useState hooks first
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingPasture, setEditingPasture] = useState(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedPasture, setSelectedPasture] = useState(null);
  const [viewMode, setViewMode] = useState("grid");
  const [filterType, setFilterType] = useState("all");
  const [filterCondition, setFilterCondition] = useState("all");
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [mapboxToken, setMapboxToken] = useState(null);
  const [addressSearchValue, setAddressSearchValue] = useState("");
  
  const [newPasture, setNewPasture] = useState({
    name: "",
    size_acres: 0,
    type: "Grazing",
    address_line1: "",
    address_line2: "",
    city: "",
    state: "",
    postal_code: "",
    country: "USA",
    lat: null,
    lon: null,
    geocode_status: "pending",
    geocode_source: null,
    geocode_updated_at: null,
    capacity: 0,
    current_animal_count: 0,
    condition: "Good",
    grazing_quality: "Good",
    water_source: "",
    fence_condition: "Good",
    notes: "",
    image_url: "",
    last_rotation_date: "",
    next_rotation_date: "",
  });

  // All useQuery hooks
  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  // Fetch Mapbox token from backend
  useEffect(() => {
    const fetchMapboxToken = async () => {
      try {
        const response = await base44.functions.invoke('getMapboxToken', {});
        if (response.data && response.data.token) {
          setMapboxToken(response.data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    
    if (user) {
      fetchMapboxToken();
    }
  }, [user]);

  // All useMutation hooks
  const createPastureMutation = useMutation({
    mutationFn: async (data) => {
      // If we have an address but no coordinates, try to geocode
      const hasAddress = data.address_line1 || data.city || data.state;
      const hasCoords = data.lat !== null && data.lon !== null;
      
      if (hasAddress && !hasCoords) {
        try {
          const response = await base44.functions.invoke('geocodeAddress', {
            address_line1: data.address_line1,
            address_line2: data.address_line2,
            city: data.city,
            state: data.state,
            postal_code: data.postal_code,
            country: data.country
          });

          if (response.data.success) {
            data.lat = response.data.lat;
            data.lon = response.data.lon;
            data.geocode_status = response.data.geocode_status;
            data.geocode_source = response.data.geocode_source;
            data.geocode_updated_at = response.data.geocode_updated_at;
          } else {
            data.geocode_status = 'failed';
            data.geocode_updated_at = new Date().toISOString();
          }
        } catch (error) {
          console.error('Geocoding error:', error);
          data.geocode_status = 'failed';
          data.geocode_updated_at = new Date().toISOString();
        }
      }
      
      return base44.entities.Pasture.create({ ...data, ranch_id: user.active_ranch_id });
    },
    onSuccess: (newPastureData) => {
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      setShowAddDialog(false);
      resetForm();
      toast.success('Pasture created successfully');
      trackPastureAdd(newPastureData.id); // Track the event
    },
    onError: (error) => {
      console.error('Error creating pasture:', error);
      toast.error('Failed to create pasture');
    }
  });

  const updatePastureMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      // Check if address changed
      const originalPasture = pastures.find(p => p.id === id);
      const addressChanged = originalPasture && (
        originalPasture.address_line1 !== data.address_line1 ||
        originalPasture.city !== data.city ||
        originalPasture.state !== data.state ||
        originalPasture.postal_code !== data.postal_code
      );

      // If address changed and we don't have manual coordinates, re-geocode
      if (addressChanged && data.geocode_source !== 'manual') {
        try {
          const response = await base44.functions.invoke('geocodeAddress', {
            address_line1: data.address_line1,
            address_line2: data.address_line2,
            city: data.city,
            state: data.state,
            postal_code: data.postal_code,
            country: data.country
          });

          if (response.data.success) {
            data.lat = response.data.lat;
            data.lon = response.data.lon;
            data.geocode_status = response.data.geocode_status;
            data.geocode_source = response.data.geocode_source;
            data.geocode_updated_at = response.data.geocode_updated_at;
          }
        } catch (error) {
          console.error('Re-geocoding error:', error);
        }
      }

      return base44.entities.Pasture.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      setShowAddDialog(false);
      setEditingPasture(null);
      resetForm();
      toast.success('Pasture updated successfully');
    },
    onError: (error) => {
      console.error('Error updating pasture:', error);
      toast.error('Failed to update pasture');
    }
  });

  const deletePastureMutation = useMutation({
    mutationFn: (id) => base44.entities.Pasture.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      setShowDetailsDialog(false);
      setSelectedPasture(null);
      toast.success('Pasture deleted successfully');
    },
  });

  // Helper functions
  const resetForm = () => {
    setNewPasture({
      name: "",
      size_acres: 0,
      type: "Grazing",
      address_line1: "",
      address_line2: "",
      city: "",
      state: "",
      postal_code: "",
      country: "USA",
      lat: null,
      lon: null,
      geocode_status: "pending",
      geocode_source: null,
      geocode_updated_at: null,
      capacity: 0,
      current_animal_count: 0,
      condition: "Good",
      grazing_quality: "Good",
      water_source: "",
      fence_condition: "Good",
      notes: "",
      image_url: "",
      last_rotation_date: "",
      next_rotation_date: "",
    });
    setIsGeocoding(false);
    setAddressSearchValue("");
  };

  const handleAddressSelect = (addressComponents) => {
    setNewPasture(prev => ({
      ...prev,
      ...addressComponents,
      geocode_status: 'success',
      geocode_source: 'mapbox',
      geocode_updated_at: new Date().toISOString()
    }));
    toast.success('Address selected and coordinates set');
  };

  const handleMarkerDragEnd = async (pastureId, newLat, newLng) => {
    try {
      await base44.entities.Pasture.update(pastureId, {
        lat: newLat,
        lon: newLng,
        geocode_status: 'manual',
        geocode_source: 'manual',
        geocode_updated_at: new Date().toISOString()
      });
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      toast.success('Pasture location updated successfully');
    } catch (error) {
      console.error('Error updating location:', error);
      toast.error('Failed to update pasture location');
    }
  };

  const handleFenceUpdate = async (pastureId, coordinates) => {
    try {
      await base44.entities.Pasture.update(pastureId, {
        fence_coordinates: coordinates
      });
      queryClient.invalidateQueries({ queryKey: ['pastures'] });
      toast.success(coordinates ? 'Fence boundary saved' : 'Fence removed');
    } catch (error) {
      console.error('Error updating fence:', error);
      toast.error('Failed to update fence boundary');
    }
  };

  // Calculate area of polygon in square feet
  const calculateFenceArea = (coordinates) => {
    if (!coordinates || coordinates.length < 3) return 0;
    
    const toMeters = (coords) => {
      const avgLat = coords.reduce((sum, c) => sum + c[1], 0) / coords.length;
      const latToMeters = 111320;
      const lonToMeters = latToMeters * Math.cos(avgLat * Math.PI / 180);
      return coords.map(c => [c[0] * lonToMeters, c[1] * latToMeters]);
    };
    
    const metersCoords = toMeters(coordinates);
    let area = 0;
    for (let i = 0; i < metersCoords.length; i++) {
      const j = (i + 1) % metersCoords.length;
      area += metersCoords[i][0] * metersCoords[j][1];
      area -= metersCoords[j][0] * metersCoords[i][1];
    }
    area = Math.abs(area) / 2;
    return Math.round(area * 10.7639); // Convert to sqft
  };

  const handleEdit = (pasture) => {
    setEditingPasture(pasture);
    setNewPasture({
      ...pasture,
      last_rotation_date: pasture.last_rotation_date ? new Date(pasture.last_rotation_date).toISOString().split('T')[0] : "",
      next_rotation_date: pasture.next_rotation_date ? new Date(pasture.next_rotation_date).toISOString().split('T')[0] : "",
    });
    setShowAddDialog(true);
  };

  const handleSave = async () => {
    if (editingPasture) {
      updatePastureMutation.mutate({ id: editingPasture.id, data: newPasture });
    } else {
      createPastureMutation.mutate(newPasture);
    }
  };

  const handleViewDetails = (pasture) => {
    navigate(`/PastureProfile?id=${pasture.id}`);
  };

  const formatFullAddress = (pasture) => {
    const parts = [
      pasture.address_line1,
      pasture.address_line2,
      pasture.city,
      pasture.state,
      pasture.postal_code,
      pasture.country
    ].filter(Boolean);
    return parts.join(', ');
  };

  // Filter and compute stats
  const filteredPastures = pastures.filter(pasture => {
    const matchesType = filterType === "all" || pasture.type === filterType;
    const matchesCondition = filterCondition === "all" || pasture.condition === filterCondition;
    return matchesType && matchesCondition;
  });

  const totalAcres = filteredPastures.reduce((sum, p) => sum + (p.size_acres || 0), 0);
  const totalCapacity = filteredPastures.reduce((sum, p) => sum + (p.capacity || 0), 0);
  const totalAnimals = filteredPastures.reduce((sum, p) => sum + (p.current_animal_count || 0), 0);
  const utilization = totalCapacity > 0 ? ((totalAnimals / totalCapacity) * 100).toFixed(1) : 0;

  // Color configurations
  const typeColors = {
    "Grazing": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Hay": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Breeding": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300",
    "Isolation": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  const conditionColors = {
    "Good": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Fair": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Poor": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  const qualityColors = {
    "Excellent": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Good": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Fair": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Poor": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  const fenceColors = {
    "Good": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Needs Repair": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "Critical": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Pasture Management</h1>
            <p className="text-gray-600 dark:text-gray-400">Monitor and manage your grazing areas</p>
          </div>
          <Dialog open={showAddDialog} onOpenChange={(open) => {
            setShowAddDialog(open);
            if (!open) {
              setEditingPasture(null);
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Add Pasture
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
              <DialogHeader>
                <DialogTitle className="dark:text-gray-100">
                  {editingPasture ? 'Edit Pasture' : 'Add New Pasture'}
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Pasture Name *</Label>
                  <Input
                    value={newPasture.name}
                    onChange={(e) => setNewPasture({...newPasture, name: e.target.value})}
                    placeholder="e.g., North Field, Back 40"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200 font-semibold flex items-center gap-2">
                    Address Search
                    {mapboxToken && <span className="text-xs text-[#F5A623]">✓ Powered by Mapbox</span>}
                  </Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Search for an address - fields will auto-fill</p>
                  <MapboxAddressInput
                    value={addressSearchValue}
                    onChange={setAddressSearchValue}
                    onSelect={handleAddressSelect}
                    placeholder="Search for pasture address..."
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    mapboxToken={mapboxToken}
                  />
                </div>

                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Street Address</Label>
                  <Input
                    value={newPasture.address_line1}
                    onChange={(e) => setNewPasture({...newPasture, address_line1: e.target.value})}
                    placeholder="123 Ranch Road"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Address Line 2 (Optional)</Label>
                  <Input
                    value={newPasture.address_line2}
                    onChange={(e) => setNewPasture({...newPasture, address_line2: e.target.value})}
                    placeholder="Unit, Suite, Building"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">City</Label>
                  <Input
                    value={newPasture.city}
                    onChange={(e) => setNewPasture({...newPasture, city: e.target.value})}
                    placeholder="City"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">State</Label>
                  <Input
                    value={newPasture.state}
                    onChange={(e) => setNewPasture({...newPasture, state: e.target.value})}
                    placeholder="CA"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Postal Code</Label>
                  <Input
                    value={newPasture.postal_code}
                    onChange={(e) => setNewPasture({...newPasture, postal_code: e.target.value})}
                    placeholder="12345"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Country</Label>
                  <Input
                    value={newPasture.country}
                    onChange={(e) => setNewPasture({...newPasture, country: e.target.value})}
                    placeholder="USA"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                {newPasture.lat !== null && newPasture.lon !== null && (
                  <div className="col-span-2">
                    <p className="text-xs text-green-600 dark:text-green-400 text-center flex items-center justify-center gap-2">
                      <MapPin className="w-3 h-3" />
                      Coordinates: {newPasture.lat.toFixed(6)}, {newPasture.lon.toFixed(6)}
                    </p>
                  </div>
                )}

                {newPasture.geocode_status === 'failed' && (
                  <div className="col-span-2">
                    <p className="text-xs text-orange-600 dark:text-orange-400 text-center flex items-center justify-center gap-1 bg-orange-50 dark:bg-orange-900/20 p-2 rounded">
                      <AlertCircle className="w-3 h-3" />
                      Couldn't auto-locate this address. You can place it manually on the map after saving.
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Latitude (Manual Override)</Label>
                  <Input
                    type="number"
                    step="any"
                    value={newPasture.lat || ""}
                    onChange={(e) => setNewPasture({...newPasture, lat: e.target.value ? parseFloat(e.target.value) : null})}
                    placeholder="e.g., 36.7783"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Longitude (Manual Override)</Label>
                  <Input
                    type="number"
                    step="any"
                    value={newPasture.lon || ""}
                    onChange={(e) => setNewPasture({...newPasture, lon: e.target.value ? parseFloat(e.target.value) : null})}
                    placeholder="e.g., -119.4179"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Acreage *</Label>
                  <Input
                    type="number"
                    value={newPasture.size_acres}
                    onChange={(e) => setNewPasture({...newPasture, size_acres: parseFloat(e.target.value) || 0})}
                    placeholder="0"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Type</Label>
                  <Select value={newPasture.type} onValueChange={(value) => setNewPasture({...newPasture, type: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Grazing">Grazing</SelectItem>
                      <SelectItem value="Hay">Hay</SelectItem>
                      <SelectItem value="Breeding">Breeding</SelectItem>
                      <SelectItem value="Isolation">Isolation</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Capacity (Animals)</Label>
                  <Input
                    type="number"
                    value={newPasture.capacity}
                    onChange={(e) => setNewPasture({...newPasture, capacity: parseInt(e.target.value) || 0})}
                    placeholder="0"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Current Animals</Label>
                  <Input
                    type="number"
                    value={newPasture.current_animal_count}
                    onChange={(e) => setNewPasture({...newPasture, current_animal_count: parseInt(e.target.value) || 0})}
                    placeholder="0"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Overall Condition</Label>
                  <Select value={newPasture.condition} onValueChange={(value) => setNewPasture({...newPasture, condition: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Good">Good</SelectItem>
                      <SelectItem value="Fair">Fair</SelectItem>
                      <SelectItem value="Poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Grazing Quality</Label>
                  <Select value={newPasture.grazing_quality} onValueChange={(value) => setNewPasture({...newPasture, grazing_quality: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Excellent">Excellent</SelectItem>
                      <SelectItem value="Good">Good</SelectItem>
                      <SelectItem value="Fair">Fair</SelectItem>
                      <SelectItem value="Poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Water Source</Label>
                  <Input
                    value={newPasture.water_source}
                    onChange={(e) => setNewPasture({...newPasture, water_source: e.target.value})}
                    placeholder="e.g., Pond, Well, Stream"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Fence Condition</Label>
                  <Select value={newPasture.fence_condition} onValueChange={(value) => setNewPasture({...newPasture, fence_condition: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Good">Good</SelectItem>
                      <SelectItem value="Needs Repair">Needs Repair</SelectItem>
                      <SelectItem value="Critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Last Rotation Date</Label>
                  <Input
                    type="date"
                    value={newPasture.last_rotation_date || ""}
                    onChange={(e) => setNewPasture({...newPasture, last_rotation_date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Next Rotation Date</Label>
                  <Input
                    type="date"
                    value={newPasture.next_rotation_date || ""}
                    onChange={(e) => setNewPasture({...newPasture, next_rotation_date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Image URL (Optional)</Label>
                  <Input
                    value={newPasture.image_url}
                    onChange={(e) => setNewPasture({...newPasture, image_url: e.target.value})}
                    placeholder="https://example.com/pasture-photo.jpg"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Notes</Label>
                  <Textarea
                    value={newPasture.notes}
                    onChange={(e) => setNewPasture({...newPasture, notes: e.target.value})}
                    placeholder="Additional information about this pasture..."
                    rows={3}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowAddDialog(false);
                    setEditingPasture(null);
                    resetForm();
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                  className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                  disabled={!newPasture.name || !newPasture.size_acres || isGeocoding}
                >
                  {isGeocoding ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    editingPasture ? 'Update Pasture' : 'Add Pasture'
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Total Pastures"
            value={filteredPastures.length}
            icon={MapPin}
            bgColor="bg-orange-500"
            textColor="text-[#F5A623]"
          />
          <StatsCard
            title="Total Acres"
            value={totalAcres}
            icon={TrendingUp}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Animals Grazing"
            value={totalAnimals}
            icon={MapPin}
            bgColor="bg-purple-500"
            textColor="text-purple-600"
          />
          <StatsCard
            title="Utilization"
            value={`${utilization}%`}
            icon={TrendingUp}
            bgColor="bg-orange-500"
            textColor="text-orange-600"
          />
        </div>

        {/* View Toggle and Filters */}
        <Card className="mb-6 border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <Tabs value={viewMode} onValueChange={setViewMode} className="w-full md:w-auto">
                <TabsList className="dark:bg-gray-900">
                  <TabsTrigger value="grid" className="dark:data-[state=active]:bg-gray-800">
                    <LayoutGrid className="w-4 h-4 mr-2" />
                    Grid View
                  </TabsTrigger>
                  <TabsTrigger value="map" className="dark:data-[state=active]:bg-gray-800">
                    <Map className="w-4 h-4 mr-2" />
                    Map View
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="flex gap-3 flex-wrap">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-full sm:w-40 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Grazing">Grazing</SelectItem>
                    <SelectItem value="Hay">Hay</SelectItem>
                    <SelectItem value="Breeding">Breeding</SelectItem>
                    <SelectItem value="Isolation">Isolation</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={filterCondition} onValueChange={setFilterCondition}>
                  <SelectTrigger className="w-full sm:w-40 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                    <SelectValue placeholder="Filter by condition" />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                    <SelectItem value="all">All Conditions</SelectItem>
                    <SelectItem value="Good">Good</SelectItem>
                    <SelectItem value="Fair">Fair</SelectItem>
                    <SelectItem value="Poor">Poor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Map View */}
        {viewMode === "map" && (
          <div className="mb-8 relative z-0">
            <MapboxPastureMap 
              pastures={filteredPastures}
              onViewDetails={handleViewDetails}
              onMarkerDragEnd={handleMarkerDragEnd}
              onFenceUpdate={handleFenceUpdate}
              mapboxToken={mapboxToken}
              allowDrawing={false}
            />
            <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-6 text-sm flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-500"></div>
                  <span className="dark:text-gray-300">Good Condition</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-yellow-500"></div>
                  <span className="dark:text-gray-300">Fair Condition</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-500"></div>
                  <span className="dark:text-gray-300">Poor Condition</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-gray-400 border-2 border-red-500"></div>
                  <span className="dark:text-gray-300">Needs Placement</span>
                </div>
                <div className="flex items-center gap-2 ml-auto">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="dark:text-gray-300 text-xs">Drag markers to adjust location</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Grid View */}
        {viewMode === "grid" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPastures.map(pasture => (
              <Card key={pasture.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300 dark:bg-gray-900 dark:border-gray-800">
                {pasture.image_url && (
                  <div className="h-48 w-full overflow-hidden rounded-t-lg">
                    <img 
                      src={pasture.image_url} 
                      alt={pasture.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="h-2 bg-gradient-to-r from-orange-500 to-orange-600" />
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl mb-1 dark:text-gray-100">{pasture.name}</CardTitle>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{pasture.size_acres} acres</p>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleViewDetails(pasture)}
                        className="dark:hover:bg-gray-800"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleEdit(pasture)}
                        className="dark:hover:bg-gray-800"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2 flex-wrap">
                    <Badge className={`${typeColors[pasture.type]} border text-xs`}>
                      {pasture.type}
                    </Badge>
                    <Badge className={`${conditionColors[pasture.condition]} border text-xs`}>
                      {pasture.condition}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                   <div>
                     <p className="text-gray-500 dark:text-gray-400">Capacity</p>
                     <p className="font-bold dark:text-gray-100">{pasture.capacity}</p>
                   </div>
                   <div>
                     <p className="text-gray-500 dark:text-gray-400">Current Animals</p>
                     <p className="font-bold text-[#F5A623]">{pasture.current_animal_count}</p>
                   </div>
                   {pasture.fence_coordinates && pasture.fence_coordinates.length > 2 && (
                     <div className="col-span-2">
                       <p className="text-gray-500 dark:text-gray-400">Fenced Area</p>
                       <p className="font-bold text-blue-600 dark:text-blue-400">
                         {calculateFenceArea(pasture.fence_coordinates).toLocaleString()} sqft
                       </p>
                     </div>
                   )}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Grazing Quality</span>
                      <Badge className={`${qualityColors[pasture.grazing_quality]} border text-xs`}>
                        {pasture.grazing_quality}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Fence Condition</span>
                      <Badge className={`${fenceColors[pasture.fence_condition]} border text-xs`}>
                        {pasture.fence_condition}
                      </Badge>
                    </div>
                  </div>

                  {formatFullAddress(pasture) && (
                    <div className="pt-4 border-t dark:border-gray-800">
                      <div className="flex items-start gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-[#F5A623] mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-400">{formatFullAddress(pasture)}</span>
                      </div>
                      {pasture.lat && pasture.lon ? (
                        <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 ml-6">
                          {pasture.lat.toFixed(6)}, {pasture.lon.toFixed(6)}
                        </p>
                      ) : (
                        <p className="text-xs text-orange-500 dark:text-orange-400 mt-1 ml-6 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          Location not set - place on map
                        </p>
                      )}
                      </div>
                      )}

                      <div className="flex gap-2 mt-4">
                      {pasture.fence_color && (
                      <div 
                        className="w-8 h-8 rounded border-2 border-gray-300 flex-shrink-0" 
                        style={{backgroundColor: pasture.fence_color}}
                        title="Fence color"
                      />
                      )}
                      <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => handleViewDetails(pasture)}
                      >
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                      </Button>
                      </div>
                      </CardContent>
                      </Card>
                      ))}
                      </div>
                      )}

        {filteredPastures.length === 0 && viewMode === 'grid' && (
          <Card className="border-none shadow-lg dark:bg-gray-900 dark:border-gray-800">
            <CardContent className="p-12 text-center">
              <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Pastures Yet</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Add pastures to start managing your grazing areas</p>
              <Button onClick={() => setShowAddDialog(true)} className="bg-[#F5A623] hover:bg-[#E09612]">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Pasture
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Pasture Details Dialog */}
        <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800 z-[9999]">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Pasture Details</DialogTitle>
            </DialogHeader>
            {selectedPasture && (
              <div className="space-y-4">
                {selectedPasture.image_url && (
                  <div className="h-64 w-full overflow-hidden rounded-lg">
                    <img 
                      src={selectedPasture.image_url} 
                      alt={selectedPasture.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div>
                  <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">{selectedPasture.name}</h3>
                  <div className="flex gap-2 flex-wrap mb-4">
                    <Badge className={`${typeColors[selectedPasture.type]} border`}>
                      {selectedPasture.type}
                    </Badge>
                    <Badge className={`${conditionColors[selectedPasture.condition]} border`}>
                      {selectedPasture.condition}
                    </Badge>
                    <Badge className={`${qualityColors[selectedPasture.grazing_quality]} border`}>
                      Grazing: {selectedPasture.grazing_quality}
                    </Badge>
                    <Badge className={`${fenceColors[selectedPasture.fence_condition]} border`}>
                      Fence: {selectedPasture.fence_condition}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Size</p>
                    <p className="text-xl font-bold dark:text-gray-100">{selectedPasture.size_acres} acres</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Capacity</p>
                    <p className="text-xl font-bold dark:text-gray-100">{selectedPasture.capacity} animals</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Current Animals</p>
                    <p className="text-xl font-bold text-[#F5A623]">{selectedPasture.current_animal_count}</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Utilization</p>
                    <p className="text-xl font-bold dark:text-gray-100">
                      {selectedPasture.capacity > 0 
                        ? `${((selectedPasture.current_animal_count / selectedPasture.capacity) * 100).toFixed(0)}%`
                        : 'N/A'}
                    </p>
                  </div>
                </div>

                {formatFullAddress(selectedPasture) && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <MapPin className="w-4 h-4 text-[#F5A623]" />
                      <p className="text-sm font-semibold dark:text-gray-200">Address</p>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">{formatFullAddress(selectedPasture)}</p>
                    {selectedPasture.lat && selectedPasture.lon && (
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        GPS: {selectedPasture.lat.toFixed(6)}, {selectedPasture.lon.toFixed(6)}
                      </p>
                    )}
                  </div>
                )}

                {selectedPasture.water_source && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Droplets className="w-4 h-4 text-blue-500" />
                      <p className="text-sm font-semibold dark:text-gray-200">Water Source</p>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">{selectedPasture.water_source}</p>
                  </div>
                )}

                {(selectedPasture.last_rotation_date || selectedPasture.next_rotation_date) && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Rotation Schedule</p>
                    <div className="space-y-1 text-sm">
                      {selectedPasture.last_rotation_date && (
                        <p className="dark:text-gray-300">
                          Last: {new Date(selectedPasture.last_rotation_date).toLocaleDateString()}
                        </p>
                      )}
                      {selectedPasture.next_rotation_date && (
                        <p className="dark:text-gray-300">
                          Next: {new Date(selectedPasture.next_rotation_date).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {selectedPasture.notes && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Notes</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedPasture.notes}</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowDetailsDialog(false);
                      handleEdit(selectedPasture);
                    }}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      if (confirm('Are you sure you want to delete this pasture?')) {
                        deletePastureMutation.mutate(selectedPasture.id);
                      }
                    }}
                    className="flex-1"
                  >
                    Delete Pasture
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}