import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, Bell, Users, CreditCard, Database, Wallet, Shield, DollarSign } from "lucide-react";
import RanchOverviewSettings from "@/components/ranch/RanchOverviewSettings";
import RanchNotificationsSettings from "@/components/ranch/RanchNotificationsSettings";
import RanchTeamSettings from "@/components/ranch/RanchTeamSettings";
import RanchBillingSettings from "@/components/ranch/RanchBillingSettings";
import RanchBankingSettings from "@/components/ranch/RanchBankingSettings";
import RanchDataSettings from "@/components/ranch/RanchDataSettings";
import RanchPermissionsSettings from "@/components/ranch/RanchPermissionsSettings";
import RanchMarketSettings from "@/components/ranch/RanchMarketSettings";

export default function RanchSettings() {
  const urlParams = new URLSearchParams(window.location.search);
  const [activeTab, setActiveTab] = useState(urlParams.get('tab') || "overview");

  useEffect(() => {
    const tab = urlParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, []);

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: () => user?.active_ranch_id ? base44.entities.Ranch.filter({ id: user.active_ranch_id }).then((r) => r[0]) : null,
    enabled: !!user?.active_ranch_id
  });

  if (!ranch) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-gray-500">Loading ranch settings...</p>
      </div>);

  }

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-emerald-50/30 dark:from-gray-900 dark:to-emerald-950/30 min-h-screen">
      <div className="max-w-6xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Building2 className="w-8 h-8 text-[#F5A623]" />
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100">Ranch Settings</h1>
          </div>
          <p className="text-gray-600 dark:text-gray-400">Manage {ranch.name} configuration and preferences</p>
        </div>

        {/* Settings Tabs */}
        <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 dark:bg-gray-900">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  <span className="hidden sm:inline">Notifications</span>
                </TabsTrigger>
                <TabsTrigger value="team" className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span className="hidden sm:inline">Team</span>
                </TabsTrigger>
                <TabsTrigger value="billing" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  <span className="hidden sm:inline">Billing</span>
                </TabsTrigger>
                <TabsTrigger value="banking" className="flex items-center gap-2">
                  <Wallet className="w-4 h-4" />
                  <span className="hidden sm:inline">Banking</span>
                </TabsTrigger>
                <TabsTrigger value="market" className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4" />
                  <span className="hidden sm:inline">Market</span>
                </TabsTrigger>
                <TabsTrigger value="permissions" className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  <span className="hidden sm:inline">Permissions</span>
                </TabsTrigger>
                <TabsTrigger value="data" className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  <span className="hidden sm:inline">Data</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <RanchOverviewSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="notifications" className="space-y-4">
                <RanchNotificationsSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="team" className="space-y-4">
                <RanchTeamSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="billing" className="space-y-4">
                <RanchBillingSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="banking" className="space-y-4">
                <RanchBankingSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="market" className="space-y-4">
                <RanchMarketSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="permissions" className="space-y-4">
                <RanchPermissionsSettings ranch={ranch} />
              </TabsContent>

              <TabsContent value="data" className="space-y-4">
                <RanchDataSettings ranch={ranch} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>);

}