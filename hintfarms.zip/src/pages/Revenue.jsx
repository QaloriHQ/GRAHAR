import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  DollarSign,
  TrendingUp,
  Eye,
  Edit,
  Upload,
  Loader2,
  X,
  Calendar,
  Tag,
  FileText,
  MoreVertical,
  Trash2,
  Search,
  Filter,
  Receipt,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import StatsCard from "../components/dashboard/StatsCard";
import { trackRevenueAdd } from "@/components/utils";

export default function Revenue() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedRevenue, setSelectedRevenue] = useState(null);
  const [editingRevenue, setEditingRevenue] = useState(null);
  const [filterCategory, setFilterCategory] = useState("all");
  const [uploadingReceipt, setUploadingReceipt] = useState(false);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: revenues = [] } = useQuery({
    queryKey: ['revenues', user?.active_ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.active_ranch_id }, '-date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newRevenue, setNewRevenue] = useState({
    date: new Date().toISOString().split('T')[0],
    category: "Cattle Sale",
    description: "",
    amount: 0,
    animal_id: "",
    animal_name: "",
    pasture_id: "",
    pasture_name: "",
    buyer: "",
    payment_method: "Cash",
    receipt_url: "",
    notes: ""
  });

  const createRevenueMutation = useMutation({
    mutationFn: (data) => base44.entities.Revenue.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['revenues'] });
      setShowAddDialog(false);
      resetForm();
      trackRevenueAdd(); // Call analytics tracking function
    },
  });

  const updateRevenueMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Revenue.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['revenues'] });
      setShowAddDialog(false);
      setEditingRevenue(null);
      resetForm();
    },
  });

  const deleteRevenueMutation = useMutation({
    mutationFn: (id) => base44.entities.Revenue.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['revenues'] });
      setShowDetailsDialog(false);
      setSelectedRevenue(null);
    },
  });

  const resetForm = () => {
    setNewRevenue({
      date: new Date().toISOString().split('T')[0],
      category: "Cattle Sale",
      description: "",
      amount: 0,
      animal_id: "",
      animal_name: "",
      pasture_id: "",
      pasture_name: "",
      buyer: "",
      payment_method: "Cash",
      receipt_url: "",
      notes: ""
    });
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingReceipt(true);
    try {
      const response = await base44.integrations.Core.UploadFile({ file });
      
      if (response.file_url) {
        setNewRevenue({ ...newRevenue, receipt_url: response.file_url });
      }
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload receipt. Please try again.');
    } finally {
      setUploadingReceipt(false);
    }
  };

  const handleEdit = (revenue) => {
    setEditingRevenue(revenue);
    setNewRevenue(revenue);
    setShowAddDialog(true);
  };

  const handleSave = () => {
    if (editingRevenue) {
      updateRevenueMutation.mutate({ id: editingRevenue.id, data: newRevenue });
    } else {
      createRevenueMutation.mutate(newRevenue);
    }
  };

  const handleViewDetails = (revenue) => {
    setSelectedRevenue(revenue);
    setShowDetailsDialog(true);
  };

  const filteredRevenues = filterCategory === "all" 
    ? revenues 
    : revenues.filter(r => r.category === filterCategory);

  const totalRevenue = revenues.reduce((sum, rev) => sum + (rev.amount || 0), 0);
  const thisMonthRevenue = revenues.filter(r => {
    const revDate = new Date(r.date);
    const now = new Date();
    return revDate.getMonth() === now.getMonth() && revDate.getFullYear() === now.getFullYear();
  }).reduce((sum, rev) => sum + (rev.amount || 0), 0);

  const categoryColors = {
    "Cattle Sale": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Calf Sale": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Milk": "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900/30 dark:text-purple-300",
    "Breeding Services": "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-900/30 dark:text-pink-300",
    "Other": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300"
  };

  // Check for URL parameter to auto-open detail dialog
  React.useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const revenueId = urlParams.get('id');
    
    if (revenueId && revenues.length > 0) {
      const revenue = revenues.find(r => r.id === revenueId);
      if (revenue) {
        handleViewDetails(revenue);
        // Clean up URL to prevent dialog from reopening on subsequent visits
        window.history.replaceState({}, '', createPageUrl('Revenue'));
      }
    }
  }, [revenues, navigate]); // Added navigate to dependency array for completeness

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header with Back Button */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              onClick={() => navigate(createPageUrl("Financials"))}
              className="dark:bg-gray-800 dark:border-gray-700"
            >
              ← Back to Financials
            </Button>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Revenue Management</h1>
              <p className="text-gray-600 dark:text-gray-400">Track and manage your ranch income</p>
            </div>
          </div>
          <Dialog open={showAddDialog} onOpenChange={(open) => {
            setShowAddDialog(open);
            if (!open) {
              setEditingRevenue(null);
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                <Plus className="w-4 h-4 mr-2" />
                Add Revenue
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
              <DialogHeader>
                <DialogTitle className="dark:text-gray-100">
                  {editingRevenue ? 'Edit Revenue' : 'Add New Revenue'}
                </DialogTitle>
                <DialogDescription className="dark:text-gray-400">
                  Fill in the details for your revenue record.
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Date *</Label>
                  <Input
                    type="date"
                    value={newRevenue.date}
                    onChange={(e) => setNewRevenue({...newRevenue, date: e.target.value})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Category *</Label>
                  <Select value={newRevenue.category} onValueChange={(value) => setNewRevenue({...newRevenue, category: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Cattle Sale">Cattle Sale</SelectItem>
                      <SelectItem value="Calf Sale">Calf Sale</SelectItem>
                      <SelectItem value="Milk">Milk</SelectItem>
                      <SelectItem value="Breeding Services">Breeding Services</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Description *</Label>
                  <Input
                    value={newRevenue.description}
                    onChange={(e) => setNewRevenue({...newRevenue, description: e.target.value})}
                    placeholder="Brief description of the revenue"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Amount ($) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={newRevenue.amount}
                    onChange={(e) => setNewRevenue({...newRevenue, amount: parseFloat(e.target.value) || 0})}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Payment Method</Label>
                  <Select value={newRevenue.payment_method} onValueChange={(value) => setNewRevenue({...newRevenue, payment_method: value})}>
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="Cash">Cash</SelectItem>
                      <SelectItem value="Check">Check</SelectItem>
                      <SelectItem value="Credit Card">Credit Card</SelectItem>
                      <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Buyer/Customer</Label>
                  <Input
                    value={newRevenue.buyer}
                    onChange={(e) => setNewRevenue({...newRevenue, buyer: e.target.value})}
                    placeholder="Who paid you?"
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Related Animal (Optional)</Label>
                  <Select 
                    value={newRevenue.animal_id || "none"} 
                    onValueChange={(value) => {
                      if (value === "none") {
                        setNewRevenue({...newRevenue, animal_id: "", animal_name: ""});
                      } else {
                        const animal = animals.find(a => a.id === value);
                        setNewRevenue({...newRevenue, animal_id: value, animal_name: animal?.name || ""});
                      }
                    }}
                  >
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue placeholder="Select animal" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="none">None</SelectItem>
                      {animals.map(animal => (
                        <SelectItem key={animal.id} value={animal.id}>
                          {animal.name} ({animal.tag_number})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="dark:text-gray-200">Related Pasture (Optional)</Label>
                  <Select 
                    value={newRevenue.pasture_id || "none"} 
                    onValueChange={(value) => {
                      if (value === "none") {
                        setNewRevenue({...newRevenue, pasture_id: "", pasture_name: ""});
                      } else {
                        const pasture = pastures.find(p => p.id === value);
                        setNewRevenue({...newRevenue, pasture_id: value, pasture_name: pasture?.name || ""});
                      }
                    }}
                  >
                    <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                      <SelectValue placeholder="Select pasture" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                      <SelectItem value="none">None</SelectItem>
                      {pastures.map(pasture => (
                        <SelectItem key={pasture.id} value={pasture.id}>
                          {pasture.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Upload Receipt/Invoice (Optional)</Label>
                  <div className="flex items-center gap-3">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      disabled={uploadingReceipt}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                    {uploadingReceipt && <Loader2 className="w-5 h-5 animate-spin text-[#F5A623]" />}
                  </div>
                  {newRevenue.receipt_url && (
                    <div className="relative inline-block mt-2">
                      <img 
                        src={newRevenue.receipt_url} 
                        alt="Receipt" 
                        className="h-24 w-24 object-cover rounded-lg border-2 border-[#F5A623]"
                      />
                      <button
                        type="button"
                        onClick={() => setNewRevenue({...newRevenue, receipt_url: ""})}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="space-y-2 col-span-2">
                  <Label className="dark:text-gray-200">Notes</Label>
                  <Textarea
                    value={newRevenue.notes}
                    onChange={(e) => setNewRevenue({...newRevenue, notes: e.target.value})}
                    placeholder="Additional information..."
                    rows={3}
                    className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                  />
                </div>
              </div>
              <DialogFooter className="flex-row sm:justify-end gap-3">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowAddDialog(false);
                    setEditingRevenue(null);
                    resetForm();
                  }}
                  className="flex-1 sm:flex-none"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleSave}
                  className="flex-1 sm:flex-none bg-[#F5A623] hover:bg-[#E09612]"
                  disabled={!newRevenue.date || !newRevenue.category || !newRevenue.description || !newRevenue.amount}
                >
                  {editingRevenue ? 'Update Revenue' : 'Add Revenue'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatsCard
            title="Total Revenue"
            value={`$${totalRevenue.toLocaleString()}`}
            icon={DollarSign}
            bgColor="bg-green-500"
            textColor="text-green-600"
          />
          <StatsCard
            title="This Month"
            value={`$${thisMonthRevenue.toLocaleString()}`}
            icon={Calendar}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Total Records"
            value={revenues.length}
            icon={TrendingUp}
            bgColor="bg-purple-500"
            textColor="text-purple-600"
          />
        </div>

        {/* Filter */}
        <Card className="mb-6 border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-64 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="Cattle Sale">Cattle Sale</SelectItem>
                  <SelectItem value="Calf Sale">Calf Sale</SelectItem>
                  <SelectItem value="Milk">Milk</SelectItem>
                  <SelectItem value="Breeding Services">Breeding Services</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRevenues.map(revenue => (
            <Card key={revenue.id} className="border-none shadow-lg hover:shadow-xl transition-all duration-300 dark:bg-gray-900 dark:border-gray-800">
              <div className="h-2 bg-gradient-to-r from-green-500 to-orange-600" />
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg mb-1 dark:text-gray-100">{revenue.description}</CardTitle>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{format(new Date(revenue.date), "MMM d, yyyy")}</p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Open menu</span>
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="dark:bg-gray-900 dark:border-gray-700">
                      <DropdownMenuItem onClick={() => handleViewDetails(revenue)} className="dark:hover:bg-gray-800 dark:focus:bg-gray-800 cursor-pointer">
                        <Eye className="mr-2 h-4 w-4" /> View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEdit(revenue)} className="dark:hover:bg-gray-800 dark:focus:bg-gray-800 cursor-pointer">
                        <Edit className="mr-2 h-4 w-4" /> Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => {
                        if (confirm('Are you sure you want to delete this revenue record?')) {
                          deleteRevenueMutation.mutate(revenue.id);
                        }
                      }} className="text-red-600 dark:text-red-500 dark:hover:bg-red-900/20 dark:focus:bg-red-900/20 cursor-pointer">
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <Badge className={`${categoryColors[revenue.category]} border text-xs`}>
                    {revenue.category}
                  </Badge>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">${revenue.amount.toLocaleString()}</p>
                </div>
                {revenue.receipt_url && (
                  <div className="pt-3 border-t dark:border-gray-800">
                    <img 
                      src={revenue.receipt_url} 
                      alt="Receipt" 
                      className="h-20 w-full object-cover rounded-lg cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => handleViewDetails(revenue)}
                    />
                  </div>
                )}
                {(revenue.animal_name || revenue.pasture_name) && (
                  <div className="pt-3 border-t dark:border-gray-800 text-xs space-y-1">
                    {revenue.animal_name && (
                      <p className="text-blue-600 dark:text-blue-400">🐄 {revenue.animal_name}</p>
                    )}
                    {revenue.pasture_name && (
                      <p className="text-green-600 dark:text-green-400">🌾 Pasture: {revenue.pasture_name}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredRevenues.length === 0 && (
          <Card className="border-none shadow-lg dark:bg-gray-900 dark:border-gray-800">
            <CardContent className="p-12 text-center">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-700" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Revenue Yet</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Start tracking your ranch income</p>
              <Button onClick={() => setShowAddDialog(true)} className="bg-[#F5A623] hover:bg-[#E09612]">
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Revenue
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Revenue Details Dialog */}
        <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Revenue Details</DialogTitle>
            </DialogHeader>
            {selectedRevenue && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">{selectedRevenue.description}</h3>
                  <div className="flex items-center gap-3 flex-wrap">
                    <Badge className={`${categoryColors[selectedRevenue.category]} border`}>
                      {selectedRevenue.category}
                    </Badge>
                    <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                      ${selectedRevenue.amount.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Date</p>
                    <p className="font-semibold dark:text-gray-100">{format(new Date(selectedRevenue.date), "MMMM d, yyyy")}</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Payment Method</p>
                    <p className="font-semibold dark:text-gray-100">{selectedRevenue.payment_method}</p>
                  </div>
                </div>

                {selectedRevenue.buyer && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Buyer/Customer</p>
                    <p className="font-semibold dark:text-gray-100">{selectedRevenue.buyer}</p>
                  </div>
                )}

                {(selectedRevenue.animal_name || selectedRevenue.pasture_name) && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg space-y-2">
                    <p className="text-sm font-semibold dark:text-gray-200">Related To</p>
                    {selectedRevenue.animal_name && (
                      <p className="text-blue-600 dark:text-blue-400">🐄 Animal: {selectedRevenue.animal_name}</p>
                    )}
                    {selectedRevenue.pasture_name && (
                      <p className="text-green-600 dark:text-green-400">🌾 Pasture: {selectedRevenue.pasture_name}</p>
                    )}
                  </div>
                )}

                {selectedRevenue.receipt_url && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Receipt/Invoice</p>
                    <a href={selectedRevenue.receipt_url} target="_blank" rel="noopener noreferrer">
                      <img 
                        src={selectedRevenue.receipt_url} 
                        alt="Receipt" 
                        className="w-full max-h-96 object-contain rounded-lg border-2 border-[#F5A623] cursor-pointer hover:opacity-80 transition-opacity"
                      />
                    </a>
                  </div>
                )}

                {selectedRevenue.notes && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Notes</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedRevenue.notes}</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowDetailsDialog(false);
                      handleEdit(selectedRevenue);
                    }}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      if (confirm('Are you sure you want to delete this revenue record?')) {
                        deleteRevenueMutation.mutate(selectedRevenue.id);
                      }
                    }}
                    className="flex-1"
                  >
                    Delete Revenue
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}