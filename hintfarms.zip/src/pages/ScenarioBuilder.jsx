
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  Save,
  Target,
  Calendar,
  BarChart3,
  DollarSign,
  TrendingUp,
  Settings
} from "lucide-react";
import ScenarioTimeframe from "@/components/scenarios/ScenarioTimeframe";
import ScenarioWidgets from "@/components/scenarios/ScenarioWidgets";
import ScenarioVariables from "@/components/scenarios/ScenarioVariables";
import ScenarioComparison from "@/components/scenarios/ScenarioComparison";

export default function ScenarioBuilder() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("timeframe");

  const scenarioId = new URLSearchParams(location.search).get('id');

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: scenario, isLoading } = useQuery({
    queryKey: ['scenario', scenarioId],
    queryFn: () => base44.entities.Scenario.filter({ id: scenarioId }).then(s => s[0]),
    enabled: !!scenarioId,
  });

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    timeframe_start: "",
    timeframe_end: "",
    aggregation: "monthly",
    widgets: [],
    price_overrides: [],
    cost_overrides: [],
    predator_loss_rate: 0.02,
    mortality_rate: 0.01,
    shrink_rate: 0.02,
    discount_rate: 0.08,
    interest_rate: 0.095,
    tax_rate: 0.22,
    allocation_rule: "by_GUM"
  });

  useEffect(() => {
    if (scenario) {
      setFormData({
        name: scenario.name || "",
        description: scenario.description || "",
        timeframe_start: scenario.timeframe_start || "",
        timeframe_end: scenario.timeframe_end || "",
        aggregation: scenario.aggregation || "monthly",
        widgets: scenario.widgets || [],
        price_overrides: scenario.price_overrides || [],
        cost_overrides: scenario.cost_overrides || [],
        predator_loss_rate: scenario.predator_loss_rate || 0.02,
        mortality_rate: scenario.mortality_rate || 0.01,
        shrink_rate: scenario.shrink_rate || 0.02,
        discount_rate: scenario.discount_rate || 0.08,
        interest_rate: scenario.interest_rate || 0.095,
        tax_rate: scenario.tax_rate || 0.22,
        allocation_rule: scenario.allocation_rule || "by_GUM"
      });
    }
  }, [scenario]);

  const createScenarioMutation = useMutation({
    mutationFn: (scenarioData) => base44.entities.Scenario.create({
      ...scenarioData,
      ranch_id: user?.active_ranch_id,
    }),
    onSuccess: (newScenario) => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
      queryClient.invalidateQueries({ queryKey: ['scenario', newScenario.id] }); // Invalidate the newly created scenario
      navigate(createPageUrl("ScenarioBuilder") + `?id=${newScenario.id}`); // Navigate to the new scenario for editing
      const event = new CustomEvent('showToast', {
        detail: { message: 'Scenario created!', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Error creating scenario: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const updateScenarioMutation = useMutation({
    mutationFn: (data) => base44.entities.Scenario.update(scenarioId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenario', scenarioId] });
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Error saving scenario: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const setAsGoalMutation = useMutation({
    mutationFn: async () => {
      const allScenarios = await base44.entities.Scenario.filter({ ranch_id: user?.active_ranch_id }); // Changed to active_ranch_id
      const updates = allScenarios.map(s =>
        base44.entities.Scenario.update(s.id, { is_ranch_goal: s.id === scenarioId })
      );
      await Promise.all(updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] }); // More specific invalidation
      queryClient.invalidateQueries({ queryKey: ['scenario', scenarioId] }); // Invalidate current scenario as well
      const event = new CustomEvent('showToast', {
        detail: { message: 'Set as Ranch Goal!', type: 'success' }
      });
      window.dispatchEvent(event);
    },
    onError: (error) => {
      const event = new CustomEvent('showToast', {
        detail: { message: `Error setting as goal: ${error.message}`, type: 'error' }
      });
      window.dispatchEvent(event);
    }
  });

  const handleSave = () => {
    if (scenarioId) {
      // Existing scenario: update
      updateScenarioMutation.mutate(formData);
      const event = new CustomEvent('showToast', {
        detail: { message: 'Scenario saved!', type: 'success' }
      });
      window.dispatchEvent(event);
    } else {
      // New scenario: create
      createScenarioMutation.mutate(formData);
    }
  };

  const handlePreview = () => {
    if (scenarioId) {
      // Save existing scenario first, then preview
      updateScenarioMutation.mutate(formData, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['scenario', scenarioId] }); // Ensure latest data for preview
          queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] }); // Ensure latest data for preview
          navigate(createPageUrl("ScenarioPreview") + `?id=${scenarioId}`);
        }
      });
    } else {
      // Create new scenario first, then preview
      createScenarioMutation.mutate(formData, {
        onSuccess: (newScenario) => {
          queryClient.invalidateQueries({ queryKey: ['scenario', newScenario.id] });
          queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
          navigate(createPageUrl("ScenarioPreview") + `?id=${newScenario.id}`);
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading scenario...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Scenarios"))}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3">
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="text-2xl font-bold border-none shadow-none focus-visible:ring-0 px-0"
                  placeholder="Scenario name..."
                />
                {scenario?.is_ranch_goal && (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <Target className="w-3 h-3 mr-1" />
                    Ranch Goal
                  </Badge>
                )}
              </div>
              <Input
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="text-sm text-gray-600 border-none shadow-none focus-visible:ring-0 px-0"
                placeholder="Add description..."
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handlePreview}
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Preview
            </Button>
            {scenarioId && !scenario?.is_ranch_goal && ( // Only show "Set as Goal" for existing, non-goal scenarios
              <Button
                variant="outline"
                onClick={() => setAsGoalMutation.mutate()}
              >
                <Target className="w-4 h-4 mr-2" />
                Set as Goal
              </Button>
            )}
            <Button
              onClick={handleSave}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Save className="w-4 h-4 mr-2" />
              Save Scenario
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="timeframe" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Timeframe
            </TabsTrigger>
            <TabsTrigger value="widgets" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Widgets
            </TabsTrigger>
            <TabsTrigger value="variables" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Variables
            </TabsTrigger>
            <TabsTrigger value="compare" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Compare
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timeframe">
            <ScenarioTimeframe formData={formData} setFormData={setFormData} />
          </TabsContent>

          <TabsContent value="widgets">
            <ScenarioWidgets formData={formData} setFormData={setFormData} />
          </TabsContent>

          <TabsContent value="variables">
            <ScenarioVariables formData={formData} setFormData={setFormData} />
          </TabsContent>

          <TabsContent value="compare">
            <ScenarioComparison scenario={scenario} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
