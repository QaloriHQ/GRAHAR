
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ArrowLeft,
  RefreshCw,
  Download,
  BarChart3,
  Calendar,
  Target,
  TrendingUp,
  DollarSign,
  Beef
} from "lucide-react";
import { format } from "date-fns";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function ScenarioPreview() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);

  const scenarioId = new URLSearchParams(location.search).get('id');

  // Helper function to safely format dates
  const safeFormatDate = (date, formatString = "MMM d, yyyy") => {
    try {
      if (!date) return "N/A";
      const d = new Date(date);
      if (isNaN(d.getTime())) return "Invalid Date";
      return format(d, formatString);
    } catch (error) {
      console.error('Error formatting date:', error, 'Original date:', date);
      return "Invalid Date";
    }
  };

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: scenario, isLoading } = useQuery({
    queryKey: ['scenario', scenarioId],
    queryFn: () => base44.entities.Scenario.filter({ id: scenarioId }).then(s => s[0]),
    enabled: !!scenarioId,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses', user?.ranch_id],
    queryFn: () => base44.entities.Expense.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  const { data: revenue = [] } = useQuery({
    queryKey: ['revenue', user?.ranch_id],
    queryFn: () => base44.entities.Revenue.filter({ ranch_id: user.ranch_id }),
    initialData: [],
    enabled: !!user?.ranch_id,
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['animals'] });
    await queryClient.invalidateQueries({ queryKey: ['expenses'] });
    await queryClient.invalidateQueries({ queryKey: ['revenue'] });
    await queryClient.invalidateQueries({ queryKey: ['scenario', scenarioId] });
    setRefreshing(false);

    const event = new CustomEvent('showToast', {
      detail: { message: 'Dashboard refreshed!', type: 'success' }
    });
    window.dispatchEvent(event);
  };

  const handleExport = () => {
    const event = new CustomEvent('showToast', {
      detail: { message: 'Export feature coming soon!', type: 'info' }
    });
    window.dispatchEvent(event);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading scenario preview...</p>
        </div>
      </div>
    );
  }

  if (!scenario) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">Scenario Not Found</h3>
          <Button onClick={() => navigate(createPageUrl("Scenarios"))}>
            Back to Scenarios
          </Button>
        </div>
      </div>
    );
  }

  // Calculate scenario metrics with risk adjustments
  const totalRevenue = revenue.reduce((sum, r) => sum + (r.amount || 0), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);

  const riskAdjustedRevenue = totalRevenue *
    (1 - (scenario.predator_loss_rate || 0)) *
    (1 - (scenario.mortality_rate || 0)) *
    (1 - (scenario.shrink_rate || 0));

  const netReturn = riskAdjustedRevenue - totalExpenses;
  const profitMargin = riskAdjustedRevenue > 0 ? (netReturn / riskAdjustedRevenue * 100).toFixed(1) : 0;

  // Prepare chart data
  const monthlyData = expenses.reduce((acc, exp) => {
    try {
      if (!exp.date) return acc;
      const date = new Date(exp.date);
      if (isNaN(date.getTime())) return acc;
      const month = format(date, "MMM yyyy");
      if (!acc[month]) {
        acc[month] = { month, expenses: 0, revenue: 0 };
      }
      acc[month].expenses += exp.amount || 0;
    } catch (error) {
      console.error('Error processing expense date:', error);
    }
    return acc;
  }, {});

  revenue.forEach(rev => {
    try {
      if (!rev.date) return;
      const date = new Date(rev.date);
      if (isNaN(date.getTime())) return;
      const month = format(date, "MMM yyyy");
      if (!monthlyData[month]) {
        monthlyData[month] = { month, expenses: 0, revenue: 0 };
      }
      monthlyData[month].revenue += rev.amount || 0;
    } catch (error) {
      console.error('Error processing revenue date:', error);
    }
  });

  const chartData = Object.values(monthlyData).slice(-12);

  const widgets = scenario.widgets || [];

  // Helper function to get widget data based on widget type
  const getWidgetData = (widget) => {
    switch (widget.widget_id) {
      case 'herd_size':
        return {
          columns: ['Type', 'Count', 'Avg Weight (lbs)', 'Total Value'],
          rows: Object.entries(
            animals.reduce((acc, animal) => {
              if (!acc[animal.type]) {
                acc[animal.type] = { count: 0, totalWeight: 0, totalValue: 0 };
              }
              acc[animal.type].count += 1;
              acc[animal.type].totalWeight += animal.weight || 0;
              acc[animal.type].totalValue += animal.current_value || 0;
              return acc;
            }, {})
          ).map(([type, data]) => [
            type,
            data.count,
            Math.round(data.totalWeight / data.count),
            `$${data.totalValue.toLocaleString()}`
          ])
        };

      case 'purchases':
        const purchases = expenses.filter(e => e.category === 'Feed' || e.description.toLowerCase().includes('purchase'));
        return {
          columns: ['Date', 'Description', 'Category', 'Amount'],
          rows: purchases.slice(0, 10).map(exp => [
            safeFormatDate(exp.date, 'MMM d, yyyy'),
            exp.description,
            exp.category,
            `$${(exp.amount || 0).toLocaleString()}`
          ])
        };

      case 'sales':
        return {
          columns: ['Date', 'Description', 'Category', 'Amount'],
          rows: revenue.slice(0, 10).map(rev => [
            safeFormatDate(rev.date, 'MMM d, yyyy'),
            rev.description,
            rev.category,
            `$${(rev.amount || 0).toLocaleString()}`
          ])
        };

      case 'gross_margins':
        return {
          columns: ['Category', 'Revenue', 'Expenses', 'Gross Margin', 'Margin %'],
          rows: Object.entries(
            revenue.reduce((acc, rev) => {
              if (!acc[rev.category]) {
                acc[rev.category] = { revenue: 0, expenses: 0 };
              }
              acc[rev.category].revenue += rev.amount || 0;
              return acc;
            }, {})
          ).map(([category, data]) => {
            const catExpenses = expenses.filter(e => e.category === category).reduce((sum, e) => sum + (e.amount || 0), 0);
            const margin = data.revenue - catExpenses;
            const marginPct = data.revenue > 0 ? ((margin / data.revenue) * 100).toFixed(1) : 0;
            return [
              category,
              `$${data.revenue.toLocaleString()}`,
              `$${catExpenses.toLocaleString()}`,
              `$${margin.toLocaleString()}`,
              `${marginPct}%`
            ];
          })
        };

      case 'enterprise_eff':
        const categories = [...new Set([...revenue.map(r => r.category), ...expenses.map(e => e.category)])];
        return {
          columns: ['Enterprise', 'Revenue', 'Costs', 'Net Return', 'Efficiency'],
          rows: categories.map(cat => {
            const catRevenue = revenue.filter(r => r.category === cat).reduce((sum, r) => sum + (r.amount || 0), 0);
            const catCosts = expenses.filter(e => e.category === cat).reduce((sum, e) => sum + (e.amount || 0), 0);
            const netReturn = catRevenue - catCosts;
            return [
              cat,
              `$${catRevenue.toLocaleString()}`,
              `$${catCosts.toLocaleString()}`,
              `$${netReturn.toLocaleString()}`,
              catRevenue > 0 ? `${((netReturn / catRevenue) * 100).toFixed(1)}%` : '0%'
            ];
          })
        };

      case 'cash_flow':
        const cashFlowData = Object.values(monthlyData).slice(-12).map(m => ({
          month: m.month,
          inflow: m.revenue,
          outflow: m.expenses,
          net: m.revenue - m.expenses
        }));
        return {
          columns: ['Month', 'Cash Inflow', 'Cash Outflow', 'Net Cash Flow'],
          rows: cashFlowData.map(d => [
            d.month,
            `$${d.inflow.toLocaleString()}`,
            `$${d.outflow.toLocaleString()}`,
            `$${d.net.toLocaleString()}`
          ])
        };

      case 'pnl':
        const totalRev = revenue.reduce((sum, r) => sum + (r.amount || 0), 0);
        const totalExp = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
        const netIncome = totalRev - totalExp;
        return {
          columns: ['Account', 'Amount'],
          rows: [
            ['Total Revenue', `$${totalRev.toLocaleString()}`],
            ['Operating Expenses', `$${totalExp.toLocaleString()}`],
            ['Gross Profit', `$${(totalRev - totalExp).toLocaleString()}`],
            ['Risk Adjustments', `$${(totalRev - riskAdjustedRevenue).toLocaleString()}`],
            ['Risk-Adjusted Revenue', `$${riskAdjustedRevenue.toLocaleString()}`],
            ['Net Income', `$${netIncome.toLocaleString()}`],
            ['Profit Margin', `${profitMargin}%`]
          ]
        };

      case 'breakeven':
        const avgAnimalValue = animals.length > 0 ? animals.reduce((sum, a) => sum + (a.current_value || 0), 0) / animals.length : 0;
        const costPerAnimal = animals.length > 0 ? totalExpenses / animals.length : 0;
        return {
          columns: ['Metric', 'Per Head', 'Per Lb', 'Per CWT'],
          rows: [
            ['Avg Animal Value', `$${avgAnimalValue.toFixed(2)}`, '-', '-'],
            ['Cost Per Animal', `$${costPerAnimal.toFixed(2)}`, '-', '-'],
            ['Breakeven Price', `$${avgAnimalValue.toFixed(2)}`, '-', '-'],
            ['Target Price (+20%)', `$${(avgAnimalValue * 1.2).toFixed(2)}`, '-', '-']
          ]
        };

      default:
        return {
          columns: ['Metric', 'Value'],
          rows: [['No data available', '-']]
        };
    }
  };

  // Render widget content based on visualization type
  const renderWidget = (widget) => {
    const widgetData = getWidgetData(widget);

    if (widget.visualization === 'table') {
      return (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {widgetData.columns.map((col, idx) => (
                  <TableHead key={idx} className="font-semibold">
                    {col}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {widgetData.rows.length > 0 ? (
                widgetData.rows.map((row, rowIdx) => (
                  <TableRow key={rowIdx}>
                    {row.map((cell, cellIdx) => (
                      <TableCell key={cellIdx}>{cell}</TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={widgetData.columns.length} className="text-center text-gray-500">
                    No data available
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      );
    } else if (widget.visualization === 'bar' || widget.visualization === 'column') {
      return (
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="revenue" fill="#10b981" name="Revenue" />
            <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
          </BarChart>
        </ResponsiveContainer>
      );
    } else if (widget.visualization === 'line') {
      return (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="revenue" stroke="#10b981" name="Revenue" />
            <Line type="monotone" dataKey="expenses" stroke="#ef4444" name="Expenses" />
          </LineChart>
        </ResponsiveContainer>
      );
    } else {
      return (
        <div className="text-center py-12 text-gray-500">
          <BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p>Widget visualization: {widget.visualization}</p>
          <p className="text-xs">Visualization type not yet supported</p>
        </div>
      );
    }
  };

  return (
    <div className="p-6 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(createPageUrl("Scenarios"))}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-2xl font-bold">{scenario.name}</h1>
                {scenario.is_ranch_goal && (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <Target className="w-3 h-3 mr-1" />
                    Ranch Goal
                  </Badge>
                )}
              </div>
              <p className="text-gray-600">
                {safeFormatDate(scenario.timeframe_start, "MMM d, yyyy")} - {safeFormatDate(scenario.timeframe_end, "MMM d, yyyy")}
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button
              variant="outline"
              onClick={handleExport}
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Scenario Parameters */}
        <Card className="mb-6 border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Scenario Parameters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-xs text-gray-500">Time Period</p>
                  <p className="font-semibold text-sm">
                    {safeFormatDate(scenario.timeframe_start, "MMM yyyy")} - {safeFormatDate(scenario.timeframe_end, "MMM yyyy")}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-500">Predator Loss</p>
                <Badge variant="outline" className="mt-1">
                  {(scenario.predator_loss_rate * 100).toFixed(1)}%
                </Badge>
              </div>
              <div>
                <p className="text-xs text-gray-500">Mortality Rate</p>
                <Badge variant="outline" className="mt-1">
                  {(scenario.mortality_rate * 100).toFixed(1)}%
                </Badge>
              </div>
              <div>
                <p className="text-xs text-gray-500">Shrink Rate</p>
                <Badge variant="outline" className="mt-1">
                  {(scenario.shrink_rate * 100).toFixed(1)}%
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Beef className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total Animals</p>
                  <p className="text-2xl font-bold">{animals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Risk-Adjusted Revenue</p>
                  <p className="text-2xl font-bold">${riskAdjustedRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Net Return</p>
                  <p className="text-2xl font-bold text-emerald-600">${netReturn.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Profit Margin</p>
                  <p className="text-2xl font-bold">{profitMargin}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Widgets Dashboard */}
        {widgets.length > 0 ? (
          <div className="grid lg:grid-cols-2 gap-6">
            {widgets.map((widget, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">
                    {widget.widget_id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </CardTitle>
                  <CardDescription>
                    Visualization: {widget.visualization}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {renderWidget(widget)}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center">
              <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No Widgets Configured</h3>
              <p className="text-gray-600 mb-6">
                Add widgets to this scenario to see visualizations and analytics
              </p>
              <Button
                onClick={() => navigate(createPageUrl("ScenarioBuilder") + `?id=${scenarioId}`)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Configure Widgets
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
