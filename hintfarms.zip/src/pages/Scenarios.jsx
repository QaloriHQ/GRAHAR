import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Target, 
  Copy, 
  Edit, 
  Trash2, 
  TrendingUp,
  BarChart3,
  DollarSign,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/components/utils";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";

export default function Scenarios() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: ranch } = useQuery({
    queryKey: ['currentRanch', user?.active_ranch_id],
    queryFn: () => user?.active_ranch_id ? base44.entities.Ranch.filter({ id: user.active_ranch_id }).then(r => r[0]) : null,
    enabled: !!user?.active_ranch_id,
  });

  const { data: scenarios = [] } = useQuery({
    queryKey: ['scenarios', user?.active_ranch_id],
    queryFn: () => base44.entities.Scenario.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const createScenarioMutation = useMutation({
    mutationFn: async () => {
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 12);
      startDate.setHours(0, 0, 0, 0);
      
      const endDate = new Date();
      endDate.setHours(23, 59, 59, 999);

      // Capture baseline snapshot
      const animals = await base44.entities.Animal.filter({ ranch_id: user.active_ranch_id });
      const expenses = await base44.entities.Expense.filter({ ranch_id: user.active_ranch_id });
      const revenue = await base44.entities.Revenue.filter({ ranch_id: user.active_ranch_id });

      return base44.entities.Scenario.create({
        ranch_id: user.active_ranch_id,
        name: `New Scenario ${scenarios.length + 1}`,
        description: "Edit to customize this scenario",
        is_ranch_goal: scenarios.length === 0,
        timeframe_start: startDate.toISOString().split('T')[0],
        timeframe_end: endDate.toISOString().split('T')[0],
        aggregation: "monthly",
        widgets: [
          { widget_id: "enterprise_eff", visualization: "bar", group_by: ["enterprise"], columns: [] },
          { widget_id: "gross_margins", visualization: "bar", group_by: ["enterprise"], columns: [] }
        ],
        baseline_source: "frozen",
        baseline_snapshot_date: new Date().toISOString(),
        baseline_data: {
          animals: animals.length,
          total_expenses: expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
          total_revenue: revenue.reduce((sum, r) => sum + (r.amount || 0), 0)
        },
        visibility: "team"
      });
    },
    onSuccess: (newScenario) => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
      navigate(createPageUrl("ScenarioBuilder") + `?id=${newScenario.id}`);
    },
  });

  const duplicateScenarioMutation = useMutation({
    mutationFn: async (scenarioId) => {
      const original = scenarios.find(s => s.id === scenarioId);
      const copy = { ...original };
      delete copy.id;
      delete copy.created_date;
      delete copy.updated_date;
      copy.name = `${original.name} (Copy)`;
      copy.is_ranch_goal = false;
      return base44.entities.Scenario.create(copy);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
    },
  });

  const setGoalMutation = useMutation({
    mutationFn: async (scenarioId) => {
      const currentGoals = scenarios.filter(s => s.is_ranch_goal);
      await Promise.all(
        currentGoals.map(s => base44.entities.Scenario.update(s.id, { is_ranch_goal: false }))
      );
      await base44.entities.Scenario.update(scenarioId, { is_ranch_goal: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
    },
  });

  const deleteScenarioMutation = useMutation({
    mutationFn: (scenarioId) => base44.entities.Scenario.delete(scenarioId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scenarios', user?.active_ranch_id] });
    },
  });

  const handlePreview = (scenarioId) => {
    navigate(createPageUrl("ScenarioPreview") + `?id=${scenarioId}`);
  };

  // Helper function to safely format dates
  const safeFormatDate = (date, formatString = "MMM yyyy") => {
    try {
      if (!date) return "N/A";
      const d = new Date(date);
      if (isNaN(d.getTime())) return "Invalid Date";
      return format(d, formatString);
    } catch (error) {
      return "Invalid Date";
    }
  };

  const goalScenario = scenarios.find(s => s.is_ranch_goal);
  const otherScenarios = scenarios.filter(s => !s.is_ranch_goal);

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-1">Planning Scenarios</h1>
            <p className="text-gray-600">Model different strategies and compare outcomes</p>
          </div>
          <Button 
            onClick={() => createScenarioMutation.mutate()}
            className="bg-blue-600 hover:bg-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Scenario
          </Button>
        </div>

        {/* Info Alert */}
        <Alert className="mb-6 border-blue-200 bg-blue-50">
          <BarChart3 className="h-4 h-4 text-blue-600" />
          <AlertTitle className="text-blue-900">What are Planning Scenarios?</AlertTitle>
          <AlertDescription className="text-blue-800">
            Create "what-if" models to test different pricing, costs, risk factors, and management strategies. 
            Compare scenarios against your current ranch data to make informed decisions.
          </AlertDescription>
        </Alert>

        {/* Goal Scenario */}
        {goalScenario && (
          <Card className="mb-6 border-2 border-green-500 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="w-5 h-5 text-green-600" />
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      Ranch Goal
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl">{goalScenario.name}</CardTitle>
                  <CardDescription>{goalScenario.description}</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handlePreview(goalScenario.id)}
                    title="Preview Dashboard"
                  >
                    <BarChart3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => navigate(createPageUrl("ScenarioBuilder") + `?id=${goalScenario.id}`)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => duplicateScenarioMutation.mutate(goalScenario.id)}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Time Period</p>
                  <p className="font-semibold">
                    {safeFormatDate(goalScenario.timeframe_start)} - {safeFormatDate(goalScenario.timeframe_end)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Aggregation</p>
                  <p className="font-semibold capitalize">{goalScenario.aggregation}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Baseline</p>
                  <p className="font-semibold capitalize">{goalScenario.baseline_source}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Widgets</p>
                  <p className="font-semibold">{goalScenario.widgets?.length || 0} configured</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Other Scenarios */}
        {otherScenarios.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4">Other Scenarios</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherScenarios.map(scenario => (
                <Card key={scenario.id} className="border-none shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-lg">{scenario.name}</CardTitle>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handlePreview(scenario.id)}
                          title="Preview Dashboard"
                        >
                          <BarChart3 className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => navigate(createPageUrl("ScenarioBuilder") + `?id=${scenario.id}`)}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => duplicateScenarioMutation.mutate(scenario.id)}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-600 hover:text-red-700"
                          onClick={() => {
                            if (confirm('Delete this scenario?')) {
                              deleteScenarioMutation.mutate(scenario.id);
                            }
                          }}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription className="text-sm">{scenario.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Period:</span>
                        <span className="font-medium">
                          {safeFormatDate(scenario.timeframe_start, "MMM yy")} - {safeFormatDate(scenario.timeframe_end, "MMM yy")}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Widgets:</span>
                        <span className="font-medium">{scenario.widgets?.length || 0}</span>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full mt-2"
                        onClick={() => setGoalMutation.mutate(scenario.id)}
                      >
                        <Target className="w-3 h-3 mr-2" />
                        Set as Ranch Goal
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {scenarios.length === 0 && (
          <Card className="border-none shadow-lg">
            <CardContent className="py-12 text-center">
              <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No Scenarios Yet</h3>
              <p className="text-gray-600 mb-6">
                Create your first planning scenario to model different ranch strategies
              </p>
              <Button 
                onClick={() => createScenarioMutation.mutate()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create First Scenario
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}