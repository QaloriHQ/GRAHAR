import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, CheckSquare, Calendar, User, Edit, Trash2, Beef, MapPin, CheckCircle2, Circle, Clock, AlertCircle, Filter, MoreVertical, Search } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, isPast } from "date-fns";
import StatsCard from "../components/dashboard/StatsCard";
import { createPageUrl } from "@/utils";
import { notifyUser, notifyRanchRoles } from "../components/notifications/NotificationHelper";
import { trackTaskCreate, trackTaskComplete } from "@/components/utils";

export default function Tasks() {
  const [showAddTaskDialog, setShowAddTaskDialog] = useState(false);
  const [showAddListDialog, setShowAddListDialog] = useState(false);
  const [showTaskDetailsDialog, setShowTaskDetailsDialog] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [editingTask, setEditingTask] = useState(null);
  const [filterList, setFilterList] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me(),
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks', user?.active_ranch_id],
    queryFn: () => base44.entities.Task.filter({ ranch_id: user.active_ranch_id }, '-created_date'),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: lists = [] } = useQuery({
    queryKey: ['lists', user?.active_ranch_id],
    queryFn: () => base44.entities.List.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: animals = [] } = useQuery({
    queryKey: ['animals', user?.active_ranch_id],
    queryFn: () => base44.entities.Animal.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: pastures = [] } = useQuery({
    queryKey: ['pastures', user?.active_ranch_id],
    queryFn: () => base44.entities.Pasture.filter({ ranch_id: user.active_ranch_id }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const { data: ranchMembers = [] } = useQuery({
    queryKey: ['ranchMembers', user?.active_ranch_id],
    queryFn: () => base44.entities.RanchMember.filter({ ranch_id: user.active_ranch_id, status: 'Active' }),
    initialData: [],
    enabled: !!user?.active_ranch_id,
  });

  const [newTask, setNewTask] = useState({
    list_id: "",
    list_name: "",
    title: "",
    description: "",
    assigned_to: "",
    assigned_to_name: "",
    related_animal_id: "",
    related_animal_name: "",
    related_pasture_id: "",
    related_pasture_name: "",
    due_date: "",
    priority: "Medium",
    status: "Pending",
    notes: ""
  });

  const [newList, setNewList] = useState({
    name: "",
    description: "",
    list_type: "To-Do",
    color: "#10b981"
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data) => {
      const task = await base44.entities.Task.create({ ...data, ranch_id: user.active_ranch_id });
      
      // Send notifications
      if (data.assigned_to) {
        // Notify assigned user
        await notifyUser({
          scope: 'ranch',
          ranch_id: user.active_ranch_id,
          user_email: data.assigned_to,
          title: `New Task Assigned: ${data.title}`,
          message: `You have been assigned a new task "${data.title}" in list "${data.list_name}". Due: ${data.due_date ? format(new Date(data.due_date), 'MMM d, yyyy') : 'No due date'}`,
          type: 'Task',
          related_record_id: task.id,
          related_record_type: 'Task',
          related_record_name: data.title,
          action_url: createPageUrl('Tasks'),
          priority: data.priority === 'Urgent' ? 'Urgent' : 'Medium',
          icon: 'CheckSquare',
          severity: 'info',
          sendEmail: true,
          emailSubject: `New Task Assigned: ${data.title}`,
          emailBody: `Hi,\n\nYou have been assigned a new task:\n\nTask: ${data.title}\nList: ${data.list_name}\nPriority: ${data.priority}\nDue Date: ${data.due_date ? format(new Date(data.due_date), 'MMM d, yyyy') : 'No due date'}\n\nDescription:\n${data.description || 'No description provided'}\n\nView your tasks in HintFarms.`
        });
      }

      // Notify managers about urgent tasks
      if (data.priority === 'Urgent') {
        await notifyRanchRoles({
          ranch_id: user.active_ranch_id,
          roles: ['Owner', 'Manager'],
          title: `Urgent Task Created: ${data.title}`,
          message: `An urgent task "${data.title}" has been created${data.assigned_to ? ` and assigned to ${data.assigned_to_name}` : ''}.`,
          type: 'Task',
          related_record_id: task.id,
          related_record_type: 'Task',
          related_record_name: data.title,
          action_url: createPageUrl('Tasks'),
          priority: 'Urgent',
          icon: 'CheckSquare',
          severity: 'warning',
          sendEmail: true
        });
      }

      trackTaskCreate(user.id, user.active_ranch_id, data.priority, data.list_name);
      
      return task;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowAddTaskDialog(false);
      resetTaskForm();
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data, oldTask }) => {
      const updatedTask = await base44.entities.Task.update(id, data);
      
      // Check if assignment changed
      if (data.assigned_to && data.assigned_to !== oldTask.assigned_to) {
        await notifyUser({
          scope: 'ranch',
          ranch_id: user.active_ranch_id,
          user_email: data.assigned_to,
          title: `Task Assigned: ${data.title}`,
          message: `You have been assigned to task "${data.title}". Due: ${data.due_date ? format(new Date(data.due_date), 'MMM d, yyyy') : 'No due date'}`,
          type: 'Task',
          related_record_id: id,
          related_record_type: 'Task',
          related_record_name: data.title,
          action_url: createPageUrl('Tasks'),
          priority: data.priority === 'Urgent' ? 'Urgent' : 'Medium',
          icon: 'CheckSquare',
          severity: 'info',
          sendEmail: true
        });
      }

      // Notify on status change to completed
      if (data.status === 'Completed' && oldTask.status !== 'Completed') {
        await notifyRanchRoles({
          ranch_id: user.active_ranch_id,
          roles: ['Owner', 'Manager'],
          title: `Task Completed: ${data.title}`,
          message: `Task "${data.title}" has been marked as completed by ${user.full_name}.`,
          type: 'Task',
          related_record_id: id,
          related_record_type: 'Task',
          related_record_name: data.title,
          action_url: createPageUrl('Tasks'),
          priority: 'Low',
          icon: 'CheckSquare',
          severity: 'success',
          sendEmail: false
        });
        trackTaskComplete(user.id, user.active_ranch_id, data.priority, data.list_name);
      }
      
      return updatedTask;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowAddTaskDialog(false);
      setShowTaskDetailsDialog(false);
      setEditingTask(null);
      resetTaskForm();
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (id) => base44.entities.Task.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowTaskDetailsDialog(false);
      setSelectedTask(null);
    },
  });

  const createListMutation = useMutation({
    mutationFn: (data) => base44.entities.List.create({ ...data, ranch_id: user.active_ranch_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lists'] });
      setShowAddListDialog(false);
      setNewList({
        name: "",
        description: "",
        list_type: "To-Do",
        color: "#10b981"
      });
    },
  });

  const resetTaskForm = () => {
    setNewTask({
      list_id: "",
      list_name: "",
      title: "",
      description: "",
      assigned_to: "",
      assigned_to_name: "",
      related_animal_id: "",
      related_animal_name: "",
      related_pasture_id: "",
      related_pasture_name: "",
      due_date: "",
      priority: "Medium",
      status: "Pending",
      notes: ""
    });
  };

  const handleEdit = (task) => {
    setEditingTask(task);
    setNewTask({
      ...task,
      due_date: task.due_date ? new Date(task.due_date).toISOString().split('T')[0] : ""
    });
    setShowAddTaskDialog(true);
  };

  const handleSave = () => {
    if (editingTask) {
      updateTaskMutation.mutate({ 
        id: editingTask.id, 
        data: newTask,
        oldTask: editingTask 
      });
    } else {
      createTaskMutation.mutate(newTask);
    }
  };

  const handleViewDetails = (task) => {
    setSelectedTask(task);
    setShowTaskDetailsDialog(true);
  };

  const filteredTasks = tasks.filter(task => {
    const matchesList = filterList === "all" || task.list_id === filterList;
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    const matchesPriority = filterPriority === "all" || task.priority === filterPriority;
    return matchesList && matchesStatus && matchesPriority;
  });

  const pendingTasks = tasks.filter(t => t.status === "Pending" || t.status === "In Progress").length;
  const completedTasks = tasks.filter(t => t.status === "Completed").length;
  const overdueTasks = tasks.filter(t => t.due_date && isPast(new Date(t.due_date)) && t.status !== "Completed").length;
  const urgentTasks = tasks.filter(t => t.priority === "Urgent" && t.status !== "Completed").length;

  const priorityColors = {
    "Low": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Medium": "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300",
    "High": "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-900/30 dark:text-orange-300",
    "Urgent": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  const statusColors = {
    "Pending": "bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-300",
    "In Progress": "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300",
    "Completed": "bg-green-100 text-green-800 border-green-200 dark:bg-green-900/30 dark:text-green-300",
    "Cancelled": "bg-red-100 text-red-800 border-red-200 dark:bg-red-900/30 dark:text-red-300"
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-gray-50 to-orange-50/30 dark:from-gray-900 dark:to-orange-950/30 min-h-screen">
      <div className="max-w-7xl mx-auto overflow-x-hidden">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-gray-100 mb-1">Tasks & Lists</h1>
            <p className="text-gray-600 dark:text-gray-400">Organize your ranch operations</p>
          </div>
          <div className="flex gap-3">
            <Dialog open={showAddListDialog} onOpenChange={setShowAddListDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" className="shadow-lg dark:border-gray-700 dark:text-gray-300">
                  <Plus className="w-4 h-4 mr-2" />
                  Add List
                </Button>
              </DialogTrigger>
              <DialogContent className="dark:bg-gray-950 dark:border-gray-800">
                <DialogHeader>
                  <DialogTitle className="dark:text-gray-100">Create New List</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">List Name</Label>
                    <Input
                      value={newList.name}
                      onChange={(e) => setNewList({...newList, name: e.target.value})}
                      placeholder="e.g., Weekly Maintenance"
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Description</Label>
                    <Textarea
                      value={newList.description}
                      onChange={(e) => setNewList({...newList, description: e.target.value})}
                      placeholder="Optional description..."
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">List Type</Label>
                    <Select value={newList.list_type} onValueChange={(value) => setNewList({...newList, list_type: value})}>
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="To-Do">To-Do</SelectItem>
                        <SelectItem value="Supply List">Supply List</SelectItem>
                        <SelectItem value="Maintenance">Maintenance</SelectItem>
                        <SelectItem value="Veterinary">Veterinary</SelectItem>
                        <SelectItem value="Feeding Schedule">Feeding Schedule</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={() => createListMutation.mutate(newList)} className="w-full bg-[#F5A623] hover:bg-[#E09612]">
                  Create List
                </Button>
              </DialogContent>
            </Dialog>

            <Dialog open={showAddTaskDialog} onOpenChange={(open) => {
              setShowAddTaskDialog(open);
              if (!open) {
                setEditingTask(null);
                resetTaskForm();
              }
            }}>
              <DialogTrigger asChild>
                <Button className="bg-[#F5A623] hover:bg-[#E09612] shadow-lg">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Task
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto dark:bg-gray-950 dark:border-gray-800">
                <DialogHeader>
                  <DialogTitle className="dark:text-gray-100">
                    {editingTask ? 'Edit Task' : 'Add New Task'}
                  </DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                  <div className="space-y-2 col-span-2">
                    <Label className="dark:text-gray-200">List *</Label>
                    <Select 
                      value={newTask.list_id} 
                      onValueChange={(value) => {
                        const list = lists.find(l => l.id === value);
                        setNewTask({...newTask, list_id: value, list_name: list?.name || ""});
                      }}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue placeholder="Select a list" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        {lists.map(list => (
                          <SelectItem key={list.id} value={list.id} className="dark:text-gray-100">
                            {list.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2 col-span-2">
                    <Label className="dark:text-gray-200">Task Title *</Label>
                    <Input
                      value={newTask.title}
                      onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                      placeholder="e.g., Check fence in north pasture"
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>

                  <div className="space-y-2 col-span-2">
                    <Label className="dark:text-gray-200">Description</Label>
                    <Textarea
                      value={newTask.description}
                      onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                      placeholder="Task details..."
                      rows={3}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Assign To</Label>
                    <Select 
                      value={newTask.assigned_to} 
                      onValueChange={(value) => {
                        const member = ranchMembers.find(m => m.user_email === value);
                        setNewTask({...newTask, assigned_to: value, assigned_to_name: member?.user_name || ""});
                      }}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue placeholder="Select team member" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        {ranchMembers.map(member => (
                          <SelectItem key={member.user_email} value={member.user_email} className="dark:text-gray-100">
                            {member.user_name} ({member.role})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Due Date</Label>
                    <Input
                      type="date"
                      value={newTask.due_date}
                      onChange={(e) => setNewTask({...newTask, due_date: e.target.value})}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Priority</Label>
                    <Select value={newTask.priority} onValueChange={(value) => setNewTask({...newTask, priority: value})}>
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Status</Label>
                    <Select value={newTask.status} onValueChange={(value) => setNewTask({...newTask, status: value})}>
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Related Animal (Optional)</Label>
                    <Select 
                      value={newTask.related_animal_id} 
                      onValueChange={(value) => {
                        const animal = animals.find(a => a.id === value);
                        setNewTask({...newTask, related_animal_id: value, related_animal_name: animal?.name || ""});
                      }}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue placeholder="Select animal" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value={null}>None</SelectItem>
                        {animals.map(animal => (
                          <SelectItem key={animal.id} value={animal.id} className="dark:text-gray-100">
                            {animal.name} ({animal.tag_number})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="dark:text-gray-200">Related Pasture (Optional)</Label>
                    <Select 
                      value={newTask.related_pasture_id} 
                      onValueChange={(value) => {
                        const pasture = pastures.find(p => p.id === value);
                        setNewTask({...newTask, related_pasture_id: value, related_pasture_name: pasture?.name || ""});
                      }}
                    >
                      <SelectTrigger className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                        <SelectValue placeholder="Select pasture" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                        <SelectItem value={null}>None</SelectItem>
                        {pastures.map(pasture => (
                          <SelectItem key={pasture.id} value={pasture.id} className="dark:text-gray-100">
                            {pasture.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2 col-span-2">
                    <Label className="dark:text-gray-200">Notes</Label>
                    <Textarea
                      value={newTask.notes}
                      onChange={(e) => setNewTask({...newTask, notes: e.target.value})}
                      placeholder="Additional notes..."
                      rows={2}
                      className="dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100"
                    />
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowAddTaskDialog(false);
                      setEditingTask(null);
                      resetTaskForm();
                    }}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleSave}
                    className="flex-1 bg-[#F5A623] hover:bg-[#E09612]"
                    disabled={!newTask.list_id || !newTask.title}
                  >
                    {editingTask ? 'Update Task' : 'Create Task'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Active Tasks"
            value={pendingTasks}
            icon={CheckSquare}
            bgColor="bg-blue-500"
            textColor="text-blue-600"
          />
          <StatsCard
            title="Completed"
            value={completedTasks}
            icon={CheckSquare}
            bgColor="bg-green-500"
            textColor="text-green-600"
          />
          <StatsCard
            title="Overdue"
            value={overdueTasks}
            icon={Calendar}
            bgColor="bg-red-500"
            textColor="text-red-600"
          />
          <StatsCard
            title="Urgent"
            value={urgentTasks}
            icon={CheckSquare}
            bgColor="bg-orange-500"
            textColor="text-orange-600"
          />
        </div>

        {/* Filters */}
        <Card className="mb-6 border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <Select value={filterList} onValueChange={setFilterList}>
                <SelectTrigger className="w-full md:w-48 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="All Lists" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Lists</SelectItem>
                  {lists.map(list => (
                    <SelectItem key={list.id} value={list.id} className="dark:text-gray-100">
                      {list.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterPriority} onValueChange={setFilterPriority}>
                <SelectTrigger className="w-full md:w-48 dark:bg-gray-900 dark:border-gray-700 dark:text-gray-100">
                  <SelectValue placeholder="All Priority" />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-900 dark:border-gray-700">
                  <SelectItem value="all">All Priority</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tasks Table */}
        <Card className="border-none shadow-lg dark:bg-gray-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="dark:text-gray-100">Tasks</CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="dark:border-gray-700">
                  <TableHead className="dark:text-gray-400">Task</TableHead>
                  <TableHead className="dark:text-gray-400">List</TableHead>
                  <TableHead className="dark:text-gray-400">Assigned To</TableHead>
                  <TableHead className="dark:text-gray-400">Due Date</TableHead>
                  <TableHead className="dark:text-gray-400">Priority</TableHead>
                  <TableHead className="dark:text-gray-400">Status</TableHead>
                  <TableHead className="dark:text-gray-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.map(task => {
                  const isOverdue = task.due_date && isPast(new Date(task.due_date)) && task.status !== "Completed";
                  return (
                    <TableRow 
                      key={task.id}
                      className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors dark:border-gray-700"
                      onClick={() => handleViewDetails(task)}
                    >
                      <TableCell className="dark:text-gray-300">
                        <div>
                          <p className="font-semibold">{task.title}</p>
                          {task.related_animal_name && (
                            <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center">
                              <Beef className="w-3 h-3 mr-1" /> {task.related_animal_name}
                            </p>
                          )}
                           {task.related_pasture_name && (
                            <p className="text-xs text-green-600 dark:text-green-400 flex items-center">
                              <MapPin className="w-3 h-3 mr-1" /> {task.related_pasture_name}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="dark:text-gray-300">{task.list_name}</TableCell>
                      <TableCell className="dark:text-gray-300">{task.assigned_to_name || "-"}</TableCell>
                      <TableCell className={isOverdue ? "text-red-600 dark:text-red-400 font-semibold" : "dark:text-gray-300"}>
                        {task.due_date ? (
                          <>
                            {format(new Date(task.due_date), "MMM d, yyyy")}
                            {isOverdue && " (Overdue)"}
                          </>
                        ) : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge className={`${priorityColors[task.priority]} border text-xs`}>
                          {task.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${statusColors[task.status]} border text-xs`}>
                          {task.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEdit(task)}
                            className="dark:hover:bg-gray-600"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              if (confirm('Are you sure you want to delete this task?')) {
                                deleteTaskMutation.mutate(task.id);
                              }
                            }}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-900/20"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>

            {filteredTasks.length === 0 && (
              <div className="text-center py-12">
                <CheckSquare className="w-16 h-16 text-gray-300 dark:text-gray-700 mx-auto mb-4" />
                <p className="text-gray-500 dark:text-gray-400">No tasks found</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Task Details Dialog */}
        <Dialog open={showTaskDetailsDialog} onOpenChange={setShowTaskDetailsDialog}>
          <DialogContent className="max-w-2xl dark:bg-gray-950 dark:border-gray-800 z-[9999]">
            <DialogHeader>
              <DialogTitle className="dark:text-gray-100">Task Details</DialogTitle>
            </DialogHeader>
            {selectedTask && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl font-bold mb-2 dark:text-gray-100">{selectedTask.title}</h3>
                  <div className="flex gap-2 flex-wrap mb-4">
                    <Badge className={`${priorityColors[selectedTask.priority]} border`}>
                      {selectedTask.priority}
                    </Badge>
                    <Badge className={`${statusColors[selectedTask.status]} border`}>
                      {selectedTask.status}
                    </Badge>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">List</p>
                    <p className="font-semibold dark:text-gray-100">{selectedTask.list_name}</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Assigned To</p>
                    <p className="font-semibold dark:text-gray-100">{selectedTask.assigned_to_name || "Unassigned"}</p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Due Date</p>
                    <p className="font-semibold dark:text-gray-100">
                      {selectedTask.due_date ? format(new Date(selectedTask.due_date), "MMMM d, yyyy") : "No due date"}
                    </p>
                  </div>
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Status</p>
                    <Badge className={`${statusColors[selectedTask.status]} border`}>
                      {selectedTask.status}
                    </Badge>
                  </div>
                </div>

                {selectedTask.description && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Description</p>
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{selectedTask.description}</p>
                  </div>
                )}

                {selectedTask.related_animal_name && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Related Animal</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedTask.related_animal_name}</p>
                  </div>
                )}

                {selectedTask.related_pasture_name && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Related Pasture</p>
                    <p className="text-gray-700 dark:text-gray-300">{selectedTask.related_pasture_name}</p>
                  </div>
                )}

                {selectedTask.notes && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
                    <p className="text-sm font-semibold mb-2 dark:text-gray-200">Notes</p>
                    <p className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{selectedTask.notes}</p>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowTaskDetailsDialog(false);
                      handleEdit(selectedTask);
                    }}
                    className="flex-1"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                  <Button 
                    variant="destructive" 
                    onClick={() => {
                      if (confirm('Are you sure you want to delete this task?')) {
                        deleteTaskMutation.mutate(selectedTask.id);
                      }
                    }}
                    className="flex-1"
                  >
                    Delete Task
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}