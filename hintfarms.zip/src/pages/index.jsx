import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Animals from "./Animals";

import Financials from "./Financials";

import HealthRecords from "./HealthRecords";

import Breeding from "./Breeding";

import Pastures from "./Pastures";

import Reports from "./Reports";

import Tasks from "./Tasks";

import Notifications from "./Notifications";

import Onboarding from "./Onboarding";

import RanchSettings from "./RanchSettings";

import TeamManagement from "./TeamManagement";

import AnimalProfile from "./AnimalProfile";

import Expenses from "./Expenses";

import Revenue from "./Revenue";

import Scenarios from "./Scenarios";

import ScenarioBuilder from "./ScenarioBuilder";

import ScenarioPreview from "./ScenarioPreview";

import BankImports from "./BankImports";

import BillingReturn from "./BillingReturn";

import AcceptInvite from "./AcceptInvite";

import AccountSettings from "./AccountSettings";

import PastureProfile from "./PastureProfile";

import AdminPortal from "./AdminPortal";

import Inventory from "./Inventory";

import FieldOps from "./FieldOps";

import RanchInsights from "./RanchInsights";

import Market from "./Market";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Animals: Animals,
    
    Financials: Financials,
    
    HealthRecords: HealthRecords,
    
    Breeding: Breeding,
    
    Pastures: Pastures,
    
    Reports: Reports,
    
    Tasks: Tasks,
    
    Notifications: Notifications,
    
    Onboarding: Onboarding,
    
    RanchSettings: RanchSettings,
    
    TeamManagement: TeamManagement,
    
    AnimalProfile: AnimalProfile,
    
    Expenses: Expenses,
    
    Revenue: Revenue,
    
    Scenarios: Scenarios,
    
    ScenarioBuilder: ScenarioBuilder,
    
    ScenarioPreview: ScenarioPreview,
    
    BankImports: BankImports,
    
    BillingReturn: BillingReturn,
    
    AcceptInvite: AcceptInvite,
    
    AccountSettings: AccountSettings,
    
    PastureProfile: PastureProfile,
    
    AdminPortal: AdminPortal,
    
    Inventory: Inventory,
    
    FieldOps: FieldOps,
    
    RanchInsights: RanchInsights,
    
    Market: Market,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Animals" element={<Animals />} />
                
                <Route path="/Financials" element={<Financials />} />
                
                <Route path="/HealthRecords" element={<HealthRecords />} />
                
                <Route path="/Breeding" element={<Breeding />} />
                
                <Route path="/Pastures" element={<Pastures />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/RanchSettings" element={<RanchSettings />} />
                
                <Route path="/TeamManagement" element={<TeamManagement />} />
                
                <Route path="/AnimalProfile" element={<AnimalProfile />} />
                
                <Route path="/Expenses" element={<Expenses />} />
                
                <Route path="/Revenue" element={<Revenue />} />
                
                <Route path="/Scenarios" element={<Scenarios />} />
                
                <Route path="/ScenarioBuilder" element={<ScenarioBuilder />} />
                
                <Route path="/ScenarioPreview" element={<ScenarioPreview />} />
                
                <Route path="/BankImports" element={<BankImports />} />
                
                <Route path="/BillingReturn" element={<BillingReturn />} />
                
                <Route path="/AcceptInvite" element={<AcceptInvite />} />
                
                <Route path="/AccountSettings" element={<AccountSettings />} />
                
                <Route path="/PastureProfile" element={<PastureProfile />} />
                
                <Route path="/AdminPortal" element={<AdminPortal />} />
                
                <Route path="/Inventory" element={<Inventory />} />
                
                <Route path="/FieldOps" element={<FieldOps />} />
                
                <Route path="/RanchInsights" element={<RanchInsights />} />
                
                <Route path="/Market" element={<Market />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}